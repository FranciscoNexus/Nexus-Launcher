import sys, wave
import numpy as np

SR = 22050
OUT = sys.argv[1]
rng = np.random.default_rng(7)

def tt(d): return np.arange(int(SR * d)) / SR
def sine(f, t): return np.sin(2 * np.pi * f * t)
def square(f, t, duty=0.5): return np.where((f * t) % 1.0 < duty, 1.0, -1.0)
def phase_sine(freqs, t):
    # freqs: array of instantaneous frequency (glide) -> integrate phase
    return np.sin(2 * np.pi * np.cumsum(freqs) / SR)
def glide(f0, f1, t, expo=True):
    x = t / t[-1] if len(t) > 1 else t
    return f0 * (f1 / f0) ** x if expo else f0 + (f1 - f0) * x
def decay(t, k): return np.exp(-k * t)
def fade(x, a=0.002, r=0.008):
    n = len(x); na = max(1, int(SR * a)); nr = max(1, int(SR * r))
    e = np.ones(n); e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr))
    return x * e
def lowpass(x, fc):
    a = np.exp(-2 * np.pi * fc / SR); y = np.zeros_like(x); p = 0.0
    for i, v in enumerate(x):
        p = (1 - a) * v + a * p; y[i] = p
    return y
def seq(parts, gap=0.0):
    out = []
    for p in parts:
        out.append(p); 
        if gap: out.append(np.zeros(int(SR * gap)))
    return np.concatenate(out)
def mix(*xs):
    n = max(len(x) for x in xs); y = np.zeros(n)
    for x in xs: y[:len(x)] += x
    return y
def delay(x, d, g):
    n = int(SR * d); y = np.concatenate([x, np.zeros(n)]); y[n:n + len(x)] += g * x; return y
def dcblock(x, r=0.995):
    y = np.zeros_like(x); px = 0.0; py = 0.0
    for i, v in enumerate(x):
        py = v - px + r * py; px = v; y[i] = py
    return y
def norm(x, rms=0.15, peak=0.8):
    # Mesma sensação de volume entre os estilos (quadrada soa bem mais alto que senoide): normaliza pelo RMS.
    x = dcblock(x)
    r = np.sqrt(np.mean(x ** 2)); m = np.max(np.abs(x))
    if r == 0 or m == 0: return x
    g = min(rms / r, peak / m)
    return x * g
def save(name, x):
    x = fade(norm(x))
    pcm = (np.clip(x, -1, 1) * 32767).astype('<i2')
    with wave.open(f"{OUT}/{name}.wav", 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())


# ================= 4.5.1: 13 sons por estilo =================
# Regra de timbre: ações "positivas" (aceitar, avançar, ligar) terminam mais AGUDAS;
# ações "negativas" (voltar, recusar, desligar) terminam mais GRAVES. Esquerda/direita e cima/baixo seguem o mesmo princípio.

def note_sq(f, d, duty=0.5, k=14): t = tt(d); return square(f, t, duty) * decay(t, k)
def sq_glide(f0, f1, d, duty=0.5, k=14):
    t = tt(d); f = glide(f0, f1, t); return np.where((np.cumsum(f) / SR) % 1.0 < duty, 1.0, -1.0) * decay(t, k)
def lp(x): return lowpass(x, 7000)

def retro():
    S = lambda n, x: save("snd_retro_" + n, lp(x))
    S("nav_up", note_sq(1120, 0.04, 0.125, 18))
    S("nav_down", note_sq(880, 0.04, 0.125, 18))
    S("nav_right", seq([note_sq(1000, 0.03, 0.125, 14), note_sq(1280, 0.04, 0.125, 18)]))
    S("nav_left", seq([note_sq(1000, 0.03, 0.125, 14), note_sq(780, 0.04, 0.125, 18)]))
    S("select", seq([note_sq(880, 0.05), note_sq(1320, 0.09, 0.5, 10)]))
    S("accept", seq([note_sq(880, 0.045, 0.25, 8), note_sq(1175, 0.045, 0.25, 8), note_sq(1568, 0.12, 0.25, 9)]))
    S("back", seq([note_sq(784, 0.05), note_sq(523, 0.09, 0.5, 10)]))
    S("deny", seq([note_sq(311, 0.08, 0.5, 8), note_sq(233, 0.14, 0.5, 8)]))
    S("on", seq([note_sq(660, 0.04, 0.25, 8), note_sq(990, 0.04, 0.25, 8), note_sq(1320, 0.08, 0.25, 10)]))
    S("off", seq([note_sq(990, 0.04, 0.25, 8), note_sq(660, 0.04, 0.25, 8), note_sq(440, 0.08, 0.25, 10)]))
    arp = [note_sq(f, 0.06, 0.25, 6) for f in (523, 659, 784, 1047)]
    t = tt(0.22); vib = 1 + 0.01 * np.sin(2 * np.pi * 9 * t)
    last = np.where((np.cumsum(1047 * vib) / SR) % 1.0 < 0.5, 1.0, -1.0) * decay(t, 7)
    S("launch", seq(arp + [last]))
    S("tab_next", seq([note_sq(1200, 0.03, 0.25, 12), note_sq(1600, 0.045, 0.25, 12)]))
    S("tab_prev", seq([note_sq(1600, 0.03, 0.25, 12), note_sq(1200, 0.045, 0.25, 12)]))

def sg(f0, f1, d, k, expo=True):
    t = tt(d); f = glide(f0, f1, t, expo); return phase_sine(f, t) * decay(t, k)
def ping(f, d, k, h2=0.3):
    t = tt(d); return (sine(f, t) + h2 * sine(f * 2, t)) * decay(t, k)

def soft():
    S = lambda n, x: save("snd_soft_" + n, x)
    S("nav_up", sg(640, 700, 0.07, 42) * 0.8)
    S("nav_down", sg(560, 510, 0.07, 42) * 0.8)
    S("nav_right", sg(600, 720, 0.08, 38) * 0.8)
    S("nav_left", sg(600, 490, 0.08, 38) * 0.8)
    t = tt(0.16); S("select", (sine(700, t) + 0.6 * sine(1050, t) + 0.15 * sine(1400, t)) * decay(t, 22))
    S("accept", delay(seq([ping(660, 0.09, 22), ping(988, 0.16, 16)]), 0.08, 0.25))
    S("back", sg(620, 400, 0.13, 20))
    S("deny", lowpass(sg(330, 230, 0.2, 14) + 0.3 * sg(165, 115, 0.2, 14), 1400))
    S("on", delay(seq([ping(523, 0.08, 24), ping(784, 0.14, 18)]), 0.07, 0.2))
    S("off", delay(seq([ping(784, 0.08, 24), ping(523, 0.14, 18)]), 0.07, 0.2))
    t = tt(0.55)
    chord = (sine(523, t) + sine(659, t) + sine(784, t)) / 3
    sw = np.minimum(1, t / 0.05) * decay(np.maximum(t - 0.05, 0), 6.5)
    spark = sine(1568, t) * decay(t, 14) * 0.25
    S("launch", delay(chord * sw + spark, 0.09, 0.3))
    S("tab_next", sg(520, 680, 0.08, 32, False))
    S("tab_prev", sg(680, 520, 0.08, 32, False))

def fm(fc, fm_, idx, t): return np.sin(2 * np.pi * fc * t + idx * np.sin(2 * np.pi * fm_ * t))
def fmg(f0, f1, d, k, idx=1.6, ratio=2.0):
    t = tt(d); f = glide(f0, f1, t); ph = np.cumsum(f) / SR
    return np.sin(2 * np.pi * ph + idx * np.sin(2 * np.pi * ph * ratio)) * decay(t, k)

def future():
    S = lambda n, x: save("snd_future_" + n, x)
    S("nav_up", fmg(1500, 1750, 0.045, 40, 2.0))
    S("nav_down", fmg(1500, 1250, 0.045, 40, 2.0))
    S("nav_right", fmg(1350, 2000, 0.06, 34, 1.8))
    S("nav_left", fmg(1350, 900, 0.06, 34, 1.8))
    t = tt(0.12)
    a = fm(900, 1800, 1.5, t) * decay(t, 24); b = fm(1350, 2700, 1.2, t) * decay(t, 26) * 0.8
    S("select", delay(mix(a, b), 0.06, 0.4))
    S("accept", delay(seq([fmg(1000, 1500, 0.06, 20), fmg(1800, 2600, 0.14, 14)]), 0.07, 0.35))
    t = tt(0.11); f = glide(1100, 400, t); y = phase_sine(f, t) + 0.4 * np.sin(2 * np.pi * np.cumsum(f * 2) / SR)
    S("back", y * decay(t, 18))
    t = tt(0.22); f = glide(320, 110, t); ph = np.cumsum(f) / SR
    saw = 2 * ((ph) % 1.0) - 1
    S("deny", lowpass(0.6 * saw + 0.5 * np.sin(2 * np.pi * ph * 1.01), 1800) * decay(t, 9))
    S("on", delay(mix(fmg(500, 1800, 0.14, 12, 1.4), seq([np.zeros(int(SR * 0.08)), fmg(1800, 2400, 0.12, 16)])), 0.06, 0.3))
    S("off", delay(mix(fmg(1800, 500, 0.16, 11, 1.4), seq([np.zeros(int(SR * 0.09)), fmg(450, 300, 0.12, 16)])), 0.06, 0.3))
    t = tt(0.62)
    f = glide(250, 2200, tt(0.38))
    sweep = phase_sine(f, tt(0.38)) * np.minimum(1, tt(0.38) / 0.03) * (0.3 + 0.7 * tt(0.38) / 0.38)
    sweep = np.concatenate([sweep, np.zeros(len(t) - len(sweep))])
    noise = lowpass(rng.standard_normal(len(t)), 3500)
    noise = noise * (np.minimum(1, t / 0.1) * decay(np.maximum(t - 0.3, 0), 18)) * 0.35
    ts = np.maximum(t - 0.36, 0)
    shim = (fm(1200, 2400, 1.4, t) + 0.8 * fm(1800, 3600, 1.1, t)) * (t > 0.36) * decay(ts, 11) * 0.6
    S("launch", mix(sweep * 0.6, noise, shim))
    S("tab_next", seq([fmg(1300, 1500, 0.03, 30, 1.5), fmg(1700, 2100, 0.045, 30, 1.5)], gap=0.01))
    S("tab_prev", seq([fmg(1700, 1500, 0.03, 30, 1.5), fmg(1300, 1000, 0.045, 30, 1.5)], gap=0.01))

retro(); soft(); future()
print("ok")

# ================= Som da animação de abertura (3,8 s), sincronizado com NexusIntro.kt =================
# Linha do tempo (s): 0-1,14 capas em órbita (pings + whoosh) | 1,14 fusão (baque + brilho) |
# 1,75/1,95/2,15 braços telescópicos (cliques) | 2,35-2,65 botões (4 notas subindo) | 2,72-3,04 subida |
# 3,04 aparelho vira logo (impacto) | 3,1-3,8 acorde final.
TOT = 3.8
def place(buf, x, at):
    i = int(SR * at); n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n]
def hp(x, fc): return x - lowpass(x, fc)
def noise_env(d, k, rise=0.0):
    t = tt(d); n = rng.standard_normal(len(t)); env = np.minimum(1, t / max(rise, 1e-3)) if rise else 1
    return n, t, env

def intro(style):
    buf = np.zeros(int(SR * TOT))
    notes_up = [523, 659, 784, 988, 1175, 1568]
    if style == "retro":
        ping = lambda f, d=0.06: lp(note_sq(f, d, 0.25, 12)) * 0.7
        def whoosh(d):
            n, t, _ = noise_env(d, 0); q = np.sign(lowpass(n, 2500)) * (t / d) ** 1.5; return lowpass(q, 3000) * 0.25
        thump = lambda: lp(sq_glide(120, 45, 0.22, 0.5, 9)) * 1.0
        click = lambda: lowpass(np.sign(rng.standard_normal(int(SR * 0.012))) * np.linspace(1, 0, int(SR * 0.012)), 6000) * 0.8
        pop = lambda f: lp(note_sq(f, 0.07, 0.5, 14))
        riser = lambda: lp(sq_glide(220, 1760, 0.32, 0.25, 0.5)) * 0.5
        shimmer = lambda: lp(sq_glide(900, 2200, 0.45, 0.125, 5)) * 0.35
        def chime():
            a = seq([note_sq(f, 0.07, 0.25, 6) for f in (523, 659, 784, 1047)])
            t = tt(0.62); c = (square(1047, t, 0.25) + 0.7 * square(1319, t, 0.25) + 0.7 * square(1568, t, 0.25)) * decay(t, 4.5)
            return lp(seq([a, c * 0.8]))
    elif style == "soft":
        ping = lambda f, d=0.12: ping_s(f, d, 18, 0.25) * 0.7
        def whoosh(d):
            n, t, _ = noise_env(d, 0); return lowpass(n, 1600) * (t / d) ** 2 * 0.16
        thump = lambda: sg(110, 50, 0.3, 8) * 1.0
        click = lambda: (lowpass(rng.standard_normal(int(SR * 0.02)), 3000) * decay(tt(0.02), 160) * 1.0 + sine(1700, tt(0.02)) * decay(tt(0.02), 140) * 0.4)
        pop = lambda f: ping_s(f, 0.12, 20, 0.3)
        riser = lambda: sg(300, 1700, 0.32, -4) * np.linspace(0.2, 1, int(SR * 0.32)) * 0.7
        shimmer = lambda: (sine(1568, tt(0.5)) * decay(tt(0.5), 7) * 0.25 + sine(2093, tt(0.5)) * decay(tt(0.5), 9) * 0.15)
        def chime():
            t = tt(0.75)
            c = (sine(523, t) + sine(659, t) + sine(784, t) + 0.5 * sine(1046, t)) / 3.5
            sw = np.minimum(1, t / 0.03) * decay(t, 4.2)
            return delay(c * sw + sine(1568, t) * decay(t, 10) * 0.22, 0.11, 0.3)
    else:
        ping = lambda f, d=0.06: fm(f * 2, f * 4, 1.5, tt(d)) * decay(tt(d), 22) * 0.7
        def whoosh(d):
            n, t, _ = noise_env(d, 0); return hp(lowpass(n, 5000), 600) * (t / d) ** 2 * 0.25
        thump = lambda: fmg(95, 38, 0.3, 8, 0.8) * 1.0
        click = lambda: hp(rng.standard_normal(int(SR * 0.014)), 1500) * np.linspace(1, 0, int(SR * 0.014)) * 0.9 + fm(2600, 5200, 1.5, tt(0.014)) * decay(tt(0.014), 150) * 0.4
        pop = lambda f: fmg(f, f * 1.3, 0.08, 22, 1.4)
        riser = lambda: fmg(220, 3000, 0.32, -2, 1.2) * np.linspace(0.2, 1, int(SR * 0.32)) * 0.6
        shimmer = lambda: (fm(1800, 3600, 1.3, tt(0.5)) + 0.7 * fm(2700, 5400, 1.0, tt(0.5))) * decay(tt(0.5), 7) * 0.3
        def chime():
            t = tt(0.75)
            c = (fm(523, 1046, 1.0, t) + fm(784, 1568, 0.9, t) + 0.7 * fm(1046, 2092, 0.8, t)) / 2.7 * decay(t, 4.2)
            sh = (fm(2093, 4186, 1.4, t) * decay(t, 9)) * 0.25
            return delay(c + sh, 0.1, 0.3)
    # fase 1: whoosh das capas e pings (cada capa que chega)
    place(buf, whoosh(1.1), 0.0)
    for i in range(6): place(buf, ping(notes_up[i]) * 0.55, 0.30 + i * 0.12)
    # fase 2: fusão
    place(buf, thump(), 1.14)
    place(buf, shimmer(), 1.20)
    # fase 3: braços telescópicos (cliques de cada seção nos dois lados)
    for k, at in enumerate((1.75, 1.95, 2.15)):
        place(buf, click() * 0.9, at); place(buf, click() * 0.7, at + 0.035)
        place(buf, ping(1500 + 250 * k, 0.04) * 0.3, at)
    place(buf, whoosh(0.5) * 0.5, 1.70)
    # botões: quatro notas subindo
    for k, f in enumerate((659, 784, 988, 1319)): place(buf, pop(f) * 0.8, 2.35 + 0.10 * k)
    # subida e impacto
    place(buf, riser(), 2.72)
    place(buf, thump() * 0.9, 3.04)
    place(buf, hp(rng.standard_normal(int(SR * 0.15)), 1200) * decay(tt(0.15), 22) * 0.35, 3.04)
    place(buf, chime(), 3.08)
    save("snd_" + style + "_intro", buf)

def ping_s(f, d, k, h2=0.3):
    t = tt(d); return (sine(f, t) + h2 * sine(f * 2, t)) * decay(t, k)

for _s in ("retro", "soft", "future"): intro(_s)
print("intro ok")

