"""Gera os recursos visuais (ícone adaptativo + peças da animação de abertura) a partir da imagem do ícone.
Versão 4.5.4: imagem nova 1024x1024 (controles já coloridos). A animação continua usando a geometria da
imagem antiga (1376x768): cada peça é reamostrada para o MESMO retângulo de antes, então NexusIntro.kt não muda.
Mapa novo -> antigo: x_old = 479 + (x_new - 298) * S ; y_old = 186 + (y_new - 284) * S, S = 0.987
Uso: python3 build_icon.py <imagem_1024.jpg> <pasta res/drawable-nodpi> """
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi

SRC, OUT = sys.argv[1], sys.argv[2]
img = np.asarray(Image.open(SRC).convert('RGB')).astype(np.float32)
H, W, _ = img.shape
SC = 0.987
def to_old(x, y): return 479 + (x - 298) * SC, 186 + (y - 284) * SC
def to_new(x, y): return 298 + (x - 479) / SC, 284 + (y - 186) / SC

# ---------- 1) fundo (gradiente horizontal) e máscara do conteúdo ----------
bgcol = np.median(img[5:60], axis=0)
bgcol = ndi.median_filter(bgcol, size=(15, 1))
bg = np.broadcast_to(bgcol[None], img.shape)
dist = np.linalg.norm(img - bg, axis=2)
alpha = np.clip((dist - 28) / 40.0, 0, 1)
mask = alpha > 0.5
lab, n = ndi.label(ndi.binary_closing(mask, iterations=3))
sizes = ndi.sum(mask, lab, range(1, n + 1))
keep = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 3000])
keep = ndi.binary_fill_holes(keep)
alpha = np.where(keep, alpha, 0.0)
alpha = np.where(ndi.binary_erosion(keep, iterations=2), 1.0, alpha)

# ---------- 2) RGBA do conteúdo (remove o fundo: c = (px - (1-a)*bg) / a) ----------
a = alpha[..., None]
fg = np.where(a > 0.02, (img - (1 - a) * bg) / np.maximum(a, 0.02), 0)
fg = np.clip(fg, 0, 255)
rgba = np.dstack([fg, alpha * 255]).astype(np.uint8)
full = Image.fromarray(rgba, 'RGBA')

# ---------- 3) círculo mínimo que envolve o conteúdo ----------
ys, xs = np.nonzero(alpha > 0.5)
pts = np.stack([xs, ys], 1).astype(np.float64)
from scipy.spatial import ConvexHull
hull = pts[ConvexHull(pts).vertices]
c = hull[0].copy()
for i in range(1, 4000):
    far = hull[np.argmax(((hull - c) ** 2).sum(1))]
    c = c + (far - c) / (i + 1)
cx0, cy0 = c
R0 = np.sqrt(((hull - c) ** 2).sum(1).max())
print('círculo do conteúdo (px): centro', round(cx0, 1), round(cy0, 1), 'raio', round(R0, 1))

# ---------- 4) foreground adaptativo: 108 dp -> 864 px; raio ocupado = 34 dp (zona segura = 33 dp) ----------
CAN, R_DP = 864, 34.0
k = (R_DP / 108.0 * CAN) / R0
big = full.resize((int(round(W * k)), int(round(H * k))), Image.LANCZOS)
ox, oy = int(round(CAN / 2 - cx0 * k)), int(round(CAN / 2 - cy0 * k))
canvas = Image.new('RGBA', (CAN, CAN), (0, 0, 0, 0)); canvas.paste(big, (ox, oy), big)
canvas.save(f'{OUT}/ic_nexus_logo.png')
print('foreground: k =', round(k, 4))

# ---------- 5) peças da animação (retângulos no espaço ANTIGO; saída em S× ) ----------
prem = np.dstack([fg * (alpha[..., None]), alpha * 255]).astype(np.float32)   # RGB pré-multiplicado + A
def piece_rgba(name, box_old, S=3):
    x0, y0, x1, y1 = box_old
    ow, oh = (x1 - x0) * S, (y1 - y0) * S
    u, v = np.meshgrid((np.arange(ow) + 0.5) / S + x0, (np.arange(oh) + 0.5) / S + y0)
    xn, yn = to_new(u, v)
    chans = [ndi.map_coordinates(prem[..., ch], [yn - 0.5, xn - 0.5], order=3, mode='constant') for ch in range(4)]
    al = np.clip(chans[3], 0, 255)
    rgb = np.stack([np.where(al > 1, np.clip(chans[ch] / np.maximum(al / 255.0, 1e-3), 0, 255), 0) for ch in range(3)], -1)
    out = np.dstack([rgb, al]).astype(np.uint8)
    Image.fromarray(out, 'RGBA').save(f'{OUT}/{name}.png')
piece_rgba('intro_ctrl_left', (378, 272, 483, 556))
piece_rgba('intro_ctrl_right', (898, 272, 1003, 556))
piece_rgba('intro_nexus_text', (572, 118, 812, 184))

# capas: caixas novas (px da imagem nova) -> retângulo interno antigo (b + 1 ... b - 1)
OLD_BOX = [(493, 199, 606, 319), (614, 199, 766, 316), (774, 198, 889, 320),
           (493, 328, 606, 458), (614, 328, 766, 458), (775, 328, 888, 458),
           (493, 466, 606, 597), (615, 467, 766, 600), (775, 467, 888, 600)]
COLS = [(312, 426), (435, 589), (598, 713)]
ROWS = [(296, 420), (428, 560), (569, 704)]
src = Image.open(SRC).convert('RGB')
S = 4
for i, b in enumerate(OLD_BOX, 1):
    cx, cy = (i - 1) % 3, (i - 1) // 3
    nx0, nx1 = COLS[cx]; ny0, ny1 = ROWS[cy]
    ow, oh = (b[2] - b[0] - 2) * S, (b[3] - b[1] - 2) * S
    c = src.resize((ow, oh), Image.LANCZOS, box=(nx0 + 1, ny0 + 1, nx1 - 1, ny1 - 1)).filter(ImageFilter.UnsharpMask(radius=2, percent=45, threshold=2))
    m = Image.new('L', c.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, c.size[0] - 1, c.size[1] - 1), radius=9 * S, fill=255)
    c = c.convert('RGBA'); c.putalpha(m)
    c.save(f'{OUT}/intro_cover_{i}.png')
print('ok')
