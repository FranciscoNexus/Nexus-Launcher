package com.nexus.launcher

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

// ---------- Ditado por voz (4.0.8) ----------
// Botão de microfone que vive DENTRO de cada caixa de texto. Ele ocupa a altura que o campo já
// tem (o campo não cresce, nada é empurrado e não surge rolagem). Tocar no microfone dita sem
// abrir o teclado; tocar no campo continua abrindo o teclado como sempre. Os dois jeitos coexistem.

private const val VOICE_LANG = "pt-BR"

/** Garante um único microfone ouvindo por vez no app inteiro. */
private object VoiceBus {
    var owner: Any? = null
    var stop: (() -> Unit)? = null
}

/** 0 = aparelho sem reconhecimento de voz, 1 = reconhecimento embutido, 2 = janela do sistema. */
private fun voiceMode(ctx: Context): Int {
    if (SpeechRecognizer.isRecognitionAvailable(ctx)) return 1
    val probe = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    return if (probe.resolveActivity(ctx.packageManager) != null) 2 else 0
}

private fun joinSpoken(base: String, spoken: String): String {
    val s = spoken.trim()
    if (s.isEmpty()) return base
    return if (base.isBlank()) s else base.trimEnd() + " " + s
}

private fun recognizerIntent(ctx: Context): Intent =
    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, VOICE_LANG)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
    }

private fun voiceToast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

private fun voiceErrorText(code: Int): String? = when (code) {
    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
        "Não entendi. Toque no microfone e fale de novo."
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
        "Permita o microfone para o Nexus nas configurações do Android."
    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
        "Sem internet para reconhecer a voz."
    SpeechRecognizer.ERROR_AUDIO -> "Não foi possível usar o microfone."
    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reconhecimento de voz ocupado. Tente de novo."
    SpeechRecognizer.ERROR_CLIENT -> null // cancelado por nós mesmos
    else -> "Falha no reconhecimento de voz."
}

private fun hideKeyboard(view: android.view.View) {
    val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    imm?.hideSoftInputFromWindow(view.windowToken, 0)
}

private fun DrawScope.drawMic(color: Color) {
    val w = this.size.width
    val h = this.size.height
    val sw = w * 0.10f
    // cápsula
    drawRoundRect(
        color, topLeft = Offset(w * 0.36f, h * 0.04f),
        size = Size(w * 0.28f, h * 0.52f), cornerRadius = CornerRadius(w * 0.14f)
    )
    // arco em U
    drawArc(
        color, startAngle = 0f, sweepAngle = 180f, useCenter = false,
        topLeft = Offset(w * 0.20f, h * 0.22f), size = Size(w * 0.60f, h * 0.52f),
        style = Stroke(width = sw, cap = StrokeCap.Round)
    )
    // haste e base
    drawLine(color, Offset(w * 0.5f, h * 0.74f), Offset(w * 0.5f, h * 0.94f), strokeWidth = sw, cap = StrokeCap.Round)
    drawLine(color, Offset(w * 0.32f, h * 0.94f), Offset(w * 0.68f, h * 0.94f), strokeWidth = sw, cap = StrokeCap.Round)
}

/**
 * Botão de microfone para uma caixa de texto.
 * [value]/[onChange]: texto atual do campo e quem o altera. Ao tocar no microfone o texto antigo é
 * APAGADO e o que for falado entra no lugar (aparece ao vivo enquanto você fala). Quem digita
 * pelo teclado continua editando o texto normalmente. Se o aparelho não tiver reconhecimento de voz,
 * o botão simplesmente não aparece e o campo fica como era.
 * [size]: diâmetro; escolha um valor menor que a altura útil do campo.
 */
@Composable
fun VoiceMic(
    value: String,
    onChange: (String) -> Unit,
    accent: Color,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    onFinal: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val mode = remember { voiceMode(ctx) }
    val curValue by rememberUpdatedState(value)
    val curChange by rememberUpdatedState(onChange)
    val curFinal by rememberUpdatedState(onFinal)
    var listening by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(0f) }
    val holder = remember { arrayOfNulls<SpeechRecognizer>(1) }
    val baseText = remember { arrayOf("") }

    fun release() {
        holder[0]?.let { r ->
            try {
                r.destroy()
            } catch (_: Exception) {
            }
        }
        holder[0] = null
        listening = false
        level = 0f
        if (VoiceBus.owner === holder) {
            VoiceBus.owner = null
            VoiceBus.stop = null
        }
    }

    fun startInApp() {
        VoiceBus.stop?.invoke()
        baseText[0] = ""   // 4.4.0: tocar no microfone apaga o texto antigo; só o que for falado fica
        hideKeyboard(view)
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        } catch (_: Exception) {
            null
        }
        if (r == null) {
            voiceToast(ctx, "Reconhecimento de voz indisponível neste aparelho.")
            return
        }
        curChange("")
        holder[0] = r
        VoiceBus.owner = holder
        VoiceBus.stop = { release() }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                if (holder[0] === r) level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                if (holder[0] !== r) return
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (t.isNotBlank()) curChange(joinSpoken(baseText[0], t))
            }
            override fun onResults(results: Bundle?) {
                if (holder[0] !== r) return
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (t.isNotBlank()) curChange(joinSpoken(baseText[0], t))
                release()
                if (t.isNotBlank()) curFinal?.invoke()
            }
            override fun onError(error: Int) {
                if (holder[0] !== r) return
                release()
                voiceErrorText(error)?.let { voiceToast(ctx, it) }
            }
        })
        listening = true
        try {
            r.startListening(recognizerIntent(ctx))
        } catch (_: Exception) {
            release()
            voiceToast(ctx, "Não foi possível iniciar o microfone.")
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startInApp()
        else voiceToast(ctx, "Sem permissão do microfone. Você ainda pode digitar normalmente.")
    }
    val dialogLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull().orEmpty()
            if (t.isNotBlank()) {
                curChange(t.trim())   // janela do sistema: o texto antigo é substituído pelo que foi falado
                curFinal?.invoke()
            }
        }
    }

    DisposableEffect(Unit) { onDispose { release() } }
    // Rede de segurança: nunca deixa o microfone "preso" em vermelho.
    LaunchedEffect(listening) {
        if (listening) {
            delay(25_000)
            holder[0]?.stopListening()
            delay(4_000)
            release()
        }
    }

    if (mode == 0) return

    val shape = CircleShape
    val bg = if (listening) BtnRed.copy(alpha = 0.55f + 0.45f * level) else accent.copy(alpha = 0.12f)
    val ring = if (listening) BtnRed else accent.copy(alpha = 0.45f)
    val fg = if (listening) Color.White else accent
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(bg)
            .border(1.dp, ring, shape)
            .navFocus(shape)
            .semantics { contentDescription = if (listening) "Parar ditado por voz" else "Ditar por voz" }
            .clickable {
                if (listening) {
                    holder[0]?.stopListening()
                } else if (mode == 1) {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED
                    ) startInApp()
                    else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else {
                    hideKeyboard(view)
                    try {
                        dialogLauncher.launch(
                            recognizerIntent(ctx).putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale agora")
                        )
                    } catch (_: ActivityNotFoundException) {
                        voiceToast(ctx, "Reconhecimento de voz indisponível neste aparelho.")
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.56f)) { drawMic(fg) }
    }
}
