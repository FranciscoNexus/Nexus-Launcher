package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.CoverThumb(cover: String, title: String, platform: String, pkg: String, modifier: Modifier) {
    val accent = parseColor(accentHex)
    val shape = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFF0F2744))
            .border(1.dp, accent.copy(alpha = 0.4f), shape),
        contentAlignment = Alignment.Center
    ) {
        val appIcon = if (platform == ANDROID_PLATFORM && pkg.isNotEmpty()) {
            remember(pkg) { bigIconFor(pkg) }
        } else null
        if (appIcon != null) {
            Image(bitmap = appIcon, contentDescription = title, modifier = Modifier.fillMaxWidth(0.7f).aspectRatio(1f))
        } else if (cover.isBlank()) {
            Text("▣", color = S_MUTED, fontSize = 18.sp)
        }
        if (cover.isNotBlank()) {
            val req = remember(cover) { Covers.request(this@CoverThumb, cover) }
            key(coverRev) {
                AsyncImage(
                    model = req, imageLoader = Covers.loader, contentDescription = title,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
internal fun MainActivity.GameDialog(initial: Game?) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var platform by remember {
        mutableStateOf(
            initial?.platform
                ?: (if (dashMode == 1 && dashPlatform.isNotEmpty() && dashPlatform in addPlatforms(null)) dashPlatform
                else defaultAddPlatform())
        )
    }
    var genreSel by remember { mutableStateOf(initial?.genres ?: emptyList<String>()) }
    var maskPlat by remember { mutableStateOf(initial?.maskPlatform ?: "") }
    var maskCol by remember { mutableStateOf(initial?.maskColor ?: "") }
    var gameCols by remember { mutableStateOf(initial?.collections ?: emptyList<String>()) }
    var cover by remember { mutableStateOf(initial?.cover ?: "") }
    var webUrl by remember { mutableStateOf(initial?.webUrl ?: "") }
    var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
    var romUri by remember { mutableStateOf(initial?.romUri ?: "") }
    var romName by remember {
        mutableStateOf(if (initial != null && initial.romUri.isNotEmpty()) fileNameOf(initial.romUri) else "")
    }
    var fav by remember { mutableStateOf(initial?.isFavorite ?: false) }
    var custom by remember { mutableStateOf(initial?.customCmd ?: "") }
    val isWeb = platform == WEB_PLATFORM
    val isAndroid = platform == ANDROID_PLATFORM
    val canMask = isWeb || isAndroid

    val save: () -> Unit = {
        if (isAndroid && pkg.isEmpty()) {
            toast("Escolha o app do jogo")
        } else if (title.isNotBlank()) {
            val now = System.currentTimeMillis()
            val exec = if (initial == null || initial.platform != platform) {
                DEFAULT_EXEC[execKey(platform)] ?: "native"
            } else initial.execType
            val base = initial ?: Game(
                id = UUID.randomUUID().toString(), title = "", platform = platform, genres = genreSel
            )
            val favTs = if (fav && initial?.isFavorite != true) now else (initial?.favoriteTs ?: 0L)
            // 4.7.0: o vídeo pode ter mudado enquanto este diálogo estava aberto; usa o dado mais novo.
            // Se o título ou a plataforma mudarem, o vídeo é descartado (a próxima abertura dos detalhes busca de novo).
            val fresh = if (initial != null) (games.firstOrNull { it.id == initial.id } ?: initial) else base
            val retitled = initial != null && (initial.title != title.trim() || initial.platform != platform)
            val saved = base.copy(
                videoId = if (retitled) "" else fresh.videoId,
                videoTitle = if (retitled) "" else fresh.videoTitle,
                videoTried = if (retitled) 0L else fresh.videoTried,
                title = title.trim(), platform = platform, genres = genreSel,
                cover = cover.trim(), webUrl = webUrl.trim(), execType = exec,
                pkg = pkg, romUri = romUri, isFavorite = fav, favoriteTs = favTs,
                customCmd = custom.trim(), collections = gameCols,
                maskPlatform = if (canMask) maskPlat else "",
                maskColor = if (canMask && maskPlat.isNotEmpty()) maskCol.ifEmpty { ACCENTS[0].second } else "",
                romFileName = if (base.isAuto && romUri != base.romUri) romName else base.romFileName,
                missing = if (romUri != base.romUri) false else base.missing
            )
            registerPlatformIfNeeded(platform)
            if (saved.maskPlatform.isNotEmpty()) registerPlatformIfNeeded(saved.maskPlatform)
            if (initial == null) {
                games.add(saved)
                saveLibrary()
            } else replaceGame(saved)
            if (initial != null && initial.cover.isNotBlank() && initial.cover != saved.cover) {
                Covers.purgeIfUnused(initial.cover, games.map { it.cover })
            }
            if (initial != null && (initial.title != saved.title || initial.platform != saved.platform)) {
                if (sgdbCache.remove(saved.id) != null) saveSgdb()
            }
            prefetchCovers()
            selectGame(saved.id)
            overlay = Overlay.None
        } else toast("Digite o título")
    }

    val onPlatformSel: (String) -> Unit = { sel ->
        val wasAndroid = platform == ANDROID_PLATFORM
        platform = sel
        if ((sel == ANDROID_PLATFORM) != wasAndroid) {
            pkg = ""
            romUri = ""
            romName = ""
        }
    }
    val fPlat: @Composable () -> Unit = {
        CSelect("Plataforma:", platform, addPlatforms(initial?.platform), Modifier.fillMaxWidth()) { onPlatformSel(it) }
    }
    val pickGameApp: () -> Unit = {
        appPickerMode = 1
        appPickerNone = "Nenhum (voltar)"
        appPickerCb = { a ->
            if (a != null) {
                pkg = a.pkg
                if (title.isBlank()) title = a.label
            }
        }
        appPickerOpen = true
    }
    val pickRom: () -> Unit = {
        val link = linkFor(platform)
        val onRom: (String, String) -> Unit = { uriStr, name ->
            romUri = uriStr
            romName = name
            if (title.isBlank()) title = cleanTitle(name, platform == "PS Vita")
        }
        if (link != null && link.folders.isNotEmpty()) {
            romList = RomListRequest(platform, onRom)
        } else {
            dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
            pickRomFile(false)
        }
    }
    val fRom: @Composable () -> Unit = {
        if (isWeb) {
            CField(webUrl, { webUrl = it }, "Link Web do Jogo (URL)", Modifier.fillMaxWidth())
        } else if (isAndroid) {
            val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
            CButton(
                if (pkg.isEmpty()) "📱 Escolher app instalado" else "📱 ${appLabel ?: pkg}",
                C_BLUE, Modifier.fillMaxWidth()
            ) { pickGameApp() }
        } else {
            CButton(
                if (romUri.isEmpty()) "📁 Escolher ROM" else "📁 $romName",
                C_BLUE, Modifier.fillMaxWidth()
            ) { pickRom() }
        }
    }
    val fTitle: @Composable () -> Unit = {
        CField(title, { title = it }, "Título do jogo", Modifier.fillMaxWidth())
    }
    val fHint: @Composable () -> Unit = {
        if (platform == "PS Vita") {
            Text(
                "⚠ Vita3K+: o título precisa conter o ID do jogo (ex.: PCSA00029)",
                color = C_ORANGE, fontSize = 10.sp, maxLines = 2
            )
        }
        if (isAndroid) {
            Text(
                "Sem URL de capa, o ícone do app é usado como capa.",
                color = C_MUTED, fontSize = 10.sp, maxLines = 2
            )
        }
    }
    val fGenre: @Composable (Modifier) -> Unit = { m ->
        MultiSelectField("Gêneros:", genreSel, genres.sortedAlpha { it }, MAX_GENRES, m) { genreSel = it }
    }
    val fCols: @Composable () -> Unit = {
        CButton(
            "📚 Coleções: " + (if (gameCols.isEmpty()) "nenhuma" else gameCols.joinToString(", ")),
            C_GRAY, Modifier.fillMaxWidth()
        ) {
            collPickerSel.clear()
            collPickerSel.addAll(gameCols)
            collPickerCb = { sel -> gameCols = sel }
            collPickerOpen = true
        }
    }
    val fFav: @Composable (Modifier) -> Unit = { m ->
        CToggle("Favorito", fav, m, star = true) { fav = it }
    }
    val fCover: @Composable () -> Unit = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(cover, { cover = it }, "URL da capa", Modifier.weight(1f))
            CButton("📋 Colar", C_ORANGE, Modifier.width(88.dp)) {
                val t = clipboardText()
                if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
            }
            CButton("🔄", C_GRAY, Modifier.width(48.dp)) { refreshCover(cover) }
        }
    }
    val fSgdbCover: @Composable () -> Unit = {
        CButton("🎮 Escolher capa no SteamGridDB", C_BLUE, Modifier.fillMaxWidth()) {
            openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
        }
    }
    val fSteam: @Composable () -> Unit = {
        CButton("🌐 Abrir site do SteamGridDB", C_GRAY, Modifier.fillMaxWidth()) { openSteamGrid(title) }
    }
    val fApp: @Composable () -> Unit = {
        if (!isWeb && !isAndroid) {
            val label = allApps.firstOrNull { it.pkg == pkg }?.label
            val lp = linkFor(platform)?.pkg ?: ""
            val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
            CButton(
                if (pkg.isEmpty()) "App/emulador: automático" + (if (linkLabel != null) " ($linkLabel)" else "")
                else "App: ${label ?: pkg}",
                C_GRAY, Modifier.fillMaxWidth()
            ) {
                appPickerMode = 2
                appPickerNone = "Automático (padrão da plataforma)"
                appPickerCb = { a -> pkg = a?.pkg ?: "" }
                appPickerOpen = true
            }
        }
    }
    val fCustom: @Composable () -> Unit = {
        val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
        if (!isWeb && !isAndroid && (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null))) {
            CField(custom, { custom = it }, "Comando personalizado (opcional)", Modifier.fillMaxWidth())
        }
    }
    val buttons: @Composable () -> Unit = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { popOverlay() }
            if (initial != null) {
                CButton("Apagar", C_RED, Modifier.weight(1f)) {
                    overlay = Overlay.ConfirmDelete(initial)
                }
            }
            CButton("Salvar", C_BLUE, Modifier.weight(1f)) { save() }
        }
    }

    // ----- Peças compartilhadas entre retrato e paisagem -----
    val accent = parseColor(accentHex)
    val amber = Color(0xFFFFC53D)
    val danger = Color(0xFFFF6B81)
    val green = Color(0xFF30D158)
    val vp = if (landscape) 4.dp else 6.dp
    val showEmu = !isWeb && !isAndroid
    val coverOk = cover.isNotBlank()

    val favPill: @Composable () -> Unit = {
        EPill(
            selected = fav, tint = accent, vpad = vp,
            modifier = Modifier,
            onClick = { fav = !fav }
        ) {
            NxStar(if (fav) accent else Color(0xFFD5DAE5), styleIdx, Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
            Text("Favorito", color = if (fav) accent else Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, softWrap = false, lineHeight = 14.sp, style = TextStyle(lineHeightStyle = CenteredLine))
        }
    }
    val headerTitle = if (initial == null) "Adicionar Novo Jogo" else "Configurar: " + title.ifBlank { initial.title }
    val tagText = if (initial == null) "NOVO JOGO" else "EDITAR JOGO"

    val romPill: @Composable (Modifier) -> Unit = { m ->
        if (isWeb) {
            PillField("LINK WEB DO JOGO", webUrl, { webUrl = it }, "https://…", m, 12, vpad = vp)
        } else if (isAndroid) {
            val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
            EPill(m, selected = pkg.isNotEmpty(), vpad = vp, onClick = pickGameApp) {
                Box(
                    Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                    contentAlignment = Alignment.Center
                ) { Text("📱", fontSize = 13.sp) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    ELabel("APP DO JOGO", accent)
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (pkg.isEmpty()) "Escolher app instalado" else (appLabel ?: pkg), Color.White, 12)
                }
            }
        } else {
            EPill(m, selected = true, vpad = vp, onClick = pickRom) {
                Box(
                    Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                    contentAlignment = Alignment.Center
                ) { Text("📁", fontSize = 13.sp) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    ELabel("ARQUIVO ROM", accent)
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (romUri.isEmpty()) "Escolher ROM" else romName, Color.White, 12)
                }
            }
        }
    }

    val titlePill: @Composable () -> Unit = {
        PillField(
            "TÍTULO DO JOGO", title, { title = it }, "Título do jogo", Modifier.fillMaxWidth(), vpad = vp,
            trailing = {
                if (title.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(Color(0x14FFFFFF))
                            .focusGlow(CircleShape)
                            .clickable { title = "" },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                }
            }
        )
    }

    val maskBlock: @Composable () -> Unit = {
        if (canMask) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    EPill(
                        Modifier.weight(1f), selected = maskPlat.isNotEmpty(),
                        tint = if (maskPlat.isNotEmpty()) parseColor(maskCol.ifEmpty { ACCENTS[0].second }) else null, vpad = vp,
                        onClick = {
                            platPicker = PlatPickerRequest(
                                "Máscara de etiqueta", maskPlat,
                                { pn -> pn != ANDROID_PLATFORM && pn != WEB_PLATFORM },
                                { o, n -> if (maskPlat == o) maskPlat = n },
                                { pn ->
                                    maskPlat = pn
                                    if (maskCol.isEmpty()) maskCol = ACCENTS[0].second
                                }
                            )
                        }
                    ) {
                        Column(Modifier.weight(1f)) {
                            ELabel("MÁSCARA DE ETIQUETA")
                            Spacer(Modifier.height(3.dp))
                            MarqueeText(if (maskPlat.isEmpty()) "Desligada" else "Aparece como $maskPlat", Color.White, 13)
                        }
                        Spacer(Modifier.width(6.dp))
                        Text("▾", color = S_MUTED, fontSize = 13.sp)
                    }
                    if (maskPlat.isNotEmpty()) MiniIcon("✕", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { maskPlat = ""; maskCol = "" }
                }
                if (maskPlat.isNotEmpty()) {
                    ELabel("COR DA ETIQUETA")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ACCENTS.forEach { (_, hex) ->
                            val c = parseColor(hex)
                            val on = hex.equals(maskCol.ifEmpty { ACCENTS[0].second }, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else S_LINE, CircleShape)
                                    .focusGlow(CircleShape)
                                    .clickable { maskCol = hex }
                            )
                        }
                    }
                }
            }
        }
    }

    val vitaRow: @Composable () -> Unit = {
        if (platform == "PS Vita") {
            val idRe = Regex("[A-Z]{4}\\d{5}")
            val idInTitle = idRe.find(title)?.value
            val idInRom = idRe.find(romName)?.value
            EPill(Modifier.fillMaxWidth(), selected = true, tint = if (idInTitle != null) green else amber, vpad = if (landscape) 4.dp else 8.dp) {
                Text(if (idInTitle != null) "✓" else "⚠", color = if (idInTitle != null) green else amber, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (idInTitle != null) "Vita3K+: ID encontrado ($idInTitle)" else "Vita3K+: inclua o ID no título",
                    color = if (idInTitle != null) Color(0xFFB7F5C8) else Color(0xFFFDE6A8),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                    modifier = Modifier.weight(1f)
                )
                if (idInTitle == null && idInRom != null) {
                    Spacer(Modifier.width(8.dp))
                    EBtn("+ $idInRom", null, Color(0x33FFC53D), Color(0x80FFC53D), Color(0xFFFFD36B)) {
                        title = (title.trim() + " " + idInRom).trim()
                    }
                }
            }
        }
    }

    val genreCols: @Composable () -> Unit = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EPill(
                Modifier.weight(1f), vpad = vp,
                onClick = {
                    genrePickerSel.clear()
                    genrePickerSel.addAll(genreSel)
                    genrePickerCb = { sel -> genreSel = sel }
                    genrePickerOpen = true
                }
            ) {
                Column(Modifier.weight(1f)) {
                    ELabel("GÊNEROS")
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (genreSel.isEmpty()) NO_GENRE else genreSel.joinToString(", "), Color.White, 13)
                }
                Spacer(Modifier.width(6.dp))
                Text("▾", color = S_MUTED, fontSize = 13.sp)
            }
            EPill(
                Modifier.weight(1f), vpad = vp,
                onClick = {
                    collPickerSel.clear()
                    collPickerSel.addAll(gameCols)
                    collPickerCb = { sel -> gameCols = sel }
                    collPickerOpen = true
                }
            ) {
                Column(Modifier.weight(1f)) {
                    ELabel("COLEÇÕES")
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (gameCols.isEmpty()) "Nenhuma" else gameCols.joinToString(", "), Color.White, 13)
                }
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(rBtn.dp))
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, S_LINE, RoundedCornerShape(rBtn.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("▣", color = Color(0xFFD5DAE5), fontSize = 12.sp) }
            }
        }
    }

    val coverHeader: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SLabel("CAPA DO JOGO (STEAMGRIDDB)", modifier = Modifier.weight(1f), compact = true)
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(6.dp).clip(CircleShape).background(if (coverOk) green else S_MUTED))
            Spacer(Modifier.width(4.dp))
            Text(
                if (coverOk) "Capa ativa" else if (isAndroid) "Ícone do app" else "Sem capa",
                color = if (coverOk) green else S_MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
            )
        }
    }

    val coverMain: @Composable () -> Unit = {
        Row(modifier = Modifier.fillMaxWidth()) {
            CoverThumb(cover, title, platform, pkg, Modifier.width(52.dp).height(if (landscape) 74.dp else 82.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PillField(null, cover, { cover = it }, "Cole a URL da capa...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, vp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), Modifier.weight(1f)) {
                        val t = clipboardText()
                        if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                    }
                    EBtn("Atualizar", "⟳", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { refreshCover(cover) }
                }
            }
        }
    }

    val coverButtons: @Composable () -> Unit = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { openSteamGrid(title) }
            EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), Modifier.weight(1f)) {
                openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
            }
        }
    }

    val emuBlock: @Composable () -> Unit = {
        val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
        val lp = linkFor(platform)?.pkg ?: ""
        val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
        val emu = if (pkg.isEmpty()) "Automático" + (if (linkLabel != null) " ($linkLabel)" else "") else (appLabel ?: pkg)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(rBtn.dp))
                        .background(accent.copy(alpha = 0.15f))
                        .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(rBtn.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("⇄", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    ELabel("APP / EMULADOR")
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(emu, Color.White, 13)
                }
                Spacer(Modifier.width(8.dp))
                EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                    appPickerMode = 2
                appPickerNone = "Automático (padrão da plataforma)"
                    appPickerCb = { a -> pkg = a?.pkg ?: "" }
                    appPickerOpen = true
                }
            }
            val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
            if (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null)) {
                PillField("COMANDO PERSONALIZADO (OPCIONAL)", custom, { custom = it }, "Comando", Modifier.fillMaxWidth(), 12, vpad = vp)
            }
        }
    }

    // 4.7.0: ações que saíram da tela de detalhes (atualizar dados) e o vídeo (trocar / buscar de novo).
    val dataBlock: @Composable () -> Unit = {
        if (initial != null) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SLabel("DADOS E VÍDEO", compact = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EBtn("Atualizar dados", "⟳", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) {
                        if (sgdbKey.isBlank()) toast("Adicione sua chave do SteamGridDB em Configurações")
                        else {
                            toast("Atualizando dados…")
                            fetchSgdb(games.firstOrNull { it.id == initial.id } ?: initial, force = true)
                        }
                    }
                    EBtn("Trocar vídeo", "▶", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) {
                        videoLinkFor = games.firstOrNull { it.id == initial.id } ?: initial
                    }
                }
            }
        }
    }

    val panel = RoundedCornerShape(rPanel.dp)

    if (landscape) {
        // Paisagem: janela cheia, cabeçalho numa linha, duas colunas e rodapé com dicas do controle.
        val view = LocalView.current
        Dialog(
            onDismissRequest = { popOverlay() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            SideEffect {
                val w = (view.parent as? DialogWindowProvider)?.window
                if (w != null) {
                    val lp = w.attributes
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    w.attributes = lp
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                    .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
            ) {
                    Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(rBtn.dp))
                                .background(accent.copy(alpha = 0.15f))
                                .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(rBtn.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                            Spacer(Modifier.width(6.dp))
                            ELabel(tagText, accent)
                        }
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f)) { MarqueeText(headerTitle, Color.White, 16, FontWeight.ExtraBold) }
                        Spacer(Modifier.width(10.dp))
                        favPill()
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 4.5.1: a "Máscara de etiqueta" foi para a coluna da direita (que tem espaço livre),
                        // então Gêneros e Coleções aparecem sempre. Se algum bloco extra surgir, a coluna rola.
                        SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                            Column(
                                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PlatPill("PLATAFORMA", platform, Modifier.weight(5f), vp, onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) defaultAddPlatform() else n }) { onPlatformSel(it) }
                                    romPill(Modifier.weight(7f))
                                }
                                titlePill()
                                vitaRow()
                                genreCols()
                            }
                        }
                        SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                            Column(
                                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                coverHeader()
                                coverMain()
                                coverButtons()
                                maskBlock()
                                if (showEmu) emuBlock()
                                dataBlock()
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PadHint("A", "Confirmar", S_PAD_A, compact = true, onClick = null)
                            Spacer(Modifier.width(8.dp))
                            PadHint("B", "Cancelar", S_PAD_B, compact = true, onClick = null)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.widthIn(min = 110.dp)) { popOverlay() }
                            if (initial != null) {
                                EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.widthIn(min = 100.dp)) {
                                    overlay = Overlay.ConfirmDelete(initial)
                                }
                            }
                            EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.widthIn(min = 110.dp)) { save() }
                        }
                    }
                }
            }
        }
    } else {
        // Retrato: a tela rola na vertical quando o conteúdo não cabe (4.7.5). Textos longos rolam sozinhos (marquee).
        Dialog(
            onDismissRequest = { popOverlay() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .then(if (canMask) Modifier else Modifier.fillMaxHeight(0.97f))
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                                Spacer(Modifier.width(6.dp))
                                ELabel(tagText)
                            }
                            Spacer(Modifier.height(2.dp))
                            MarqueeText(headerTitle, Color.White, 18, FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.width(10.dp))
                        favPill()
                    }
                    Spacer(Modifier.height(6.dp))

                    // 4.7.5: o conteúdo rola na vertical quando não cabe (o Editar tem muitas opções); os botões
                    // Cancelar/Apagar/Salvar ficam sempre visíveis embaixo.
                    Box(modifier = Modifier.weight(1f, fill = !canMask).fillMaxWidth()) {
                        Column(
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SCard(pad = 10.dp) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        PlatPill("PLATAFORMA", platform, Modifier.weight(5f), vp, onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) defaultAddPlatform() else n }) { onPlatformSel(it) }
                                        romPill(Modifier.weight(7f))
                                    }
                                    titlePill()
                                    maskBlock()
                                    vitaRow()
                                }
                            }
                            SCard(pad = 10.dp) { genreCols() }
                            SCard(pad = 10.dp) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    coverHeader()
                                    coverMain()
                                    coverButtons()
                                }
                            }
                            if (showEmu) SCard(pad = 10.dp) { emuBlock() }
                            if (initial != null) SCard(pad = 10.dp) { dataBlock() }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { popOverlay() }
                        if (initial != null) {
                            EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.weight(1f), tall = true) {
                                overlay = Overlay.ConfirmDelete(initial)
                            }
                        }
                        EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) { save() }
                    }
                }
            }
        }
    }
}
