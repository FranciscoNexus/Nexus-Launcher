package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Dados de um jogo vindos da RAWG (guardados no aparelho para funcionar offline). */
data class RawgInfo(
    val found: Boolean = false,
    val rawgId: Int = 0,
    val slug: String = "",
    val name: String = "",
    val released: String = "",
    val platforms: List<String> = emptyList(),
    val developers: List<String> = emptyList(),
    val publishers: List<String> = emptyList(),
    val metacritic: Int? = null,
    val image: String = "",
    val fetchedAt: Long = 0L
)

sealed class RawgResult {
    class Ok(val info: RawgInfo) : RawgResult()
    class Failure(val message: String) : RawgResult()
}

class RawgException(message: String) : Exception(message)

// IDs de plataforma da RAWG por plataforma embutida do Nexus. Usados só para melhorar a busca:
// se a busca com plataforma não achar nada, repete sem ela.
val RAWG_PLATFORM_IDS = mapOf(
    "PlayStation 1" to 27, "PlayStation 2" to 15, "PlayStation 4" to 18, "PSP" to 17, "PS Vita" to 19,
    "Super Nintendo" to 79, "Nintendo 64" to 83, "GameCube" to 105, "Wii" to 11, "Nintendo Wii U" to 10,
    "Nintendo Switch" to 7, "Game Boy Advance" to 24, "Nintendo DS" to 9, "Nintendo 3DS" to 8,
    "Xbox Clássico" to 80, "Xbox 360" to 14, "PC" to 4, "Sega Mega Drive" to 167, "Sega Saturn" to 107,
    "Android" to 21
)

object RawgApi {
    private const val BASE = "https://api.rawg.io/api"

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun errorFor(code: Int): String = when (code) {
        401, 403 -> "Chave da RAWG inválida"
        429 -> "Limite mensal da RAWG atingido"
        else -> "Erro da RAWG ($code)"
    }

    private fun httpOk(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "NexusLauncher/3.6 (uso pessoal)")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw RawgException(errorFor(code))
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun names(arr: JSONArray?, inner: String?): List<String> {
        if (arr == null) return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val n = if (inner == null) o else o.optJSONObject(inner)
            val name = if (n == null) "" else str(n, "name")
            if (name.isNotBlank()) out.add(name)
        }
        return out
    }

    fun cleanQuery(title: String): String =
        title.replace(Regex("[\\(\\[][^\\)\\]]*[\\)\\]]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun search(key: String, q: String, platformId: Int?): JSONArray {
        val url = "$BASE/games?key=${enc(key)}&search=${enc(q)}&page_size=5" +
            (if (platformId != null) "&platforms=$platformId" else "")
        return JSONObject(httpOk(url)).optJSONArray("results") ?: JSONArray()
    }

    private fun pickBest(results: JSONArray, q: String): JSONObject {
        val want = norm(q)
        for (i in 0 until results.length()) {
            val o = results.getJSONObject(i)
            if (norm(str(o, "name")) == want) return o
        }
        return results.getJSONObject(0)
    }

    /** Busca pelo título (e plataforma, se conhecida) e devolve os detalhes. Faz de 2 a 3 requisições. */
    fun lookup(key: String, title: String, platformId: Int?): RawgResult {
        val now = System.currentTimeMillis()
        return try {
            val q = cleanQuery(title)
            if (q.isEmpty()) return RawgResult.Ok(RawgInfo(found = false, fetchedAt = now))
            var results = search(key, q, platformId)
            if (results.length() == 0 && platformId != null) results = search(key, q, null)
            if (results.length() == 0) return RawgResult.Ok(RawgInfo(found = false, fetchedAt = now))
            val id = pickBest(results, q).getInt("id")
            val d = JSONObject(httpOk("$BASE/games/$id?key=${enc(key)}"))
            RawgResult.Ok(
                RawgInfo(
                    found = true,
                    rawgId = id,
                    slug = str(d, "slug"),
                    name = str(d, "name"),
                    released = str(d, "released"),
                    platforms = names(d.optJSONArray("platforms"), "platform"),
                    developers = names(d.optJSONArray("developers"), null),
                    publishers = names(d.optJSONArray("publishers"), null),
                    metacritic = if (d.isNull("metacritic")) null else d.optInt("metacritic"),
                    image = str(d, "background_image"),
                    fetchedAt = now
                )
            )
        } catch (e: RawgException) {
            RawgResult.Failure(e.message ?: "Erro da RAWG")
        } catch (e: IOException) {
            RawgResult.Failure("Sem conexão com a RAWG")
        } catch (e: org.json.JSONException) {
            RawgResult.Failure("Resposta inesperada da RAWG")
        }
    }

    /** Imagem de fundo da plataforma (para o dashboard por plataformas). */
    fun platformImage(key: String, platformId: Int): RawgResult = try {
        val d = JSONObject(httpOk("$BASE/platforms/$platformId?key=${enc(key)}"))
        RawgResult.Ok(RawgInfo(found = true, image = str(d, "image_background"), fetchedAt = System.currentTimeMillis()))
    } catch (e: RawgException) {
        RawgResult.Failure(e.message ?: "Erro da RAWG")
    } catch (e: IOException) {
        RawgResult.Failure("Sem conexão com a RAWG")
    } catch (e: org.json.JSONException) {
        RawgResult.Failure("Resposta inesperada da RAWG")
    }

    /** null = chave válida; senão, a mensagem de erro. */
    fun ping(key: String): String? = try {
        httpOk("$BASE/platforms?key=${enc(key)}&page_size=1")
        null
    } catch (e: RawgException) {
        e.message
    } catch (e: IOException) {
        "Sem conexão com a RAWG"
    }
}

/** Cache em arquivo, por id de jogo do Nexus. Fica fora do backup (os dados são da RAWG, não seus). */
object RawgStore {
    fun load(file: File): Map<String, RawgInfo> {
        if (!file.exists()) return emptyMap()
        return try {
            val root = JSONObject(file.readText())
            val out = HashMap<String, RawgInfo>()
            for (k in root.keys()) {
                val o = root.optJSONObject(k) ?: continue
                out[k] = RawgInfo(
                    found = o.optBoolean("found", false),
                    rawgId = o.optInt("id", 0),
                    slug = o.optString("slug", ""),
                    name = o.optString("name", ""),
                    released = o.optString("released", ""),
                    platforms = list(o.optJSONArray("platforms")),
                    developers = list(o.optJSONArray("developers")),
                    publishers = list(o.optJSONArray("publishers")),
                    metacritic = if (o.isNull("metacritic")) null else o.optInt("metacritic"),
                    image = o.optString("image", ""),
                    fetchedAt = o.optLong("fetchedAt", 0L)
                )
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun list(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        return (0 until a.length()).map { a.optString(it, "") }.filter { it.isNotBlank() }
    }

    fun save(file: File, map: Map<String, RawgInfo>) {
        try {
            val root = JSONObject()
            for ((id, i) in map) {
                root.put(
                    id,
                    JSONObject()
                        .put("found", i.found)
                        .put("id", i.rawgId)
                        .put("slug", i.slug)
                        .put("name", i.name)
                        .put("released", i.released)
                        .put("platforms", JSONArray(i.platforms))
                        .put("developers", JSONArray(i.developers))
                        .put("publishers", JSONArray(i.publishers))
                        .put("metacritic", i.metacritic ?: JSONObject.NULL)
                        .put("image", i.image)
                        .put("fetchedAt", i.fetchedAt)
                )
            }
            file.writeText(root.toString())
        } catch (_: Exception) {
        }
    }
}
