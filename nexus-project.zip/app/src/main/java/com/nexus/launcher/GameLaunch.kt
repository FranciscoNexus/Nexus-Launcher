package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

internal fun MainActivity.openUrl(url: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        toast("Erro ao abrir o navegador")
    }
}

internal fun MainActivity.playGame(g: Game) {
    val link = linkFor(g.platform)
    val pkg = effectivePkg(g, link)
    val tpl = if (g.customCmd.isNotBlank()) g.customCmd
    else if (pkg != null) templateFor(pkg, link) else null
    if (tpl != null && tpl.contains("{file.") && g.romUri.isEmpty()) {
        if (link != null && link.folders.isNotEmpty()) {
            romList = RomListRequest(g.platform) { uri, _ ->
                val u = g.copy(romUri = uri)
                replaceGame(u)
                launchGame(u)
            }
        } else {
            pendingPlay = g
            pickRomFile(true)
        }
    } else {
        launchGame(g)
    }
}

internal fun MainActivity.goHome() {
    stopHold()
    overlay = Overlay.None
    appsDrawerOpen = false
    appPickerOpen = false
    appFilterKind = 0
    emuPicker = null
    platPicker = null
    genrePickerOpen = false
    collPickerOpen = false
    sgdbPicker = null
    videoLinkFor = null
    closeVideo()
    romList = null
}

// ---------- Modo launcher (4.3.0) ----------
/** Liga/desliga o painel flutuante de temperatura e bateria (toque no cabeçalho ou em Extras). */
internal fun MainActivity.toggleFloat() {
    if (FloatState.on) {
        FloatingPanelService.stop(this)
        toast("Painel flutuante desligado")
        return
    }
    if (!FloatingPanelService.canDraw(this)) {
        if (!TvMode.isTv) toast("Permita \"Exibir sobre outros apps\" para o Nexus e volte")
        try {
            overlayPermRequest.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            // Muitas TVs não têm essa tela: mostra como liberar pelo computador (ADB).
            if (TvMode.isTv) permHelp = "overlay" else toast("Não foi possível abrir a permissão de sobreposição")
        }
        return
    }
    askNotifThenStartFloat()
}

internal fun MainActivity.askNotifThenStartFloat() {
    if (!FloatingPanelService.notificationsAllowed(this) && Build.VERSION.SDK_INT >= 33) {
        try {
            notifPermRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        } catch (_: Exception) {
        }
    }
    startFloat()
}

internal fun MainActivity.startFloat() {
    prefs.edit().putBoolean("floatOn", true).apply()
    FloatingPanelService.start(this)
    FloatState.on = true
    toast(if (TvMode.isTv) "Painel ligado: a temperatura aparece sobre os outros apps." else "Painel ligado: aparece sobre os outros apps. Arraste para onde quiser; toque para diminuir; segure e leve ao X para fechar.")
}

internal fun MainActivity.askDefaultLauncher() {
    try {
        homeRequest.launch(LauncherMode.requestIntent(this))
    } catch (_: Exception) {
        openHomeSettings()
    }
}

internal fun MainActivity.openHomeSettings() {
    try {
        startActivity(LauncherMode.homeSettingsIntent())
    } catch (_: Exception) {
        toast("Não foi possível abrir as configurações de launcher")
    }
}

internal fun MainActivity.openSystemSettings() {
    try {
        startActivity(LauncherMode.systemSettingsIntent())
    } catch (_: Exception) {
        toast("Não foi possível abrir as configurações do Android")
    }
}

internal fun MainActivity.openAppInfo(pkg: String) {
    try {
        startActivity(LauncherMode.appInfoIntent(pkg))
    } catch (_: Exception) {
        toast("Não foi possível abrir as informações do app")
    }
}

/** Intent de abertura do app. Na TV, apps feitos para Android TV só têm a entrada "leanback". */
internal fun MainActivity.launchIntentFor(pkg: String): Intent? {
    val pm = packageManager
    return if (TvMode.isTv) (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))
    else (pm.getLaunchIntentForPackage(pkg) ?: pm.getLeanbackLaunchIntentForPackage(pkg))
}

internal fun MainActivity.launchApp(pkg: String) {
    val i = launchIntentFor(pkg)
    if (i == null) {
        toast("Este app não pode ser aberto")
        return
    }
    try {
        startActivity(i)
    } catch (e: Exception) {
        toast("Erro ao abrir: ${e.message}")
    }
}

internal fun MainActivity.persist(uri: Uri) {
    try {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (_: Exception) {
    }
}

/** 4.7.4: transforma em jogos os atalhos recebidos de outros apps (ver PinShortcut.kt). */
internal fun MainActivity.importPendingShortcuts() {
    val pend = PinShortcuts.take(this)
    if (pend.isEmpty()) return
    var added = 0
    var lastId: String? = null
    for (p in pend) {
        if (games.any { it.pkg == p.pkg && it.shortcutId == p.shortcutId }) continue
        val g = Game(
            id = UUID.randomUUID().toString(), title = p.label, platform = ANDROID_PLATFORM,
            cover = p.iconPath, pkg = p.pkg, shortcutId = p.shortcutId,
            execType = DEFAULT_EXEC[execKey(ANDROID_PLATFORM)] ?: "native"
        )
        games.add(g)
        lastId = g.id
        added++
    }
    if (added > 0) {
        saveLibrary()
        lastId?.let { selectGame(it) }
        toast(if (added == 1) "Atalho adicionado como jogo" else "$added atalhos adicionados como jogos")
    }
}

internal fun MainActivity.launchShortcutGame(g: Game) {
    val err = PinShortcuts.start(this, g.pkg, g.shortcutId)
    if (err == null) {
        markPlayed(g)
        return
    }
    // Plano B: abre o próprio app do atalho.
    val intent = launchIntentFor(g.pkg)
    if (intent != null) {
        try {
            startActivity(intent)
            markPlayed(g)
            // 4.9.16: mostra o erro real do Android (e fica salvo no Relatório de diagnóstico, em Sobre).
            toast("Não deu para abrir o atalho direto. Abrindo o app. Motivo: $err")
            return
        } catch (_: Exception) {
        }
    }
    toast("Não foi possível abrir o atalho: $err")
}

internal fun MainActivity.launchGame(g: Game) {
    if (g.shortcutId.isNotEmpty()) {
        launchShortcutGame(g)
        return
    }
    if (g.execType == "browser") {
        if (g.webUrl.isBlank()) {
            toast("Este jogo não tem link configurado")
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
        return
    }
    val custom = g.customCmd.trim()
    if (custom.isNotEmpty()) {
        val b = buildIntent(custom, g) ?: return
        try {
            startActivity(b.intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
        return
    }
    val link = linkFor(g.platform)
    val pkg = effectivePkg(g, link)
    if (pkg == null) {
        if (link != null && link.pkg.isNotEmpty()) {
            toast("O emulador ${link.playerName.ifEmpty { link.pkg }} não está instalado")
        } else {
            toast("Defina o app em Editar (segure a capa ou aperte START)")
        }
        return
    }
    val tpl = templateFor(pkg, link)
    try {
        if (tpl != null && !(tpl.contains("{file.") && g.romUri.isEmpty())) {
            val b = buildIntent(tpl, g) ?: return
            if (b.kill) {
                try {
                    (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                } catch (_: Exception) {
                }
            }
            startActivity(b.intent)
            markPlayed(g)
            return
        }
        val intent = launchIntentFor(pkg)
        if (intent == null) {
            toast("Não foi possível abrir $pkg")
            return
        }
        startActivity(intent)
        markPlayed(g)
    } catch (e: Exception) {
        toast("Erro ao abrir: ${e.message}")
    }
}

// ---------- Acesso a todos os arquivos (para pastas de ROMs vindas de backup) ----------
internal fun MainActivity.hasAllFiles(): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

internal fun MainActivity.askStorage() {
    if (Build.VERSION.SDK_INT >= 30) {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                if (TvMode.isTv) permHelp = "storage"
                else toast("Abra Configurações > Apps > Nexus e libere o acesso a todos os arquivos")
            }
        }
    } else {
        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77)
    }
}

// Converte o comando em um Intent.
internal fun MainActivity.buildIntent(tpl: String, g: Game): BuiltIntent? {
    val uriStr = effectiveRomUri(g.romUri)
    val fileName = if (uriStr.isEmpty()) "" else fileNameOf(uriStr)
    val unsupported = Regex("\\{tags\\.([A-Za-z0-9_]+)\\}").findAll(tpl)
        .map { it.groupValues[1] }.firstOrNull { it != "vita_game_id" }
    if (unsupported != null) {
        toast("Este emulador usa {tags.$unsupported}, que o Nexus ainda não preenche. Use um comando personalizado no jogo.")
        return null
    }
    val idRe = Regex("[A-Z]{4}\\d{5}")
    val vitaId = idRe.find(g.title)?.value ?: idRe.find(fileName)?.value ?: ""
    if (tpl.contains("{tags.vita_game_id}") && vitaId.isEmpty()) {
        toast("Vita3K+ precisa do ID do jogo no título (ex.: PCSA00029)")
        return null
    }
    fun sub(x: String): String = x
        .replace("{file.uri}", uriStr)
        .replace("{file.path}", if (uriStr.isEmpty()) "" else pathOf(uriStr))
        .replace("{file.name}", fileName)
        .replace("{file.mime}", if (uriStr.isEmpty()) "" else mimeOf(fileName))
        .replace("{tags.vita_game_id}", vitaId)

    val t = tpl.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    var comp: ComponentName? = null
    var action: String? = null
    var data: String? = null
    var type: String? = null
    val cats = ArrayList<String>()
    val extras = LinkedHashMap<String, String>()
    val arrays = LinkedHashMap<String, List<String>>()
    val typed = ArrayList<Triple<String, Char, String>>()
    var flags = Intent.FLAG_ACTIVITY_NEW_TASK
    var kill = false
    try {
        var i = 0
        while (i < t.size) {
            when (t[i]) {
                "-n" -> {
                    i++
                    val p = sub(t[i]).split("/")
                    if (p.size == 2) {
                        val cls = if (p[1].startsWith(".")) p[0] + p[1] else p[1]
                        comp = ComponentName(p[0], cls)
                    }
                }
                "-a" -> { i++; action = sub(t[i]) }
                "-c" -> { i++; cats.add(sub(t[i])) }
                "-d" -> { i++; data = sub(t[i]) }
                "-t" -> { i++; type = sub(t[i]) }
                "-e", "--es" -> {
                    i++
                    val k = t[i]
                    i++
                    extras[k] = sub(t[i])
                }
                "--esa" -> {
                    i++
                    val k = t[i]
                    i++
                    arrays[k] = sub(t[i]).split(",")
                }
                "--ez", "--ei", "--el" -> {
                    val kind = t[i].last()
                    i++
                    val k = t[i]
                    i++
                    typed.add(Triple(k, kind, sub(t[i])))
                }
                "-f" -> {
                    i++
                    flags = flags or java.lang.Long.decode(t[i]).toInt()
                }
                "--activity-clear-task" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TASK
                "--activity-clear-top" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TOP
                "--activity-no-history" -> flags = flags or Intent.FLAG_ACTIVITY_NO_HISTORY
                "--nexus-kill" -> kill = true
            }
            i++
        }
    } catch (_: Exception) {
        toast("Comando de abertura inválido")
        return null
    }
    val intent = Intent()
    val a = action
    if (a != null) intent.action = a
    val c = comp
    if (c != null) intent.component = c
    for (cat in cats) intent.addCategory(cat)
    val d = data
    val ty = type
    if (d != null && ty != null) intent.setDataAndType(Uri.parse(d), ty)
    else if (d != null) intent.data = Uri.parse(d)
    else if (ty != null) intent.type = ty
    for ((k, v) in extras) intent.putExtra(k, v)
    for ((k, v) in arrays) intent.putExtra(k, v.toTypedArray())
    for ((k, kind, v) in typed) {
        when (kind) {
            'z' -> intent.putExtra(k, v.equals("true", ignoreCase = true))
            'i' -> intent.putExtra(k, v.toIntOrNull() ?: 0)
            else -> intent.putExtra(k, v.toLongOrNull() ?: 0L)
        }
    }
    intent.addFlags(flags)
    if (uriStr.startsWith("content://")) {
        intent.clipData = ClipData.newRawUri("rom", Uri.parse(uriStr))
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    return BuiltIntent(intent, kill)
}

internal fun MainActivity.askNotifications() {
    if (Build.VERSION.SDK_INT >= 33 &&
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
        !prefs.getBoolean("notifAsked", false)
    ) {
        prefs.edit().putBoolean("notifAsked", true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 78)
    }
}
