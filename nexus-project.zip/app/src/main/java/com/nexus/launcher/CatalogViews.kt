package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Cartão de plataforma (ocupa o espaço de 2 capas) ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MainActivity.PlatformCard(p: GamePlatform, selected: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f) {
    val shape = RoundedCornerShape(radius.dp)
    val sid = PLAT_PREFIX + p.name
    val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scalePlat")
    val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowPlat")
    val underline = showUnderline(selected)
    val nav = FocusStyle.navColor
    Box(
        modifier = modifier
            .zIndex(if (selected) 1f else 0f)
            .aspectRatio(0.69f)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                if (underline) {
                    // 4.9.3: sublinhado fino, do tamanho da capa, na cor de navegação (a mesma dos botões em foco).
                    val t = 3.dp.toPx()
                    drawRoundRect(
                        nav, topLeft = Offset(0f, size.height + 4.dp.toPx()),
                        size = Size(size.width, t), cornerRadius = CornerRadius(t / 2f)
                    )
                }
            }
            .clip(shape)
            .background(Color(0xFF13161E))
            .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
            .catalogFocus()
            .combinedClickable(
                onClick = { selectedId = sid },
                onLongClick = {
                    selectedId = sid
                    overlay = Overlay.PlatformImage(p.name)
                }
            )
    ) {
        Text(
            p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.Center).padding(14.dp)
        )
        if (p.image.isNotBlank()) {
            val req = remember(p.image) { Covers.request(this@PlatformCard, p.image) }
            key(coverRev) {
                AsyncImage(
                    model = req, imageLoader = Covers.loader, contentDescription = p.name,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

// ---------- TV: modo Lista (4.6.1) ----------
/** Casca comum dos cartões da lista: brilho, borda, escala e clique (1º toque seleciona, 2º abre). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MainActivity.ListRowShell(
    selected: Boolean, accent: Color, haloTopDp: Float,
    onClick: () -> Unit, onLongClick: () -> Unit,
    content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius.dp)
    val sc by animateFloatAsState(if (selected) 1.02f else 1f, label = "scaleList")
    val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowList")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(listRowH.dp)
            .zIndex(if (selected) 1f else 0f)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                drawHalo(
                    accent, glow, radius.dp.toPx(),
                    if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE, 1.02f
                )
            }
            .clip(shape)
            .background(Color(0xFF13161E))
            .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
            .catalogFocus()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
internal fun MainActivity.GameListRow(g: Game, selected: Boolean, recent: Boolean, accent: Color, haloTopDp: Float) {
    ListRowShell(
        selected, accent, haloTopDp,
        onClick = { if (selectedId == g.id) overlay = Overlay.Info(g.id) else selectedId = g.id },
        onLongClick = { selectedId = g.id; overlay = Overlay.Info(g.id) }
    ) {
        CoverThumb(g.cover, g.title, g.platform, g.pkg, Modifier.fillMaxHeight().aspectRatio(0.69f))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                g.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                val maskBg = if (g.maskPlatform.isNotEmpty() && g.maskColor.isNotEmpty()) parseColor(g.maskColor) else null
                Text(
                    g.shownPlatform.uppercase(),
                    color = if (maskBg != null) onAccent(maskBg) else Color(0xFFF1F5F9), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp, maxLines = 1, softWrap = false,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(maskBg ?: Color(0xD9000000))
                        .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                if (g.genres.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        g.genres.joinToString(" · "), color = Color(0xFFB4BCCB), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            // Legenda: última vez jogado e quantas vezes foi aberto.
            val meta = buildList {
                if (g.lastPlayedTs > 0) add("Último jogo: " + listDate(g.lastPlayedTs))
                if (g.openCount > 0) add("Aberto ${g.openCount}×")
                if (g.missing) add("⚠ Arquivo não encontrado")
                if (pinLost(g)) add("⚠ Atalho precisa ser recriado")
            }
            if (meta.isNotEmpty()) {
                Text(
                    meta.joinToString("  ·  "), color = Color(0xFF8A93A6), fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        // 4.7.0: no fim do cartão, sem fundo: ampulheta (só nos recentes) à esquerda da estrela.
        // A estrela aparece em todos os jogos (cinza apagada / amarela) e é apenas um ícone, não um botão.
        Spacer(Modifier.width(10.dp))
        // 4.7.9: ícones redesenhados (NxIcons.kt): mesma altura (27 dp) e mesma caixa, cor de destaque do usuário,
        // cantos conforme o estilo de borda escolhido. 20 dp de distância entre os dois.
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            if (recent) NxHourglass(accent, styleIdx, Modifier.size(27.dp))
            NxStar(if (g.isFavorite) accent else Color(0x4DFFFFFF), styleIdx, Modifier.size(27.dp))
        }
        Spacer(Modifier.width(8.dp))
    }
}

@Composable
internal fun MainActivity.PlatformListRow(p: GamePlatform, selected: Boolean, accent: Color, haloTopDp: Float) {
    val sid = PLAT_PREFIX + p.name
    val count = filteredGames().count { it.shownPlatform == p.name }
    ListRowShell(
        selected, accent, haloTopDp,
        onClick = { if (selectedId == sid) enterPlatform(p.name) else selectedId = sid },
        onLongClick = { selectedId = sid; overlay = Overlay.PlatformImage(p.name) }
    ) {
        CoverThumb(p.image, p.name, p.name, "", Modifier.fillMaxHeight().aspectRatio(0.69f))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                p.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (count == 1) "1 jogo" else "$count jogos", color = Color(0xFFB4BCCB), fontSize = 12.sp,
                maxLines = 1
            )
        }
        Spacer(Modifier.width(10.dp))
    }
}

@Composable
internal fun MainActivity.AddListRow(selected: Boolean, accent: Color, haloTopDp: Float) {
    ListRowShell(
        selected, accent, haloTopDp,
        onClick = { if (selectedId == ADD_ID) openAdd() else selectedId = ADD_ID },
        onLongClick = { selectedId = ADD_ID }
    ) {
        Box(
            Modifier.fillMaxHeight().aspectRatio(0.69f).clip(RoundedCornerShape(rBtn.dp)).background(Color(0x0FFFFFFF)),
            contentAlignment = Alignment.Center
        ) { Text("+", color = Color(0xFFB4BCCB), fontSize = 28.sp, fontWeight = FontWeight.Light) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Adicionar Novo Jogo", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, maxLines = 1)
            Text("Cadastre um jogo, app ou site", color = Color(0xFFB4BCCB), fontSize = 12.sp, maxLines = 1)
        }
    }
}

// ---------- TV: escolha do modo de visualização (olho) ----------
@Composable
internal fun MainActivity.ViewModeDialog() {
    val accent = parseColor(accentHex)
    val names = listOf("Padrão", "Carrossel", "Grade", "Lista")
    val descs = listOf(
        "Capas em fila, uma ao lado da outra",
        "A capa do centro fica selecionada, com efeito de carrossel",
        "Várias capas por tela, como no celular em pé",
        "Cartões com capa e informações. A abre o jogo; direita abre Detalhes"
    )
    val icons = listOf(R.drawable.ic_view_standard, R.drawable.ic_view_carousel, R.drawable.ic_view_grid, R.drawable.ic_view_list)
    NexusModal("Visualização", { back() }) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val shape = RoundedCornerShape(rBtn.dp)
            for (i in 0..3) {
                val cur = tvView == i
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (cur) accent.copy(alpha = 0.16f) else Color(0xFF1A1E29))
                        .border(1.dp, if (cur) accent else Color(0x1FFFFFFF), shape)
                        .initialFocus(cur)
                        .clickable {
                            applyTvView(i)
                            overlay = Overlay.None
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // ícones em máscara transparente, pintados com a cor de destaque escolhida
                    Box(Modifier.width(54.dp), contentAlignment = Alignment.CenterStart) {
                        Image(
                            painter = painterResource(icons[i]),
                            contentDescription = names[i],
                            contentScale = ContentScale.Fit,
                            colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(accent),
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text(names[i], color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        Text(descs[i], color = Color(0xFF8A93A6), fontSize = 11.sp)
                    }
                    if (cur) Text("✓", color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.PlatformImageDialog(name: String) {
    var url by remember { mutableStateOf(platforms.firstOrNull { it.name == name }?.image ?: "") }
    val accent = parseColor(accentHex)
    val panel = RoundedCornerShape(rPanel.dp)
    val danger = Color(0xFFFF6B81)
    Dialog(
        onDismissRequest = { popOverlay() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .widthIn(max = 620.dp)
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                    .padding(horizontal = 14.dp, vertical = if (landscape) 8.dp else 12.dp)
            ) {
                val pasteBtn: @Composable (Modifier) -> Unit = { m ->
                    EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), m) {
                        val t = clipboardText().trim()
                        if (t.isNotEmpty()) url = t else toast("Área de transferência vazia")
                    }
                }
                val clearBtn: @Composable (Modifier) -> Unit = { m ->
                    EBtn("Limpar", "✕", S_FIELD, S_LINE, Color(0xFFE2E6EF), m) { url = "" }
                }
                val siteBtn: @Composable (Modifier) -> Unit = { m ->
                    EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), m) { openSteamGrid(name) }
                }
                val pickBtn: @Composable (Modifier) -> Unit = { m ->
                    EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), m) {
                        openSgdbPicker("Imagem: $name", name, true) { u -> url = u }
                    }
                }
                if (landscape) {
                    // Paisagem: cabeçalho numa linha, tudo compacto para caber sem corte.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                        Spacer(Modifier.width(6.dp))
                        ELabel("IMAGEM DA PLATAFORMA")
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f)) { MarqueeText(name, Color.White, 16, FontWeight.ExtraBold) }
                    }
                    Spacer(Modifier.height(6.dp))
                    SCard(pad = 8.dp) {
                        Row {
                            CoverThumb(url, name, name, "", Modifier.width(46.dp).height(70.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                PillField("LINK DA IMAGEM", url, { url = it }, "Cole a URL da imagem...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, 3.dp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    pasteBtn(Modifier.weight(1f))
                                    clearBtn(Modifier.weight(1f))
                                    siteBtn(Modifier.weight(1f))
                                    pickBtn(Modifier.weight(1.2f))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Sem imagem, o cartão mostra só o nome.",
                            color = S_MUTED, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.widthIn(min = 120.dp)) { popOverlay() }
                        Spacer(Modifier.width(8.dp))
                        EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.widthIn(min = 120.dp)) {
                            savePlatformImage(name, url)
                            overlay = Overlay.None
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                        Spacer(Modifier.width(6.dp))
                        ELabel("IMAGEM DA PLATAFORMA")
                    }
                    Spacer(Modifier.height(2.dp))
                    MarqueeText(name, Color.White, 18, FontWeight.ExtraBold)
                    Spacer(Modifier.height(10.dp))
                    SCard(pad = 10.dp) {
                        Row {
                            CoverThumb(url, name, name, "", Modifier.width(52.dp).height(82.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                PillField("LINK DA IMAGEM", url, { url = it }, "Cole a URL da imagem...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, 6.dp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    pasteBtn(Modifier.weight(1f))
                                    clearBtn(Modifier.weight(1f))
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            siteBtn(Modifier.weight(1f))
                            pickBtn(Modifier.weight(1f))
                        }
                    }
                    Text(
                        "Sem imagem, o cartão da plataforma mostra só o nome.",
                        color = S_MUTED, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 2.dp, vertical = 8.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { popOverlay() }
                        EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                            savePlatformImage(name, url)
                            overlay = Overlay.None
                        }
                    }
                }
            }
        }
    }
}

// ---------- Capas ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MainActivity.GameCard(g: Game, selected: Boolean, recent: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f, grid: Boolean = false) {
    val shape = RoundedCornerShape(radius.dp)
    val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scale")
    val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glow")
    val underline = showUnderline(selected)
    val nav = FocusStyle.navColor
    Box(
        modifier = modifier
            .zIndex(if (selected) 1f else 0f)
            .aspectRatio(0.69f)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                if (underline) {
                    // 4.9.3: sublinhado fino, do tamanho da capa, na cor de navegação (a mesma dos botões em foco).
                    val t = 3.dp.toPx()
                    drawRoundRect(
                        nav, topLeft = Offset(0f, size.height + 4.dp.toPx()),
                        size = Size(size.width, t), cornerRadius = CornerRadius(t / 2f)
                    )
                }
            }
            .clip(shape)
            .background(Color(0xFF13161E))
            .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
            .catalogFocus()
            .combinedClickable(
                onClick = { selectedId = g.id },
                onLongClick = {
                    selectedId = g.id
                    overlay = Overlay.Info(g.id)
                }
            )
    ) {
        // 4.9.0: o ícone do app Android é decodificado em segundo plano (antes travava a rolagem na 1ª vez).
        val isApp = g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()
        val iconState by produceState<ImageBitmap?>(if (isApp) cachedBigIcon(g.pkg) else null, g.pkg, isApp) {
            if (isApp && value == null) value = withContext(Dispatchers.Default) { bigIconFor(g.pkg) }
        }
        val appIcon: ImageBitmap? = iconState
        if (appIcon != null) {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    bitmap = appIcon, contentDescription = g.title,
                    modifier = Modifier.fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        } else {
            Text(
                g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(10.dp)
            )
        }
        if (g.cover.isNotBlank()) {
            // 4.9.12: só a capa em foco anima (e só sem nenhuma tela por cima).
            val anim = selected && overlay is Overlay.None && coverAnimates(g)
            val req = remember(g.cover, anim) { Covers.request(this@GameCard, g.cover, anim) }
            key(coverRev) {
                AsyncImage(
                    model = req, imageLoader = Covers.loaderFor(anim), contentDescription = g.title,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
            // 4.9.14: capa animada em APNG: a biblioteca toca por cima do 1º quadro.
            if (anim && isApngUrl(g.cover)) ApngPlayer(g.cover, Modifier.fillMaxSize())
        }
        // 4.8.0: etiqueta + ícones num layout só (NxCardBadges, em NxIcons.kt).
        //  Grade e celular em pé: ícones (12 dp) acima da etiqueta, à direita. Padrão e Carrossel: ícones na linha da etiqueta
        //  (mesma altura dela) no canto esquerdo; se a etiqueta for grande demais, sobem para cima dela.
        val maskBg = if (g.maskPlatform.isNotEmpty() && g.maskColor.isNotEmpty()) parseColor(g.maskColor) else null
        NxCardBadges(
            inlineWhenFits = !grid, hasHour = recent, hasStar = g.isFavorite,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                g.shownPlatform.uppercase(),
                color = if (maskBg != null) onAccent(maskBg) else Color(0xFFF1F5F9), fontSize = 8.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp, maxLines = 1, softWrap = false,
                lineHeight = 8.sp, style = TextStyle(lineHeightStyle = CenteredLine),
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(maskBg ?: Color(0xD9000000))
                    .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                    .height(18.dp)
                    .wrapContentHeight(Alignment.CenterVertically)
                    .padding(horizontal = 6.dp)
            )
            if (recent) NxHourglass(accent, styleIdx, Modifier.fillMaxSize())
            if (g.isFavorite) NxStar(accent, styleIdx, Modifier.fillMaxSize())
        }
        // 4.9.18: atalho de jogo (ex.: GameHub) perdido: selo "!" no canto superior direito.
        if (pinLost(g)) {
            Text(
                "!", color = Color(0xFF1A1300), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(20.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFFC53D))
                    .wrapContentHeight(Alignment.CenterVertically)
            )
        }
    }
}

@Composable
internal fun MainActivity.AddTile(selected: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f) {
    val shape = RoundedCornerShape(radius.dp)
    val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scaleAdd")
    val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowAdd")
    val underline = showUnderline(selected)
    val nav = FocusStyle.navColor
    Box(
        modifier = modifier
            .zIndex(if (selected) 1f else 0f)
            .aspectRatio(0.69f)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .drawBehind {
                drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                if (underline) {
                    // 4.9.3: sublinhado fino, do tamanho da capa, na cor de navegação (a mesma dos botões em foco).
                    val t = 3.dp.toPx()
                    drawRoundRect(
                        nav, topLeft = Offset(0f, size.height + 4.dp.toPx()),
                        size = Size(size.width, t), cornerRadius = CornerRadius(t / 2f)
                    )
                }
            }
            .clip(shape)
            .background(Color(0xCC14171F))
            .then(
                if (selected) Modifier.border(2.2.dp, accent, shape)
                else Modifier.drawBehind {
                    val sw = 1.5.dp.toPx()
                    drawRoundRect(
                        Color(0x3DFFFFFF),
                        topLeft = Offset(sw / 2, sw / 2),
                        size = Size(size.width - sw, size.height - sw),
                        cornerRadius = CornerRadius(radius.dp.toPx()),
                        style = Stroke(
                            width = sw,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 7.dp.toPx()))
                        )
                    )
                }
            )
            .catalogFocus()
            .clickable {
                if (selectedId == ADD_ID) openAdd() else selectedId = ADD_ID
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0x0FFFFFFF))
                    .border(1.dp, Color(0x26FFFFFF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+", color = Color(0xFFE2E8F0), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Adicionar", color = if (selected) Color.White else Color(0xFF94A3B8),
                fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
            )
        }
    }
}
