package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Configurações (redesign 3.9.6: retrato sem rolagem + paisagem dedicada) ----------
@Composable
internal fun MainActivity.SLabel(text: String, color: Color = S_MUTED, modifier: Modifier = Modifier, compact: Boolean = false) {
    Text(
        text, color = color, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp, modifier = modifier
    )
}

/** Texto de uma linha com altura de linha justa (o padrão do tema deixa o espaço entre linhas enorme). */
@Composable
internal fun MainActivity.LTxt(
    text: String, size: Float, color: Color, weight: FontWeight = FontWeight.Normal,
    spacing: Float = 0f, modifier: Modifier = Modifier
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight, letterSpacing = spacing.sp,
        maxLines = 1, softWrap = false, lineHeight = (size * 1.25f).sp,
        style = TextStyle(lineHeightStyle = CenteredLine), modifier = modifier
    )
}

/** Cartão da aba Visual em paisagem: conteúdo centralizado na altura disponível. */
@Composable
internal fun MainActivity.LCard(
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(rCard.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .padding(horizontal = 13.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.Center,
        content = content
    )
}

/** Linha de título do cartão: nome à esquerda, valor atual na cor de destaque à direita. */
@Composable
internal fun MainActivity.LHead(label: String, value: String, accent: Color) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        LTxt(label, 10.5f, S_MUTED, FontWeight.Bold, 0.8f, Modifier.weight(1f))
        LTxt(value, 11f, accent, FontWeight.SemiBold)
    }
}

/** Barra de tamanho: trilho fino, parte preenchida grossa e bolinha com borda branca. */
@Composable
internal fun MainActivity.LSlider(
    value: Int, lo: Int, hi: Int, accent: Color,
    onChange: (Int) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier
) {
    val frac = ((value - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)
    val thumb = 14.dp
    val sliderKeyMs = remember { LongArray(2) }
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    val shape = RoundedCornerShape(12.dp)
    BoxWithConstraints(
        modifier = modifier
            .height(28.dp)
            .clip(shape)
            .focusGlow(shape)
            .onPreviewKeyEvent { ev ->
                val k = ev.nativeKeyEvent
                if (k.action == android.view.KeyEvent.ACTION_DOWN &&
                    (k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT || k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT)
                ) {
                    // 4.9.5: passos de 10 que aceleram enquanto a direção fica apertada (10, 20, 30... até 60).
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - sliderKeyMs[0] < 260L) sliderKeyMs[1]++ else sliderKeyMs[1] = 0L
                    sliderKeyMs[0] = now
                    val step = (10 * (1 + (sliderKeyMs[1] / 4).toInt())).coerceAtMost(60)
                    val d = if (k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT) -step else step
                    change((value + d).coerceIn(lo, hi))
                    done()
                    true
                } else false
            }
            .focusable()
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    val tp = thumb.toPx()
                    val f = ((off.x - tp / 2f) / (size.width - tp).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    change((lo + f * (hi - lo)).roundToInt())
                    done()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(onDragEnd = { done() }, onDragCancel = { done() }) { c, _ ->
                    c.consume()
                    val tp = thumb.toPx()
                    val f = ((c.position.x - tp / 2f) / (size.width - tp).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    change((lo + f * (hi - lo)).roundToInt())
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        val travel = maxWidth - thumb
        Box(Modifier.fillMaxWidth().height(2.dp).clip(CircleShape).background(Color(0xFF334155)))
        Box(Modifier.width(travel * frac + thumb / 2).height(6.dp).clip(CircleShape).background(accent))
        Box(
            Modifier
                .offset(x = travel * frac)
                .size(thumb)
                .shadow(6.dp, CircleShape, ambientColor = accent, spotColor = accent)
                .clip(CircleShape)
                .background(accent)
                .border(2.dp, Color.White, CircleShape)
        )
    }
}

@Composable
internal fun MainActivity.SCard(
    modifier: Modifier = Modifier, pad: Dp = 14.dp,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(rCard.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .padding(pad),
        content = content
    )
}

@Composable
internal fun MainActivity.SChip(text: String, accent: Color) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.45f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun MainActivity.SSwitch(on: Boolean, accent: Color) {
    Box(
        modifier = Modifier
            .width(48.dp)
            .height(28.dp)
            .clip(CircleShape)
            .background(if (on) accent else Color(0xFF2A2F3D))
            .border(2.dp, if (on) accent else Color(0xFF4B5267), CircleShape)
            .padding(horizontal = 4.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .size(if (on) 18.dp else 16.dp)
                .clip(CircleShape)
                .background(if (on) Color(0xFF080A0F) else S_MUTED)
        )
    }
}

@Composable
internal fun MainActivity.Swatch(hex: String, size: Dp = 44.dp, tight: Boolean = false) {
    val sel = accentHex.equals(hex, true)
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .focusGlow(CircleShape)
            .clickable {
                accentHex = hex
                savePrefs()
            },
        contentAlignment = Alignment.Center
    ) {
        if (sel) Box(Modifier.size(size - 2.dp).border(2.dp, Color.White, CircleShape))
        Box(
            Modifier.size(if (sel) size - (if (tight) 8.dp else 10.dp) else size - (if (tight) 2.dp else 6.dp))
                .clip(CircleShape).background(parseColor(hex))
        )
    }
}

@Composable
internal fun MainActivity.CatalogTile(
    glyph: String, title: String, sub: String, count: Int, modifier: Modifier,
    compact: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(rCard.dp)
    if (compact) {
        Row(
            modifier = modifier
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape).background(S_FIELD),
                contentAlignment = Alignment.Center
            ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = 14.sp) }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                MarqueeText(title, Color.White, 13)
                MarqueeText(sub, S_MUTED, 10, FontWeight.Normal)
            }
            Spacer(Modifier.width(6.dp))
            Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 8.dp, vertical = 3.dp)) {
                Text("$count", color = S_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            }
        }
        return
    }
    Column(
        modifier = modifier
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .height(128.dp)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(34.dp).clip(CircleShape).background(S_FIELD),
                contentAlignment = Alignment.Center
            ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 10.dp, vertical = 3.dp)) {
                Text("$count", color = S_MUTED, fontSize = if (compact) 12.sp else 13.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column {
            MarqueeText(title, Color.White, 15)
            MarqueeText(sub, S_MUTED, 11, FontWeight.Normal)
        }
    }
}

@Composable
internal fun MainActivity.ActionRow(
    glyph: String, title: String, sub: String,
    bg: Color, border: Color, iconBg: Color, iconFg: Color,
    titleColor: Color = Color.White, chevron: Boolean = true,
    modifier: Modifier = Modifier, compact: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(rCard.dp)
    val ib = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = if (compact) 12.dp else 14.dp, vertical = if (compact) 4.dp else 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(if (compact) 34.dp else 44.dp).clip(ib).background(iconBg),
            contentAlignment = Alignment.Center
        ) { Text(glyph, color = iconFg, fontSize = if (compact) 17.sp else 20.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = titleColor, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.Bold,
                lineHeight = if (compact) 16.sp else 19.sp, style = TextStyle(lineHeightStyle = CenteredLine))
            Text(sub, color = S_MUTED, fontSize = if (compact) 10.sp else 12.sp,
                lineHeight = if (compact) 13.sp else 15.sp, style = TextStyle(lineHeightStyle = CenteredLine))
        }
        if (chevron) {
            Spacer(Modifier.width(8.dp))
            Text("›", color = parseColor(accentHex), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun MainActivity.PadHint(letter: String, label: String, color: Color, compact: Boolean = false, onClick: (() -> Unit)?) {
    // Mesmo tamanho dos botões do rodapé da tela inicial (PadButton).
    val shape = RoundedCornerShape(rBtn.dp)
    val fg = when (letter) {
        "Y" -> Color(0xFF1A1202)
        "A" -> Color(0xFF05140B)
        else -> Color.White
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(26.dp)
            .clip(shape)
            .background(Color(0xEB161A23))
            .border(1.dp, Color(0x17FFFFFF), shape)
            .focusGlow(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp)
    ) {
        Box(
            modifier = Modifier.size(16.dp).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                letter, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 9.5.sp,
                lineHeight = 9.5.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            label, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false,
            lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
        )
    }
}

@Composable
internal fun MainActivity.KeyCap(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(5.dp)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(Color(0x1AFFFFFF))
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 1.dp)
    ) { Text(label, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold) }
}

@Composable
internal fun MainActivity.LRHint() {
    val shape = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = Modifier
            .height(26.dp)
            .clip(shape)
            .background(Color(0xEB161A23))
            .border(1.dp, Color(0x17FFFFFF), shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        KeyCap("L1") { settingsTab = (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS }
        Spacer(Modifier.width(4.dp))
        KeyCap("R1") { settingsTab = (settingsTab + 1) % SETTINGS_TABS }
        Spacer(Modifier.width(6.dp))
        Text("Abas", color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------- Aba Extras (4.3.0) ----------
@Composable
internal fun MainActivity.SwitchCard(
    glyph: String, title: String, sub: String, on: Boolean, compact: Boolean,
    modifier: Modifier = Modifier, enabled: Boolean = true, iconRes: Int? = null, onToggle: () -> Unit
) {
    val accent = parseColor(accentHex)
    val card = RoundedCornerShape(rCard.dp)
    val btn = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .clip(card)
            .background(S_CARD)
            .border(1.dp, S_LINE, card)
            .focusGlow(card)
            .clickable(enabled = enabled, onClick = onToggle)
            .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 6.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(if (compact) 30.dp else 44.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
            contentAlignment = Alignment.Center
        ) {
            if (iconRes != null) {
                Image(
                    painter = painterResource(iconRes), contentDescription = null, contentScale = ContentScale.Fit,
                    colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(accent),
                    modifier = Modifier.size(if (compact) 20.dp else 28.dp)
                )
            } else Text(
                glyph, fontSize = if (compact) 14.sp else 19.sp,
                lineHeight = if (compact) 16.sp else 24.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(if (compact) 10.dp else 12.dp))
        if (compact) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                LTxt(title, 11.5f, Color.White, FontWeight.Bold)
                LTxt(sub, 9.5f, S_MUTED)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(20.dp)
                    .clip(CircleShape)
                    .background(if (on) accent else Color(0xFF242C3D))
                    .padding(2.dp),
                contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Box(Modifier.size(16.dp).clip(CircleShape).background(if (on) Color.White else Color(0xFF94A3B8)))
            }
        } else {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(sub, color = S_MUTED, fontSize = 12.sp, maxLines = 2)
            }
            Spacer(Modifier.width(12.dp))
            SSwitch(on, accent)
        }
    }
}

@Composable
internal fun MainActivity.DangerButton(label: String, bg: Color, rkey: String = "", onClick: () -> Unit) {
    val btn = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .then(if (rkey.isNotEmpty()) Modifier.returnFocus(rkey) else Modifier)
            .clip(btn)
            .background(bg)
            .focusGlow(btn)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
}
