package com.nexus.launcher

import android.view.KeyEvent
import androidx.compose.foundation.Indication
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable as foundationClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.node.ModifierNodeElement
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Destaque de foco do Nexus (4.6.0).
 * Em TODO lugar por onde o D-pad do controle remoto ou o direcional/alavanca do gamepad passa, o item fica
 * com borda e fundo na cor de destaque. Isso vale para qualquer `.clickable`: este arquivo define um `clickable`
 * no pacote do app, que tem prioridade sobre o do Compose porque os arquivos não importam o original.
 */
object FocusStyle {
    /** Cor de destaque (a mesma escolhida nas configurações). Atualizada pela tela principal. */
    var accent by mutableStateOf(Color(0xFF0A84FF))

    /** Raio padrão dos cantos do destaque (acompanha o estilo de bordas escolhido). */
    var radiusDp by mutableStateOf(10f)
}

/** Marca "este item já desenha o próprio anel de foco": o `clickable` não desenha outro por cima. */
private object OwnRingElement : ModifierNodeElement<OwnRingNode>() {
    override fun create(): OwnRingNode = OwnRingNode()
    override fun update(node: OwnRingNode) {}
    override fun hashCode(): Int = 7
    override fun equals(other: Any?): Boolean = other === this
}

private class OwnRingNode : Modifier.Node()

internal fun Modifier.ownRing(): Modifier = this.then(OwnRingElement)

private fun Modifier.hasOwnRing(): Boolean = this.any { it === OwnRingElement }

/** Anel de foco padrão: fundo suave + borda na cor de destaque, desenhado por cima do conteúdo. */
internal fun Modifier.focusRing(): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val accent = FocusStyle.accent
    val radius = FocusStyle.radiusDp
    this
        .onFocusChanged { focused = it.isFocused }
        .drawWithContent {
            drawContent()
            if (focused) {
                val sw = 3.dp.toPx()
                val r = radius.dp.toPx().coerceAtMost(size.minDimension / 2f)
                drawRoundRect(accent.copy(alpha = 0.20f), cornerRadius = CornerRadius(r))
                drawRoundRect(
                    accent,
                    topLeft = Offset(sw / 2f, sw / 2f),
                    size = Size((size.width - sw).coerceAtLeast(1f), (size.height - sw).coerceAtLeast(1f)),
                    cornerRadius = CornerRadius((r - sw / 2f).coerceAtLeast(0f)),
                    style = Stroke(width = sw)
                )
            }
        }
}

/** `clickable` do Nexus: igual ao do Compose, mais o destaque de foco para controle/controle remoto. */
fun Modifier.clickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier {
    val base = if (hasOwnRing()) this else this.focusRing()
    return base.foundationClickable(enabled = enabled, onClickLabel = onClickLabel, role = role, onClick = onClick)
}

/**
 * Versão sem efeito visual (usada em telas de fundo que só "pegam" o toque).
 * Essas áreas grandes não devem receber o foco do D-pad.
 */
fun Modifier.clickable(
    interactionSource: MutableInteractionSource,
    indication: Indication?,
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier = this
    .focusProperties { canFocus = false }
    .foundationClickable(
        interactionSource = interactionSource, indication = indication, enabled = enabled,
        onClickLabel = onClickLabel, role = role, onClick = onClick
    )

/** Destaque fixo (estado controlado por código, usado no cabeçalho e no rodapé da tela inicial). */
fun Modifier.navHighlight(on: Boolean, shape: androidx.compose.ui.graphics.Shape): Modifier =
    if (on) this.border(3.dp, FocusStyle.accent, shape) else this

// ---------- Caixas de texto na TV ----------

/**
 * Estado de uma caixa de texto na TV. O D-pad do controle remoto só SELECIONA a caixa;
 * o teclado do Chromecast só abre quando o usuário aperta OK.
 */
class TvEdit {
    /** A caixa está com o destaque do D-pad (ou sendo editada). */
    var selected by mutableStateOf(false)
    var editing by mutableStateOf(false)
    val input = FocusRequester()
}

@Composable
fun rememberTvEdit(): TvEdit = remember { TvEdit() }

/**
 * Na TV: a área do texto vira um item focável; OK entra em modo de edição (abre o teclado).
 * O destaque é desenhado pela própria caixa, lendo [TvEdit.selected]. Fora da TV não muda nada.
 */
@Composable
fun Modifier.tvFieldBox(edit: TvEdit): Modifier {
    if (!TvMode.isTv) return this
    val kb = LocalSoftwareKeyboardController.current
    LaunchedEffect(edit.editing) {
        if (edit.editing) {
            delay(60)
            try {
                edit.input.requestFocus()
            } catch (_: Exception) {
            }
            delay(60)
            kb?.show()
        }
    }
    return this
        .onFocusChanged { edit.selected = it.hasFocus }
        .foundationClickable { edit.editing = true }
}

/**
 * Na TV: o campo de texto em si só aceita foco depois que o usuário apertou OK na caixa;
 * OK de novo (com o teclado fechado) reabre o teclado; sair do campo encerra a edição.
 */
@Composable
fun Modifier.tvFieldInput(edit: TvEdit): Modifier {
    if (!TvMode.isTv) return this
    val kb = LocalSoftwareKeyboardController.current
    return this
        .focusRequester(edit.input)
        .focusProperties { canFocus = edit.editing }
        .onFocusChanged { if (!it.isFocused) edit.editing = false }
        .onPreviewKeyEvent { ev ->
            val n = ev.nativeKeyEvent
            if (n.keyCode == KeyEvent.KEYCODE_DPAD_CENTER && n.action == KeyEvent.ACTION_DOWN && n.repeatCount == 0) {
                kb?.show()
            }
            false
        }
}
