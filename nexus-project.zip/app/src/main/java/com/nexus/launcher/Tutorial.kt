package com.nexus.launcher

// 4.9.13: tutorial do Nexus (só celular e tablet; a TV não mostra). Tudo do tutorial fica neste arquivo.
// - Módulos com ✓ verde quando concluídos; o progresso é salvo e vale para celular em pé e deitado.
// - Boas-vindas na primeira abertura (biblioteca vazia): Fazer o tutorial / Adicionar jogos agora / Agora não.
// - Abre pelo botão "?" (Configurações > ?) > Tutorial. "Refazer tutorial" zera os ✓.

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// Conteúdo
// ---------------------------------------------------------------------------------------------

/** Desenho de apoio de cada passo (miniaturas feitas com o próprio Compose, sem imagens). */
internal sealed class TutVisual {
    /** Caminho de toques: "START" → "Adicionar novo jogo" → ... */
    class Flow(val steps: List<String>) : TutVisual()
    /** Cabeçalho do Nexus com um botão destacado: "START", "SELECT", "?", "⚙", "👁". */
    class Header(val highlight: String) : TutVisual()
    /** Dois cartões lado a lado, um deles marcado. */
    class TwoCards(val a: String, val b: String, val pick: Int) : TutVisual()
    /** Lista com caixinhas marcadas. */
    class Checklist(val items: List<String>, val checked: Int) : TutVisual()
    /** Grade de capas; [sel] é a capa em foco (a que anima, se for animada). */
    class Grid(val sel: Int, val animated: Boolean = false) : TutVisual()
    /** Abas lado a lado, uma marcada. */
    class Tabs(val names: List<String>, val sel: Int) : TutVisual()
    /** Um símbolo grande. */
    class Big(val glyph: String) : TutVisual()
}

internal class TutPage(val title: String, val text: String, val visual: TutVisual, val tip: String = "")

internal class TutModule(val id: String, val glyph: String, val title: String, val sub: String, val pages: List<TutPage>)

internal val TUT_MODULES: List<TutModule> = listOf(
    TutModule(
        "lote", "📦", "Adicionar jogos em lote", "Pastas inteiras de uma vez",
        listOf(
            TutPage(
                "Abra o botão START",
                "No cabeçalho, toque em START e depois em \"Adicionar novo jogo\".",
                TutVisual.Header("START"),
                "Pelo controle, o botão START do controle faz o mesmo."
            ),
            TutPage(
                "Escolha \"Em lote\"",
                "\"Em lote\": você escolhe a plataforma e as pastas, e o Nexus encontra os jogos de uma vez.",
                TutVisual.TwoCards("Manualmente", "Em lote", 1)
            ),
            TutPage(
                "Plataforma, emulador e pastas",
                "Escolha a plataforma e o app (emulador) que abre os jogos. Depois toque em \"Adicionar pasta\" para cada pasta com os arquivos dos jogos.",
                TutVisual.Flow(listOf("Plataforma", "Emulador", "+ Adicionar pasta")),
                "Se o Android pedir acesso aos arquivos, permita. É só para o Nexus ler os nomes dos jogos."
            ),
            TutPage(
                "Varredura e lista",
                "O Nexus varre as pastas e mostra os jogos achados. Marque os que você quer (\"Todos\" e \"Nenhum\" ajudam) e confirme.",
                TutVisual.Checklist(listOf("Jogo A", "Jogo B", "Jogo C", "Jogo D"), 3),
                "Pode minimizar a varredura: ela continua e avisa na notificação."
            ),
            TutPage(
                "Pronto!",
                "Os jogos aparecem na tela inicial. Para colocar capas em todos de uma vez, veja o módulo \"Capas\".",
                TutVisual.Big("✓")
            )
        )
    ),
    TutModule(
        "manual", "✍", "Adicionar um jogo manualmente", "Um jogo por vez",
        listOf(
            TutPage(
                "START > Adicionar novo jogo",
                "Toque em START, depois em \"Adicionar novo jogo\" e escolha \"Manualmente\".",
                TutVisual.Flow(listOf("START", "Adicionar novo jogo", "Manualmente"))
            ),
            TutPage(
                "Título e plataforma",
                "Digite o título e escolha a plataforma. Quanto mais parecido com o nome real do jogo, melhor a busca de capa e de vídeo.",
                TutVisual.TwoCards("Título", "Plataforma", 0)
            ),
            TutPage(
                "Como o jogo abre",
                "Escolha o arquivo da ROM, o app do jogo ou o emulador (o campo muda conforme a plataforma). É isso que abre quando você toca em \"Jogar\".",
                TutVisual.Flow(listOf("Arquivo ROM", "Emulador", "Jogar"))
            ),
            TutPage(
                "Gêneros e coleções",
                "Marque até 3 gêneros e as coleções do jogo (ex.: \"Quero jogar\"). Eles alimentam o filtro SELECT.",
                TutVisual.Checklist(listOf("Ação", "Aventura", "Corrida"), 2)
            ),
            TutPage(
                "Capa e salvar",
                "Escolha a capa no SteamGridDB (ou cole um link) e toque em Salvar. O jogo aparece na tela inicial.",
                TutVisual.Grid(0)
            )
        )
    ),
    TutModule(
        "capas", "🖼", "Capas e capas animadas", "SteamGridDB, lote e animadas",
        listOf(
            TutPage(
                "Chave do SteamGridDB",
                "Para buscar capas, crie uma chave grátis no site do SteamGridDB e cole em Configurações > Biblioteca > SteamGridDB. Só precisa fazer uma vez.",
                TutVisual.Flow(listOf("⚙ Configurações", "Biblioteca", "SteamGridDB"))
            ),
            TutPage(
                "Escolher capa de um jogo",
                "No editor do jogo, toque em \"Escolher capa\". Toque na imagem que você quer. A capa fica guardada no aparelho (funciona sem internet).",
                TutVisual.Tabs(listOf("Estáticas", "Animadas"), 0)
            ),
            TutPage(
                "Capas animadas",
                "Na aba \"Animadas\" as capas aparecem paradas. Toque numa capa para ver a animação e use o botão \"Usar esta capa\" para escolher. Só a escolhida fica guardada no aparelho. Na tela inicial só a capa em foco anima, e nos Detalhes ela sempre anima.",
                TutVisual.Grid(1, animated = true),
                "Para desligar: Configurações > Extras > \"Animar capas escolhidas\"."
            ),
            TutPage(
                "Capas em lote",
                "Em Configurações > Biblioteca, \"Capas em lote\" procura a capa estática de todos os jogos que ainda não têm uma. As que você já tem nunca são trocadas.",
                TutVisual.Checklist(listOf("Jogo A", "Jogo B", "Jogo C"), 3)
            )
        )
    ),
    TutModule(
        "visual", "👁", "Visualizações da tela inicial", "Grade, lista, carrossel e tamanhos",
        listOf(
            TutPage(
                "Celular em pé: a grade",
                "Em pé, as capas aparecem em grade. O tamanho das capas muda em Configurações > Visual.",
                TutVisual.Grid(0)
            ),
            TutPage(
                "Celular deitado: o botão do olho",
                "Com o celular deitado aparece o botão do olho no cabeçalho. Ele troca entre Padrão, Carrossel, Grade e Lista.",
                TutVisual.Header("👁")
            ),
            TutPage(
                "Aparência",
                "Em Configurações > Visual você muda a cor de destaque, os cantos arredondados e o tamanho das capas. Em Extras, liga e desliga a animação de abertura.",
                TutVisual.Tabs(listOf("Visual", "Biblioteca", "Sistema", "Extras"), 0)
            )
        )
    ),
    TutModule(
        "filtros", "🔎", "Filtros, pesquisa e coleções", "Achar jogos rápido",
        listOf(
            TutPage(
                "O botão SELECT",
                "SELECT abre os filtros: só favoritos, plataforma, gênero, coleção e a ordem da lista. Os filtros ficam salvos até você tocar em \"Remover Filtros\".",
                TutVisual.Header("SELECT"),
                "Com um filtro ativo, aparece um \"i\" vermelho no SELECT (celular em pé) ou \"Filtro ativo\" no rodapé (deitado)."
            ),
            TutPage(
                "Pesquisar",
                "A pesquisa de texto procura pelo título. Ela não fica salva: ao fechar o app, volta vazia.",
                TutVisual.Big("🔎")
            ),
            TutPage(
                "Coleções",
                "Crie suas coleções em Configurações > Biblioteca > Coleções e marque os jogos nelas pelo editor. As coleções aparecem em ordem alfabética.",
                TutVisual.Checklist(listOf("Clássicos", "Jogando agora", "Quero jogar"), 1)
            )
        )
    ),
    TutModule(
        "detalhes", "▶", "Detalhes, vídeo e favoritos", "O que dá para fazer com um jogo",
        listOf(
            TutPage(
                "Detalhes do jogo",
                "Toque na capa para abrir os Detalhes. Lá estão o botão \"Jogar\", o favorito, as coleções e as informações do jogo.",
                TutVisual.Grid(0)
            ),
            TutPage(
                "Vídeo de gameplay",
                "Os Detalhes mostram um vídeo de gameplay do YouTube (precisa da chave do YouTube em Configurações > Biblioteca).",
                TutVisual.Big("▶")
            ),
            TutPage(
                "Backup",
                "Em Configurações > Biblioteca, \"Exportar backup\" salva a biblioteca, as configurações e os vínculos. Faça um antes de trocar de aparelho ou reinstalar.",
                TutVisual.Flow(listOf("⚙ Configurações", "Biblioteca", "Exportar backup"))
            )
        )
    )
)

// ---------------------------------------------------------------------------------------------
// Progresso (salvo nas preferências; vale para qualquer orientação)
// ---------------------------------------------------------------------------------------------

internal fun MainActivity.loadTutorial() {
    tutDone = (prefs.getString("tutDone", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
}

internal fun MainActivity.tutMarkDone(id: String) {
    tutDone = tutDone + id
    prefs.edit().putString("tutDone", tutDone.joinToString(",")).apply()
}

internal fun MainActivity.tutReset() {
    tutDone = emptySet()
    prefs.edit().putString("tutDone", "").apply()
}

/** O tutorial existe só no celular e no tablet. */
internal val MainActivity.tutorialAvailable: Boolean get() = !TvMode.isTv

internal fun MainActivity.openTutorial() {
    tutOpenId = null
    tutPage = 0
    overlay = Overlay.Tutorial
}

// ---------------------------------------------------------------------------------------------
// Telas
// ---------------------------------------------------------------------------------------------

/** Boas-vindas (primeira abertura com a biblioteca vazia). */
@Composable
internal fun MainActivity.TutorialWelcomeDialog() {
    NexusModal("Bem-vindo ao Nexus", { overlay = Overlay.None }) {
        Text(
            "O Nexus organiza os seus jogos num catálogo de capas. Quer um passeio rápido ou prefere já adicionar jogos?",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        CButton("Fazer o tutorial", C_BLUE, Modifier.fillMaxWidth().initialFocus()) {
            overlay = Overlay.None
            openTutorial()
        }
        Spacer(Modifier.height(8.dp))
        CButton("Adicionar jogos agora", C_GRAY, Modifier.fillMaxWidth()) {
            overlay = Overlay.None
            overlay = Overlay.AddChoice(false)
        }
        Spacer(Modifier.height(8.dp))
        CButton("Agora não", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
        Spacer(Modifier.height(8.dp))
        Text(
            "O tutorial fica sempre em Configurações > ? > Tutorial.",
            color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Lista de módulos (com ✓) e, ao abrir um módulo, os passos dele. */
@Composable
internal fun MainActivity.TutorialDialog() {
    val accent = parseColor(accentHex)
    val soft = accent.copy(alpha = 0.14f)
    val green = Color(0xFF30D158)
    val openId = tutOpenId
    val mod = TUT_MODULES.firstOrNull { it.id == openId }
    // Ao trocar de módulo/passo o foco inicial é refeito (controle/teclado).
    RefocusOnStep((mod?.id ?: "") + ":" + tutPage)
    // Uma única janela para a lista e para os passos (trocar de uma para outra não recria a janela).
    NexusModal(mod?.title ?: "Tutorial", { back() }) {
        if (mod == null) {
            val done = TUT_MODULES.count { it.id in tutDone }
            Text(
                if (done == TUT_MODULES.size) "Tudo concluído! Você pode rever qualquer módulo quando quiser."
                else "$done de ${TUT_MODULES.size} módulos concluídos. Toque em um módulo para começar.",
                color = if (done == TUT_MODULES.size) green else Color(0xFFCBD2E0),
                fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            val firstPending = TUT_MODULES.firstOrNull { it.id !in tutDone }?.id ?: TUT_MODULES.first().id
            for (m in TUT_MODULES) {
                val ok = m.id in tutDone
                ActionRow(
                    if (ok) "✓" else m.glyph, m.title, m.sub,
                    bg = if (ok) green.copy(alpha = 0.10f) else S_CARD,
                    border = if (ok) green.copy(alpha = 0.55f) else S_LINE,
                    iconBg = if (ok) green else soft,
                    iconFg = if (ok) Color(0xFF06210F) else accent,
                    modifier = Modifier.initialFocus(m.id == firstPending)
                ) {
                    tutPage = 0
                    tutOpenId = m.id
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(2.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Refazer tutorial", C_GRAY, Modifier.weight(1f)) { tutReset() }
                CButton("Fechar", C_BLUE, Modifier.weight(1f)) { back() }
            }
        } else {
            val last = mod.pages.size - 1
            val i = tutPage.coerceIn(0, last)
            val pg = mod.pages[i]
            Text(
                "Passo ${i + 1} de ${mod.pages.size}",
                color = C_MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            // barra de progresso do módulo
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (k in 0..last) {
                    Box(
                        Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (k <= i) accent else Color(0x22FFFFFF))
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            TutVisualView(pg.visual, accent)
            Spacer(Modifier.height(10.dp))
            Text(pg.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text(pg.text, color = Color(0xFFCBD2E0), fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.fillMaxWidth())
            if (pg.tip.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.12f)).padding(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("💡", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(pg.tip, color = Color(0xFFE2E8F0), fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton(if (i == 0) "Lista" else "Anterior", C_GRAY, Modifier.weight(1f)) {
                    if (i == 0) tutOpenId = null else tutPage = i - 1
                }
                CButton(if (i == last) "Concluir ✓" else "Próximo", C_BLUE, Modifier.weight(1f).initialFocus()) {
                    if (i == last) {
                        tutMarkDone(mod.id)
                        tutOpenId = null
                        tutPage = 0
                    } else tutPage = i + 1
                }
            }
        }
    }
}

/** Página "Sobre o Nexus" (dentro de Configurações > ?). */
@Composable
internal fun MainActivity.AboutNexusPage() {
    Text("Nexus Launcher", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    Spacer(Modifier.height(4.dp))
    Text("Versão $APP_VERSION", color = C_MUTED, fontSize = 12.sp)
    Spacer(Modifier.height(10.dp))
    Text(
        "O Nexus funciona em celulares e tablets Android e em aparelhos Google TV e Fire OS.",
        color = Color(0xFFCBD2E0), fontSize = 13.sp, lineHeight = 18.sp
    )
}

// ---------------------------------------------------------------------------------------------
// Desenhos de apoio
// ---------------------------------------------------------------------------------------------

@Composable
private fun MainActivity.TutChip(text: String, accent: Color, on: Boolean = false) {
    val shape = RoundedCornerShape(8.dp)
    Text(
        text,
        color = if (on) onAccent(accent) else Color(0xFFE2E8F0),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .background(if (on) accent else Color(0xFF232838))
            .border(1.dp, if (on) accent else Color(0x26FFFFFF), shape)
            .padding(horizontal = 9.dp, vertical = 6.dp)
    )
}

@Composable
internal fun MainActivity.TutVisualView(v: TutVisual, accent: Color) {
    val frame = RoundedCornerShape(14.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(frame)
            .background(Color(0xFF0F121A))
            .border(1.dp, Color(0x1FFFFFFF), frame)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        when (v) {
            is TutVisual.Flow -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                v.steps.forEachIndexed { k, s ->
                    TutChip(s, accent, on = k == v.steps.size - 1)
                    if (k < v.steps.size - 1) Text("↓", color = C_MUTED, fontSize = 14.sp)
                }
            }
            is TutVisual.Header -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (n in listOf("👁", "SELECT", "START", "⚙")) {
                    TutChip(n, accent, on = n == v.highlight)
                }
                if (v.highlight == "?") TutChip("?", accent, on = true)
            }
            is TutVisual.TwoCards -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for ((k, n) in listOf(v.a, v.b).withIndex()) {
                    val on = k == v.pick
                    val shape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.weight(1f).clip(shape)
                            .background(if (on) accent.copy(alpha = 0.18f) else Color(0xFF1A1E29))
                            .border(1.5.dp, if (on) accent else Color(0x26FFFFFF), shape)
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(n, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                }
            }
            is TutVisual.Checklist -> Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                v.items.forEachIndexed { k, s ->
                    val on = k < v.checked
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(18.dp).clip(RoundedCornerShape(5.dp))
                                .background(if (on) Color(0xFF30D158) else Color(0xFF232838)),
                            contentAlignment = Alignment.Center
                        ) {
                            // 4.9.14: o ✓ é desenhado (não é texto), por isso fica sempre no centro da caixinha.
                            if (on) androidx.compose.foundation.Canvas(Modifier.size(18.dp)) {
                                val w = size.width
                                val h = size.height
                                val path = androidx.compose.ui.graphics.Path().apply {
                                    moveTo(w * 0.26f, h * 0.52f)
                                    lineTo(w * 0.43f, h * 0.69f)
                                    lineTo(w * 0.75f, h * 0.31f)
                                }
                                drawPath(
                                    path, Color(0xFF06210F),
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                                        width = w * 0.15f,
                                        cap = androidx.compose.ui.graphics.StrokeCap.Round,
                                        join = androidx.compose.ui.graphics.StrokeJoin.Round
                                    )
                                )
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(s, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                    }
                }
            }
            is TutVisual.Grid -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (k in 0..2) {
                    val on = k == v.sel
                    val shape = RoundedCornerShape(8.dp)
                    Box(
                        Modifier.size(width = 54.dp, height = 78.dp).clip(shape)
                            .background(Color(0xFF232838))
                            .border(if (on) 2.dp else 1.dp, if (on) accent else Color(0x26FFFFFF), shape),
                        contentAlignment = Alignment.Center
                    ) { Text(if (on && v.animated) "▶" else "▣", color = if (on) accent else C_MUTED, fontSize = 18.sp) }
                }
            }
            is TutVisual.Tabs -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                v.names.forEachIndexed { k, n ->
                    val on = k == v.sel
                    val shape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.weight(1f).clip(shape)
                            .background(if (on) accent else Color(0xFF232838))
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            n, color = if (on) onAccent(accent) else Color(0xFFE2E8F0),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                }
            }
            is TutVisual.Big -> Box(
                Modifier.size(64.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)).border(2.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(v.glyph, color = accent, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}
