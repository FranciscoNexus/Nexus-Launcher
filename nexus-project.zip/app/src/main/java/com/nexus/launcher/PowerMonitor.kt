package com.nexus.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat

/**
 * Situação de energia e calor do aparelho.
 * thermal: 0 normal, 1 leve, 2 moderado (aviso), 3 ou mais = thermal throttling (o sistema está reduzindo o desempenho).
 */
data class PowerSnapshot(
    val level: Int = 0,
    val charging: Boolean = false,
    /** Temperatura da bateria em °C. null = o aparelho não informa. */
    val tempC: Float? = null,
    val thermal: Int = 0
)

/**
 * Acompanha bateria, temperatura e estado térmico sem nenhuma permissão especial.
 * - Bateria/temperatura: broadcast ACTION_BATTERY_CHANGED (o Android só avisa quando algum valor muda).
 * - Estado térmico: PowerManager (Android 10+), avisa na hora. Em Android 8/9 é estimado pela temperatura.
 */
class PowerMonitor(ctx: Context, private val onChange: (PowerSnapshot) -> Unit) {

    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var receiver: BroadcastReceiver? = null
    private var thermalListener: Any? = null
    private var level = 0
    private var charging = false
    private var tempC: Float? = null
    private var rawThermal = 0
    private var last: PowerSnapshot? = null

    fun start() {
        stop()
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i != null) fromBattery(i)
            }
        }
        receiver = r
        val sticky = ContextCompat.registerReceiver(
            app, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        if (sticky != null) fromBattery(sticky)
        if (Build.VERSION.SDK_INT >= 29) startThermal()
        emit()
    }

    fun stop() {
        receiver?.let {
            try {
                app.unregisterReceiver(it)
            } catch (_: Exception) {
            }
        }
        receiver = null
        if (Build.VERSION.SDK_INT >= 29) stopThermal()
    }

    private fun fromBattery(i: Intent) {
        val lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        level = if (lv < 0 || scale <= 0) 0 else lv * 100 / scale
        charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)   // décimos de °C; 0 = sem sensor
        tempC = if (t == 0) null else t / 10f
        emit()
    }

    @RequiresApi(29)
    private fun startThermal() {
        try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            val l = PowerManager.OnThermalStatusChangedListener { status ->
                main.post {
                    rawThermal = status
                    emit()
                }
            }
            pm.addThermalStatusListener(ContextCompat.getMainExecutor(app), l)
            thermalListener = l
            rawThermal = pm.currentThermalStatus
        } catch (_: Exception) {
        }
    }

    @RequiresApi(29)
    private fun stopThermal() {
        val l = thermalListener as? PowerManager.OnThermalStatusChangedListener ?: return
        try {
            (app.getSystemService(Context.POWER_SERVICE) as PowerManager).removeThermalStatusListener(l)
        } catch (_: Exception) {
        }
        thermalListener = null
    }

    private fun emit() {
        val thermal = if (Build.VERSION.SDK_INT >= 29) rawThermal else estimate(tempC)
        val s = PowerSnapshot(level, charging, tempC, thermal)
        if (s == last) return
        last = s
        onChange(s)
    }

    /** Android 8/9 não informa o estado térmico: usa a temperatura da bateria como aproximação. */
    private fun estimate(t: Float?): Int = when {
        t == null -> 0
        t >= 46f -> 3
        t >= 43f -> 2
        else -> 0
    }
}
