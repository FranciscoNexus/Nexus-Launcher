package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

/** 4.9.3: menu do botão START. O botão "+" do fim da lista continua existindo; este é só um atalho. */
/** 4.9.4: botão "?" (igual ao da engrenagem, só que à direita do título). */
@Composable
internal fun MainActivity.AboutButton(accent: Color, size: Int) {
    val btn = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(btn)
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.45f), btn)
            .returnFocus("about")
            .focusGlow(btn)
            .clickable { aboutPage = 0; returnKey = "about"; overlay = Overlay.About },
        contentAlignment = Alignment.Center
    ) {
        Text(
            "?", color = accent, fontSize = if (size >= 40) 20.sp else 16.sp, fontWeight = FontWeight.Bold,
            style = TextStyle(lineHeightStyle = CenteredLine)
        )
    }
}

/** Conteúdo só de leitura: com o controle, cima/baixo (e o direcional) rolam a janela. */
@Composable
internal fun MainActivity.ScrollRead(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val sc = LocalModalScroll.current
    val scope = rememberCoroutineScope()
    val shape = RoundedCornerShape(rCard.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .initialFocus()
            .clip(shape)
            .focusGlow(shape)
            .onPreviewKeyEvent { ev ->
                val k = ev.nativeKeyEvent
                if (sc != null && k.action == KeyEvent.ACTION_DOWN &&
                    (k.keyCode == KeyEvent.KEYCODE_DPAD_DOWN || k.keyCode == KeyEvent.KEYCODE_DPAD_UP)
                ) {
                    val down = k.keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                    val can = if (down) sc.value < sc.maxValue else sc.value > 0
                    if (can) {
                        scope.launch { sc.animateScrollBy(if (down) 220f else -220f) }
                        true
                    } else false
                } else false
            }
            .focusable()
    ) { content() }
}

@Composable
internal fun MainActivity.AboutRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text(k, color = S_MUTED, fontSize = 12.sp, modifier = Modifier.width(96.dp))
        Text(v, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
    }
}

@Composable
internal fun MainActivity.AboutDialog() {
    val accent = parseColor(accentHex)
    val soft = accent.copy(alpha = 0.14f)
    val titles = listOf("Informações", "Estatísticas da biblioteca", "Dados do aparelho", "Relatório de diagnóstico", "Atualização", "Créditos", "Sobre o Nexus")
    val page = aboutPage.coerceIn(0, 6)
    val aboutPad = padNav
    remember(page) { FocusProbe.reset(); 0 }
    LaunchedEffect(page, aboutPad) {
        if (aboutPad && page != 0) {
            delay(130)
            try {
                FocusProbe.target?.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
    NexusModal(titles[page], { if (aboutPage != 0) aboutPage = 0 else { returnKey = "about"; popOverlay() } }) {
        when (page) {
            0 -> {
                // 4.9.13: Tutorial (só celular/tablet) e Sobre o Nexus.
                if (tutorialAvailable) {
                    ActionRow("🎓", "Tutorial", "${tutModules.count { it.id in tutDone }} de ${tutModules.size} módulos concluídos",
                        bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f), iconBg = accent, iconFg = onAccent(accent),
                        modifier = Modifier.returnFocus("ab0").initialFocus()) { returnKey = "ab0"; openTutorial() }
                    Spacer(Modifier.height(8.dp))
                }
                ActionRow("ℹ", "Sobre o Nexus", "Versão e onde o Nexus funciona",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab6")) { returnKey = "ab6"; aboutPage = 6 }
                Spacer(Modifier.height(8.dp))
                ActionRow("▦", "Estatísticas da biblioteca", "Jogos, plataformas e mais abertos",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab1").initialFocus(!tutorialAvailable)) { returnKey = "ab1"; aboutPage = 1 }
                Spacer(Modifier.height(8.dp))
                ActionRow("☷", "Dados do aparelho", "Modelo, Android, tela, memória e controles",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab2")) { returnKey = "ab2"; aboutPage = 2 }
                Spacer(Modifier.height(8.dp))
                ActionRow("✚", "Relatório de diagnóstico", "Copiar ou compartilhar para suporte",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab3")) { returnKey = "ab3"; aboutPage = 3 }
                Spacer(Modifier.height(8.dp))
                ActionRow("⟳", "Procurar atualização", "Verificar se há uma versão nova",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab4")) { returnKey = "ab4"; aboutPage = 4 }
                Spacer(Modifier.height(8.dp))
                ActionRow("★", "Créditos", "Quem e o que faz o Nexus funcionar",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.returnFocus("ab5")) { returnKey = "ab5"; aboutPage = 5 }
            }
            1 -> ScrollRead {
                val total = games.size
                AboutRow("Jogos", "$total")
                AboutRow("Favoritos", "${games.count { it.isFavorite }}")
                AboutRow("Com vídeo", "${games.count { it.videoId.isNotBlank() }}")
                AboutRow("Sem arquivo", "${games.count { it.missing }}")
                AboutRow("Plataformas", "${games.map { it.platform }.distinct().size}")
                val byPlat = games.groupBy { it.platform }.map { it.key to it.value.size }.sortedByDescending { it.second }
                if (byPlat.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    SLabel("POR PLATAFORMA")
                    Spacer(Modifier.height(4.dp))
                    for ((name, n) in byPlat.take(12)) AboutRow(name, "$n")
                }
                val top = games.filter { it.openCount > 0 }.sortedByDescending { it.openCount }.take(5)
                if (top.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    SLabel("MAIS ABERTOS")
                    Spacer(Modifier.height(4.dp))
                    for (g in top) AboutRow("${g.openCount}x", g.title)
                }
            }
            2 -> ScrollRead {
                for ((k, v) in aboutDeviceLines()) AboutRow(k, v)
            }
            3 -> {
                Text(diagnosticReport(), color = Color(0xFFCBD2E0), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Copiar", C_BLUE, Modifier.weight(1f)) {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Relatório do Nexus", diagnosticReport()))
                        toast("Relatório copiado")
                    }
                    CButton("Compartilhar", C_GRAY, Modifier.weight(1f)) {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, diagnosticReport())
                        }
                        startActivity(Intent.createChooser(i, "Compartilhar relatório"))
                    }
                }
            }
            4 -> {
                AboutRow("Versão instalada", "v$APP_VERSION")
                Spacer(Modifier.height(10.dp))
                // 4.9.4: só o botão. A função entra quando o Nexus tiver um endereço de download.
                CButton("Procurar atualização", C_GRAY, Modifier.fillMaxWidth().initialFocus()) { }
                Spacer(Modifier.height(8.dp))
                Text("Disponível em breve.", color = S_MUTED, fontSize = 11.sp)
            }
            6 -> ScrollRead { AboutNexusPage() }
            else -> ScrollRead {
                Text("Nexus Launcher v$APP_VERSION", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Frontend e launcher para jogos retrô, em celulares e tablets Android e em aparelhos Google TV e Fire OS.", color = Color(0xFFCBD2E0), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                SLabel("SERVIÇOS E TECNOLOGIAS")
                Spacer(Modifier.height(4.dp))
                AboutRow("Capas e dados", "SteamGridDB")
                AboutRow("Vídeos", "YouTube")
                AboutRow("Interface", "Kotlin e Jetpack Compose")
                AboutRow("Plataforma", "Android")
            }
        }
    }
}
