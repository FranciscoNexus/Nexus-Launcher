package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Vídeo gameplay (4.7.0) ----------
/**
 * Procura o vídeo do jogo no YouTube. Só roda na 1ª vez que a tela de detalhes abre (ou quando o usuário
 * toca no botão depois de uma busca sem resultado). O vídeo achado fica salvo e a busca nunca se repete.
 */
internal fun MainActivity.ensureVideo(g: Game, force: Boolean = false) {
    val key = ytKey.trim()
    if (key.isEmpty() || g.id in ytBusy || g.videoId.isNotEmpty()) return
    if (!force && g.videoTried > 0) return
    ytBusy = ytBusy + g.id
    ytErr.remove(g.id)
    val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
    mainScope.launch {
        val res = withContext(Dispatchers.IO) { YouTubeApi.search(key, g.title, plat) }
        ytBusy = ytBusy - g.id
        val cur = games.firstOrNull { it.id == g.id } ?: return@launch
        when (res) {
            is YtResult.Ok -> replaceGame(cur.copy(videoId = res.video.id, videoTitle = res.video.title, videoTried = System.currentTimeMillis()))
            YtResult.NotFound -> {
                replaceGame(cur.copy(videoTried = System.currentTimeMillis()))
                if (force) toast("Nenhum vídeo encontrado. Use Opções para colar um link.")
            }
            is YtResult.Failure -> {
                ytErr[g.id] = res.message
                if (force) toast(res.message)
            }
        }
    }
}

internal fun MainActivity.onVideoClick(g: Game) {
    when {
        g.videoId.isNotEmpty() -> {
            ytCtl = YT_PLAY
            ytFull = false
            ytNav = infoNav
            ytCtrl.reset()
            ytOpen = true
        }
        ytKey.isBlank() -> {
            // 4.7.6: sem chave de API o player abre só com o aviso e o botão YouTube (busca no app/navegador).
            ytCtl = YT_EXT
            ytFull = false
            ytNav = infoNav
            ytCtrl.reset()
            ytOpen = true
        }
        g.id in ytBusy -> toast("Buscando vídeo…")
        else -> {
            toast("Buscando vídeo…")
            ensureVideo(g, force = true)
        }
    }
}

/** Abre o vídeo no app do YouTube (ou no navegador, se o app não existir). */
internal fun MainActivity.openInYouTube(videoId: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")))
    } catch (e: Exception) {
        openUrl("https://www.youtube.com/watch?v=$videoId")
    }
}

/** Sem vídeo salvo (e sem chave de API): abre a busca do jogo no app do YouTube ou, se não houver, no navegador. */
internal fun MainActivity.openYouTubeSearch(g: Game) {
    val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
    openUrl(YouTubeApi.searchUrl(g.title, plat))
}

/**
 * 4.9.0 (TV): abre o app do YouTube já na busca "título plataforma gameplay", no último usuário usado.
 * Tenta o app do Google TV, o do Fire TV e, por último, o navegador. (O app não consegue escolher o perfil.)
 */
internal fun MainActivity.openYouTubeSearchTv(g: Game) {
    val plat = if (g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
    val url = YouTubeApi.searchUrl(g.title, plat, simple = true)
    val q = listOf(g.title, plat, "gameplay").filter { it.isNotBlank() }.joinToString(" ")
    val pkgs = listOf("com.google.android.youtube.tv", "com.amazon.firetv.youtube", "com.google.android.youtube")
    for (pkg in pkgs) {
        if (!isInstalled(pkg)) continue
        val tries = listOf(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg),
            Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(android.app.SearchManager.QUERY, q)
        )
        for (intent in tries) {
            if (intent.resolveActivity(packageManager) == null) continue
            try {
                startActivity(intent)
                return
            } catch (_: Exception) { }
        }
    }
    openUrl(url)
}

internal fun MainActivity.closeVideo() {
    ytOpen = false
    ytFull = false
    ytCtl = YT_PLAY
}

/** Ação de um botão do player (toque, OK do controle remoto ou A do gamepad). */
internal fun MainActivity.ytAct(i: Int) {
    ytCtl = i
    when (i) {
        YT_CLOSE -> closeVideo()
        YT_BACK -> ytCtrl.seekBy(-10)
        YT_FWD -> ytCtrl.seekBy(10)
        YT_PLAY -> if (ytCtrl.error != 0) {
            infoGame()?.let { openInYouTube(it.videoId) }
        } else ytCtrl.toggle()
        YT_FULL -> if (landscape) ytFull = !ytFull
        // 4.9.3: OK/A na barra de progresso = pausar/continuar (esquerda/direita andam 10 s).
        YT_SEEK -> if (ytCtrl.error == 0) ytCtrl.toggle()
        YT_EXT -> infoGame()?.let {
            if (TvMode.isTv) openYouTubeSearchTv(it)
            else if (it.videoId.isNotEmpty()) openInYouTube(it.videoId) else openYouTubeSearch(it)
        }
    }
}

/** Teclas com o player aberto: o D-pad anda pelos botões do player e nada vaza para a tela de trás. */
internal fun MainActivity.ytHandleKey(ev: KeyEvent, code: Int): Boolean {
    if (ev.action != KeyEvent.ACTION_DOWN) return true
    // Paisagem com os controles escondidos: qualquer tecla só os traz de volta (foco no play/pause);
    // só B / Voltar agem.
    val isBack = code == KeyEvent.KEYCODE_BUTTON_B || code == KeyEvent.KEYCODE_BACK
    if (landscape && !ytCtrl.uiVisible && !isBack) {
        ytCtl = YT_PLAY
        ytNav = true
        infoNav = true
        ytCtrl.wake()
        return true
    }
    ytCtrl.wake()
    val canFull = landscape
    infoNav = true
    ytNav = true
    val noVideo = infoGame()?.videoId.isNullOrEmpty()
    val transport = !noVideo && ytCtrl.error == 0
    // Ordem na tela, da esquerda para a direita: YouTube, −10s, play/pause, +10s, tela cheia.
    val order = when {
        !transport -> listOf(YT_EXT)
        canFull -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD, YT_FULL)
        else -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD)
    }
    val home = if (YT_PLAY in order) YT_PLAY else YT_EXT
    // 4.9.3: com os controles fora do vídeo (celular em pé e TV fora da tela cheia) a barra de progresso fica
    // entre o vídeo e os botões: ✕ (em cima) → barra → botões.
    val seekRow = transport && (!landscape || (TvMode.isTv && !ytFull))
    when (code) {
        KeyEvent.KEYCODE_DPAD_LEFT -> if (ytCtl == YT_SEEK) ytCtrl.seekBy(-10) else if (ytCtl != YT_CLOSE) {
            val i = order.indexOf(if (ytCtl in order) ytCtl else home)
            ytCtl = order[(i - 1).coerceAtLeast(0)]
        }
        KeyEvent.KEYCODE_DPAD_RIGHT -> if (ytCtl == YT_SEEK) ytCtrl.seekBy(10) else if (ytCtl != YT_CLOSE) {
            val i = order.indexOf(if (ytCtl in order) ytCtl else home)
            ytCtl = order[(i + 1).coerceAtMost(order.lastIndex)]
        }
        KeyEvent.KEYCODE_DPAD_UP -> when {
            ytCtl == YT_CLOSE -> {}
            seekRow && ytCtl != YT_SEEK -> { ytLast = ytCtl; ytCtl = YT_SEEK }
            else -> { if (ytCtl != YT_SEEK) ytLast = ytCtl; ytCtl = YT_CLOSE }
        }
        KeyEvent.KEYCODE_DPAD_DOWN -> when {
            ytCtl == YT_CLOSE -> ytCtl = if (seekRow) YT_SEEK else if (ytLast in order) ytLast else home
            ytCtl == YT_SEEK -> ytCtl = if (ytLast in order) ytLast else home
        }
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
        KeyEvent.KEYCODE_BUTTON_A -> if (ev.repeatCount == 0) ytAct(if (ytCtl in order || ytCtl == YT_CLOSE || ytCtl == YT_SEEK) ytCtl else home)
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> if (ev.repeatCount == 0) back()
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> if (transport && ev.repeatCount == 0) ytCtrl.toggle()
        KeyEvent.KEYCODE_MEDIA_PLAY -> if (transport) ytCtrl.play()
        KeyEvent.KEYCODE_MEDIA_PAUSE -> if (transport) ytCtrl.pause()
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_MEDIA_REWIND -> if (transport) ytCtrl.seekBy(-10)
        KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> if (transport) ytCtrl.seekBy(10)
        KeyEvent.KEYCODE_BUTTON_Y -> if (landscape && transport && ev.repeatCount == 0) ytFull = !ytFull
    }
    return true
}

internal fun MainActivity.testYtKey() {
    val key = ytKey.trim()
    if (key.isEmpty()) {
        toast("Cole sua chave do YouTube primeiro")
        return
    }
    toast("Testando chave…")
    mainScope.launch {
        val err = withContext(Dispatchers.IO) { YouTubeApi.ping(key) }
        toast(err ?: "Chave válida ✓")
    }
}
