package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject

/**
 * Plataforma cadastrada pelo usuário.
 * base = nome da plataforma embutida que originou esta (usado para extensões de ROM e emulador padrão,
 * mesmo que o usuário renomeie). Vazio = plataforma personalizada.
 */
data class GamePlatform(
    val name: String,
    val manufacturer: String = "",
    val base: String = "",
    val image: String = ""
)

val DEFAULT_MANUFACTURER = mapOf(
    "PlayStation 1" to "Sony",
    "PlayStation 2" to "Sony",
    "PlayStation 4" to "Sony",
    "PSP" to "Sony",
    "PS Vita" to "Sony",
    "Super Nintendo" to "Nintendo",
    "Nintendo 64" to "Nintendo",
    "GameCube" to "Nintendo",
    "Wii" to "Nintendo",
    "Nintendo Wii U" to "Nintendo",
    "Nintendo Switch" to "Nintendo",
    "Game Boy Advance" to "Nintendo",
    "Nintendo DS" to "Nintendo",
    "Nintendo 3DS" to "Nintendo",
    "Xbox Clássico" to "Microsoft",
    "Xbox 360" to "Microsoft",
    "PC" to "Microsoft",
    "Sega Mega Drive" to "Sega",
    "Sega Saturn" to "Sega",
    "Android" to "Google"
)

fun defaultPlatforms(): List<GamePlatform> =
    PLATFORMS.map { GamePlatform(it, DEFAULT_MANUFACTURER[it] ?: "", it) }

/** Comparador alfabético (A-Z) em português: ignora maiúsculas/minúsculas e acentos. */
private val COLLATOR: java.text.Collator = java.text.Collator.getInstance(java.util.Locale("pt", "BR")).apply {
    strength = java.text.Collator.PRIMARY
}

val ALPHA: Comparator<String> = Comparator { a, b -> COLLATOR.compare(a, b) }

/** Ordena qualquer lista de itens em ordem alfabética pelo texto escolhido. */
fun <T> Iterable<T>.sortedAlpha(selector: (T) -> String): List<T> = sortedWith(compareBy(ALPHA, selector))

/** Ordem alfabética (A-Z) pelo nome. */
fun sortPlatforms(list: List<GamePlatform>): List<GamePlatform> = list.sortedAlpha { it.name }

object PlatformStore {
    /** Lê o formato novo e também o de backups antigos ([{name, active}]). */
    fun parse(json: String): List<GamePlatform> {
        val arr = JSONArray(json)
        val out = ArrayList<GamePlatform>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name", "").trim()
            if (name.isEmpty() || out.any { it.name.equals(name, ignoreCase = true) }) continue
            val man = if (o.has("manufacturer")) o.optString("manufacturer", "").trim()
            else (DEFAULT_MANUFACTURER[name] ?: "")
            val base = if (o.has("base")) o.optString("base", "")
            else (if (name in PLATFORMS) name else "")
            out.add(GamePlatform(name, man, base, o.optString("image", "")))
        }
        return out
    }

    fun toJsonArray(list: List<GamePlatform>): JSONArray {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject()
                    .put("name", p.name)
                    .put("manufacturer", p.manufacturer)
                    .put("base", p.base)
                    .put("image", p.image)
                    .put("active", true)
            )
        }
        return arr
    }

    fun toJson(list: List<GamePlatform>): String = toJsonArray(list).toString()
}
