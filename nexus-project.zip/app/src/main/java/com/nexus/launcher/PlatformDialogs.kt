package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.PlatformsDialog() {
    NexusModal("Plataformas e emuladores", { back() }, tall = true) {
        if (links.isEmpty()) {
            Text(
                "Nenhuma plataforma vinculada ainda. Vincule uma plataforma a um emulador e às pastas das ROMs.",
                color = C_MUTED, fontSize = 12.sp, modifier = Modifier.fillMaxWidth()
            )
        }
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(links.sortedAlpha { it.platform }, key = { it.platform }) { l ->
                val emu = if (l.pkg.isEmpty()) "sem emulador (app nativo)"
                else if (l.playerName.isNotEmpty()) l.playerName
                else (allApps.firstOrNull { it.pkg == l.pkg }?.label ?: l.pkg)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .cardRow { overlay = Overlay.LinkEdit(l) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(l.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(l.platform, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("$emu · ${l.folders.size} pasta(s)", color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                    }
                    Text("›", color = C_MUTED, fontSize = 20.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        CButton("+ Vincular plataforma", C_BLUE, Modifier.fillMaxWidth()) { overlay = Overlay.LinkEdit(null) }
        Spacer(Modifier.height(8.dp))
        CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
    }
}

@Composable
internal fun MainActivity.LinkEditDialog(initial: PlatformLink?, batch: Boolean = false) {
    // Plataformas já cadastradas + todas as plataformas do catálogo ainda não cadastradas.
    val emuAll = remember { EmuCatalog.all(this@LinkEditDialog) }
    val registered = linkablePlatforms()
    val extra = emuAll.map { it.name }
        .filter { n -> registered.none { it.equals(n, ignoreCase = true) } }
        .sortedAlpha { it }
    // Marca (fabricante) de cada plataforma: cadastrada primeiro, senão a do catálogo.
    val brandOf: (String) -> String = { n ->
        (platforms.firstOrNull { it.name == n }?.manufacturer
            ?: emuAll.firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
            ?: "").ifBlank { "Outros" }
    }
    // Ordem alfabética pela marca (Outros por último) e depois pelo nome da plataforma.
    val options = (registered + extra)
        .filter { p -> if (batch) p != WEB_PLATFORM else (p == initial?.platform || links.none { it.platform == p }) }
        .sortedWith(
            compareBy<String> { brandOf(it) == "Outros" }
                .thenBy(ALPHA) { brandOf(it) }
                .thenBy(ALPHA) { it }
        )

    // Em lote, se a primeira plataforma da lista já tem vínculo, parte dele (emulador e pastas).
    val startLink = initial ?: (if (batch) linkFor(options.firstOrNull() ?: "") else null)
    var platform by remember { mutableStateOf(initial?.platform ?: (options.firstOrNull() ?: WEB_PLATFORM)) }
    var pkg by remember { mutableStateOf(startLink?.pkg ?: "") }
    var tpl by remember {
        mutableStateOf(startLink?.template?.takeIf { it.isNotBlank() } ?: (TEMPLATES[startLink?.pkg ?: ""] ?: ""))
    }
    var playerName by remember { mutableStateOf(startLink?.playerName ?: "") }
    var exts by remember { mutableStateOf(startLink?.exts ?: emptyList<String>()) }
    val folders = remember {
        mutableStateListOf<String>().apply { if (startLink != null) addAll(startLink.folders) }
    }
    val emuPlat = remember(platform) { EmuCatalog.forPlatform(this@LinkEditDialog, execKey(platform)) }

    val accent = parseColor(accentHex)
    val fPlat: @Composable () -> Unit = {
        PlatPill(
            "PLATAFORMA", platform, Modifier.fillMaxWidth(),
            filter = { pn ->
                pn != ANDROID_PLATFORM &&
                    (if (batch) pn != WEB_PLATFORM else (pn == initial?.platform || links.none { it.platform == pn }))
            },
            onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) (options.firstOrNull() ?: WEB_PLATFORM) else n }
        ) {
            if (batch && it != platform) {
                // Plataforma já vinculada: traz o emulador e as pastas dela.
                val ex = linkFor(it)
                pkg = ex?.pkg ?: ""
                tpl = ex?.template?.takeIf { t -> t.isNotBlank() } ?: (TEMPLATES[ex?.pkg ?: ""] ?: "")
                playerName = ex?.playerName ?: ""
                exts = ex?.exts ?: emptyList()
                folders.clear()
                if (ex != null) folders.addAll(ex.folders)
            } else if (it != platform && playerName.isNotEmpty()) {
                pkg = ""
                tpl = ""
                playerName = ""
                exts = emptyList()
            }
            platform = it
        }
    }
    val fEmu: @Composable () -> Unit = {
        val label = allApps.firstOrNull { it.pkg == pkg }?.label ?: pkg
        val shown = if (playerName.isNotEmpty()) playerName else label
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val dp = emuPlat
            if (dp != null && dp.players.isNotEmpty()) {
                ActionRow("📚", "Catálogo de emuladores", "${dp.players.size} disponíveis para esta plataforma",
                    bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f),
                    iconBg = accent, iconFg = onAccent(accent), compact = true) {
                    emuPicker = EmuPickerRequest(dp) { pl ->
                        pkg = pl.pkg
                        tpl = pl.template
                        playerName = pl.name
                        exts = pl.exts
                    }
                }
            } else {
                Text(
                    "Esta plataforma não tem emuladores no catálogo. Escolha um app instalado.",
                    color = C_MUTED, fontSize = 11.sp
                )
            }
            EPill(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    ELabel("EMULADOR")
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (pkg.isEmpty()) "Nenhum (app nativo)" else shown, Color.White, 13)
                }
                Spacer(Modifier.width(8.dp))
                EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                    appPickerMode = 2
                    appPickerNone = "Nenhum (app nativo / escolho por jogo)"
                    appPickerCb = { a ->
                        val np = a?.pkg ?: ""
                        pkg = np
                        // Se o catálogo tem um único emulador com esse pacote para a plataforma, usa o comando dele.
                        val only = emuPlat?.players?.filter { it.pkg == np }?.singleOrNull()
                        tpl = TEMPLATES[np] ?: only?.template ?: ""
                        playerName = only?.name ?: ""
                        exts = only?.exts ?: emptyList()
                    }
                    appPickerOpen = true
                }
            }
        }
    }
    val fFolders: @Composable () -> Unit = {
        Column {
            ELabel("PASTAS DE ROMS (${folders.size})")
            Spacer(Modifier.height(6.dp))
            LazyColumn(modifier = Modifier.heightIn(max = if (landscape) 96.dp else 130.dp)) {
                items(folders.sortedAlpha { folderLabel(it) }, key = { it }) { f ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) { MarqueeText(folderLabel(f), Color(0xFFCBD2E0), 11, FontWeight.Medium) }
                        Spacer(Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0x26E11D48))
                                .focusGlow(CircleShape)
                                .clickable { folders.remove(f) },
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFFF6B81), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            EBtn("Adicionar pasta", "+", accent.copy(alpha = 0.14f), accent.copy(alpha = 0.5f), accent, Modifier.fillMaxWidth()) {
                treeCb = { u -> if (u !in folders) folders.add(u) }
                pickFolder()
            }
        }
    }
    val fTpl: @Composable () -> Unit = {
        Column {
            ELabel("COMANDO DE ABERTURA (AVANÇADO)")
            Spacer(Modifier.height(6.dp))
            PillField(null, tpl, { tpl = it }, "-n pacote/.Activity -d {file.uri}", Modifier.fillMaxWidth(), 12, FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            // Toque em um item para inserir no comando.
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("{file.uri}", "{file.path}", "{file.mime}", "{tags.vita_game_id}").forEach { tk ->
                    val chip = RoundedCornerShape(rBtn.dp)
                    Box(
                        modifier = Modifier
                            .clip(chip)
                            .background(S_FIELD)
                            .border(1.dp, S_LINE, chip)
                            .focusGlow(chip)
                            .clickable { tpl = if (tpl.isEmpty() || tpl.endsWith(" ")) tpl + tk else tpl + " " + tk }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) { Text(tk, color = C_MUTED, fontSize = 10.sp, maxLines = 1, softWrap = false) }
                }
            }
        }
    }

    NexusModal(
        if (batch) "Adicionar jogos em lote" else if (initial == null) "Vincular plataforma" else "Editar: ${initial.platform}",
        { overlay = if (batch) Overlay.None else Overlay.Platforms },
        footer = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) {
                overlay = if (batch) Overlay.None else Overlay.Platforms
            }
            if (initial != null) {
                EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), Color(0xFFFF6B81), Modifier.weight(1f), tall = true) {
                    links.removeAll { it.platform == initial.platform }
                    savePrefs()
                    overlay = Overlay.Platforms
                }
            }
            EBtn(if (batch) "Varrer pastas" else "Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                if (batch) {
                    if (folders.isEmpty()) {
                        toast("Adicione ao menos uma pasta de jogos")
                        return@EBtn
                    }
                    if (ScanEngine.profileFor(platform, execBase(platform), batchExts(platform, exts)) == null) {
                        toast("Escolha um emulador para esta plataforma")
                        return@EBtn
                    }
                }
                val clean = if (tpl.trim() == (TEMPLATES[pkg] ?: "")) "" else tpl.trim()
                val nl = PlatformLink(platform, pkg, clean, folders.toList(), playerName, exts)
                // Plataforma do catálogo ainda não cadastrada: cadastra ao vincular,
                // assim ela passa a aparecer ao adicionar jogos.
                if (platforms.none { it.name == platform }) {
                    val dp = EmuCatalog.forPlatform(this@LinkEditDialog, platform)
                    platforms.add(GamePlatform(platform, dp?.manufacturer ?: "", platform))
                }
                val idx = if (batch) links.indexOfFirst { it.platform == platform }
                else if (initial == null) -1 else links.indexOfFirst { it.platform == initial.platform }
                if (idx >= 0) links[idx] = nl else links.add(nl)
                savePrefs()
                if (batch) {
                    overlay = Overlay.None
                    startBatchScan(platform)
                } else overlay = Overlay.Platforms
            }
        }
        }
    ) {
        if (landscape) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fPlat()
                    fEmu()
                    if (!batch) fTpl()
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) { fFolders() }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                fPlat()
                fEmu()
                fFolders()
                if (!batch) fTpl()
            }
        }
    }
}

@Composable
internal fun MainActivity.EmuPickerDialog(req: EmuPickerRequest) {
    var q by remember { mutableStateOf("") }
    val k = foldText(q.trim())
    val accent = parseColor(accentHex)
    class Row2(val pl: EmuPlayer, val inst: Boolean, val recIdx: Int, val name: String)
    val rows = remember(req) {
        val recs = EmuCatalog.recommended(this@EmuPickerDialog)[req.platform.id] ?: emptyList()
        req.platform.players.map { pl ->
            val idx = recs.indexOfFirst { it.pkg == pl.pkg }
            val inst = isInstalled(pl.pkg)
            Row2(pl, inst, idx, emuDisplayName(pl, inst, recs.getOrNull(idx)))
        }
            .sortedWith(
                compareBy<Row2> {
                    when {
                        it.inst && it.recIdx >= 0 -> 0
                        it.inst -> 1
                        it.recIdx >= 0 -> 2
                        else -> 3
                    }
                }.thenBy { if (it.recIdx >= 0) it.recIdx else 0 }.thenBy(ALPHA) { it.name }
            )
    }
    val filtered = if (k.isEmpty()) rows else rows.filter {
        foldText(it.name).contains(k) || foldText(it.pl.name).contains(k) || it.pl.pkg.lowercase().contains(k)
    }
    NexusModal("Emuladores: ${req.platform.name}", { emuPicker = null }, tall = true) {
        val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        CField(q, { q = it }, "🔍 Buscar emulador", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(filtered) { row ->
                val pl = row.pl
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .cardRow {
                            req.onPick(pl)
                            emuPicker = null
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(if (row.inst) pl.pkg else "")
                    Spacer(Modifier.width(12.dp))
                    Text(
                        row.name, color = Color.White, fontSize = 14.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        if (row.recIdx >= 0) {
                            Text(
                                "recomendado", color = onAccent(accent), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, softWrap = false,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(accent)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            if (row.inst) "instalado" else "não instalado",
                            color = if (row.inst) Color(0xFF34D399) else C_MUTED, fontSize = 10.sp,
                            fontWeight = if (row.inst) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
        }
        val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Spacer(Modifier.height(8.dp))
        CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { emuPicker = null }
        }
        if (landscape) {
            Panes(0.36f, {
                topUi()
                Spacer(Modifier.height(10.dp))
                botUi()
            }, { listUi() })
        } else {
            topUi()
            listUi()
            botUi()
        }
    }
}

@Composable
internal fun MainActivity.MiniIcon(glyph: String, tint: Color, bg: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(bg)
            .focusGlow(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(glyph, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
}

/** Campo "Plataforma" (estilo pílula) que abre o seletor com busca. */
@Composable
internal fun MainActivity.PlatPill(
    label: String, value: String, modifier: Modifier, vpad: Dp = 8.dp,
    filter: (String) -> Boolean = { true },
    onChanged: (String, String) -> Unit = { _, _ -> },
    onSelect: (String) -> Unit
) {
    EPill(
        modifier, vpad = vpad,
        onClick = { platPicker = PlatPickerRequest("Plataforma", value, filter, onChanged, onSelect) }
    ) {
        Column(Modifier.weight(1f)) {
            ELabel(label)
            Spacer(Modifier.height(3.dp))
            MarqueeText(value.ifEmpty { "Escolher" }, Color.White, 13)
        }
        Spacer(Modifier.width(6.dp))
        Text("▾", color = S_MUTED, fontSize = 13.sp)
    }
}

@Composable
internal fun MainActivity.PlatformPickerDialog(req: PlatPickerRequest) {
    var q by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(0) } // 0 lista, 1 formulário, 2 confirmar exclusão
    var target by remember { mutableStateOf<GamePlatform?>(null) }
    var nameF by remember { mutableStateOf("") }
    var manF by remember { mutableStateOf("") }
    val accent = parseColor(accentHex)
    val close: () -> Unit = { platPicker = null }
    val title = when (mode) {
        1 -> if (target == null) "Nova plataforma" else "Editar plataforma"
        2 -> "Apagar plataforma?"
        else -> req.title
    }
    RefocusOnStep(mode)
    NexusModal(title, { if (mode != 0) mode = 0 else close() }, tall = mode == 0) {
        when (mode) {
            1 -> {
                PillField("NOME DA PLATAFORMA", nameF, { nameF = it }, "Ex.: Dreamcast", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                PillField("FABRICANTE (OPCIONAL)", manF, { manF = it }, "Ex.: Sega", Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { mode = 0 }
                    CButton("Salvar", C_BLUE, Modifier.weight(1f)) {
                        val n = nameF.trim()
                        val t = target
                        val clash = EmuCatalog.all(this@PlatformPickerDialog).any { it.name.equals(n, ignoreCase = true) } &&
                            (t == null || !t.name.equals(n, ignoreCase = true))
                        if (clash) {
                            toast("Já existe uma plataforma com esse nome")
                        } else if (savePlatform(t, n, manF)) {
                            if (t == null) {
                                req.onPick(n)
                                close()
                            } else {
                                if (t.name != n) req.onChanged(t.name, n)
                                mode = 0
                            }
                        }
                    }
                }
            }
            2 -> {
                val t = target
                if (t != null) {
                    Text(
                        "Apagar \"${t.name}\"? O vínculo dela com emulador e pastas também será removido.",
                        color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CButton("Cancelar", C_GRAY, Modifier.weight(1f).initialFocus()) { mode = 0 }
                        CButton("Apagar", C_RED, Modifier.weight(1f)) {
                            deletePlatform(t)
                            req.onChanged(t.name, "")
                            mode = 0
                        }
                    }
                }
            }
            else -> {
                val k = foldText(q.trim())
                val shown = platformPickList(req.filter).filter {
                    k.isEmpty() || foldText(it).contains(k) || foldText(brandOfPlatform(it)).contains(k)
                }
                val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                CField(q, { q = it }, "🔍 Buscar plataforma (digite ou fale)", Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                CButton("＋ Nova plataforma", C_GRAY, Modifier.fillMaxWidth()) {
                    target = null
                    nameF = q.trim()
                    manF = ""
                    mode = 1
                }
                Spacer(Modifier.height(8.dp))
                }
                val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(shown, key = { it }) { n ->
                        val custom = isCustomPlatform(n)
                        Row(
                            modifier = Modifier.fillMaxWidth().cardRow { req.onPick(n); close() },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    n, color = if (n == req.selected) accent else Color.White,
                                    fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    brandOfPlatform(n) + if (custom) " · personalizada" else "",
                                    color = C_MUTED, fontSize = 11.sp, maxLines = 1
                                )
                            }
                            if (custom) {
                                MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) {
                                    val gp = platforms.firstOrNull { it.name == n }
                                    target = gp
                                    nameF = n
                                    manF = gp?.manufacturer ?: ""
                                    mode = 1
                                }
                                Spacer(Modifier.width(6.dp))
                                MiniIcon("🗑", Color(0xFFFF6B81), Color(0x26E11D48)) {
                                    val used = games.count { it.platform == n || it.maskPlatform == n }
                                    if (used > 0) {
                                        toast("Esta plataforma tem $used jogo(s). Apague ou mude esses jogos antes.")
                                    } else {
                                        target = platforms.firstOrNull { it.name == n }
                                        mode = 2
                                    }
                                }
                            }
                        }
                    }
                }
                }
                if (landscape) {
                    Panes(0.36f, {
                        topUi()
                        Spacer(Modifier.height(10.dp))
                        CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { close() }
                    }, { listUi() })
                } else {
                    topUi()
                    listUi()
                Spacer(Modifier.height(8.dp))
                CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { close() }
                }
            }
        }
    }
}
