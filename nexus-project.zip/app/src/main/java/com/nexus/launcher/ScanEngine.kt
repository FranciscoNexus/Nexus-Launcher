package com.nexus.launcher

import java.io.File
import java.text.Normalizer

/*
 * Motor da varredura em lote (modo automático de cadastro).
 * Código puro (sem Android): recebe a lista bruta de arquivos/pastas e aplica as regras de cada
 * plataforma, devolvendo os jogos candidatos, os ignorados (com o motivo) e as duplicatas por região.
 */

/** Arquivo ou pasta encontrado numa pasta de jogos. [folder] = caminho relativo à pasta raiz ("" ou "sub/"). */
class RawEntry(val name: String, val folder: String, val uri: String, val isDir: Boolean = false)

class ScanCandidate(
    val title: String,
    val fileName: String,
    val folder: String,
    val uri: String,
    val regions: List<String>,
    /** Título normalizado (ou ID, nas plataformas de pasta): agrupa o mesmo jogo em formatos e regiões diferentes. */
    val key: String,
    val ext: String,
    val isDir: Boolean = false
) {
    val region: String get() = regions.firstOrNull() ?: ""
}

class IgnoredItem(val name: String, val reason: String, val candidate: ScanCandidate)

class ScanOutcome(val candidates: List<ScanCandidate>, val ignored: List<IgnoredItem>)

/** Mesmo jogo encontrado em mais de uma região. */
class DupGroup(val key: String, val title: String, val variants: List<ScanCandidate>)

enum class ScanKind {
    /** Um arquivo = um jogo (com regras de discos e formatos). */
    FILES,

    /** O jogo é identificado pelo ID no nome da pasta (ex.: PS Vita). */
    FOLDER_ID
}

class ScanProfile(
    val platform: String,
    val kind: ScanKind,
    val exts: Set<String>,
    val idRegex: Regex? = null,
    val switchRules: Boolean = false
)

object ScanEngine {

    // ---------- Perfis ----------

    /** Extensões comuns de jogos, usadas em plataformas criadas pelo usuário (sem tabela própria). */
    val GENERIC_EXTS = setOf(
        "iso", "bin", "cue", "chd", "cso", "img", "rom", "zip", "7z", "gdi", "cdi", "nsp", "xci",
        "rvz", "gcm", "wbfs", "pbp", "nds", "gba", "gbc", "gb", "sfc", "smc", "nes", "md", "gen", "n64", "z64", "v64"
    )

    val REGION_CHOICES = listOf("Brazil", "USA", "Europe", "Japan", "World")

    private val SWITCH_GAME_EXTS = setOf("nsp", "xci", "nsz", "xcz", "nro")

    /** Extensões usadas quando nem o emulador escolhido nem a tabela embutida informam nenhuma. */
    private val FALLBACK_EXTS: Map<String, Set<String>> = mapOf(
        "PlayStation 1" to setOf("cue", "chd", "pbp", "iso", "m3u", "ccd", "mds", "bin"),
        "PlayStation 2" to setOf("iso", "chd", "cso", "gz", "mdf", "bin"),
        "PSP" to setOf("iso", "cso", "chd", "pbp"),
        "Sega Saturn" to setOf("cue", "chd", "iso", "m3u", "mds", "ccd", "bin"),
        "Sega Mega Drive" to setOf("md", "gen", "smd", "bin", "zip", "7z"),
        "Nintendo 64" to setOf("z64", "n64", "v64", "zip", "7z"),
        "Nintendo DS" to setOf("nds", "zip", "7z"),
        "Nintendo 3DS" to setOf("3ds", "cia", "cci", "cxi", "3dsx"),
        "Nintendo Wii U" to setOf("wua", "wud", "wux", "rpx"),
        "Xbox Clássico" to setOf("iso", "xiso"),
        "Xbox 360" to setOf("iso", "xex"),
        "Nintendo Switch" to SWITCH_GAME_EXTS
    )

    /**
     * Monta o perfil de varredura de uma plataforma.
     * [base] = plataforma embutida que originou a do usuário ("" se for personalizada).
     * [exts] = extensões do emulador escolhido ou da tabela embutida (vazio = usa o padrão da plataforma).
     * Devolve null se não houver nenhuma extensão conhecida (o usuário precisa escolher um emulador).
     */
    fun profileFor(platform: String, base: String, exts: Collection<String>?): ScanProfile? {
        val given = exts?.map { it.trim().lowercase().removePrefix(".") }?.filter { it.isNotEmpty() }?.toSet() ?: emptySet()
        val key = base.ifEmpty { platform }
        val set = given.ifEmpty { FALLBACK_EXTS[key] ?: emptySet() }
        if (set.isEmpty()) return null
        return when (key) {
            "PS Vita" -> ScanProfile(platform, ScanKind.FOLDER_ID, set + "vpk", Regex("[A-Z]{4}\\d{5}"))
            "Nintendo Switch" -> {
                val only = set.intersect(SWITCH_GAME_EXTS)
                ScanProfile(platform, ScanKind.FILES, only.ifEmpty { SWITCH_GAME_EXTS }, switchRules = true)
            }
            else -> ScanProfile(platform, ScanKind.FILES, set)
        }
    }

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    // ---------- Leitura de pastas (java.io.File) ----------

    private const val MAX_DEPTH = 12
    private const val MAX_ENTRIES = 60000

    /** O arquivo/pasta interessa à varredura? (usado pelos leitores para não guardar o que não serve). */
    fun wanted(p: ScanProfile, name: String, isDir: Boolean): Boolean {
        if (name.startsWith(".")) return false
        return when (p.kind) {
            ScanKind.FOLDER_ID -> if (isDir) p.idRegex!!.containsMatchIn(name) else extOf(name) in p.exts && p.idRegex!!.containsMatchIn(name)
            ScanKind.FILES -> !isDir && extOf(name) in p.exts
        }
    }

    /** Nas plataformas de pasta, entra-se nas pastas sem ID (para achar as pastas de jogos mais abaixo). */
    fun shouldDescend(p: ScanProfile, name: String, depth: Int): Boolean {
        if (name.startsWith(".")) return false
        return when (p.kind) {
            ScanKind.FILES -> depth < MAX_DEPTH
            ScanKind.FOLDER_ID -> depth < 4 && !p.idRegex!!.containsMatchIn(name)
        }
    }

    fun walkFiles(
        root: File, p: ScanProfile, out: MutableList<RawEntry>,
        uriOf: (File) -> String, cancelled: () -> Boolean = { false }, onFound: (Int) -> Unit = {},
        path: String = "", depth: Int = 0
    ) {
        if (cancelled() || out.size > MAX_ENTRIES) return
        val kids = root.listFiles() ?: return
        for (k in kids) {
            if (cancelled()) return
            val isDir = k.isDirectory
            if (wanted(p, k.name, isDir)) {
                out.add(RawEntry(k.name, path, uriOf(k), isDir))
                onFound(out.size)
            } else if (isDir && shouldDescend(p, k.name, depth)) {
                walkFiles(k, p, out, uriOf, cancelled, onFound, "$path${k.name}/", depth + 1)
            }
        }
    }

    // ---------- Título, região e filtros ----------

    private val TAGS = Regex("[\\(\\[]([^\\)\\]]*)[\\)\\]]")
    private val TAG_STRIP = Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]")
    private val TRAILING_ID = Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$")

    fun cleanTitle(file: String, isDir: Boolean = false, idRegex: Regex? = null): String {
        var s = if (isDir) file else file.substringBeforeLast('.', file)
        s = s.replace(TAG_STRIP, "")
        if (idRegex != null) {
            s = s.replace(Regex("\\s*[-–_]?\\s*" + idRegex.pattern + "\\s*[-–_]?\\s*"), " ")
        } else {
            s = s.replace(TRAILING_ID, "")
        }
        if (!s.contains(' ') && s.count { it == '_' } >= 2) s = s.replace('_', ' ')
        s = s.replace(Regex("\\s+"), " ").trim().trim('-', '–', '_', ',').trim()
        return s
    }

    /** Chave para agrupar o mesmo jogo: minúsculas, sem acentos, só letras e números. */
    fun normKey(title: String): String {
        val d = Normalizer.normalize(title, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        return d.lowercase().replace(Regex("[^a-z0-9]+"), "")
    }

    private val REGION_WORDS: Map<String, String> = mapOf(
        "usa" to "USA", "us" to "USA", "u.s.a." to "USA", "ntsc-u" to "USA", "america" to "USA", "canada" to "USA",
        "europe" to "Europe", "eur" to "Europe", "eu" to "Europe", "pal" to "Europe", "uk" to "Europe",
        "germany" to "Europe", "france" to "Europe", "spain" to "Europe", "italy" to "Europe",
        "netherlands" to "Europe", "sweden" to "Europe", "denmark" to "Europe", "norway" to "Europe",
        "finland" to "Europe", "russia" to "Europe", "portugal" to "Europe",
        "japan" to "Japan", "jpn" to "Japan", "jp" to "Japan", "ntsc-j" to "Japan",
        "brazil" to "Brazil", "brasil" to "Brazil", "br" to "Brazil",
        "world" to "World",
        "asia" to "Asia", "korea" to "Asia", "china" to "Asia", "taiwan" to "Asia", "hong kong" to "Asia",
        "australia" to "Asia"
    )

    private val PTBR = Regex("(?i)(\\bpt[-_ ]?br\\b|\\[t[+\\-]\\s*(port|pt|br)[^\\]]*\\]|\\btraduzid[oa]\\b|\\bportugu[eê]s\\b|\\bportuguese\\b)")

    fun regionsOf(name: String): List<String> {
        val out = ArrayList<String>()
        if (PTBR.containsMatchIn(name)) out.add("PT-BR")
        for (m in TAGS.findAll(name)) {
            for (part in m.groupValues[1].split(',', '/', ';')) {
                val r = REGION_WORDS[part.trim().lowercase()] ?: continue
                if (r !in out) out.add(r)
            }
        }
        return out
    }

    /** Ordem de preferência das regiões: a escolhida primeiro, depois as demais. "Brazil" põe as traduções PT-BR na frente. */
    fun regionPriority(preferred: String): List<String> {
        val rest = listOf("World", "USA", "Europe", "Japan", "Asia")
        val head = if (preferred == "Brazil") listOf("PT-BR", "Brazil") else listOf(preferred)
        return (head + rest + "PT-BR" + "Brazil").distinct()
    }

    private val BIOS_WORD = Regex("(?i)(^|[^a-z])bios([^a-z]|$)")
    private val BIOS_FIXED = setOf(
        "neogeo", "pgm", "qsound", "syscard", "syscard1", "syscard2", "syscard3", "dc_boot", "dc_flash",
        "sega_101", "stvbios", "decocass", "skns", "cchip", "ym2608"
    )

    fun isBios(name: String): Boolean {
        val b = name.substringBeforeLast('.', name).lowercase()
        if (BIOS_WORD.containsMatchIn(b)) return true
        if (b in BIOS_FIXED) return true
        if (Regex("^scph[-_]?\\d+.*").matches(b)) return true
        if (Regex("^mpr-\\d+$").matches(b)) return true
        if (Regex("^psxonpsp\\d*$").matches(b)) return true
        return false
    }

    private val TEST_TAG = Regex("(?i)^(beta|proto|prototype|demo|sample|kiosk|debug|unl|hack|pirate)\\b.*")
    private val BAD_DUMP_TAG = Regex("(?i)^([bo]|h)\\d*$")

    /** Motivo para ignorar por ser Beta/Proto/Demo/Sample/Unl/Hack ou dump ruim; null se estiver ok. */
    fun testReason(name: String): String? {
        for (m in Regex("\\(([^)]*)\\)").findAll(name)) {
            val t = m.groupValues[1].trim()
            if (TEST_TAG.matches(t)) return "Beta/Proto/Demo (${t.take(14)})"
        }
        for (m in Regex("\\[([^\\]]*)]").findAll(name)) {
            if (BAD_DUMP_TAG.matches(m.groupValues[1].trim())) return "dump ruim ou modificado [${m.groupValues[1].trim()}]"
        }
        return null
    }

    private val SWITCH_TID = Regex("\\[([0-9a-fA-F]{16})\\]")
    private val SWITCH_WORDS = Regex(
        "(?i)(^|[^\\p{L}])(dlcs?|patch(es)?|updates?|upd|addons?|add-ons?|add on|atualiza[cç][aã]o|atualiza[cç][oõ]es|" +
            "actualizaci[oó]n|aktualisierung|mise [àa] jour|mise-[àa]-jour|aggiornamento|season pass|expansion pass)([^\\p{L}]|$)"
    )

    /** Update/DLC do Switch: pelo Title ID (final 000 = jogo; 800 = update; outros = DLC) ou, sem ID, por palavras. */
    fun switchReason(name: String): String? {
        val tid = SWITCH_TID.find(name)?.groupValues?.get(1)
        if (tid != null) {
            return when (tid.takeLast(3)) {
                "000" -> null
                "800" -> "Update (Title ID $tid)"
                else -> "DLC (Title ID $tid)"
            }
        }
        val m = SWITCH_WORDS.find(name.substringBeforeLast('.', name))
        return if (m != null) "Update/DLC (palavra no nome)" else null
    }

    private val DISC_TAG = Regex("(?i)[\\(\\[]\\s*(?:disc|disk|cd|dvd|gd)\\s*[-_ ]?0*(\\d{1,2})(?:\\s*(?:of|de|/)\\s*\\d+)?\\s*[\\)\\]]")

    fun discNumber(name: String): Int? = DISC_TAG.find(name)?.groupValues?.get(1)?.toIntOrNull()

    // ---------- Formatos (discos com vários arquivos) ----------

    private val COMPANIONS: Map<String, Set<String>> = mapOf(
        "cue" to setOf("bin", "wav", "ape", "flac", "mp3", "ogg", "raw", "img", "sub"),
        "gdi" to setOf("bin", "raw", "wav"),
        "ccd" to setOf("img", "sub"),
        "mds" to setOf("mdf")
    )
    private val TRACK_SUFFIX = Regex("(?i)\\s*[-_ ]*\\(?\\s*track\\s*\\d+\\s*\\)?\\s*$")

    private fun baseNoExt(n: String) = n.substringBeforeLast('.', n)

    private val GENERIC_NAMES = setOf("disc", "disk", "game", "image")

    private val FORMAT_PREF = listOf(
        "m3u", "cue", "gdi", "ccd", "mds", "chd", "rvz", "wua", "wux", "wud", "xci", "nsp", "nsz", "xcz",
        "iso", "gcz", "wbfs", "ciso", "cso", "pbp", "img", "bin", "zip", "7z"
    )

    private fun formatRank(ext: String): Int = FORMAT_PREF.indexOf(ext).let { if (it < 0) 999 else it }

    // ---------- Processamento ----------

    fun process(entries: List<RawEntry>, p: ScanProfile): ScanOutcome {
        val ignored = ArrayList<IgnoredItem>()
        val kept = ArrayList<ScanCandidate>()
        val hidden = HashSet<RawEntry>()

        if (p.kind == ScanKind.FILES) hideCompanions(entries, hidden)

        for (e in entries) {
            if (e in hidden) continue
            val ext = if (e.isDir) "" else extOf(e.name)
            val id = if (p.kind == ScanKind.FOLDER_ID) p.idRegex!!.find(e.name)?.value else null
            // "Jogo/disc.gdi": o nome do arquivo é genérico, então o título vem da pasta do jogo.
            val folderName = e.folder.trimEnd('/').substringAfterLast('/')
            val fromFolder = !e.isDir && folderName.isNotEmpty() && baseNoExt(e.name).lowercase() in GENERIC_NAMES
            val nameForTitle = if (fromFolder) folderName else e.name
            val title = cleanTitle(nameForTitle, e.isDir || fromFolder, p.idRegex).ifEmpty { id ?: baseNoExt(e.name) }
            val key = if (id != null) id else normKey(title).ifEmpty { normKey(e.name) }
            val c = ScanCandidate(title, e.name, e.folder, e.uri, regionsOf(nameForTitle), key, ext, e.isDir)

            if (p.kind == ScanKind.FOLDER_ID && id == null) {
                ignored.add(IgnoredItem(e.name, "sem ID de jogo no nome", c))
                continue
            }
            if (isBios(e.name)) { ignored.add(IgnoredItem(e.name, "BIOS", c)); continue }
            if (p.switchRules) {
                val r = switchReason(e.name)
                if (r != null) { ignored.add(IgnoredItem(e.name, r, c)); continue }
            }
            val t = testReason(e.name)
            if (t != null) { ignored.add(IgnoredItem(e.name, t, c)); continue }
            val d = discNumber(e.name)
            if (d != null && d >= 2) { ignored.add(IgnoredItem(e.name, "disco adicional (Disc $d)", c)); continue }
            kept.add(c)
        }

        // Jogos de vários discos com .m3u: o .m3u vira o jogo e os discos soltos somem.
        val m3uKeys = kept.filter { it.ext == "m3u" }.map { it.key }.toSet()
        val afterM3u = if (m3uKeys.isEmpty()) kept
        else kept.filter { it.ext == "m3u" || discNumber(it.fileName) == null || it.key !in m3uKeys }

        // Mesmo jogo, mesma região, em outro formato/revisão: fica só um.
        val groups = LinkedHashMap<String, MutableList<ScanCandidate>>()
        for (c in afterM3u) groups.getOrPut(c.key + "|" + c.regions.sorted().joinToString(",")) { ArrayList() }.add(c)
        val result = ArrayList<ScanCandidate>()
        for ((_, g) in groups) {
            if (g.size == 1) { result.add(g[0]); continue }
            val best = g.sortedWith(
                compareBy<ScanCandidate>({ formatRank(it.ext) }, { tagCount(it.fileName) }, { it.fileName.length }, { it.fileName.lowercase() })
            ).first()
            result.add(best)
            for (o in g) if (o !== best) {
                ignored.add(IgnoredItem(o.fileName, "mesmo jogo em outro formato/revisão (mantido: ${best.fileName})", o))
            }
        }
        return ScanOutcome(result, ignored)
    }

    private fun tagCount(name: String) = TAGS.findAll(name).count()

    private fun hideCompanions(entries: List<RawEntry>, hidden: MutableSet<RawEntry>) {
        val byFolder = entries.filter { !it.isDir }.groupBy { it.folder }
        for ((_, list) in byFolder) {
            for ((master, comps) in COMPANIONS) {
                val masters = list.filter { extOf(it.name) == master }
                if (masters.isEmpty()) continue
                val companions = list.filter { extOf(it.name) in comps }
                if (companions.isEmpty()) continue
                if (masters.size == 1) {
                    hidden.addAll(companions)
                } else {
                    val bases = masters.map { baseNoExt(it.name).lowercase() }.toSet()
                    for (c in companions) {
                        val b = baseNoExt(c.name).lowercase()
                        if (b in bases || b.replace(TRACK_SUFFIX, "") in bases) hidden.add(c)
                    }
                }
            }
        }
    }

    // ---------- Duplicatas por região ----------

    fun dupGroups(cands: List<ScanCandidate>): List<DupGroup> =
        cands.groupBy { it.key }
            .filter { it.value.size >= 2 }
            .map { (k, v) -> DupGroup(k, v.minByOrNull { it.title.length }?.title ?: v[0].title, v.sortedBy { it.fileName.lowercase() }) }
            .sortedBy { it.title.lowercase() }

    private fun regionRank(c: ScanCandidate, priority: List<String>): Int {
        if (c.regions.isEmpty()) return 500
        return c.regions.minOf { r -> priority.indexOf(r).let { if (it < 0) 400 else it } }
    }

    /** Escolhe uma versão por jogo. [overrides] = chave do jogo -> uri escolhida à mão. */
    fun resolveRegions(cands: List<ScanCandidate>, priority: List<String>, overrides: Map<String, String> = emptyMap()): List<ScanCandidate> {
        val out = ArrayList<ScanCandidate>()
        for ((k, g) in cands.groupBy { it.key }) {
            if (g.size == 1) { out.add(g[0]); continue }
            val forced = overrides[k]?.let { u -> g.firstOrNull { it.uri == u } }
            out.add(forced ?: g.sortedWith(compareBy({ regionRank(it, priority) }, { it.fileName.lowercase() })).first())
        }
        return out
    }
}
