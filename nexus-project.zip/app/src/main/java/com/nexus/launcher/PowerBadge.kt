package com.nexus.launcher

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cores do item de bateria + temperatura. */
object PowerColors {
    val BG = Color(0xFF0B0D12)

    // Bateria (metade direita da borda)
    val BAT_HIGH = Color(0xFF30D158)   // 70% ou mais
    val BAT_MID = Color(0xFFFFD60A)    // 25% a 69%
    val BAT_LOW = Color(0xFFFF5A36)    // 24% ou menos

    // Temperatura (metade esquerda da borda)
    val TEMP_COLD = Color(0xFF00E5FF)  // abaixo de 37 °C
    val TEMP_WARM = Color(0xFFFF9F0A)  // 37 a 42 °C
    val TEMP_HOT = Color(0xFFFF2D2D)   // 43 °C ou mais
    val TEMP_NONE = Color(0xFF8E98AB)  // aparelho não informa

    // Fundo em caso de aquecimento
    val WARN_BG = Color(0xFF5B0F22)    // estado moderado: aviso fixo (vinho)
    val ALERT_A = Color(0xFFB3001B)    // thermal throttling: pulsa entre estas duas cores
    val ALERT_B = Color(0xFFFF1744)

    fun battery(level: Int): Color = when {
        level >= 70 -> BAT_HIGH
        level >= 25 -> BAT_MID
        else -> BAT_LOW
    }

    fun temp(t: Float?): Color = when {
        t == null -> TEMP_NONE
        t < 37f -> TEMP_COLD
        t < 43f -> TEMP_WARM
        else -> TEMP_HOT
    }
}

/**
 * Item único: temperatura (metade esquerda) + bateria (metade direita).
 * A borda é bicolor (cada metade na cor do seu valor). O fundo é quase preto e, em thermal throttling,
 * fica vermelho forte pulsando, com um fio branco por dentro da borda.
 */
@Composable
fun PowerBadge(
    s: PowerSnapshot,
    corner: Dp,
    modifier: Modifier = Modifier,
    height: Dp = 28.dp,
    halfWidth: Dp = 46.dp,
    fontSp: Float = 10f
) {
    val critical = s.thermal >= 3
    val warn = s.thermal == 2
    val pulse = if (critical) {
        val tr = rememberInfiniteTransition()
        val v by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse))
        v
    } else 0f

    val tempColor = PowerColors.temp(s.tempC)
    val batColor = PowerColors.battery(s.level)
    val bg = when {
        critical -> lerp(PowerColors.ALERT_A, PowerColors.ALERT_B, pulse)
        warn -> PowerColors.WARN_BG
        else -> PowerColors.BG
    }
    val onDark = critical || warn
    val t = s.tempC
    val tempTxt = (if (critical) "⚠ " else "") + (if (t == null) "--°" else "${Math.round(t)}°")
    val batTxt = (if (s.charging) "⚡" else "") + "${s.level}%"

    Row(
        modifier = modifier
            .height(height)
            .width(halfWidth * 2)
            .drawBehind {
                val w = size.width
                val h = size.height
                val r = corner.toPx().coerceAtMost(h / 2f)
                val sw = 1.5.dp.toPx()
                drawRoundRect(bg, cornerRadius = CornerRadius(r))
                val inset = sw / 2f
                val tl = Offset(inset, inset)
                val sz = Size(w - sw, h - sw)
                val cr = CornerRadius((r - inset).coerceAtLeast(0f))
                clipRect(right = w / 2f) { drawRoundRect(tempColor, tl, sz, cr, style = Stroke(sw)) }
                clipRect(left = w / 2f) { drawRoundRect(batColor, tl, sz, cr, style = Stroke(sw)) }
                if (critical) {
                    val ring = 1.dp.toPx()
                    val i2 = sw + ring / 2f + 0.5.dp.toPx()
                    drawRoundRect(
                        Color.White.copy(alpha = 0.9f), Offset(i2, i2), Size(w - 2 * i2, h - 2 * i2),
                        CornerRadius((r - i2).coerceAtLeast(0f)), style = Stroke(ring)
                    )
                }
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(halfWidth).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Text(
                tempTxt, color = if (onDark) Color.White else tempColor,
                fontSize = fontSp.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false
            )
        }
        Box(Modifier.width(halfWidth).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Text(
                batTxt, color = if (onDark) Color.White else batColor,
                fontSize = fontSp.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false
            )
        }
    }
}
