package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// Tela de plataformas ativa (modo Plataformas, fora de qualquer plataforma e com ao menos um jogo).
internal fun MainActivity.inPlatformList(): Boolean =
    dashMode == 1 && dashPlatform.isEmpty() && platformCards().isNotEmpty()

internal fun MainActivity.navIds(): List<String> =
    if (inPlatformList()) platformCards().map { PLAT_PREFIX + it.name }
    else visibleGames().map { it.id } + ADD_ID

internal fun MainActivity.firstNavId(): String? =
    if (inPlatformList()) navIds().firstOrNull() else visibleGames().firstOrNull()?.id

internal fun MainActivity.selectGame(id: String) {
    if (dashMode == 1) {
        games.firstOrNull { it.id == id }?.let { if (dashPlatform != it.shownPlatform) dashPlatform = it.shownPlatform }
    }
    if (visibleGames().none { it.id == id }) resetFilters()
    selectedId = id
}

// ---------- Ações ----------
// Um passo na direção (dx, dy). Na paisagem só importa dx; no retrato dy anda uma linha.
internal fun MainActivity.stepSelection(dx: Int, dy: Int) {
    if (dx != 0) coverUnderline = false
    if (padNav) {
        // TV: o D-pad também chega ao cabeçalho (cima) e ao rodapé (baixo) da tela inicial.
        if (navZone != 0) {
            zoneStep(dx, dy)
            return
        }
        // Modo Lista: só cima/baixo andam pelos cartões.
        if (tvListOn && dx != 0) return
        if (zoneEnter(dx, dy)) return
    }
    stepSelectionRaw(dx, dy)
}

/** Colunas usadas pelo D-pad: 1 na lista; as da grade nos outros modos de grade. */
internal fun MainActivity.navCols(): Int = if (tvListOn) 1 else max(1, gridColumns)

/**
 * 4.9.3: quantas capas cabem por linha na grade. Conta os dp da tela e oferece 3 tamanhos:
 * size 0 = pequenas (uma a mais que o confortável), 1 = médias, 2 = grandes (uma a menos).
 * Os cartões de plataforma são mais largos (cerca de 1,5 capa), então usam menos colunas.
 */
internal fun MainActivity.gridColsFor(screenDp: Float, size: Int, plat: Boolean): Int {
    val gap = 14f
    val avail = screenDp - (if (TvMode.isTv) 36f else 16f)
    val c0 = ((avail + gap) / (120f + gap)).roundToInt().coerceIn(2, 10)
    val cMax = max(c0, ((avail + gap) / (70f + gap)).toInt())
    val g = when (size.coerceIn(0, 2)) {
        0 -> min(c0 + 1, cMax)
        2 -> max(2, c0 - 1)
        else -> c0
    }
    return if (plat) max(2, (g / 1.5f).roundToInt()) else g
}

/** Itens do cabeçalho na ordem em que aparecem (a TV não tem o botão de girar a tela). */
internal fun MainActivity.headerOrder(): List<Int> {
    val l0 = if (landscape) listOf(H_ORIENT, H_FLOAT, H_SELECT, H_START, H_GEAR)
    else listOf(H_ORIENT, H_SELECT, H_START, H_FLOAT, H_GEAR)
    // 4.9.3: Fire TV não mostra temperatura nem painel flutuante, então o botão sai do cabeçalho.
    val l = if (TvMode.isFireTv) l0.filter { it != H_FLOAT } else l0
    // 4.7.7: no celular deitado o olho vem logo depois do botão de girar a tela.
    if (!TvMode.isTv) return if (landscape) listOf(H_ORIENT, H_EYE) + l.drop(1) else l
    // TV deitada: o olho (modos de visualização) ocupa o lugar do botão de girar a tela.
    val tvl = l.filter { it != H_ORIENT }
    return if (landscape) listOf(H_EYE) + tvl else tvl
}

internal fun MainActivity.zoneCount(): Int = when (navZone) {
    1 -> headerOrder().size
    2 -> if (drawerAvailable()) 5 else 4   // 4.9.22: o 5º é o botão Apps (R3)
    else -> 0
}

internal fun MainActivity.zoneStep(dx: Int, dy: Int) {
    if (dx != 0) {
        val n = max(1, zoneCount())
        if (navZone == 1) hdrIdx = (hdrIdx + dx).coerceIn(0, n - 1)
        else ftrIdx = (ftrIdx + dx).coerceIn(0, n - 1)
        return
    }
    if ((navZone == 1 && dy > 0) || (navZone == 2 && dy < 0)) {
        navZone = 0
        coverUnderline = true   // 4.9.3: o foco voltou para a capa pela vertical: mostra o sublinhado
    }
}

/** O sublinhado aparece só no modo Padrão da TV, na capa em foco, enquanto o D-pad não anda para os lados. */
internal fun MainActivity.showUnderline(selected: Boolean): Boolean =
    selected && coverUnderline && navZone == 0 && padNav && rowNav && !carouselOn

internal fun MainActivity.zoneEnter(dx: Int, dy: Int): Boolean {
    if (dy == 0 || dx != 0) return false
    val ids = navIds()
    val idx = ids.indexOf(selectedId)
    val cols = navCols()
    val firstRow = rowNav || idx < cols
    val lastRow = rowNav || idx < 0 || idx >= ((ids.size - 1) / cols) * cols
    if (dy < 0 && firstRow) {
        hdrIdx = hdrIdx.coerceIn(0, max(0, headerOrder().size - 1))
        navZone = 1
        return true
    }
    if (dy > 0 && lastRow) {
        ftrIdx = ftrIdx.coerceIn(0, if (drawerAvailable()) 4 else 3)
        navZone = 2
        return true
    }
    return false
}

/** OK do controle remoto / botão A: age sobre o que está destacado (capa, botão do cabeçalho ou do rodapé). */
internal fun MainActivity.zoneActivate() {
    when (navZone) {
        1 -> when (headerOrder().getOrNull(hdrIdx)) {
            H_ORIENT -> toggleOrientation()
            H_EYE -> overlay = Overlay.ViewMode
            H_FLOAT -> toggleFloat()
            H_SELECT -> overlay = Overlay.Filter
            H_START -> overlay = Overlay.StartMenu
            H_GEAR -> overlay = Overlay.Settings
        }
        2 -> when (ftrIdx) {
            0 -> openSelected()
            1 -> {
                navZone = 0
                back()
            }
            2 -> overlay = Overlay.Search
            3 -> randomPick()
            4 -> openDrawer()   // 4.9.22
        }
        else -> openSelected()
    }
}

internal fun MainActivity.stepSelectionRaw(dx: Int, dy: Int) {
    val ids = navIds()
    val idx = ids.indexOf(selectedId)
    if (idx < 0) {
        selectedId = ids.first()
        return
    }
    val step = if (rowNav) dx else if (tvListOn) dy else dx + dy * navCols()
    if (step == 0) return
    val target = idx + step
    if (target in ids.indices) {
        selectedId = ids[target]
    } else if (dy > 0 && !rowNav) {
        selectedId = ids.last()
    }
}

// RB (+1) / LB (-1): PAGE_ITEMS jogos. Paisagem = para o lado; retrato = linhas para baixo/cima na mesma coluna.
internal fun MainActivity.pageStep(sign: Int) {
    val before = selectedId
    pageStepRaw(sign)
}

internal fun MainActivity.pageStepRaw(sign: Int) {
    coverUnderline = false
    val ids = navIds()
    val idx = ids.indexOf(selectedId)
    if (idx < 0) {
        selectedId = ids.first()
        return
    }
    val unit = if (rowNav) 1 else navCols()
    selectedId = ids[(idx + sign * PAGE_ITEMS * unit).coerceIn(0, ids.lastIndex)]
}

// RT (toEnd = true) / LT (false): último/primeiro jogo da fila.
// Paisagem = fim/começo da lista; retrato = fim/topo da coluna em que está.
internal fun MainActivity.jumpEdge(toEnd: Boolean) {
    val before = selectedId
    jumpEdgeRaw(toEnd)
}

internal fun MainActivity.jumpEdgeRaw(toEnd: Boolean) {
    coverUnderline = false
    val ids = navIds()
    val idx = ids.indexOf(selectedId)
    if (idx < 0) {
        selectedId = ids.first()
        return
    }
    val lastGame = if (ids.lastOrNull() == ADD_ID) ids.size - 2 else ids.size - 1 // "Adicionar" não conta
    if (lastGame < 0) return
    if (rowNav) {
        selectedId = ids[if (toEnd) lastGame else 0]
        return
    }
    val cols = navCols()
    val col = idx % cols
    val target = if (toEnd) {
        if (lastGame >= col) lastGame - ((lastGame - col) % cols) else lastGame
    } else {
        if (col <= lastGame) col else 0
    }
    selectedId = ids[target]
}

internal fun MainActivity.currentDir(): Pair<Int, Int> {
    when (heldKeys.lastOrNull()) {
        KeyEvent.KEYCODE_DPAD_LEFT -> return Pair(-1, 0)
        KeyEvent.KEYCODE_DPAD_RIGHT -> return Pair(1, 0)
        KeyEvent.KEYCODE_DPAD_UP -> return Pair(0, -1)
        KeyEvent.KEYCODE_DPAD_DOWN -> return Pair(0, 1)
    }
    return Pair(axisDx, axisDy)
}

// Chamado sempre que botão/alavanca muda: nova direção = um passo imediato + início da contagem de "segurar".
internal fun MainActivity.updateHold() {
    val (dx, dy) = currentDir()
    if (dx == holdDx && dy == holdDy) return
    holdDx = dx
    holdDy = dy
    padHandler.removeCallbacks(repeatTick)
    if (dx == 0 && dy == 0) return
    stepSelection(dx, dy)
    holdStartMs = SystemClock.uptimeMillis()
    padHandler.postDelayed(repeatTick, HOLD_DELAY_MS)
}

internal fun MainActivity.stopHold() {
    padHandler.removeCallbacks(repeatTick)
    heldKeys.clear()
    axisDx = 0
    axisDy = 0
    holdDx = 0
    holdDy = 0
    ltDown = false
    rtDown = false
}

internal fun MainActivity.handleTriggers(ev: MotionEvent) {
    val l = max(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
    val r = max(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
    if (!ltDown && l >= TRIGGER_PRESS) {
        ltDown = true
        jumpEdge(false)
    } else if (ltDown && l < TRIGGER_RELEASE) {
        ltDown = false
    }
    if (!rtDown && r >= TRIGGER_PRESS) {
        rtDown = true
        jumpEdge(true)
    } else if (rtDown && r < TRIGGER_RELEASE) {
        rtDown = false
    }
}

/** Primeiro uso: pergunta como o usuário quer cadastrar o primeiro jogo (uma vez só). */
internal fun MainActivity.maybeWelcome() {
    if (prefs.getBoolean("welcomeDone", false)) return
    prefs.edit().putBoolean("welcomeDone", true).apply()
    if (games.isEmpty() && overlay is Overlay.None) {
        // 4.9.13: celular e tablet começam pelas boas-vindas do tutorial; a TV segue com a escolha de como adicionar.
        overlay = if (tutorialAvailable) Overlay.TutorialWelcome else Overlay.AddChoice(true)
    }
}

internal fun MainActivity.openAdd() {
    overlay = Overlay.AddChoice(false)
}

internal fun MainActivity.openSelected() {
    val id = selectedId ?: return
    if (id.startsWith(PLAT_PREFIX)) {
        enterPlatform(id.removePrefix(PLAT_PREFIX))
        return
    }
    if (id == ADD_ID) {
        openAdd()
        return
    }
    if (games.none { it.id == id }) return
    overlay = Overlay.Info(id)
}

internal fun MainActivity.infoPlay(g: Game) {
    overlay = Overlay.None
    playGame(g)
}

internal fun MainActivity.editSelected() {
    val id = selectedId
    if (id != null && id.startsWith(PLAT_PREFIX)) {
        overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
        return
    }
    if (id == null || id == ADD_ID) {
        openAdd()
        return
    }
    games.firstOrNull { it.id == id }?.let { overlay = Overlay.Edit(it) }
}

internal fun MainActivity.randomPick() {
    coverUnderline = false
    if (inPlatformList()) {
        selectedId = navIds().random()
        return
    }
    val l = visibleGames()
    if (l.isNotEmpty()) selectedId = l.random().id
}

/** 4.9.5: sem controle conectado o teste nem abre (avisa na tela) — antes, em pé, ele travava o Nexus. */
internal fun MainActivity.openPadTest() {
    if (PadInput.gamepadDevice() == null) {
        toast("Conecte um controle (Bluetooth ou cabo) para usar o teste.")
        return
    }
    returnKey = "pad"
    overlay = Overlay.PadTest
}

/** Volta uma tela (a que abriu a atual) ou fecha tudo se não houver. */
internal fun MainActivity.popOverlay() {
    overlay = if (overlayStack.isNotEmpty()) overlayStack[overlayStack.size - 1] else Overlay.None
}

internal fun MainActivity.back() {
    when {
        ytOpen -> if (ytFull) ytFull = false else closeVideo()
        videoLinkFor != null -> videoLinkFor = null
        permHelp != null -> permHelp = null
        explorer != null -> explorer?.let { if (!it.up()) explorer = null }
        !modalOpen() && navZone != 0 -> navZone = 0
        appsDrawerOpen -> appsDrawerOpen = false
        hiddenAppsOpen -> hiddenAppsOpen = false
        romList != null -> romList = null
        batch != null -> {
            val b = batch
            if (b != null && b.phase == BatchPhase.SCANNING) toast("Varredura em andamento. Use Cancelar ou Minimizar.")
            else closeBatch()
        }
        launcherReturn != null -> launcherReturn = null
        shortcutFix != null -> shortcutFix = null
        platPicker != null -> platPicker = null
        emuPicker != null -> emuPicker = null
        appFilterKind != 0 -> appFilterKind = 0
        appPickerOpen -> appPickerOpen = false
        sgdbPicker != null -> { if (sgdbPicker?.backStep?.invoke() != true) sgdbPicker = null }
        genrePickerOpen -> genrePickerOpen = false
        collPickerOpen -> collPickerOpen = false
        overlay is Overlay.Tutorial && tutOpenId != null -> tutOpenId = null
        overlay is Overlay.About && aboutPage != 0 -> aboutPage = 0
        overlay is Overlay.About -> { returnKey = "about"; popOverlay() }
        // 4.9.11: as confirmações de apagar voltam para a tela de onde saíram, mesmo com outras telas na pilha.
        overlay is Overlay.ConfirmDeleteCollection -> overlay = Overlay.Collections
        overlay is Overlay.ConfirmDelete -> overlay = Overlay.Edit((overlay as Overlay.ConfirmDelete).game)
        overlay !is Overlay.None && overlayStack.isNotEmpty() -> overlay = overlayStack[overlayStack.size - 1]
        overlay is Overlay.About -> overlay = Overlay.Settings
        overlay is Overlay.Genres || overlay is Overlay.Platforms || overlay is Overlay.Collections -> overlay = Overlay.Settings
        overlay is Overlay.ConfirmDeleteCollection -> overlay = Overlay.Collections
        overlay is Overlay.LinkEdit -> overlay = Overlay.Platforms
        overlay is Overlay.ConfirmDelete -> overlay = Overlay.Edit((overlay as Overlay.ConfirmDelete).game)
        overlay !is Overlay.None -> overlay = Overlay.None
        dashMode == 1 && dashPlatform.isNotEmpty() -> exitPlatform()
        else -> selectedId = null
    }
}

// ---------- Controle (gamepad) ----------
internal fun MainActivity.modalOpen(): Boolean = overlay !is Overlay.None || appsDrawerOpen || hiddenAppsOpen || appPickerOpen || appFilterKind != 0 || emuPicker != null || platPicker != null || shortcutFix != null || launcherReturn != null || genrePickerOpen || collPickerOpen || sgdbPicker != null || videoLinkFor != null || romList != null || batch != null || explorer != null || permHelp != null

/**
 * Tela inicial da TV: Voltar NUNCA fecha o Nexus de primeira. Fora da primeira capa, leva o foco para ela.
 * Na primeira capa só avisa; fecha com 3 toques rápidos (até 1,5 s entre eles) ou segurando 3 segundos.
 */
internal fun MainActivity.tvHomeBack(ev: KeyEvent): Boolean {
    if (modalOpen() || ytOpen || overlay !is Overlay.None) return false
    if (dashMode == 1 && dashPlatform.isNotEmpty()) { tvBackCount = 0; return false }   // dentro de uma plataforma: sobe um nível
    val now = SystemClock.uptimeMillis()
    if (ev.action == KeyEvent.ACTION_UP) {
        tvBackHoldToast = false
        return true
    }
    if (ev.repeatCount > 0) {
        val held = now - tvBackDownMs
        if (held >= 3000L) {
            tvBackCount = 0
            if (isHome) moveTaskToBack(true) else finish()
        } else if (held >= 700L && !tvBackHoldToast) {
            tvBackHoldToast = true
            toast("Continue segurando para sair…")
        }
        return true
    }
    tvBackDownMs = now
    tvBackHoldToast = false
    val first = firstNavId()
    val onFirst = navZone == 0 && selectedId == first
    if (!onFirst) {
        tvBackCount = 0
        navZone = 0
        coverUnderline = false
        if (first != null) selectedId = first
        return true
    }
    tvBackCount = if (tvBackCount > 0 && now - tvBackLastMs <= 1500L) tvBackCount + 1 else 1
    tvBackLastMs = now
    when {
        tvBackCount >= 3 -> {
            tvBackCount = 0
            if (isHome) moveTaskToBack(true) else finish()
        }
        tvBackCount == 1 -> toast("Aperte Voltar 3 vezes seguidas, ou segure por 3 segundos, para sair")
        else -> toast("Mais uma vez para sair")
    }
    return true
}

/** Toque longo (OK segurado) no item selecionado: jogo = detalhes; plataforma = trocar a imagem dela. */
internal fun MainActivity.longPressSelected() {
    val id = selectedId ?: return
    when {
        id.startsWith(PLAT_PREFIX) -> overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
        id == ADD_ID -> return
        games.any { it.id == id } -> overlay = Overlay.Info(id)
    }
}

internal fun MainActivity.okKey(ev: KeyEvent): Boolean {
    if (navZone != 0) {
        // Cabeçalho e rodapé: age na hora, como antes.
        if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) zoneActivate()
        return true
    }
    when (ev.action) {
        KeyEvent.ACTION_DOWN -> {
            if (ev.repeatCount == 0) {
                okPending = true
                okLong = false
            } else if (okPending && !okLong && (ev.isLongPress || ev.eventTime - ev.downTime >= OK_LONG_MS)) {
                okLong = true
                okSwallow = true
                longPressSelected()
            }
        }
        KeyEvent.ACTION_UP -> {
            if (okPending && !okLong) {
                // Alguns controles não repetem a tecla: se ficou apertado o tempo do toque longo, vale como longo.
                if (ev.eventTime - ev.downTime >= OK_LONG_MS) longPressSelected() else zoneActivate()
            }
            okPending = false
            okLong = false
        }
    }
    return true
}
