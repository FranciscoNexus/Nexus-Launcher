package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Plataformas cadastradas ----------
internal fun MainActivity.platformNames(): List<String> = sortPlatforms(platforms.toList()).map { it.name }

// Android não usa emulador, então não entra no vínculo de plataformas e emuladores.
internal fun MainActivity.linkablePlatforms(): List<String> = platformNames().filter { it != ANDROID_PLATFORM }

// Chave para tabelas embutidas (extensões de ROM, emulador padrão), mesmo se a plataforma foi renomeada.
internal fun MainActivity.execKey(platform: String): String {
    val b = platforms.firstOrNull { it.name == platform }?.base ?: ""
    return if (b.isEmpty()) platform else b
}

// Garante que "Web / Navegador" exista e que toda plataforma usada por algum jogo esteja cadastrada.
internal fun MainActivity.syncPlatforms() {
    var changed = false
    for (fixed in listOf(WEB_PLATFORM, ANDROID_PLATFORM)) {
        if (platforms.none { it.name == fixed }) {
            platforms.add(GamePlatform(fixed, DEFAULT_MANUFACTURER[fixed] ?: "", fixed))
            changed = true
        }
    }
    for (g in games) {
        if (g.platform.isNotBlank() && platforms.none { it.name == g.platform }) {
            platforms.add(
                GamePlatform(g.platform, DEFAULT_MANUFACTURER[g.platform] ?: "", if (g.platform in PLATFORMS || EmuCatalog.all(this).any { it.name == g.platform }) g.platform else "")
            )
            changed = true
        }
    }
    if (changed) savePrefs()
}

internal fun MainActivity.savePlatform(old: GamePlatform?, name: String, manufacturer: String): Boolean {
    val n = name.trim()
    if (n.isEmpty()) {
        toast("Digite o nome da plataforma")
        return false
    }
    if (platforms.any { it.name.equals(n, ignoreCase = true) && it.name != old?.name }) {
        toast("Já existe uma plataforma com esse nome")
        return false
    }
    val m0 = manufacturer.trim()
    val m = platforms.map { it.manufacturer }.firstOrNull { it.isNotBlank() && it.equals(m0, ignoreCase = true) } ?: m0
    if (old == null) {
        platforms.add(GamePlatform(n, m, ""))
    } else {
        val i = platforms.indexOfFirst { it.name == old.name }
        if (i >= 0) platforms[i] = old.copy(name = n, manufacturer = m)
        if (n != old.name) {
            for (k in games.indices) {
                if (games[k].platform == old.name) games[k] = games[k].copy(platform = n)
                if (games[k].maskPlatform == old.name) games[k] = games[k].copy(maskPlatform = n)
            }
            for (k in links.indices) if (links[k].platform == old.name) links[k] = links[k].copy(platform = n)
            if (fPlatform == old.name) fPlatform = n
            if (dashPlatform == old.name) dashPlatform = n
            saveLibrary()
        }
    }
    savePrefs()
    return true
}

internal fun MainActivity.deletePlatform(p: GamePlatform) {
    platforms.removeAll { it.name == p.name }
    links.removeAll { it.platform == p.name }
    if (fPlatform == p.name) fPlatform = ""
    savePrefs()
}

internal fun MainActivity.effectivePkg(g: Game, link: PlatformLink?): String? {
    if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
    if (link != null && link.pkg.isNotEmpty() && isInstalled(link.pkg)) return link.pkg
    val kw = EXEC_KEYWORD[g.execType] ?: return null
    return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
}

internal fun MainActivity.templateFor(pkg: String, link: PlatformLink?): String? {
    if (link != null && link.pkg == pkg && link.template.isNotBlank()) return link.template
    return TEMPLATES[pkg]
}

internal fun MainActivity.linkFor(platform: String): PlatformLink? = links.firstOrNull { it.platform == platform }

/** Lista completa (cadastradas + catálogo) que o seletor mostra, em ordem alfabética. */
internal fun MainActivity.platformPickList(filter: (String) -> Boolean): List<String> {
    val reg = platformNames()
    val extra = EmuCatalog.all(this).map { it.name }.filter { n -> reg.none { it.equals(n, ignoreCase = true) } }
    return (reg + extra).filter(filter).distinctBy { it.lowercase() }.sortedAlpha { it }
}

internal fun MainActivity.addPlatforms(current: String?): List<String> {
    val base = platformPickList { true }
    return if (current != null && current !in base) base + current else base
}

/** Jogos de emulador entram em lote; o que sobra no cadastro manual quase sempre é Android. */
internal fun MainActivity.defaultAddPlatform(): String = ANDROID_PLATFORM

/** Só as plataformas criadas pelo usuário podem ser editadas ou apagadas. */
internal fun MainActivity.isCustomPlatform(name: String): Boolean =
    name != WEB_PLATFORM && name != ANDROID_PLATFORM &&
        platforms.firstOrNull { it.name == name }?.base?.isEmpty() == true

internal fun MainActivity.brandOfPlatform(n: String): String =
    (platforms.firstOrNull { it.name == n }?.manufacturer
        ?: EmuCatalog.all(this).firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
        ?: "").ifBlank { "Outros" }

/** Cadastra a plataforma (do catálogo) quando um jogo ou emulador passa a usá-la. */
internal fun MainActivity.registerPlatformIfNeeded(name: String) {
    if (name.isBlank() || platforms.any { it.name == name }) return
    val dp = EmuCatalog.forPlatform(this, name)
    platforms.add(GamePlatform(name, dp?.manufacturer ?: DEFAULT_MANUFACTURER[name] ?: "", name))
    savePrefs()
}

// ---------- Cadastro em lote (varredura automática) ----------
internal fun MainActivity.execBase(platform: String): String = platforms.firstOrNull { it.name == platform }?.base ?: ""

/** Nome do app para mostrar: o nome real quando o catálogo só traz o pacote. */
internal fun MainActivity.emuDisplayName(pl: EmuPlayer, installed: Boolean, rec: EmuRec?): String {
    if (!PKG_LIKE.matches(pl.name)) return pl.name
    if (installed) allApps.firstOrNull { it.pkg == pl.pkg }?.label?.takeIf { it.isNotBlank() }?.let { return it }
    if (rec != null) return rec.name
    val seg = pl.name.substringAfterLast('.')
    return seg.replaceFirstChar { it.uppercase() }
}
