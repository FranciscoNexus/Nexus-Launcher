package com.nexus.launcher

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Modo TV (4.6.0): o mesmo APK roda em celular e em TV/dongle (Chromecast com Google TV, Fire TV Stick, Mi TV Stick...).
 * Em TV o Nexus é operado só por controle (gamepad ou controle remoto): D-pad navega, OK clica,
 * e as funções que só existem em celular (girar tela, launcher padrão, apps ocultos...) ficam escondidas.
 */
object TvMode {
    /** Escala da interface em TV (tela vista de longe: tudo um pouco maior). */
    const val UI_SCALE = 1.3f

    private var detected by mutableStateOf(false)
    private var forced by mutableStateOf(false)

    /** true = interface de TV. Lido pela tela (Compose), então muda na hora quando o modo é forçado. */
    val isTv: Boolean get() = detected || forced

    /** 4.9.0: modo leve (automático na TV): sem brilho nas capas e com carrossel simples, para aparelhos fracos como o Fire TV Stick. */
    val light: Boolean get() = isTv

    /** O aparelho se declara TV/dongle (não é só o modo forçado nas configurações). */
    val isRealTv: Boolean get() = detected

    /**
     * 4.9.3: Amazon Fire TV (Fire TV Stick, Fire TV Cube, TVs com Fire TV). Esses aparelhos não informam a temperatura
     * e não aceitam painel flutuante sobre outros apps, então a interface esconde essas funções.
     */
    val isFireTv: Boolean get() = fireTv
    private var fireTv = false

    /** Chame uma vez ao abrir (Activity e serviços). Guarda também a escolha manual de "Modo TV". */
    fun init(ctx: Context) {
        detected = detect(ctx)
        fireTv = try {
            ctx.packageManager.hasSystemFeature("amazon.hardware.fire_tv")
        } catch (_: Exception) {
            false
        }
        val sp = ctx.getSharedPreferences("nexus_prefs", Context.MODE_PRIVATE)
        // 4.9.6: o "Modo TV" forçado deixa tudo 30% maior. Em celular ele é só para teste e ficava ligado sem a pessoa
        // perceber, então na primeira abertura da 4.9.6 ele é desligado uma vez (a pessoa pode ligar de novo depois).
        if (!detected && !sp.getBoolean("tvForceReset496", false)) {
            sp.edit().putBoolean("tvForce", false).putBoolean("tvForceReset496", true).apply()
        }
        forced = sp.getBoolean("tvForce", false)
    }

    /** Liga/desliga o modo TV à mão (para testar num celular ou numa TV que o Android não identificou). */
    fun setForced(ctx: Context, on: Boolean) {
        forced = on
        ctx.getSharedPreferences("nexus_prefs", Context.MODE_PRIVATE).edit().putBoolean("tvForce", on).apply()
    }

    val isForced: Boolean get() = forced

    private fun detect(ctx: Context): Boolean {
        return try {
            val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
            val byMode = ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
            val pm = ctx.packageManager
            val leanback = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
            val fireTv = pm.hasSystemFeature("amazon.hardware.fire_tv")
            byMode || leanback || fireTv
        } catch (_: Exception) {
            false
        }
    }
}
