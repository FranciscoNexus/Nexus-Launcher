package com.nexus.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

val PanelBg = Color(0xFF1C1C1E)
val FieldBg = Color(0xFF2C2C2E)
val FieldBorder = Color(0xFF48484A)
val BtnGray = Color(0xFF3A3A3C)
val BtnBlue = Color(0xFF007AFF)
val BtnOrange = Color(0xFFFF9500)
val BtnRed = Color(0xFFFF3B30)
val FocusRing = Color(0xFF0A84FF)

/** Anel de foco para navegar por controle. Deve vir ANTES do clickable. */
@Composable
fun Modifier.navFocus(shape: Shape): Modifier {
    var focused by remember { mutableStateOf(false) }
    return this
        .onFocusChanged { focused = it.isFocused }
        .then(if (focused) Modifier.border(2.dp, FocusRing, shape) else Modifier)
}

@Composable
fun NBtn(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(40.dp)
            .clip(shape)
            .background(color)
            .navFocus(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun NField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    focus: FocusRequester? = null
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
        cursorBrush = SolidColor(Color.White),
        modifier = modifier
            .height(40.dp)
            .then(if (focus != null) Modifier.focusRequester(focus) else Modifier)
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(FieldBg)
                    .border(if (focused) 2.dp else 1.dp, if (focused) FocusRing else FieldBorder, shape)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (value.isEmpty()) Text(hint, color = Color(0xFF8E8E93), fontSize = 14.sp, maxLines = 1)
                inner()
            }
        }
    )
}

@Composable
fun NDrop(
    label: String,
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Box(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .clip(shape)
                .background(FieldBg)
                .border(1.dp, FieldBorder, shape)
                .navFocus(shape)
                .clickable { open = true }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (label.isEmpty()) value else "$label: $value",
                color = Color.White, fontSize = 13.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text("▾", color = Color(0xFF8E8E93), fontSize = 14.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(
                    text = { Text(o, fontSize = 14.sp) },
                    onClick = {
                        onSelect(o)
                        open = false
                    }
                )
            }
        }
    }
}

@Composable
fun NCheck(checked: Boolean, label: String, onChange: (Boolean) -> Unit) {
    val box = RoundedCornerShape(6.dp)
    val row = RoundedCornerShape(8.dp)
    Row(
        modifier = Modifier
            .height(40.dp)
            .clip(row)
            .navFocus(row)
            .clickable { onChange(!checked) }
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(box)
                .background(if (checked) BtnBlue else FieldBg)
                .border(1.dp, if (checked) BtnBlue else FieldBorder, box),
            contentAlignment = Alignment.Center
        ) {
            if (checked) Text("✓", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp, maxLines = 1, softWrap = false)
    }
}

@Composable
fun SmallLabel(text: String) {
    Text(text, color = Color(0xFF8E8E93), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
}

/** Ícone de orientação (celular + colchete), desenhado em vetor. */
@Composable
fun OrientationIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(20.dp)) {
        val s = size.minDimension
        val c = Color(0xFFEDEDED)
        val stroke = Stroke(width = s * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        drawRoundRect(
            color = c,
            topLeft = Offset(s * 0.08f, s * 0.14f),
            size = Size(s * 0.48f, s * 0.72f),
            cornerRadius = CornerRadius(s * 0.1f),
            style = stroke
        )
        drawCircle(color = c, radius = s * 0.05f, center = Offset(s * 0.20f, s * 0.72f))
        val p = Path().apply {
            moveTo(s * 0.64f, s * 0.26f)
            lineTo(s * 0.80f, s * 0.26f)
            quadraticBezierTo(s * 0.92f, s * 0.26f, s * 0.92f, s * 0.38f)
            lineTo(s * 0.92f, s * 0.62f)
            quadraticBezierTo(s * 0.92f, s * 0.74f, s * 0.80f, s * 0.74f)
            lineTo(s * 0.64f, s * 0.74f)
        }
        drawPath(p, color = c, style = stroke)
    }
}

/**
 * Diálogo próprio: tela cheia por trás, painel centralizado que se ajusta ao conteúdo,
 * barras do sistema ocultas e sem rolagem quando o conteúdo cabe.
 */
@Composable
fun NexusDialog(
    landscape: Boolean,
    onDismiss: () -> Unit,
    scroll: Boolean = true,
    tall: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = false,
            decorFitsSystemWindows = false
        )
    ) {
        val view = LocalView.current
        SideEffect {
            val w = (view.parent as? DialogWindowProvider)?.window
            if (w != null) {
                WindowCompat.setDecorFitsSystemWindows(w, false)
                val c = WindowInsetsControllerCompat(w, view)
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
                .imePadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            val shape = RoundedCornerShape(20.dp)
            var m = Modifier
                .widthIn(max = 760.dp)
                .fillMaxWidth(if (landscape) 0.92f else 0.95f)
            if (tall) m = m.fillMaxHeight(0.94f)
            m = m.clip(shape).background(PanelBg).border(1.dp, FieldBg, shape).padding(14.dp)
            Column(
                modifier = if (scroll) m.verticalScroll(rememberScrollState()) else m,
                content = content
            )
        }
    }
}
