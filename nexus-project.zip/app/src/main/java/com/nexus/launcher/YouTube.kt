package com.nexus.launcher

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Vídeo achado no YouTube. */
data class YtVideo(val id: String, val title: String)

sealed class YtResult {
    class Ok(val video: YtVideo) : YtResult()
    /** A busca funcionou, mas nenhum vídeo serviu. */
    object NotFound : YtResult()
    class Failure(val message: String, val quota: Boolean = false) : YtResult()
}

/** Busca de vídeo de gameplay pela API do YouTube (chave do próprio usuário). Uma busca por jogo; o resultado fica salvo. */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3/search"

    /** Idioma da busca: o do sistema, limitado a português, inglês e espanhol (outro = inglês). */
    fun searchLang(): String = when (Locale.getDefault().language) {
        "pt" -> "pt"
        "es" -> "es"
        else -> "en"
    }

    /** Endereço da busca no site do YouTube (abre no app do YouTube, se instalado, ou no navegador). Não usa a chave. */
    fun searchUrl(title: String, platform: String, simple: Boolean = false): String {
        // simple (TV, 4.9.0): "título plataforma gameplay".
        val q = listOf(title, platform, if (simple) "gameplay" else terms(searchLang())).filter { it.isNotBlank() }.joinToString(" ")
        return "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(q, "UTF-8")
    }

    /** Termos de busca no idioma escolhido. */
    private fun terms(lang: String): String = when (lang) {
        "pt" -> "gameplay sem comentários detonado"
        "es" -> "gameplay sin comentarios"
        else -> "gameplay no commentary walkthrough"
    }

    private fun errorFor(code: Int, body: String): YtResult.Failure {
        val reason = try {
            JSONObject(body).optJSONObject("error")?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason", "") ?: ""
        } catch (_: Exception) { "" }
        return when {
            reason == "quotaExceeded" || reason == "dailyLimitExceeded" || reason == "rateLimitExceeded" ->
                YtResult.Failure("Limite diário da API do YouTube atingido. Tente amanhã.", quota = true)
            code == 400 || reason == "keyInvalid" -> YtResult.Failure("Chave da API do YouTube inválida")
            code == 403 -> YtResult.Failure("Chave do YouTube sem permissão (ative a YouTube Data API v3)")
            else -> YtResult.Failure("Erro do YouTube ($code)")
        }
    }

    private fun get(url: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "NexusLauncher (uso pessoal)")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    /** Procura o vídeo (bloqueante: chame fora da thread principal). */
    fun search(key: String, title: String, platform: String): YtResult {
        val lang = searchLang()
        val q = listOf(title.trim(), platform.trim(), terms(lang)).filter { it.isNotEmpty() }.joinToString(" ")
        val url = BASE + "?part=snippet&type=video&maxResults=5&videoEmbeddable=true&videoSyndicated=true" +
            "&safeSearch=none&relevanceLanguage=$lang&q=" + URLEncoder.encode(q, "UTF-8") +
            "&key=" + URLEncoder.encode(key, "UTF-8")
        return try {
            val (code, body) = get(url)
            if (code !in 200..299) return errorFor(code, body)
            val items = JSONObject(body).optJSONArray("items")
            if (items == null || items.length() == 0) return YtResult.NotFound
            // Prefere o primeiro resultado cujo título contém o nome do jogo; senão, o primeiro.
            val wanted = foldKey(title)
            var first: YtVideo? = null
            for (i in 0 until items.length()) {
                val obj = items.optJSONObject(i) ?: continue
                val id = obj.optJSONObject("id")?.optString("videoId", "") ?: ""
                if (id.isEmpty()) continue
                val t = obj.optJSONObject("snippet")?.optString("title", "") ?: ""
                val v = YtVideo(id, t)
                if (first == null) first = v
                if (wanted.isNotEmpty() && foldKey(t).contains(wanted)) return YtResult.Ok(v)
            }
            if (first != null) YtResult.Ok(first) else YtResult.NotFound
        } catch (_: IOException) {
            YtResult.Failure("Sem conexão com o YouTube")
        } catch (_: Exception) {
            YtResult.Failure("Resposta inesperada do YouTube")
        }
    }

    /** Valida a chave com uma busca mínima (custa 100 unidades da cota). Retorna null se válida, ou a mensagem de erro. */
    fun ping(key: String): String? {
        val url = BASE + "?part=snippet&type=video&maxResults=1&q=gameplay&key=" + URLEncoder.encode(key, "UTF-8")
        return try {
            val (code, body) = get(url)
            if (code in 200..299) null else errorFor(code, body).message
        } catch (_: IOException) {
            "Sem conexão com o YouTube"
        } catch (_: Exception) {
            "Resposta inesperada do YouTube"
        }
    }

    private fun foldKey(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private val ID_RE = Regex("^[A-Za-z0-9_-]{11}$")
    private val URL_RE = Regex("(?:youtu\\.be/|youtube\\.com/(?:watch\\?(?:.*&)?v=|embed/|shorts/|live/|v/)|youtube-nocookie\\.com/embed/)([A-Za-z0-9_-]{11})")

    /** Extrai o ID de um link do YouTube (ou aceita o próprio ID de 11 caracteres). Null se não reconhecer. */
    fun parseId(text: String): String? {
        val t = text.trim()
        if (t.isEmpty()) return null
        if (ID_RE.matches(t)) return t
        return URL_RE.find(t)?.groupValues?.get(1)
    }
}
