package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Tela principal ----------
@Composable
internal fun MainActivity.NexusScreen() {
    val ctx = LocalContext.current
    val list = visibleGames()
    val accent = parseColor(accentHex)
    val recents = recentIds()
    val inPlat = inPlatformList()
    val platCards = if (inPlat) platformCards() else emptyList()
    val ids = if (inPlat) platCards.map { PLAT_PREFIX + it.name } else list.map { it.id } + ADD_ID
    BackHandler(enabled = dashMode == 1 && dashPlatform.isNotEmpty() && overlay is Overlay.None) { exitPlatform() }
    // Como launcher padrão, o Nexus é a tela inicial: "Voltar" na tela principal não deve fechá-lo.
    BackHandler(enabled = isHome && !modalOpen() && !(dashMode == 1 && dashPlatform.isNotEmpty())) { }
    // TV (controle remoto): "Voltar" sai do cabeçalho/rodapé.
    // 4.9.11: a tela de Detalhes não é uma janela (Dialog); o gesto Voltar do celular também precisa fechá-la
    // (antes só funcionava com controle, e no celular o gesto fechava o app).
    BackHandler(enabled = (padNav && navZone != 0) || overlay is Overlay.Info) { back() }
    // 4.7.0: com o vídeo aberto, "Voltar" sai da tela cheia / fecha o player (celular e TV).
    BackHandler(enabled = ytOpen || videoLinkFor != null) { back() }
    // 4.9.11: os filtros (menos a pesquisa de texto) ficam salvos até "Remover Filtros".
    LaunchedEffect(favOnly, fPlatform, fGenre, fCollection, sortMode) { saveFilters() }
    LaunchedEffect(selectedId, tvView) { navZone = 0 }
    // 4.9.1: ao fechar qualquer tela por cima, o foco do Compose não pode ficar "preso" num botão do cabeçalho
    // (era o olho que ficava aceso). Quem marca a posição na tela inicial é o seletor próprio do Nexus.
    val rootFm = LocalFocusManager.current
    val modalForFocus = modalOpen()
    val padForFocus = padNav
    SideEffect { FocusStyle.blockBehind = modalForFocus; FocusStyle.padMode = padForFocus }
    LaunchedEffect(overlay) {
        if (padNav && overlay is Overlay.None) {
            delay(120)
            try {
                rootFm.clearFocus(force = true)
            } catch (_: Exception) {
            }
        }
    }
    val gridState = rememberLazyGridState()
    val rowState = rememberLazyListState()
    val listState = rememberLazyListState()   // TV, modo Lista (vertical)
    val dens = LocalDensity.current
    var rowW by remember { mutableStateOf(0) }
    val userDrag = remember { booleanArrayOf(false) }
    LaunchedEffect(rowState) {
        rowState.interactionSource.interactions.collect { if (it is DragInteraction.Start) userDrag[0] = true }
    }
    // Carrossel: ao terminar de arrastar, a capa que parou no centro vira a selecionada.
    LaunchedEffect(rowState, carouselOn) {
        snapshotFlow { rowState.isScrollInProgress }.collect { moving ->
            if (!moving && userDrag[0]) {
                userDrag[0] = false
                if (carouselOn) {
                    val info = rowState.layoutInfo
                    val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                    val c = info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2f - mid) }
                    (c?.key as? String)?.let { k -> if (k != selectedId) selectedId = k }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        val monitor = PowerMonitor(ctx) { power = it }
        monitor.start()
        onDispose { monitor.stop() }
    }

    val cols by remember {
        derivedStateOf {
            val v = gridState.layoutInfo.visibleItemsInfo
            if (v.isEmpty()) 2 else max(1, v.count { it.offset.y == v.first().offset.y })
        }
    }
    SideEffect { gridColumns = cols }

    // 4.9.5: com qualquer janela aberta o catálogo atrás fica PARADO: guarda a posição ao abrir e volta nela ao fechar.
    val modalNow = modalOpen()
    val frozenPos = remember { IntArray(7) }
    LaunchedEffect(modalNow) {
        if (modalNow) {
            frozenPos[0] = rowState.firstVisibleItemIndex; frozenPos[1] = rowState.firstVisibleItemScrollOffset
            frozenPos[2] = listState.firstVisibleItemIndex; frozenPos[3] = listState.firstVisibleItemScrollOffset
            frozenPos[4] = gridState.firstVisibleItemIndex; frozenPos[5] = gridState.firstVisibleItemScrollOffset
            frozenPos[6] = 1
        } else if (frozenPos[6] == 1) {
            frozenPos[6] = 0
            try {
                if (rowState.firstVisibleItemIndex != frozenPos[0] || rowState.firstVisibleItemScrollOffset != frozenPos[1]) rowState.scrollToItem(frozenPos[0], frozenPos[1])
                if (listState.firstVisibleItemIndex != frozenPos[2] || listState.firstVisibleItemScrollOffset != frozenPos[3]) listState.scrollToItem(frozenPos[2], frozenPos[3])
                if (gridState.firstVisibleItemIndex != frozenPos[4] || gridState.firstVisibleItemScrollOffset != frozenPos[5]) gridState.scrollToItem(frozenPos[4], frozenPos[5])
            } catch (_: Exception) {
            }
        }
    }
    var lastView by remember { mutableStateOf(tvView) }
    // 4.9.3: rolagem LINEAR. A capa em foco só empurra a lista o mínimo para ficar inteira à vista (antes, ao chegar na
    // última capa da direita a lista "virava a página" e o foco pulava para a primeira da esquerda).
    LaunchedEffect(selectedId, landscape, tvView, modalNow) {
        if (modalNow) return@LaunchedEffect
        val idx = ids.indexOf(selectedId)
        if (idx < 0) return@LaunchedEffect
        val viewChanged = lastView != tvView
        lastView = tvView
        val margin = with(dens) { 14.dp.toPx() }
        if (tvListOn) {
            val info = listState.layoutInfo
            val vis = info.visibleItemsInfo
            val h = with(dens) { listRowH.dp.toPx() }
            if (viewChanged || vis.isEmpty()) {
                // Primeira vez no modo: a capa selecionada fica no meio da tela.
                val vh = info.viewportEndOffset - info.viewportStartOffset
                val off = -(((vh - h) / 2f).toInt()).coerceAtLeast(0)
                listState.scrollToItem(idx, off)
            } else {
                val first = vis.first()
                val last = vis.last()
                val pitch = if (vis.size >= 2) (vis[1].offset - vis[0].offset).toFloat() else h + with(dens) { 10.dp.toPx() }
                val here = vis.firstOrNull { x -> x.index == idx }
                val far = here == null && (if (idx > last.index) idx - last.index else first.index - idx) > 4
                if (far) {
                    val vh = info.viewportEndOffset - info.viewportStartOffset
                    listState.animateScrollToItem(idx, -(((vh - h) / 2f).toInt()).coerceAtLeast(0))
                } else {
                    val start = here?.offset?.toFloat()
                        ?: if (idx > last.index) last.offset + (idx - last.index) * pitch else first.offset - (first.index - idx) * pitch
                    val d = fitDelta(start, h, info.viewportEndOffset.toFloat(), margin)
                    if (d != 0f) listState.animateScrollBy(d)
                }
            }
        } else if (rowNav) {
            val info = rowState.layoutInfo
            val vis = info.visibleItemsInfo
            if (carouselOn) {
                val item = vis.firstOrNull { x -> x.index == idx }
                val ok = item != null && abs(item.offset + item.size / 2f -
                    (info.viewportStartOffset + info.viewportEndOffset) / 2f) < 2f
                if (!ok) rowState.animateScrollToItem(idx)
            } else if (vis.isEmpty()) {
                rowState.animateScrollToItem(idx)
            } else {
                val first = vis.first()
                val last = vis.last()
                val pitch = if (vis.size >= 2) (vis[1].offset - vis[0].offset).toFloat() else last.size + with(dens) { 16.dp.toPx() }
                val here = vis.firstOrNull { x -> x.index == idx }
                val far = here == null && (if (idx > last.index) idx - last.index else first.index - idx) > 4
                if (far) {
                    rowState.animateScrollToItem(idx)   // salto longo (L1/R1, L2/R2, aleatório)
                } else {
                    val start = here?.offset?.toFloat()
                        ?: if (idx > last.index) last.offset + (idx - last.index) * pitch else first.offset - (first.index - idx) * pitch
                    val size = (here ?: last).size.toFloat()
                    val d = fitDelta(start, size, info.viewportEndOffset.toFloat(), margin)
                    if (d != 0f) rowState.animateScrollBy(d)
                }
            }
        } else {
            val info = gridState.layoutInfo
            val vis = info.visibleItemsInfo
            val colsNow = max(1, gridColumns)
            if (viewChanged || vis.isEmpty()) {
                gridState.scrollToItem(idx)
            } else {
                val first = vis.first()
                val last = vis.last()
                val second = vis.firstOrNull { x -> x.offset.y != first.offset.y }
                val pitch = if (second != null) (second.offset.y - first.offset.y).toFloat()
                    else first.size.height + with(dens) { 14.dp.toPx() }
                val here = vis.firstOrNull { x -> x.index == idx }
                val rowsAhead = if (idx > last.index) idx / colsNow - last.index / colsNow else 0
                val rowsBehind = if (idx < first.index) first.index / colsNow - idx / colsNow else 0
                if (here == null && (rowsAhead > 3 || rowsBehind > 3)) {
                    gridState.animateScrollToItem(idx)
                } else {
                    val start = here?.offset?.y?.toFloat()
                        ?: if (rowsAhead > 0) last.offset.y + rowsAhead * pitch else first.offset.y - rowsBehind * pitch
                    val d = fitDelta(start, (here ?: last).size.height.toFloat(), info.viewportEndOffset.toFloat(), margin)
                    if (d != 0f) gridState.animateScrollBy(d)
                }
            }
        }
    }

    val blurR by animateDpAsState(if (overlay is Overlay.Info) 14.dp else 0.dp, label = "infoBlur")
    val title = when (val s = selectedId) {
        null -> ""
        ADD_ID -> "Adicionar Novo Jogo"
        else -> if (s.startsWith(PLAT_PREFIX)) s.removePrefix(PLAT_PREFIX) else (games.firstOrNull { it.id == s }?.title ?: "")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C10))
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(accent.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.32f, size.height * 0.52f),
                        radius = size.width * 0.52f
                    )
                )
            }
            .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
            .then(if (blurR > 0.dp) Modifier.blur(blurR) else Modifier)
            // Com a tela de informações aberta por cima, o D-pad não pode "vazar" para as capas de trás.
            // 4.9.3: com QUALQUER janela por cima (não só os detalhes) o fundo não recebe o foco do D-pad.
            .focusProperties { canFocus = !modalOpen() }
    ) {
        // 4.6.1: o cabeçalho é desenhado por cima das capas (e do brilho delas); o rodapé continua por cima também.
        Box(Modifier.zIndex(1f)) { Header(title) }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (tvListOn) {
                // TV, modo Lista: cartões com capa e informações; rola para cima e para baixo.
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = LIST_TOP_PAD_DP.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (inPlat) {
                        items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                            PlatformListRow(p, selectedId == PLAT_PREFIX + p.name, accent,
                                if (platCards.firstOrNull()?.name == p.name) LIST_TOP_PAD_DP else -1f)
                        }
                    } else {
                        items(list, key = { it.id }) { g ->
                            GameListRow(g, selectedId == g.id, g.id in recents, accent,
                                if (list.firstOrNull()?.id == g.id) LIST_TOP_PAD_DP else -1f)
                        }
                        item(key = ADD_ID) {
                            AddListRow(selectedId == ADD_ID, accent, if (list.isEmpty()) LIST_TOP_PAD_DP else -1f)
                        }
                    }
                }
            } else if (rowNav) {
                val car = carouselOn
                // 4.9.2 (TV): distância entre os centros das capas = largura da lista / 6 → 7 capas à vista, as das pontas pela metade.
                val tvPitchDp = if (rowW > 0) rowW / LocalDensity.current.density / 6f else widthL * 0.9f
                val sidePad = if (car) with(LocalDensity.current) { max(18f, (rowW - widthL.dp.toPx()) / 2f / density).dp } else 18.dp
                LazyRow(
                    state = rowState,
                    modifier = Modifier.fillMaxSize().onSizeChanged { rowW = it.width },
                    flingBehavior = if (car) rememberSnapFlingBehavior(rowState, SnapPosition.Center)
                        else androidx.compose.foundation.gestures.ScrollableDefaults.flingBehavior(),
                    verticalAlignment = Alignment.CenterVertically,
                    contentPadding = PaddingValues(start = sidePad, end = sidePad, top = 8.dp, bottom = if (TvMode.isTv && !car) 16.dp else 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(if (car) (if (TvMode.light) (tvPitchDp - widthL) else (-0.16f * widthL)).dp else 16.dp)
                ) {
                    if (inPlat) {
                        items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                            PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent,
                                Modifier.width(widthL.dp).carouselFx(rowState, PLAT_PREFIX + p.name, car))
                        }
                    } else {
                        items(list, key = { it.id }) { g ->
                            GameCard(g, selectedId == g.id, g.id in recents, accent,
                                Modifier.width(widthL.dp).carouselFx(rowState, g.id, car))
                        }
                        item(key = ADD_ID) {
                            AddTile(selectedId == ADD_ID, accent, Modifier.width(widthL.dp).carouselFx(rowState, ADD_ID, car))
                        }
                    }
                }
            } else {
                // Grade: celular em pé (3 por linha) ou TV (quantas couberem; o tamanho segue o da capa da horizontal).
                val tvg = tvGridOn
                // Primeira linha: o brilho encolhe para não ser cortado pela borda de cima da grade.
                val firstRowIds = list.take(cols).map { it.id }.toSet()
                val firstRowPlats = platCards.take(cols).map { PLAT_PREFIX + it.name }.toSet()
                LazyVerticalGrid(
                    state = gridState,
                    // Celular: jogos 3 por linha, plataformas 2 por linha.
                    // 4.9.3: o número de capas por linha sai da largura da tela (3 tamanhos à escolha em Configurações).
                    columns = GridCells.Fixed(gridColsFor(LocalConfiguration.current.screenWidthDp.toFloat(), gridSize, inPlat)),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = if (tvg) 18.dp else 8.dp, vertical = LIST_TOP_PAD_DP.dp),
                    horizontalArrangement = Arrangement.spacedBy(if (tvg) 16.dp else 14.dp),
                    verticalArrangement = Arrangement.spacedBy(if (tvg) 16.dp else 14.dp)
                ) {
                    if (inPlat) {
                        items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                            PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent, Modifier.fillMaxWidth(),
                                if ((PLAT_PREFIX + p.name) in firstRowPlats) LIST_TOP_PAD_DP else -1f)
                        }
                    } else {
                        items(list, key = { it.id }) { g ->
                            GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.fillMaxWidth(),
                                if (g.id in firstRowIds) LIST_TOP_PAD_DP else -1f, grid = true)
                        }
                        item(key = ADD_ID) {
                            AddTile(selectedId == ADD_ID, accent, Modifier.fillMaxWidth(),
                                if (list.size < cols) LIST_TOP_PAD_DP else -1f)
                        }
                    }
                }
            }
        }

        BottomBar(inPlat)
    }

    when (val o = overlay) {
        Overlay.None -> {}
        is Overlay.Edit -> GameDialog(o.game)
        Overlay.Filter -> FilterDialog()
        Overlay.Settings -> SettingsDialog()
        Overlay.Genres -> GenresDialog()
        Overlay.Platforms -> PlatformsDialog()
        Overlay.CoverBatchSetup -> CoverBatchDialog()
        is Overlay.LinkEdit -> LinkEditDialog(o.link)
        Overlay.Search -> SearchDialog()
        Overlay.ResetGames -> ResetGamesDialog()
        Overlay.ConfirmFactory -> ConfirmFactoryDialog()
        is Overlay.ConfirmDelete -> ConfirmDeleteDialog(o.game)
        is Overlay.Info -> InfoOverlay(o.id)
        is Overlay.PlatformImage -> PlatformImageDialog(o.name)
        Overlay.Collections -> CollectionsDialog()
        is Overlay.ConfirmDeleteCollection -> ConfirmDeleteCollectionDialog(o.name)
        Overlay.StoragePrompt -> StoragePromptDialog()
        is Overlay.AddChoice -> AddChoiceDialog(o.first)
        Overlay.BatchSetup -> LinkEditDialog(null, batch = true)
        Overlay.ViewMode -> ViewModeDialog()
        Overlay.StartMenu -> StartMenuDialog()
        Overlay.PadTest -> PadTestDialog(parseColor(accentHex)) { overlay = Overlay.Settings }
        Overlay.About -> AboutDialog()
        Overlay.Tutorial -> TutorialDialog()
        Overlay.TutorialWelcome -> TutorialWelcomeDialog()
    }
    batch?.let { BatchHost(it) }
    if (appPickerOpen) AppPickerDialog()
    if (appFilterKind != 0) AppFilterDialog(appFilterKind)
    if (appsDrawerOpen) AppsDrawerDialog()
    shortcutFix?.let { ShortcutFixDialog(it) }
    launcherReturn?.let { LauncherReturnDialog(it) }
    emuPicker?.let { EmuPickerDialog(it) }
    platPicker?.let { PlatformPickerDialog(it) }
    if (collPickerOpen) CollectionPickerDialog()
    if (genrePickerOpen) GenrePickerDialog()
    sgdbPicker?.let { SgdbPickerDialog(it) }
    videoLinkFor?.let { VideoLinkDialog(it) }
    val rl = romList
    if (rl != null) RomListDialog(rl)
    explorer?.let { ex ->
        FileExplorerDialog(
            ex, parseColor(accentHex), rBtn, rCard, rPanel,
            hasAccess = { hasAllFiles() }, askAccess = { askStorage() }, onClose = { explorer = null }
        )
    }
    permHelp?.let { k -> PermHelpDialog(k, packageName, parseColor(accentHex), rBtn, rPanel) { permHelp = null } }
}

// ---------- Cabeçalho e rodapé ----------
@Composable
internal fun MainActivity.Pill(text: String, hl: Boolean = false, badge: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = Modifier
            .height(28.dp)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else HDR_BG)
            .border(1.dp, HDR_LINE, shape)
            .ownRing()
            .navHighlight(hl, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // 4.9.11: celular em pé, com filtro ativo: um "i" vermelho antes do texto.
            // 4.9.12: só a letra, sem círculo (o círculo alargava o SELECT e o START ia para baixo da câmera frontal).
            if (badge) {
                Text("i", color = Color(0xFFFF3B30), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text, color = Color(0xFFE2E8F0), fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.6.sp, maxLines = 1, softWrap = false
            )
        }
    }
}

@Composable
internal fun MainActivity.BatteryPill(hl: Boolean = false) {
    // Temperatura (metade esquerda) + bateria (metade direita), borda bicolor. Em thermal throttling o fundo fica vermelho.
    val shape = RoundedCornerShape(rBtn.dp)
    // Tocar liga/desliga o painel flutuante de temperatura sobre qualquer app.
    PowerBadge(power, corner = rBtn.dp, modifier = Modifier.clip(shape).ownRing()
            .navHighlight(hl, shape).clickable { toggleFloat() })
}

@Composable
internal fun MainActivity.OrientButton(hl: Boolean = false) {
    val shape = RoundedCornerShape(rBtn.dp)
    val ic = Color(0xFFE2E8F0)
    Box(
        modifier = Modifier
            .height(28.dp)
            .width(34.dp)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else HDR_BG)
            .border(1.dp, HDR_LINE, shape)
            .ownRing()
            .navHighlight(hl, shape)
            .clickable { toggleOrientation() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(16.dp)) {
            val w = size.width
            val h = size.height
            val sw = 1.5.dp.toPx()
            drawRoundRect(
                ic, Offset(w * 0.06f, h * 0.04f), Size(w * 0.5f, h * 0.92f),
                CornerRadius(w * 0.1f), style = Stroke(width = sw)
            )
            drawCircle(ic, sw * 0.8f, Offset(w * 0.2f, h * 0.8f))
            val p = Path().apply {
                moveTo(w * 0.68f, h * 0.25f)
                lineTo(w * 0.82f, h * 0.25f)
                quadraticBezierTo(w * 0.96f, h * 0.25f, w * 0.96f, h * 0.4f)
                lineTo(w * 0.96f, h * 0.6f)
                quadraticBezierTo(w * 0.96f, h * 0.75f, w * 0.82f, h * 0.75f)
                lineTo(w * 0.68f, h * 0.75f)
            }
            drawPath(p, ic, style = Stroke(width = sw, cap = StrokeCap.Round))
        }
    }
}

/** 4.6.1 / 4.7.7: olho que abre os modos de visualização das capas. A cor segue o destaque escolhido pelo usuário. */
@Composable
internal fun MainActivity.EyeButton(hl: Boolean = false) {
    val shape = RoundedCornerShape(rBtn.dp)
    val ac = parseColor(accentHex)
    Box(
        modifier = Modifier
            .height(28.dp)
            .width(34.dp)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else HDR_BG)
            .border(1.dp, HDR_LINE, shape)
            .ownRing()
            .navHighlight(hl, shape)
            .clickable { overlay = Overlay.ViewMode },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(width = 20.dp, height = 13.dp)) {
            val w = size.width
            val h = size.height
            val eye = Path().apply {
                moveTo(0f, h / 2f)
                quadraticBezierTo(w / 2f, -h * 0.5f, w, h / 2f)
                quadraticBezierTo(w / 2f, h * 1.5f, 0f, h / 2f)
                close()
            }
            drawPath(eye, ac)
            // íris: anel escuro com o centro na cor do olho
            drawCircle(Color(0xFF0A0C10), radius = h * 0.34f, center = Offset(w / 2f, h / 2f), style = Stroke(width = h * 0.15f))
        }
    }
}

@Composable
internal fun MainActivity.GearButton(hl: Boolean = false) {
    val shape = RoundedCornerShape(rBtn.dp)
    Box(modifier = Modifier.size(28.dp)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(shape)
                .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .ownRing()
                .navHighlight(hl, shape)
                .clickable { overlay = Overlay.Settings },
            contentAlignment = Alignment.Center
        ) {
            Text("\u2699\uFE0E", color = Color(0xFFE2E8F0), fontSize = 15.sp)
        }
        // 4.9.19: "!" laranja no canto da engrenagem enquanto o Nexus é launcher padrão só de passagem (saída nas Configurações).
        if (tempLauncher && isHome && !TvMode.isTv) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 4.dp, y = (-4).dp)
                    .size(13.dp)
                    .clip(CircleShape)
                    .background(C_ORANGE),
                contentAlignment = Alignment.Center
            ) {
                Text("!", color = Color(0xFF1A1200), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 9.sp,
                    style = TextStyle(lineHeightStyle = CenteredLine))
            }
        }
    }
}

@Composable
internal fun MainActivity.TitleText(title: String, modifier: Modifier) {
    // Títulos grandes rolam sozinhos, devagar, em vez de ficarem cortados.
    MarqueeText(title, Color.White, if (landscape) 16 else 14, FontWeight.ExtraBold, modifier)
}

@Composable
internal fun MainActivity.Header(title: String) {
    val tv = TvMode.isTv
    val hz = navZone == 1
    val cur = headerOrder().getOrNull(hdrIdx)
    if (landscape) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!tv) {
                OrientButton(hz && cur == H_ORIENT)
                Spacer(Modifier.width(8.dp))
            }
            // O olho dos modos de visualização existe na horizontal (celular e TV). No celular fica logo depois
            // do botão de girar a tela; na TV ocupa o lugar dele.
            EyeButton(hz && cur == H_EYE)
            Spacer(Modifier.width(12.dp))
            TitleText(title, Modifier.weight(1f).padding(end = 8.dp))
            if (!TvMode.isFireTv) {
                BatteryPill(hz && cur == H_FLOAT)
                Spacer(Modifier.width(8.dp))
            }
            Pill("SELECT", hz && cur == H_SELECT) { overlay = Overlay.Filter }
            Spacer(Modifier.width(8.dp))
            Pill("START", hz && cur == H_START) { overlay = Overlay.StartMenu }
            Spacer(Modifier.width(8.dp))
            GearButton(hz && cur == H_GEAR)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 4.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (!tv) {
                    OrientButton(hz && cur == H_ORIENT)
                    Spacer(Modifier.width(8.dp))
                }
                Pill("SELECT", hz && cur == H_SELECT, badge = filterActive && !tv) { overlay = Overlay.Filter }
                Spacer(Modifier.width(8.dp))
                Pill("START", hz && cur == H_START) { overlay = Overlay.StartMenu }
                Spacer(Modifier.weight(1f))
                if (!TvMode.isFireTv) {
                    BatteryPill(hz && cur == H_FLOAT)
                    Spacer(Modifier.width(8.dp))
                }
                GearButton(hz && cur == H_GEAR)
            }
            Spacer(Modifier.height(10.dp))
            TitleText(title, Modifier.fillMaxWidth())
        }
    }
}

@Composable
@OptIn(ExperimentalTextApi::class)
internal fun MainActivity.PadButton(letter: String, label: String, color: Color, hl: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(rBtn.dp)
    val fg = when (letter) {
        "Y" -> Color(0xFF1A1202)
        "A" -> Color(0xFF05140B)
        else -> Color.White
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(26.dp)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else Color(0xEB161A23))
            .border(1.dp, Color(0x17FFFFFF), shape)
            .ownRing()
            .navHighlight(hl, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp)
    ) {
        Box(
            modifier = Modifier.size(16.dp).clip(CircleShape).background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                letter, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 9.5.sp,
                lineHeight = 9.5.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            label, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false,
            lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
        )
    }
}

@Composable
internal fun MainActivity.BottomBar(platformMode: Boolean = false) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x0FFFFFFF)))
        Box(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val fz = navZone == 2
                PadButton("A", if (platformMode) "Abrir" else "Detalhes", Color(0xFF10B981), fz && ftrIdx == 0) { openSelected() }
                PadButton("B", "Voltar", Color(0xFFF43F5E), fz && ftrIdx == 1) { navZone = 0; back() }
                PadButton("Y", if (searchTerm.isNotBlank()) "Pesquisar •" else "Pesquisar", Color(0xFFFBBF24), fz && ftrIdx == 2) { overlay = Overlay.Search }
                PadButton("X", "Aleatório", Color(0xFF0EA5E9), fz && ftrIdx == 3) { randomPick() }
            }
            // 4.9.3: só na horizontal, no canto inferior direito: quantos jogos aparecem agora
            // (a biblioteca inteira, ou o resultado do filtro/pesquisa/plataforma aberta).
            if (landscape) {
                val total = if (platformMode) filteredGames().size else visibleGames().size
                Text(
                    if (total == 1) "1 Jogo" else "$total Jogos",
                    color = Color(0xFF8A93A6), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, softWrap = false,
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp)
                )
                // 4.9.11: canto inferior esquerdo: aviso discreto quando há filtro ativo (ordem e pesquisa não contam).
                if (filterActive) {
                    Text(
                        "Filtro ativo",
                        color = Color(0xFF8A93A6), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, softWrap = false,
                        modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp)
                    )
                }
            }
        }
    }
}
