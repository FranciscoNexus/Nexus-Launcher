package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Biblioteca ----------
internal fun MainActivity.defaultGames(): List<Game> =
    LibraryStore.parse(assets.open("default_library.json").bufferedReader().use { it.readText() })

internal fun MainActivity.loadLibrary() {
    val existed = libFile.exists()
    val list = try {
        if (existed) LibraryStore.parse(libFile.readText()) else defaultGames()
    } catch (e: Exception) {
        toast("Erro ao ler biblioteca: ${e.message}")
        emptyList()
    }
    games.addAll(list)
    if (!existed) saveLibrary()
}

internal fun MainActivity.saveLibrary() {
    if (wiping) return
    try {
        libFile.writeText(LibraryStore.toJson(games.toList()))
    } catch (e: Exception) {
        toast("Erro ao salvar: ${e.message}")
    }
}

internal fun MainActivity.replaceGame(updated: Game) {
    val idx = games.indexOfFirst { it.id == updated.id }
    if (idx >= 0) {
        games[idx] = updated
        saveLibrary()
    }
}

internal fun MainActivity.markPlayed(g: Game) {
    val idx = games.indexOfFirst { it.id == g.id }
    if (idx >= 0) {
        games[idx] = games[idx].copy(
            lastPlayedTs = System.currentTimeMillis(),
            openCount = games[idx].openCount + 1
        )
        saveLibrary()
    }
}

internal fun MainActivity.recentIds(): Set<String> = recentIdsD.value

internal fun MainActivity.filteredGames(): List<Game> = filteredGamesD.value

internal fun MainActivity.visibleGames(): List<Game> = visibleGamesD.value

internal fun MainActivity.platformCards(): List<GamePlatform> = platformCardsD.value

internal fun MainActivity.computeRecentIds(): Set<String> =
    games.filter { it.lastPlayedTs > 0 }
        .sortedByDescending { it.lastPlayedTs }
        .take(if (sortMode == 1) 10 else 3).map { it.id }.toSet()

// Filtros do botão Select (favoritos, plataforma, gênero e coleção), sem o recorte do dashboard.
internal fun MainActivity.computeFilteredGames(): List<Game> {
    var l: List<Game> = games.toList()
    if (favOnly) l = l.filter { it.isFavorite }
    if (fPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == fPlatform }
    if (fGenre.isNotEmpty()) l = l.filter { if (fGenre == NO_GENRE) it.genres.isEmpty() else fGenre in it.genres }
    if (fCollection.isNotEmpty()) l = l.filter { fCollection in it.collections }
    val k = searchTerm.trim().lowercase()
    if (k.isNotEmpty()) {
        l = l.filter { g ->
            g.title.lowercase().contains(k) || g.shownPlatform.lowercase().contains(k) ||
                g.genres.any { it.lowercase().contains(k) } || (k.length >= 3 && g.genres.isEmpty() && foldText(NO_GENRE).contains(foldText(k))) || g.collections.any { it.lowercase().contains(k) }
        }
    }
    return l
}

internal fun MainActivity.computeVisibleGames(): List<Game> {
    var l: List<Game> = filteredGames()
    if (dashMode == 1 && dashPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == dashPlatform }
    return when (sortMode) {
        1 -> l.filter { it.lastPlayedTs > 0 }.sortedByDescending { it.lastPlayedTs }.take(10)
        2 -> l.sortedAlpha { it.title }
        3 -> l.sortedAlpha { it.title }.reversed()
        else -> {
            val rec = l.filter { it.lastPlayedTs > 0 }
                .sortedByDescending { it.lastPlayedTs }.take(3)
            val ids = rec.map { it.id }.toSet()
            val rest = l.filter { it.id !in ids }
            rec +
                rest.filter { it.isFavorite }.sortedAlpha { it.title } +
                rest.filter { !it.isFavorite }.sortedAlpha { it.title }
        }
    }
}

// ---------- Dashboard por plataformas ----------
internal fun MainActivity.computePlatformCards(): List<GamePlatform> =
    filteredGames().let { fg ->
        platforms.filter { p -> fg.any { it.shownPlatform == p.name } }
            .sortedAlpha { it.name }
    }

internal fun MainActivity.enterPlatform(name: String) {
    dashPlatform = name
    selectedId = visibleGames().firstOrNull()?.id
}

internal fun MainActivity.exitPlatform() {
    val left = dashPlatform
    dashPlatform = ""
    selectedId = if (platformCards().any { it.name == left }) PLAT_PREFIX + left else firstNavId()
}

internal fun MainActivity.savePlatformImage(name: String, url: String) {
    val i = platforms.indexOfFirst { it.name == name }
    if (i < 0) return
    val old = platforms[i].image
    val u = url.trim()
    platforms[i] = platforms[i].copy(image = u)
    savePrefs()
    if (old.isNotBlank() && old != u) {
        Covers.purgeIfUnused(old, games.map { it.cover } + platforms.map { it.image })
    }
    prefetchCovers()
}

internal fun MainActivity.resetFilters() {
    favOnly = false
    fPlatform = ""
    fGenre = ""
    fCollection = ""
    searchTerm = ""
    sortMode = 0
}

// ---------- Capas em lote ----------
internal fun MainActivity.isMobileGame(g: Game): Boolean = g.platform == ANDROID_PLATFORM || g.platform == WEB_PLATFORM

internal fun MainActivity.infoGame(): Game? = (overlay as? Overlay.Info)?.let { o -> games.firstOrNull { it.id == o.id } }

internal fun MainActivity.deleteGame(g: Game) {
    games.removeAll { it.id == g.id }
    saveLibrary()
    Covers.purgeIfUnused(g.cover, games.map { it.cover })
    if (sgdbCache.remove(g.id) != null) saveSgdb()
    selectedId = visibleGames().firstOrNull()?.id
    overlay = Overlay.None
}

/** 4.7.8: apaga só os jogos (todos ou de uma plataforma). Não mexe em vínculos, apps, gêneros, coleções nem chaves de API. */
internal fun MainActivity.deleteGamesWhere(all: Boolean, platform: String = "") {
    // 4.7.9: por plataforma ORIGINAL (jogos com máscara de etiqueta contam na plataforma real, ex.: Android).
    val gone = if (all) games.toList() else games.filter { it.platform == platform }
    val ids = gone.map { it.id }.toSet()
    games.removeAll { it.id in ids }
    saveLibrary()
    var sg = false
    for (g in gone) if (sgdbCache.remove(g.id) != null) sg = true
    if (sg) saveSgdb()
    if (all) {
        Covers.clearAll()
        resetFilters()
    } else {
        val keep = games.map { it.cover }
        for (g in gone) Covers.purgeIfUnused(g.cover, keep)
        if (fPlatform.isNotEmpty() && games.none { it.shownPlatform == fPlatform }) fPlatform = ""
    }
    dashPlatform = ""
    selectedId = firstNavId()
    overlay = Overlay.None
    toast(if (gone.size == 1) "1 jogo apagado" else "${gone.size} jogos apagados")
}
