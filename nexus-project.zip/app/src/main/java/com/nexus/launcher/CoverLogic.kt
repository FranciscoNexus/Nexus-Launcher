package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

/** Sem capa própria (o ícone do app não conta como capa). Android/Web só entram se [includeMobile]. */
internal fun MainActivity.coverEligible(g: Game, scope: String, includeMobile: Boolean = true): Boolean =
    g.cover.isBlank() && (includeMobile || !isMobileGame(g)) &&
        (scope.isEmpty() || g.shownPlatform == scope)

internal fun MainActivity.coverMissingCount(): Int = games.count { coverEligible(it, "") }

internal fun MainActivity.startCoverBatch(scope: String, includeMobile: Boolean) {
    val key = sgdbKey.trim()
    if (key.isEmpty()) {
        toast("Informe a chave do SteamGridDB em Sistema")
        return
    }
    val targets = games.filter { coverEligible(it, scope, includeMobile) }.sortedWith(compareBy(ALPHA) { it.platform })
    if (targets.isEmpty()) {
        toast("Nenhum jogo sem capa")
        return
    }
    val job = CoverBatch(scope, targets.size)
    coverBatch = job
    ScanService.start(this)
    mainScope.launch {
        withContext(Dispatchers.IO) {
            for (g in targets) {
                if (job.cancelled) break
                val r = SgdbApi.findGrids(key, g.title, true)
                if (r is SgdbGridsResult.Failure) {
                    job.error = r.message
                    break
                }
                val url = (r as SgdbGridsResult.Ok).grids.firstOrNull()?.url
                if (url == null) {
                    job.notFound.add(g.title)
                } else {
                    withContext(Dispatchers.Main) {
                        val i = games.indexOfFirst { it.id == g.id }
                        // Nunca sobrescreve uma capa que já exista.
                        if (i >= 0 && games[i].cover.isBlank()) {
                            games[i] = games[i].copy(cover = url)
                            job.applied++
                        }
                    }
                }
                job.done++
                ScanNotify.progressText(this@startCoverBatch, "Capas em lote", "${job.done} de ${job.total} jogos")
                kotlinx.coroutines.delay(120)
            }
        }
        job.running = false
        saveLibrary()
        prefetchCovers()
        ScanService.stop(this@startCoverBatch)
        ScanNotify.doneTitled(
            this@startCoverBatch, "Capas em lote concluído",
            "${job.applied} capa(s) aplicada(s), ${job.notFound.size} não encontrada(s)"
        )
    }
}

// ---------- SteamGridDB ----------
internal fun MainActivity.saveSgdb() { if (!wiping) SgdbStore.save(sgdbFile, sgdbCache.toMap()) }

internal fun MainActivity.fmtReleased(secs: Long): String {
    if (secs <= 0L) return ""
    val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
    f.timeZone = TimeZone.getTimeZone("UTC")
    return f.format(Date(secs * 1000L))
}

// Busca nome oficial e data de lançamento no SteamGridDB e guarda no aparelho. Só repete se force = true.
internal fun MainActivity.fetchSgdb(g: Game, force: Boolean = false) {
    val key = sgdbKey.trim()
    if (key.isEmpty() || g.id in sgdbBusy) return
    if (!force && sgdbCache[g.id] != null) return
    sgdbBusy = sgdbBusy + g.id
    sgdbErr.remove(g.id)
    mainScope.launch {
        val res = withContext(Dispatchers.IO) { SgdbApi.lookup(key, g.title) }
        sgdbBusy = sgdbBusy - g.id
        when (res) {
            is SgdbResult.Ok -> {
                sgdbCache[g.id] = res.info
                saveSgdb()
            }
            is SgdbResult.Failure -> {
                sgdbErr[g.id] = res.message
            }
        }
    }
}

// Abre o seletor de imagens do SteamGridDB (capas de jogos em pé; imagens de plataformas em qualquer formato).
internal fun MainActivity.openSgdbPicker(
    title: String, term: String, portrait: Boolean, onPickAnim: ((String) -> Unit)? = null, onPick: (String) -> Unit
) {
    if (sgdbKey.isBlank()) {
        toast("Adicione sua chave do SteamGridDB em Configurações")
        return
    }
    if (term.isBlank()) {
        toast("Digite o título primeiro")
        return
    }
    // Capas animadas: só celular/tablet e só no Android 9+ (antes disso o WebP animado não toca).
    sgdbPicker = SgdbPicker(title, term, portrait, onPick, if (animCoversSupported) onPickAnim else null)
}

internal fun MainActivity.testSgdbKey() {
    val key = sgdbKey.trim()
    if (key.isEmpty()) {
        toast("Cole sua chave primeiro")
        return
    }
    toast("Testando chave…")
    mainScope.launch {
        val err = withContext(Dispatchers.IO) { SgdbApi.ping(key) }
        toast(err ?: "Chave válida ✓")
    }
}

internal fun MainActivity.prefetchCovers() = Covers.prefetch(this, games.map { it.cover } + platforms.map { it.image })

internal fun MainActivity.refreshCover(url: String) {
    val u = url.trim()
    if (u.isEmpty()) {
        toast("Sem URL de capa")
        return
    }
    toast("Atualizando capa…")
    Covers.refresh(this, u) { ok ->
        if (ok) coverRev++
        toast(if (ok) "Capa atualizada" else "Não foi possível atualizar. Mantive a capa salva.")
    }
}

internal fun MainActivity.openSteamGrid(title: String) {
    if (title.isBlank()) {
        toast("Digite o título primeiro")
        return
    }
    val url = "https://www.steamgriddb.com/search/grids?term=" + URLEncoder.encode(title.trim(), "UTF-8")
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        toast("Erro ao abrir o navegador")
    }
}
