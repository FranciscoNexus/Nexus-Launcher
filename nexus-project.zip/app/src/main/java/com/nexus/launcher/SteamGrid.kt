package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Dados de um jogo no SteamGridDB (nome oficial e data de lançamento), guardados no aparelho. */
data class SgdbInfo(
    val found: Boolean = false,
    val gameId: Int = 0,
    val name: String = "",
    val released: Long = 0L, // segundos Unix; 0 = desconhecido
    val verified: Boolean = false,
    val fetchedAt: Long = 0L
)

data class SgdbGrid(val url: String, val thumb: String, val width: Int, val height: Int)

sealed class SgdbResult {
    class Ok(val info: SgdbInfo) : SgdbResult()
    class Failure(val message: String) : SgdbResult()
}

sealed class SgdbGridsResult {
    class Ok(val game: SgdbInfo?, val grids: List<SgdbGrid>) : SgdbGridsResult()
    class Failure(val message: String) : SgdbGridsResult()
}

class SgdbException(message: String) : Exception(message)

object SgdbApi {
    private const val BASE = "https://www.steamgriddb.com/api/v2"

    private fun encPath(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun errorFor(code: Int): String = when (code) {
        401, 403 -> "Chave do SteamGridDB inválida"
        429 -> "Limite de requisições do SteamGridDB atingido. Tente mais tarde."
        else -> "Erro do SteamGridDB ($code)"
    }

    private fun get(key: String, path: String): String {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("User-Agent", "NexusLauncher (uso pessoal)")
        try {
            val code = c.responseCode
            if (code == 404) return "{\"success\":true,\"data\":[]}"
            if (code !in 200..299) throw SgdbException(errorFor(code))
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun dataArray(body: String): JSONArray = JSONObject(body).optJSONArray("data") ?: JSONArray()

    fun cleanQuery(title: String): String =
        title.replace(Regex("[\\(\\[][^\\)\\]]*[\\)\\]]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun parseGame(o: JSONObject, now: Long): SgdbInfo = SgdbInfo(
        found = true,
        gameId = o.optInt("id", 0),
        name = str(o, "name"),
        released = if (o.isNull("release_date")) 0L else o.optLong("release_date", 0L),
        verified = o.optBoolean("verified", false),
        fetchedAt = now
    )

    private fun search(key: String, term: String): List<SgdbInfo> {
        val now = System.currentTimeMillis()
        val arr = dataArray(get(key, "/search/autocomplete/${encPath(term)}"))
        val out = ArrayList<SgdbInfo>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val g = parseGame(o, now)
            if (g.gameId > 0) out.add(g)
        }
        return out
    }

    private fun pickBest(list: List<SgdbInfo>, q: String): SgdbInfo {
        val want = norm(q)
        return list.firstOrNull { norm(it.name) == want } ?: list.first()
    }

    /** Busca o jogo pelo título. Uma requisição só (a busca já traz nome e data de lançamento). */
    fun lookup(key: String, title: String): SgdbResult {
        val now = System.currentTimeMillis()
        try {
            val q = cleanQuery(title)
            if (q.isEmpty()) return SgdbResult.Ok(SgdbInfo(found = false, fetchedAt = now))
            val found = search(key, q)
            if (found.isEmpty()) return SgdbResult.Ok(SgdbInfo(found = false, fetchedAt = now))
            return SgdbResult.Ok(pickBest(found, q))
        } catch (e: SgdbException) {
            return SgdbResult.Failure(e.message ?: "Erro do SteamGridDB")
        } catch (e: IOException) {
            return SgdbResult.Failure("Sem conexão com o SteamGridDB")
        } catch (e: org.json.JSONException) {
            return SgdbResult.Failure("Resposta inesperada do SteamGridDB")
        }
    }

    private fun grids(key: String, gameId: Int, portrait: Boolean): List<SgdbGrid> {
        val dims = if (portrait) "&dimensions=600x900,342x482,660x930" else ""
        val arr = dataArray(get(key, "/grids/game/$gameId?types=static&nsfw=false$dims"))
        val out = ArrayList<SgdbGrid>()
        for (i in 0 until minOf(arr.length(), 24)) {
            val o = arr.optJSONObject(i) ?: continue
            val url = str(o, "url")
            if (url.isBlank()) continue
            val thumb = str(o, "thumb").ifBlank { url }
            out.add(SgdbGrid(url, thumb, o.optInt("width", 0), o.optInt("height", 0)))
        }
        return out
    }

    /** Imagens (grids) do jogo que melhor combina com o termo. portrait = capas em pé (jogos). */
    fun findGrids(key: String, term: String, portrait: Boolean): SgdbGridsResult {
        try {
            val q = cleanQuery(term)
            if (q.isEmpty()) return SgdbGridsResult.Ok(null, emptyList())
            val games = search(key, q)
            if (games.isEmpty()) return SgdbGridsResult.Ok(null, emptyList())
            val game = pickBest(games, q)
            var list = grids(key, game.gameId, portrait)
            if (list.isEmpty() && portrait) list = grids(key, game.gameId, false)
            return SgdbGridsResult.Ok(game, list)
        } catch (e: SgdbException) {
            return SgdbGridsResult.Failure(e.message ?: "Erro do SteamGridDB")
        } catch (e: IOException) {
            return SgdbGridsResult.Failure("Sem conexão com o SteamGridDB")
        } catch (e: org.json.JSONException) {
            return SgdbGridsResult.Failure("Resposta inesperada do SteamGridDB")
        }
    }

    /** null = chave válida; senão, a mensagem de erro. */
    fun ping(key: String): String? {
        try {
            get(key, "/search/autocomplete/test")
            return null
        } catch (e: SgdbException) {
            return e.message
        } catch (e: IOException) {
            return "Sem conexão com o SteamGridDB"
        }
    }
}

/** Cache em arquivo, por id de jogo do Nexus. Fica fora do backup. */
object SgdbStore {
    fun load(file: File): Map<String, SgdbInfo> {
        if (!file.exists()) return emptyMap()
        return try {
            val root = JSONObject(file.readText())
            val out = HashMap<String, SgdbInfo>()
            for (k in root.keys()) {
                val o = root.optJSONObject(k) ?: continue
                out[k] = SgdbInfo(
                    found = o.optBoolean("found", false),
                    gameId = o.optInt("id", 0),
                    name = o.optString("name", ""),
                    released = o.optLong("released", 0L),
                    verified = o.optBoolean("verified", false),
                    fetchedAt = o.optLong("fetchedAt", 0L)
                )
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun save(file: File, map: Map<String, SgdbInfo>) {
        try {
            val root = JSONObject()
            for ((id, i) in map) {
                root.put(
                    id,
                    JSONObject()
                        .put("found", i.found)
                        .put("id", i.gameId)
                        .put("name", i.name)
                        .put("released", i.released)
                        .put("verified", i.verified)
                        .put("fetchedAt", i.fetchedAt)
                )
            }
            file.writeText(root.toString())
        } catch (_: Exception) {
        }
    }
}
