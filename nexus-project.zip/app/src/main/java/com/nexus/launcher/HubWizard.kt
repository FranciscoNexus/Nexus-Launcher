package com.nexus.launcher

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

/**
 * 4.9.23 – Assistente "Adicionar jogo do GameHub" (também usado por "Recriar atalho").
 * Plano: claude/nexus-plano-integracao-gamehub-facil.md (Fase B).
 *
 * Passos: 0 = explicação · 1 = fazer nesta ordem (launcher padrão de passagem, abrir o app, criar o atalho) ·
 * 2 = atalho recebido ("Adicionar outro" / "Concluir") · 3 = devolver o launcher anterior.
 * O estado fica no disco (prefs "hubWiz*"): o Android pode encerrar o Nexus enquanto o usuário está no GameHub.
 * A PinShortcutActivity traz o Nexus para a frente quando o assistente está ligado.
 */
private const val HUB_WIZ_TTL_MS = 6L * 60L * 60L * 1000L

private fun MainActivity.hubWizSave() {
    prefs.edit()
        .putBoolean("hubWizOn", true)
        .putLong("hubWizAt", System.currentTimeMillis())
        .putInt("hubWizStep", hubWizStep)
        .putString("hubWizFor", hubWizFor)
        .putString("hubWizPkg", hubWizPkg)
        .putString("hubWizAdded", JSONArray(hubWizAdded.toList()).toString())
        .apply()
}

private fun MainActivity.hubWizClearPrefs() {
    prefs.edit().remove("hubWizOn").remove("hubWizAt").remove("hubWizStep").remove("hubWizFor")
        .remove("hubWizPkg").remove("hubWizAdded").apply()
}

/** Chamado ao abrir o Nexus: retoma o assistente se ele estava aberto (e não é velho demais). */
internal fun MainActivity.loadHubWizPrefs() {
    hubWizAdded.clear()
    val on = prefs.getBoolean("hubWizOn", false)
    if (!on) {
        hubWizOpen = false
        return
    }
    val age = System.currentTimeMillis() - prefs.getLong("hubWizAt", 0L)
    if (age < 0L || age >= HUB_WIZ_TTL_MS) {
        hubWizOpen = false
        hubWizClearPrefs()
        return
    }
    hubWizOpen = true
    hubWizStep = prefs.getInt("hubWizStep", 0).coerceIn(0, 3)
    hubWizFor = prefs.getString("hubWizFor", "") ?: ""
    hubWizPkg = (prefs.getString("hubWizPkg", GAMEHUB_PKG) ?: GAMEHUB_PKG).ifEmpty { GAMEHUB_PKG }
    try {
        prefs.getString("hubWizAdded", null)?.let { j ->
            val a = JSONArray(j)
            for (i in 0 until a.length()) hubWizAdded.add(a.getString(i))
        }
    } catch (_: Exception) {
    }
}

/** [forTitle] vazio = adicionar jogo novo; com título = recriar o atalho daquele jogo (em [forPkg]). */
internal fun MainActivity.startHubWizard(forTitle: String = "", forPkg: String = GAMEHUB_PKG) {
    if (TvMode.isTv) return
    hubWizAdded.clear()
    hubWizFor = forTitle
    hubWizPkg = forPkg
    hubWizStep = 0
    hubWizOpen = true
    hubWizSave()
}

internal fun MainActivity.closeHubWizard() {
    hubWizOpen = false
    hubWizAdded.clear()
    hubWizFor = ""
    hubWizStep = 0
    hubWizClearPrefs()
}

internal fun MainActivity.hubWizStepTo(s: Int) {
    hubWizStep = s
    hubWizSave()
}

/** Um atalho chegou (ver importPendingShortcuts): mostra "adicionado ✓". */
internal fun MainActivity.hubWizNoteAdded(labels: List<String>) {
    for (l in labels) if (l.isNotBlank() && l !in hubWizAdded) hubWizAdded.add(l)
    hubWizStep = 2
    hubWizSave()
}

/** Concluir: se o Nexus virou launcher só de passagem, oferece devolver o anterior; senão, só fecha. */
internal fun MainActivity.hubWizFinish() {
    if (!TvMode.isTv && isHome && tempLauncher) {
        hubWizStepTo(3)
    } else {
        closeHubWizard()
    }
}

/** Voltar (B / toque fora / ✕). */
internal fun MainActivity.hubWizBack() {
    when (hubWizStep) {
        1 -> hubWizStepTo(0)
        2 -> hubWizFinish()
        else -> closeHubWizard()
    }
}

@Composable
internal fun MainActivity.HubWizardDialog() {
    val step = hubWizStep
    val note = Color(0xFFCBD2E0)
    val recreate = hubWizFor.isNotEmpty()
    val appPkg = hubWizPkg
    val isHub = appPkg == GAMEHUB_PKG
    val appItem = allApps.firstOrNull { it.pkg == appPkg }
    val appName = appItem?.label ?: if (isHub) "GameHub" else "app do jogo"
    val prev = prevLauncherName()
    RefocusOnStep(step)
    NexusModal(
        if (recreate) "Recriar o atalho" else "Adicionar jogo do GameHub",
        { hubWizBack() }
    ) {
        when (step) {
            0 -> {
                if (appItem == null) {
                    Text(
                        "O $appName não foi encontrado neste aparelho. Instale o app e volte aqui.",
                        color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    CButton("Fechar", C_GRAY, Modifier.fillMaxWidth().initialFocus()) { closeHubWizard() }
                } else {
                    Text(
                        if (recreate) "O Nexus não consegue mais abrir o atalho de \"$hubWizFor\". É só criar o atalho de novo dentro do $appName. Eu guio você."
                        else "Adicione jogos que estão no $appName. O Android só entrega o atalho do jogo ao launcher padrão, então o Nexus fica como launcher só de passagem e depois você volta ao que usava.",
                        color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "São 3 passos: aceitar o pedido do Android, criar o atalho no $appName e voltar ao launcher anterior." +
                            (if (recreate) "" else " Dá para adicionar quantos jogos quiser de uma vez."),
                        color = C_MUTED, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    CButton("Começar", C_BLUE, Modifier.fillMaxWidth().initialFocus()) {
                        if (!isHome) askDefaultLauncher(temporary = true)
                        hubWizStepTo(1)
                    }
                    Spacer(Modifier.height(8.dp))
                    CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { closeHubWizard() }
                }
            }
            1 -> {
                // O pedido de "launcher temporário" já foi marcado ao tocar em Começar (ou no botão abaixo).
                Text("Faça nesta ordem:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(
                    if (isHome) "1. O Nexus já é o launcher padrão ✓"
                    else "1. Deixe o Nexus como launcher padrão, só por alguns instantes (o Android só entrega o pedido de atalho ao launcher padrão).",
                    color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
                )
                if (!isHome) {
                    Spacer(Modifier.height(6.dp))
                    CButton("Tornar o Nexus o launcher padrão", C_BLUE, Modifier.fillMaxWidth().initialFocus()) { askDefaultLauncher(temporary = true) }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    if (isHub) {
                        if (recreate) "2. Abra o GameHub, entre em \"$hubWizFor\", toque no botão de menu (≡) e use \"Adicionar à área de trabalho\"."
                        else "2. Abra o GameHub, entre no jogo que você quer, toque no botão de menu (≡) e use \"Adicionar à área de trabalho\"."
                    } else {
                        "2. Abra o $appName e crie o atalho de \"${hubWizFor.ifEmpty { "o jogo" }}\" na área de trabalho."
                    },
                    color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                CButton("Abrir o $appName", if (isHome) C_BLUE else C_GRAY, Modifier.fillMaxWidth().initialFocus()) { launchApp(appPkg) }
                Spacer(Modifier.height(12.dp))
                Text(
                    "3. Quando o Android aceitar o atalho, o Nexus volta sozinho para a frente. Se não voltar, abra o Nexus pelo botão Início ou pelos apps recentes.",
                    color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                CButton("Voltar", C_GRAY, Modifier.fillMaxWidth()) { hubWizStepTo(0) }
                Spacer(Modifier.height(8.dp))
                CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { closeHubWizard() }
            }
            2 -> {
                val n = hubWizAdded.size
                Text(
                    when {
                        recreate -> "Atalho de \"${hubWizAdded.firstOrNull() ?: hubWizFor}\" recriado ✓"
                        n == 1 -> "\"${hubWizAdded[0]}\" adicionado ✓"
                        else -> "$n jogos adicionados ✓"
                    },
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                if (n > 1) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        hubWizAdded.take(8).joinToString("\n") { "• $it" } + (if (n > 8) "\n• e mais ${n - 8}" else ""),
                        color = note, fontSize = 12.sp, modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(14.dp))
                CButton(if (recreate) "Recriar outro atalho" else "Adicionar outro", C_BLUE, Modifier.fillMaxWidth().initialFocus()) {
                    hubWizStepTo(1)
                    launchApp(appPkg)
                }
                Spacer(Modifier.height(8.dp))
                CButton("Concluir", C_GRAY, Modifier.fillMaxWidth()) { hubWizFinish() }
            }
            else -> {
                val n = hubWizAdded.size
                Text(
                    (if (recreate) "Atalho recriado ✓. " else if (n == 1) "Jogo adicionado ✓. " else "$n jogos adicionados ✓. ") +
                        "O Nexus ainda é o launcher padrão do aparelho (a tela inicial). Quer voltar para ${if (prev.isNotEmpty()) "o $prev" else "o launcher que você usava"}?",
                    color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                CButton(if (prev.isNotEmpty()) "Voltar ao $prev" else "Voltar ao launcher anterior", C_BLUE, Modifier.fillMaxWidth().initialFocus()) {
                    closeHubWizard()
                    backToPreviousLauncher()
                }
                Spacer(Modifier.height(8.dp))
                CButton("Continuar com o Nexus", C_GRAY, Modifier.fillMaxWidth()) {
                    setTempLauncher(false)
                    closeHubWizard()
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Para sair depois: Configurações > Extras > Trocar launcher padrão.",
                    color = C_MUTED, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
