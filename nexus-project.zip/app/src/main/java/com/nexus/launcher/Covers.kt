package com.nexus.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import coil.ImageLoader
import coil.annotation.ExperimentalCoilApi
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Size
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Cache de capas offline.
 * - Arquivos ficam em filesDir/covers (o "limpar cache" do Android NÃO apaga).
 * - Ignora cabeçalhos de cache do servidor: baixou uma vez, usa sempre do disco.
 * - Só baixa de novo se a capa não existir no disco ou se o usuário pedir para atualizar.
 */
object Covers {
    private var loaderRef: ImageLoader? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val THUMB = Size(300, 450)

    val loader: ImageLoader
        get() = loaderRef ?: error("Covers.init não foi chamado")

    private var animLoaderRef: ImageLoader? = null

    /**
     * 4.9.13: mesmo cache de disco e de memória do [loader], mais o decodificador animado (GIF; WebP animado no Android 9+).
     * Antes o decodificador animado era pedido dentro de cada imagem; agora fica no carregador (jeito oficial do Coil).
     */
    val animLoader: ImageLoader
        get() = animLoaderRef ?: loader.newBuilder().components {
            if (android.os.Build.VERSION.SDK_INT >= 28) add(coil.decode.ImageDecoderDecoder.Factory()) else add(coil.decode.GifDecoder.Factory())
        }.build().also { animLoaderRef = it }

    fun loaderFor(animate: Boolean): ImageLoader = if (animate) animLoader else loader

    fun init(ctx: Context) {
        if (loaderRef != null) return
        val app = ctx.applicationContext
        // 4.9.0: memória das capas conforme o aparelho. Celular com bastante RAM: reserva grande (rolagem sem redecodificar)
        // e cores completas (sem faixas nas capas escuras). TV/Stick e celular fraco: reserva menor e RGB565.
        val pm = app.packageManager
        val tvLike = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || pm.hasSystemFeature("amazon.hardware.fire_tv")
        val mi = ActivityManager.MemoryInfo()
        try { (app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.getMemoryInfo(mi) } catch (_: Exception) { }
        val bigRam = !tvLike && mi.totalMem >= 6L * 1024 * 1024 * 1024
        val memPct = if (tvLike) 0.15 else if (bigRam) 0.40 else 0.25
        loaderRef = ImageLoader.Builder(app)
            .diskCache {
                DiskCache.Builder()
                    .directory(File(app.filesDir, "covers"))
                    .maxSizeBytes(512L * 1024 * 1024)
                    .build()
            }
            .memoryCache { MemoryCache.Builder(app).maxSizePercent(memPct).build() }
            .respectCacheHeaders(false)
            .allowRgb565(!bigRam)
            .build()
    }

    fun request(ctx: Context, url: String, animate: Boolean = false): ImageRequest {
        val b = ImageRequest.Builder(ctx)
            .data(url)
            .diskCacheKey(url)
        // 4.9.12: capa animada (só a em foco / dos Detalhes): sem cache de memória (o Coil só guarda bitmaps ali) e com chave
        // própria, para nunca trocar pelo 1º quadro parado guardado para o mesmo link.
        // 4.9.13: quem toca a animação é o carregador [animLoader] (use [loaderFor]); as demais capas seguem no [loader] comum,
        // que mostra o 1º quadro parado.
        return if (animate) {
            b.memoryCacheKey(url + "#anim")
                .memoryCachePolicy(CachePolicy.DISABLED)
                .build()
        } else {
            b.memoryCacheKey(url).build()
        }
    }

    /** Baixa em segundo plano as capas que ainda não estão no disco (não ocupa memória). */
    @OptIn(ExperimentalCoilApi::class)
    fun prefetch(ctx: Context, urls: Collection<String>) {
        val app = ctx.applicationContext
        val list = urls.map { it.trim() }
            .filter { it.startsWith("http", ignoreCase = true) }
            .distinct()
        if (list.isEmpty()) return
        scope.launch {
            for (u in list) {
                val cached = loader.diskCache?.openSnapshot(u)?.use { true } ?: false
                if (!cached) {
                    loader.enqueue(
                        ImageRequest.Builder(app)
                            .data(u)
                            .diskCacheKey(u)
                            .size(THUMB)
                            .memoryCachePolicy(CachePolicy.DISABLED)
                            .build()
                    )
                }
            }
        }
    }

    /** Baixa de novo ignorando o disco. Se falhar (ex.: sem internet), a capa antiga é mantida. */
    @OptIn(ExperimentalCoilApi::class)
    fun refresh(ctx: Context, url: String, onDone: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        val u = url.trim()
        scope.launch {
            val res = loader.execute(
                ImageRequest.Builder(app)
                    .data(u)
                    .diskCacheKey(u)
                    .size(THUMB)
                    .diskCachePolicy(CachePolicy.WRITE_ONLY)
                    .memoryCachePolicy(CachePolicy.DISABLED)
                    .build()
            )
            val ok = res is SuccessResult
            if (ok) loader.memoryCache?.remove(MemoryCache.Key(u))
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    /**
     * 4.9.14: arquivo da capa no disco (baixa se ainda não estiver). Serve para tocar APNG, que o Coil/Android não anima.
     * Devolve null se não foi possível baixar.
     */
    @OptIn(ExperimentalCoilApi::class)
    suspend fun localFile(ctx: Context, url: String): File? = withContext(Dispatchers.IO) {
        val u = url.trim()
        fun snap(): File? = try { loader.diskCache?.openSnapshot(u)?.use { it.data.toFile() } } catch (_: Exception) { null }
        snap() ?: run {
            // Baixa o arquivo (o Coil guarda o original no disco); decodifica em tamanho mínimo só para não gastar memória.
            try {
                loader.execute(
                    ImageRequest.Builder(ctx.applicationContext)
                        .data(u)
                        .diskCacheKey(u)
                        .size(Size(8, 8))
                        .memoryCachePolicy(CachePolicy.DISABLED)
                        .build()
                )
            } catch (_: Exception) { }
            snap()
        }
    }

    /**
     * 4.9.14: ao fechar o seletor de capas animadas, apaga do disco o que foi baixado só para a prévia.
     * Nunca apaga o que algum jogo usa (stillUsed) nem a capa escolhida.
     */
    @OptIn(ExperimentalCoilApi::class)
    fun discardPreviews(urls: Collection<String>, stillUsed: Collection<String>) {
        val keep = stillUsed.map { it.trim() }.toHashSet()
        val drop = urls.map { it.trim() }.filter { it.isNotEmpty() && it !in keep }.distinct()
        if (drop.isEmpty()) return
        scope.launch {
            for (u in drop) {
                loader.memoryCache?.remove(MemoryCache.Key(u))
                loader.memoryCache?.remove(MemoryCache.Key(u + "#anim"))
                loader.diskCache?.remove(u)
            }
        }
    }

    /** Remove a capa do disco, a menos que outro jogo ainda use o mesmo link. */
    @OptIn(ExperimentalCoilApi::class)
    fun purgeIfUnused(url: String, stillUsed: Collection<String>) {
        val u = url.trim()
        if (u.isEmpty() || stillUsed.any { it.trim() == u }) return
        scope.launch {
            loader.memoryCache?.remove(MemoryCache.Key(u))
            loader.diskCache?.remove(u)
        }
    }

    @OptIn(ExperimentalCoilApi::class)
    fun clearAll() {
        scope.launch {
            loader.memoryCache?.clear()
            loader.diskCache?.clear()
        }
    }
}
