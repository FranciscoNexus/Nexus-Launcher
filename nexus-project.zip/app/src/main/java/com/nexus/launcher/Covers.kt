package com.nexus.launcher

import android.content.Context
import coil.ImageLoader
import coil.annotation.ExperimentalCoilApi
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Size
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Cache de capas offline.
 * - Arquivos ficam em filesDir/covers (o "limpar cache" do Android NÃO apaga).
 * - Ignora cabeçalhos de cache do servidor: baixou uma vez, usa sempre do disco.
 * - Só baixa de novo se a capa não existir no disco ou se o usuário pedir para atualizar.
 */
object Covers {
    private var loaderRef: ImageLoader? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val THUMB = Size(300, 450)

    val loader: ImageLoader
        get() = loaderRef ?: error("Covers.init não foi chamado")

    fun init(ctx: Context) {
        if (loaderRef != null) return
        val app = ctx.applicationContext
        loaderRef = ImageLoader.Builder(app)
            .diskCache {
                DiskCache.Builder()
                    .directory(File(app.filesDir, "covers"))
                    .maxSizeBytes(512L * 1024 * 1024)
                    .build()
            }
            .memoryCache { MemoryCache.Builder(app).maxSizePercent(0.15).build() }
            .respectCacheHeaders(false)
            .allowRgb565(true)
            .build()
    }

    fun request(ctx: Context, url: String): ImageRequest =
        ImageRequest.Builder(ctx)
            .data(url)
            .diskCacheKey(url)
            .memoryCacheKey(url)
            .build()

    /** Baixa em segundo plano as capas que ainda não estão no disco (não ocupa memória). */
    @OptIn(ExperimentalCoilApi::class)
    fun prefetch(ctx: Context, urls: Collection<String>) {
        val app = ctx.applicationContext
        val list = urls.map { it.trim() }
            .filter { it.startsWith("http", ignoreCase = true) }
            .distinct()
        if (list.isEmpty()) return
        scope.launch {
            for (u in list) {
                val cached = loader.diskCache?.openSnapshot(u)?.use { true } ?: false
                if (!cached) {
                    loader.enqueue(
                        ImageRequest.Builder(app)
                            .data(u)
                            .diskCacheKey(u)
                            .size(THUMB)
                            .memoryCachePolicy(CachePolicy.DISABLED)
                            .build()
                    )
                }
            }
        }
    }

    /** Baixa de novo ignorando o disco. Se falhar (ex.: sem internet), a capa antiga é mantida. */
    @OptIn(ExperimentalCoilApi::class)
    fun refresh(ctx: Context, url: String, onDone: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        val u = url.trim()
        scope.launch {
            val res = loader.execute(
                ImageRequest.Builder(app)
                    .data(u)
                    .diskCacheKey(u)
                    .size(THUMB)
                    .diskCachePolicy(CachePolicy.WRITE_ONLY)
                    .memoryCachePolicy(CachePolicy.DISABLED)
                    .build()
            )
            val ok = res is SuccessResult
            if (ok) loader.memoryCache?.remove(MemoryCache.Key(u))
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    /** Remove a capa do disco, a menos que outro jogo ainda use o mesmo link. */
    @OptIn(ExperimentalCoilApi::class)
    fun purgeIfUnused(url: String, stillUsed: Collection<String>) {
        val u = url.trim()
        if (u.isEmpty() || stillUsed.any { it.trim() == u }) return
        scope.launch {
            loader.memoryCache?.remove(MemoryCache.Key(u))
            loader.diskCache?.remove(u)
        }
    }

    @OptIn(ExperimentalCoilApi::class)
    fun clearAll() {
        scope.launch {
            loader.memoryCache?.clear()
            loader.diskCache?.clear()
        }
    }
}
