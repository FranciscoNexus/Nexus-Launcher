package com.nexus.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat

/**
 * Serviço em primeiro plano que mantém o Nexus vivo enquanto a varredura de pastas roda,
 * mesmo com o app minimizado. A varredura em si roda na MainActivity; aqui só fica a notificação.
 */
class ScanService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ScanNotify.ensureChannel(this)
        val n = ScanNotify.build(this, "Varrendo pastas de jogos…", ongoing = true, title = "Nexus")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ScanNotify.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(ScanNotify.ID_PROGRESS, n)
            }
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            ScanNotify.active = true
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, ScanService::class.java))
            } catch (_: Exception) {
                // Sem o serviço a varredura continua, só não sobrevive ao app minimizado por muito tempo.
            }
        }

        fun stop(ctx: Context) {
            ScanNotify.active = false
            try {
                ctx.stopService(Intent(ctx, ScanService::class.java))
            } catch (_: Exception) {
            }
            ScanNotify.clearProgress(ctx)
        }
    }
}

object ScanNotify {
    private const val CHANNEL = "nexus_scan"
    const val ID_PROGRESS = 7101
    const val ID_DONE = 7102
    @Volatile private var lastTs = 0L
    @Volatile var active = false

    fun clearProgress(ctx: Context) {
        try {
            ctx.getSystemService(NotificationManager::class.java)?.cancel(ID_PROGRESS)
        } catch (_: Exception) {
        }
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Varredura de jogos", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    fun build(ctx: Context, text: String, ongoing: Boolean, title: String): Notification {
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setAutoCancel(!ongoing)
        if (ongoing) b.setProgress(0, 0, true)
        return b.build()
    }

    /** Atualiza a notificação de andamento (no máximo 2 vezes por segundo). */
    fun progress(ctx: Context, platform: String, count: Int) {
        if (!active) return
        val now = System.currentTimeMillis()
        if (now - lastTs < 500) return
        lastTs = now
        try {
            ensureChannel(ctx)
            ctx.getSystemService(NotificationManager::class.java)
                ?.notify(ID_PROGRESS, build(ctx, "$platform: $count arquivo(s) encontrado(s)", true, "Varrendo pastas"))
        } catch (_: Exception) {
        }
    }

    /** Andamento genérico (título e texto livres), no máximo 2 atualizações por segundo. */
    fun progressText(ctx: Context, title: String, text: String) {
        if (!active) return
        val now = System.currentTimeMillis()
        if (now - lastTs < 500) return
        lastTs = now
        try {
            ensureChannel(ctx)
            ctx.getSystemService(NotificationManager::class.java)
                ?.notify(ID_PROGRESS, build(ctx, text, true, title))
        } catch (_: Exception) {
        }
    }

    fun doneTitled(ctx: Context, title: String, text: String) {
        try {
            ensureChannel(ctx)
            ctx.getSystemService(NotificationManager::class.java)
                ?.notify(ID_DONE, build(ctx, text, false, title))
        } catch (_: Exception) {
        }
    }

    fun done(ctx: Context, text: String) {
        try {
            ensureChannel(ctx)
            ctx.getSystemService(NotificationManager::class.java)
                ?.notify(ID_DONE, build(ctx, text, false, "Varredura concluída"))
        } catch (_: Exception) {
        }
    }
}
