package com.nexus.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

/*
 * 4.7.9: ícones de "Favorito" (estrela) e "Jogado recentemente" (ampulheta), desenhados em código.
 *  - Os dois usam a MESMA caixa (mesma altura e mesma largura): as pontas da estrela e as tampas da ampulheta
 *    ficam alinhadas no topo e na base.
 *  - A cor vem de quem chama (cor de destaque escolhida pelo usuário).
 *  - O estilo das bordas escolhido pelo usuário (0 = Reto, 1 = Padrão, 2 = Suave) muda os cantos dos ícones.
 */

/** Largura da caixa dos dois ícones = altura × este valor. */
const val NX_ICON_W = 1.06f

/** Converte o raio de botão do estilo (4 / 11 / 18 dp) para o índice do estilo (0 / 1 / 2). */
fun nxStyleFromBtn(btnDp: Int): Int = if (btnDp <= 6) 0 else if (btnDp <= 14) 1 else 2

@Composable
fun NxStar(height: Dp, color: Color, style: Int, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = height * NX_ICON_W, height = height)) { drawNxStar(color, style) }
}

@Composable
fun NxHourglass(height: Dp, color: Color, style: Int, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = height * NX_ICON_W, height = height)) { drawNxHourglass(color, style) }
}

private fun DrawScope.drawNxStar(color: Color, style: Int) {
    val h = size.height
    // Contorno de largura w com junta redonda arredonda as pontas (Reto = pontas vivas, sem contorno).
    val w = when (style) { 0 -> 0f; 1 -> h * 0.10f; else -> h * 0.20f }
    // Altura total de uma estrela regular = 1,809 × raio externo; o contorno acrescenta w.
    val rOut = (h - w) / 1.809f
    val rIn = rOut * 0.44f
    val cx = size.width / 2f
    val cy = w / 2f + rOut
    val path = Path()
    for (k in 0 until 10) {
        val ang = Math.toRadians(-90.0 + 36.0 * k)
        val r = if (k % 2 == 0) rOut else rIn
        val x = cx + (r * Math.cos(ang)).toFloat()
        val y = cy + (r * Math.sin(ang)).toFloat()
        if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color)
    if (w > 0f) drawPath(path, color, style = Stroke(width = w, join = StrokeJoin.Round))
}

private fun DrawScope.drawNxHourglass(color: Color, style: Int) {
    val h = size.height
    val cx = size.width / 2f
    fun gy(v: Float) = h * (0.17f + (v - 0.15f) / 0.70f * 0.66f) // vidro entre 17% e 83% da altura
    fun gx(v: Float) = cx + h * v

    // Tampas (topo e base): cantos conforme o estilo.
    val barH = h * 0.11f
    val barW = h * 0.72f
    val rad = when (style) { 0 -> h * 0.015f; 1 -> h * 0.035f; else -> barH / 2f }
    drawRoundRect(color, Offset(cx - barW / 2f, 0f), Size(barW, barH), CornerRadius(rad, rad))
    drawRoundRect(color, Offset(cx - barW / 2f, h - barH), Size(barW, barH), CornerRadius(rad, rad))

    // Vidro: Reto = polígono de pontas vivas; Padrão/Suave = curvas.
    val glass = Path()
    if (style == 0) {
        glass.moveTo(gx(-0.27f), gy(0.15f))
        glass.lineTo(gx(0.27f), gy(0.15f))
        glass.lineTo(gx(0.04f), gy(0.50f))
        glass.lineTo(gx(0.27f), gy(0.85f))
        glass.lineTo(gx(-0.27f), gy(0.85f))
        glass.lineTo(gx(-0.04f), gy(0.50f))
        glass.close()
    } else {
        glass.moveTo(gx(-0.27f), gy(0.15f))
        glass.lineTo(gx(0.27f), gy(0.15f))
        glass.cubicTo(gx(0.27f), gy(0.34f), gx(0.04f), gy(0.40f), gx(0.04f), gy(0.50f))
        glass.cubicTo(gx(0.04f), gy(0.60f), gx(0.27f), gy(0.66f), gx(0.27f), gy(0.85f))
        glass.lineTo(gx(-0.27f), gy(0.85f))
        glass.cubicTo(gx(-0.27f), gy(0.66f), gx(-0.04f), gy(0.60f), gx(-0.04f), gy(0.50f))
        glass.cubicTo(gx(-0.04f), gy(0.40f), gx(-0.27f), gy(0.34f), gx(-0.27f), gy(0.15f))
        glass.close()
    }
    drawPath(
        glass, color,
        style = Stroke(width = h * 0.075f, join = if (style == 0) StrokeJoin.Miter else StrokeJoin.Round)
    )

    // Areia de baixo (monte) e de cima (restante perto do gargalo).
    val bottom = Path()
    bottom.moveTo(gx(-0.27f), gy(0.85f))
    bottom.quadraticBezierTo(gx(-0.04f), gy(0.80f), gx(0f), gy(0.66f))
    bottom.quadraticBezierTo(gx(0.04f), gy(0.80f), gx(0.27f), gy(0.85f))
    bottom.close()
    drawPath(bottom, color)

    val top = Path()
    top.moveTo(gx(-0.13f), gy(0.30f))
    top.quadraticBezierTo(gx(0f), gy(0.38f), gx(0.13f), gy(0.30f))
    top.lineTo(gx(0.035f), gy(0.47f))
    top.lineTo(gx(-0.035f), gy(0.47f))
    top.close()
    drawPath(top, color)
}
