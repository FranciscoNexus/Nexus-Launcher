package com.nexus.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.inset
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp

/*
 * 4.8.0: ícones de "Favorito" (estrela dentro de um QUADRADO) e "Jogado recentemente" (ampulheta dentro de um CÍRCULO).
 *  - Fundo transparente; a cor (moldura + desenho) vem de quem chama = cor de destaque escolhida pelo usuário.
 *  - O quadrado muda os cantos conforme o estilo de borda escolhido (0 = Reto, 1 = Padrão, 2 = Suave).
 *  - Os dois ocupam um quadrado do mesmo tamanho: quem usa define o tamanho com Modifier.size(...) (ou deixa o pai medir).
 */

/** Converte o raio de botão do estilo (4 / 11 / 18 dp) para o índice do estilo (0 / 1 / 2). */
fun nxStyleFromBtn(btnDp: Int): Int = if (btnDp <= 6) 0 else if (btnDp <= 14) 1 else 2

/** Estrela dentro do quadrado. */
@Composable
fun NxStar(color: Color, style: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = minOf(size.width, size.height)
        inset((size.width - s) / 2f, (size.height - s) / 2f, (size.width - s) / 2f, (size.height - s) / 2f) {
            val sw = s * 0.09f
            val cr = s * when (style) { 0 -> 0.04f; 1 -> 0.18f; else -> 0.32f }
            drawRoundRect(
                color, Offset(sw / 2f, sw / 2f), Size(s - sw, s - sw), CornerRadius(cr, cr),
                style = Stroke(width = sw)
            )
            val hs = s * 0.56f
            val ws = hs * 1.06f
            inset((s - ws) / 2f, (s - hs) / 2f + s * 0.01f, (s - ws) / 2f, (s - hs) / 2f - s * 0.01f) {
                drawNxStar(color, 1)
            }
        }
    }
}

/** Ampulheta dentro do círculo. */
@Composable
fun NxHourglass(color: Color, style: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = minOf(size.width, size.height)
        inset((size.width - s) / 2f, (size.height - s) / 2f, (size.width - s) / 2f, (size.height - s) / 2f) {
            val sw = s * 0.08f
            drawCircle(color, radius = (s - sw) / 2f, center = Offset(s / 2f, s / 2f), style = Stroke(width = sw))
            val hh = s * 0.56f
            val hw = hh * 1.06f
            inset((s - hw) / 2f, (s - hh) / 2f, (s - hw) / 2f, (s - hh) / 2f) {
                drawNxHourglass(color, 2)
            }
        }
    }
}

/**
 * Posiciona a etiqueta de plataforma (canto inferior direito) e os ícones da capa.
 * Conteúdo, nesta ordem: etiqueta, ampulheta (se [hasHour]), estrela (se [hasStar]).
 *  - [inlineWhenFits] = false (grade / celular em pé): ícones SEMPRE acima da etiqueta, à direita; estrela encostada na
 *    etiqueta (2 dp), ampulheta à esquerda dela (5 dp), tamanho fixo [aboveDp].
 *  - [inlineWhenFits] = true (Padrão e Carrossel): ícones no canto inferior ESQUERDO, na mesma linha da etiqueta, com a
 *    mesma altura dela (ampulheta à esquerda, estrela à direita; se só houver um, ele fica no canto). Se a etiqueta for
 *    grande demais e bater nos ícones, eles passam para cima da etiqueta, como na grade.
 */
@Composable
fun NxCardBadges(
    inlineWhenFits: Boolean, hasHour: Boolean, hasStar: Boolean,
    modifier: Modifier = Modifier, aboveDp: Float = 12f,
    content: @Composable () -> Unit
) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val pad = 6.dp.roundToPx()
        val label = measurables[0].measure(Constraints(0, (w - 2 * pad).coerceAtLeast(0), 0, h))
        var idx = 1
        val hm = if (hasHour) measurables[idx++] else null
        val sm = if (hasStar) measurables[idx] else null
        val count = (if (hm != null) 1 else 0) + (if (sm != null) 1 else 0)
        val gap = 5.dp.roundToPx()
        val gapLabel = 6.dp.roundToPx()
        val inlineSize = label.height
        val inlineW = count * inlineSize + (count - 1).coerceAtLeast(0) * gap
        val fits = inlineWhenFits && count > 0 && pad + inlineW + gapLabel + label.width + pad <= w
        val size = if (fits) inlineSize else aboveDp.dp.roundToPx()
        val c = Constraints.fixed(size, size)
        val hp = hm?.measure(c)
        val sp = sm?.measure(c)
        layout(w, h) {
            label.place(w - pad - label.width, h - pad - label.height)
            if (fits) {
                val y = h - pad - label.height
                var x = pad
                hp?.let { it.place(x, y); x += size + gap }
                sp?.place(x, y)
            } else {
                val total = count * size + (count - 1).coerceAtLeast(0) * gap
                val y = h - pad - label.height - 2.dp.roundToPx() - size
                var x = w - pad - total
                hp?.let { it.place(x, y); x += size + gap }
                sp?.place(x, y)
            }
        }
    }
}

private fun DrawScope.drawNxStar(color: Color, style: Int) {
    val h = size.height
    // Contorno de largura w com junta redonda arredonda as pontas (Reto = pontas vivas, sem contorno).
    val w = when (style) { 0 -> 0f; 1 -> h * 0.10f; else -> h * 0.20f }
    // Altura total de uma estrela regular = 1,809 × raio externo; o contorno acrescenta w.
    val rOut = (h - w) / 1.809f
    val rIn = rOut * 0.44f
    val cx = size.width / 2f
    val cy = w / 2f + rOut
    val path = Path()
    for (k in 0 until 10) {
        val ang = Math.toRadians(-90.0 + 36.0 * k)
        val r = if (k % 2 == 0) rOut else rIn
        val x = cx + (r * Math.cos(ang)).toFloat()
        val y = cy + (r * Math.sin(ang)).toFloat()
        if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color)
    if (w > 0f) drawPath(path, color, style = Stroke(width = w, join = StrokeJoin.Round))
}

private fun DrawScope.drawNxHourglass(color: Color, style: Int) {
    val h = size.height
    val cx = size.width / 2f
    fun gy(v: Float) = h * (0.17f + (v - 0.15f) / 0.70f * 0.66f) // vidro entre 17% e 83% da altura
    fun gx(v: Float) = cx + h * v

    // Tampas (topo e base): cantos conforme o estilo.
    val barH = h * 0.11f
    val barW = h * 0.72f
    val rad = when (style) { 0 -> h * 0.015f; 1 -> h * 0.035f; else -> barH / 2f }
    drawRoundRect(color, Offset(cx - barW / 2f, 0f), Size(barW, barH), CornerRadius(rad, rad))
    drawRoundRect(color, Offset(cx - barW / 2f, h - barH), Size(barW, barH), CornerRadius(rad, rad))

    // Vidro: Reto = polígono de pontas vivas; Padrão/Suave = curvas.
    val glass = Path()
    if (style == 0) {
        glass.moveTo(gx(-0.27f), gy(0.15f))
        glass.lineTo(gx(0.27f), gy(0.15f))
        glass.lineTo(gx(0.04f), gy(0.50f))
        glass.lineTo(gx(0.27f), gy(0.85f))
        glass.lineTo(gx(-0.27f), gy(0.85f))
        glass.lineTo(gx(-0.04f), gy(0.50f))
        glass.close()
    } else {
        glass.moveTo(gx(-0.27f), gy(0.15f))
        glass.lineTo(gx(0.27f), gy(0.15f))
        glass.cubicTo(gx(0.27f), gy(0.34f), gx(0.04f), gy(0.40f), gx(0.04f), gy(0.50f))
        glass.cubicTo(gx(0.04f), gy(0.60f), gx(0.27f), gy(0.66f), gx(0.27f), gy(0.85f))
        glass.lineTo(gx(-0.27f), gy(0.85f))
        glass.cubicTo(gx(-0.27f), gy(0.66f), gx(-0.04f), gy(0.60f), gx(-0.04f), gy(0.50f))
        glass.cubicTo(gx(-0.04f), gy(0.40f), gx(-0.27f), gy(0.34f), gx(-0.27f), gy(0.15f))
        glass.close()
    }
    drawPath(
        glass, color,
        style = Stroke(width = h * 0.075f, join = if (style == 0) StrokeJoin.Miter else StrokeJoin.Round)
    )

    // Areia de baixo (monte) e de cima (restante perto do gargalo).
    val bottom = Path()
    bottom.moveTo(gx(-0.27f), gy(0.85f))
    bottom.quadraticBezierTo(gx(-0.04f), gy(0.80f), gx(0f), gy(0.66f))
    bottom.quadraticBezierTo(gx(0.04f), gy(0.80f), gx(0.27f), gy(0.85f))
    bottom.close()
    drawPath(bottom, color)

    val top = Path()
    top.moveTo(gx(-0.13f), gy(0.30f))
    top.quadraticBezierTo(gx(0f), gy(0.38f), gx(0.13f), gy(0.30f))
    top.lineTo(gx(0.035f), gy(0.47f))
    top.lineTo(gx(-0.035f), gy(0.47f))
    top.close()
    drawPath(top, color)
}
