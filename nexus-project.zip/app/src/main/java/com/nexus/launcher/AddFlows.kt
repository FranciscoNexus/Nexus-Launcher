package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.AddChoiceDialog(first: Boolean) {
    val accent = parseColor(accentHex)
    NexusModal(if (first) "Bem-vindo ao Nexus" else "Adicionar jogos", { popOverlay() }) {
        Text(
            if (first) "Vamos cadastrar seu primeiro jogo no catálogo. Como você quer adicionar?"
            else "Como você quer adicionar?",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        ActionRow(
            "✍", "Manualmente", "Um jogo por vez. Entra no catálogo só o que você escolher.",
            bg = S_CARD, border = S_LINE, iconBg = S_FIELD, iconFg = Color.White
        ) { overlay = Overlay.Edit(null) }
        Spacer(Modifier.height(8.dp))
        ActionRow(
            "📦", "Em lote", "Escolha a plataforma e as pastas; o Nexus encontra os jogos de uma vez.",
            bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f), iconBg = accent, iconFg = onAccent(accent)
        ) { overlay = Overlay.BatchSetup }
        // 4.9.23: só celular/tablet (a TV/Fire OS não aceitam launcher padrão, então o GameHub fácil não existe lá).
        if (!TvMode.isTv) {
            Spacer(Modifier.height(8.dp))
            ActionRow(
                "🎮", "Jogo do GameHub", "Guiado: cria o atalho do jogo pelo GameHub, um ou vários.",
                bg = S_CARD, border = S_LINE, iconBg = S_FIELD, iconFg = Color.White
            ) {
                overlay = Overlay.None
                startHubWizard()
            }
        }
        if (first) {
            Spacer(Modifier.height(10.dp))
            CButton("Pular por agora", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
        }
    }
}

@Composable
internal fun MainActivity.StartMenuDialog() {
    val accent = parseColor(accentHex)
    val sel = selectedId
    val game = games.firstOrNull { it.id == sel }
    val plat = sel?.takeIf { it.startsWith(PLAT_PREFIX) }?.removePrefix(PLAT_PREFIX)
    NexusModal("Opções", { back() }) {
        ActionRow(
            "＋", "Adicionar novo jogo", "Manualmente ou em lote",
            bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f), iconBg = accent, iconFg = onAccent(accent)
        ) { overlay = Overlay.AddChoice(false) }
        if (game != null || plat != null) {
            Spacer(Modifier.height(8.dp))
            ActionRow(
                "✎", if (game != null) "Editar jogo" else "Editar plataforma",
                game?.title ?: plat ?: "",
                bg = S_CARD, border = S_LINE, iconBg = S_FIELD, iconFg = Color.White
            ) { editSelected() }
        }
    }
}

@Composable
internal fun MainActivity.BatchHost(s: BatchSession) {
    when (s.phase) {
        BatchPhase.SCANNING -> BatchProgressDialog(s)
        BatchPhase.REGIONS -> BatchRegionDialog(s)
        BatchPhase.LIST -> BatchListDialog(s)
    }
}

@Composable
internal fun MainActivity.BatchProgressDialog(s: BatchSession) {
    NexusModal("Varrendo pastas", { back() }) {
        Text(s.platform, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("${s.found} arquivo(s) encontrado(s)", color = C_MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        androidx.compose.material3.LinearProgressIndicator(
            modifier = Modifier.fillMaxWidth(), color = parseColor(accentHex)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Pode minimizar o Nexus. Avisamos por notificação quando terminar.",
            color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Cancelar", C_GRAY, Modifier.weight(1f)) {
                closeBatch()
                toast("Varredura cancelada")
            }
            CButton("Minimizar", C_BLUE, Modifier.weight(1f)) { moveTaskToBack(true) }
        }
    }
}

@Composable
internal fun MainActivity.BatchRegionDialog(s: BatchSession) {
    NexusModal("Jogos em mais de uma região", { closeBatch() }) {
        Text(
            "Encontramos ${s.dupGroups} jogo(s) com versões de regiões diferentes. " +
                "Qual região você prefere? Se um jogo não tiver essa região, o Nexus usa a mais próxima. " +
                "Na lista seguinte você pode trocar a versão de cada jogo.",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        ScanEngine.REGION_CHOICES.forEach { r ->
            CButton(
                if (r == "Brazil") "Brasil (traduções PT-BR primeiro)" else regionLabel(r),
                if (r == "Brazil") C_BLUE else C_GRAY, Modifier.fillMaxWidth()
            ) { buildBatchItems(s, ScanEngine.regionPriority(r)) }
            Spacer(Modifier.height(6.dp))
        }
        Spacer(Modifier.height(4.dp))
        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { closeBatch() }
    }
}

@Composable
internal fun MainActivity.BatchListDialog(s: BatchSession) {
    val accent = parseColor(accentHex)
    val k = s.query.trim().lowercase()
    val shown = if (k.isEmpty()) s.items.toList()
    else s.items.filter { it.cand.title.lowercase().contains(k) || it.cand.fileName.lowercase().contains(k) }
    val ign = if (k.isEmpty()) s.ignoredItems.toList()
    else s.ignoredItems.filter { it.item.name.lowercase().contains(k) }
    val marked = s.items.count { it.checked }
    val total = marked + s.ignoredItems.count { it.checked }
    val addLabel = if (total == 0) "Nada marcado" else "Adicionar $total"
    val onAdd = { if (total > 0) confirmBatch(s) else toast("Marque ao menos um jogo") }
    val counter = "$marked de ${s.items.size} marcados" + (if (s.alreadyCount > 0) " · ${s.alreadyCount} já no catálogo" else "")
    val controls: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        CField(s.query, { s.query = it }, "🔍 Buscar", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        if (landscape) {
            Text(counter, color = C_MUTED, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                EBtn("Todos", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f)) { shown.forEach { it.checked = true } }
                EBtn("Nenhum", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f)) { shown.forEach { it.checked = false } }
            }
        } else {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(counter, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.weight(1f))
                EBtn("Todos", null, S_FIELD, S_LINE, Color(0xFFE2E8F0)) { shown.forEach { it.checked = true } }
                Spacer(Modifier.width(6.dp))
                EBtn("Nenhum", null, S_FIELD, S_LINE, Color(0xFFE2E8F0)) { shown.forEach { it.checked = false } }
            }
        }
        if (s.failedFolders > 0) {
            Text("⚠ ${s.failedFolders} pasta(s) sem acesso.", color = C_ORANGE, fontSize = 10.sp)
        }
    }
    val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Spacer(Modifier.height(4.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(shown, key = { "g" + it.key }) { bi -> BatchRow(bi, accent) }
            if (ign.isNotEmpty()) {
                item(key = "ign-header") {
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow { s.showIgnored = !s.showIgnored },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Ignorados (${ign.size}): BIOS, updates, DLC, Beta e outros",
                            color = C_MUTED, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(if (s.showIgnored) "▴" else "▾", color = C_MUTED, fontSize = 14.sp)
                    }
                }
                if (s.showIgnored) {
                    items(ign, key = { "i" + it.item.candidate.uri }) { ig -> BatchIgnoredRow(ig, accent) }
                }
            }
        }
    }
    if (landscape) {
        NexusModal(
            "Adicionar: ${s.platform}", { closeBatch() }, tall = true,
            leftPane = {
                controls()
                Spacer(Modifier.height(14.dp))
                EBtn(addLabel, "✓", accent, accent, onAccent(accent), Modifier.fillMaxWidth(), tall = true) { onAdd() }
                Spacer(Modifier.height(8.dp))
                EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.fillMaxWidth(), tall = true) { closeBatch() }
            }
        ) { listUi() }
    } else {
        NexusModal(
            "Adicionar: ${s.platform}", { closeBatch() }, tall = true,
            footer = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) { closeBatch() }
                    EBtn(addLabel, "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) { onAdd() }
                }
            }
        ) {
            controls()
            listUi()
        }
    }
}

@Composable
internal fun MainActivity.BatchRow(bi: BatchItem, accent: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().cardRow { bi.checked = !bi.checked },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (bi.checked) "☑" else "☐", color = if (bi.checked) accent else C_MUTED, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(bi.cand.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(bi.cand.fileName, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (bi.variants.size > 1) {
            Spacer(Modifier.width(6.dp))
            VariantPicker(bi)
        }
    }
}

@Composable
internal fun MainActivity.VariantPicker(bi: BatchItem) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(rBtn.dp)
    Box {
        Box(
            modifier = Modifier
                .clip(shape)
                .background(S_FIELD)
                .border(1.dp, S_LINE, shape)
                .clickable { open = true }
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Text(regionText(bi.cand) + " ▾", color = Color.White, fontSize = 11.sp, maxLines = 1)
        }
        if (open) {
            OptionsWindow("Versão", { open = false }) {
                bi.variants.forEachIndexed { i, v ->
                    OptRow(regionText(v), v.fileName, cur = v == bi.cand, initial = v == bi.cand || i == 0) {
                        bi.cand = v
                        open = false
                    }
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.BatchIgnoredRow(ig: BatchIgnored, accent: Color) {
    Row(
        modifier = Modifier.fillMaxWidth().cardRow { ig.checked = !ig.checked },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (ig.checked) "☑" else "☐", color = if (ig.checked) accent else C_MUTED, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(ig.item.name, color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(ig.item.reason, color = C_ORANGE, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
internal fun MainActivity.RomListDialog(req: RomListRequest) {
    var entries by remember(req) { mutableStateOf<ScanResult?>(null) }
    var q by remember(req) { mutableStateOf("") }
    LaunchedEffect(req) { entries = withContext(Dispatchers.IO) { scanRoms(req.platform) } }
    val k = q.trim().lowercase()
    val all = entries?.roms
    val failed = entries?.failed ?: 0
    val shown = if (all == null) emptyList() else if (k.isEmpty()) all else all.filter { it.name.lowercase().contains(k) }
    NexusModal("ROMs · ${req.platform}", { romList = null }, tall = true) {
        CField(q, { q = it }, "🔍 Buscar ROM", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(
            if (all == null) "Lendo pastas…" else "${shown.size} de ${all.size} arquivo(s)",
            color = C_MUTED, fontSize = 11.sp
        )
        if (failed > 0) {
            Text(
                "⚠ $failed pasta(s) sem acesso. Vincule de novo em Configurações.",
                color = C_ORANGE, fontSize = 10.sp
            )
        }
        Spacer(Modifier.height(4.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(shown, key = { it.uri }) { e ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .cardRow {
                            romList = null
                            req.onPick(e.uri, e.name)
                        }
                ) {
                    Text(e.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (e.folder.isNotEmpty()) Text(e.folder, color = C_MUTED, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Escolher manualmente", C_GRAY, Modifier.weight(1f)) {
                romList = null
                dialogRomCb = { uri -> req.onPick(uri.toString(), displayName(uri)) }
                pickRomFile(false)
            }
            CButton("Fechar (B)", C_BLUE, Modifier.weight(1f)) { romList = null }
        }
    }
}
