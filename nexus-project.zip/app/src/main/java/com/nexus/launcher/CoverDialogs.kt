package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// Escolha de coleções de um jogo (seleção múltipla). Também permite criar uma coleção na hora.
// Escolha de imagem no SteamGridDB: busca o jogo (ou a plataforma) e mostra miniaturas para tocar.
@Composable
internal fun MainActivity.SgdbPickerDialog(p: SgdbPicker) {
    var term by remember { mutableStateOf(p.term) }
    var tick by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var gameName by remember { mutableStateOf("") }
    var grids by remember { mutableStateOf(emptyList<SgdbGrid>()) }
    // 4.9.12: abas "Estáticas" / "Animadas" (a segunda só existe quando quem abriu o seletor aceita capa animada).
    var animTab by remember { mutableStateOf(false) }
    val hasAnim = p.onPickAnim != null
    // 4.9.14: nas animadas a escolha é em dois passos. Tocar/focar uma capa só a põe em prévia (anima);
    // quem escolhe é o botão "Usar esta capa". Nas estáticas, um toque já escolhe, como sempre.
    var previewUrl by remember { mutableStateOf<String?>(null) }   // capa em prévia (com borda)
    var playUrl by remember { mutableStateOf<String?>(null) }      // capa tocando a animação (após uma pequena espera)
    var focusedUrl by remember { mutableStateOf<String?>(null) }   // capa com o foco do controle
    var btnFocused by remember { mutableStateOf(false) }
    var chosenUrl by remember { mutableStateOf("") }
    val useBtn = remember { FocusRequester() }
    val previewReq = remember { FocusRequester() }
    // Tudo que foi baixado só para a prévia (apagado ao fechar, exceto a escolhida e o que algum jogo já usa).
    val seen = remember { HashSet<String>() }
    DisposableEffect(Unit) {
        onDispose { Covers.discardPreviews(seen.toList(), games.map { it.cover } + chosenUrl) }
    }
    LaunchedEffect(previewUrl) {
        playUrl = null
        if (previewUrl != null) {
            delay(300)   // passando rápido pelas capas (controle), não começa a baixar/animar cada uma
            playUrl = previewUrl
        }
    }
    p.backStep = {
        // B com o foco no botão "Usar esta capa": volta o foco para a capa em prévia, em vez de fechar a janela.
        if (btnFocused && previewUrl != null) {
            try { previewReq.requestFocus() } catch (_: Exception) { }
            true
        } else false
    }
    val confirmAnim: () -> Unit = confirm@{
        val u = previewUrl ?: return@confirm
        chosenUrl = u
        p.onPickAnim?.invoke(u)
        // A capa animada escolhida fica guardada no aparelho (se já foi baixada na prévia, não baixa de novo).
        Covers.prefetch(this@SgdbPickerDialog, listOf(u))
        sgdbPicker = null
    }
    val pickGrid: (SgdbGrid) -> Unit = { g ->
        if (animTab && p.onPickAnim != null) {
            previewUrl = g.url
            // Com o controle: A numa capa leva o foco direto ao botão "Usar esta capa".
            if (padActive || focusedUrl == g.url) {
                try { useBtn.requestFocus() } catch (_: Exception) { }
            }
        } else {
            p.onPick(g.url)
            sgdbPicker = null
        }
    }
    /** Modificador de uma miniatura: prévia pelo foco do controle, borda na capa em prévia e o toque. */
    fun thumbMod(g: SgdbGrid, base: Modifier): Modifier {
        val sel = animTab && previewUrl == g.url
        return base
            .then(if (sel) Modifier.border(3.dp, parseColor(accentHex), RoundedCornerShape(rBtn.dp)) else Modifier)
            .then(if (sel) Modifier.focusRequester(previewReq) else Modifier)
            .onFocusChanged {
                if (it.isFocused) {
                    focusedUrl = g.url
                    if (animTab) previewUrl = g.url
                } else if (focusedUrl == g.url) focusedUrl = null
            }
            .clickable { pickGrid(g) }
    }
    val useBtnRow: @Composable () -> Unit = {
        if (animTab) {
            val ready = previewUrl != null
            CButton(
                "Usar esta capa", if (ready) C_BLUE else C_GRAY,
                Modifier.fillMaxWidth().focusRequester(useBtn).onFocusChanged { btnFocused = it.isFocused }
            ) { if (ready) confirmAnim() }
            Spacer(Modifier.height(6.dp))
        }
    }
    val tabsRow: @Composable () -> Unit = {
        if (hasAnim) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CButton("Estáticas", if (!animTab) C_BLUE else C_GRAY, Modifier.weight(1f)) { animTab = false }
                CButton("Animadas", if (animTab) C_BLUE else C_GRAY, Modifier.weight(1f)) { animTab = true }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
    LaunchedEffect(tick, animTab) {
        loading = true
        error = ""
        grids = emptyList()
        previewUrl = null
        val key = sgdbKey.trim()
        val res = withContext(Dispatchers.IO) { SgdbApi.findGrids(key, term, p.portrait, animTab) }
        when (res) {
            is SgdbGridsResult.Ok -> {
                gameName = res.game?.name ?: ""
                grids = res.grids
                if (animTab) res.grids.forEach { seen.add(it.url); seen.add(it.thumb) }
            }
            is SgdbGridsResult.Failure -> {
                error = res.message
                grids = emptyList()
            }
        }
        loading = false
    }
    val statusText = when {
        loading -> "Buscando…"
        error.isNotEmpty() -> error
        gameName.isEmpty() -> "Nada encontrado. Tente outro nome."
        grids.isEmpty() && animTab -> "Nenhuma capa animada para: $gameName."
        animTab -> "Resultado para: $gameName. Toque numa capa para ver a animação e use o botão \"Usar esta capa\"."
        else -> "Resultado para: $gameName. Toque em uma imagem."
    }
    if (p.portrait && landscape) {
        // Paisagem: busca numa coluna estreita à esquerda e as capas ocupam todo o resto à direita.
        // O grid mostra 2 linhas inteiras (6+ capas) e deixa uma faixa da 3ª linha à vista, indicando a rolagem.
        val accent = parseColor(accentHex)
        val panelShape = RoundedCornerShape(rPanel.dp)
        val closeShape = RoundedCornerShape(rBtn.dp)
        Dialog(
            onDismissRequest = { back() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .fillMaxHeight()
                        .shadow(14.dp, panelShape, ambientColor = accent, spotColor = accent)
                        .clip(panelShape)
                        .background(C_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
                        .padding(12.dp)
                ) {
                    Column(Modifier.width(210.dp).fillMaxHeight()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { MarqueeText(p.title, Color.White, 15, FontWeight.ExtraBold) }
                            Spacer(Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(closeShape)
                                    .background(Color(0x0FFFFFFF))
                                    .border(1.dp, S_LINE, closeShape)
                                    .focusGlow(closeShape)
                                    .clickable { sgdbPicker = null },
                                contentAlignment = Alignment.Center
                            ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 13.sp) }
                        }
                        Spacer(Modifier.height(10.dp))
                        tabsRow()
                        CField(term, { term = it }, "Nome para buscar", Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        CButton("🔍 Buscar", C_BLUE, Modifier.fillMaxWidth()) { tick++ }
                        Spacer(Modifier.height(8.dp))
                        Text(statusText, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.weight(1f))
                        useBtnRow()
                        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { sgdbPicker = null }
                    }
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.width(1.dp).fillMaxHeight().background(S_LINE))
                    Spacer(Modifier.width(12.dp))
                    BoxWithConstraints(Modifier.weight(1f).fillMaxHeight()) {
                        val gap = 8.dp
                        val cellH = (maxHeight - gap * 2) / 2.35f
                        val cellW = cellH * 0.67f
                        val cols = ((maxWidth + gap) / (cellW + gap)).toInt().coerceIn(3, 8)
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(cols),
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.spacedBy(gap),
                            verticalArrangement = Arrangement.spacedBy(gap)
                        ) {
                            items(grids, key = { it.url }) { g ->
                                SgdbThumb(
                                    g, animTab && playUrl == g.url,
                                    thumbMod(
                                        g,
                                        Modifier
                                            .fillMaxWidth()
                                            .height(cellH)
                                            .clip(RoundedCornerShape(rBtn.dp))
                                            .background(Color(0xFF1A1E29))
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
        return
    }
    NexusModal(p.title, { back() }, tall = true) {
        tabsRow()
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(term, { term = it }, "Nome para buscar", Modifier.weight(1f))
            CButton("🔍", C_BLUE, Modifier.width(52.dp)) { tick++ }
        }
        Spacer(Modifier.height(6.dp))
        Text(statusText, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (p.portrait) 3 else 2),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(grids, key = { it.url }) { g ->
                SgdbThumb(
                    g, animTab && playUrl == g.url,
                    thumbMod(
                        g,
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(if (p.portrait) 0.67f else 1.43f)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(Color(0xFF1A1E29))
                    )
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        useBtnRow()
        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { sgdbPicker = null }
    }
}

/**
 * 4.9.14: miniatura do seletor. Nas capas animadas a grade mostra só o 1º quadro, parado (leve, nenhuma anima sozinha).
 * Só a capa em prévia ([playing]) toca a animação, por cima do 1º quadro. Os arquivos baixados só para a prévia são
 * apagados ao fechar o seletor (exceto a capa escolhida).
 */
@Composable
private fun MainActivity.SgdbThumb(g: SgdbGrid, playing: Boolean, modifier: Modifier) {
    if (!g.animated) {
        AsyncImage(model = g.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier)
        return
    }
    val ctx = LocalContext.current
    val accent = parseColor(accentHex)
    val spinner: @Composable () -> Unit = {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator(Modifier.size(22.dp), color = accent, strokeWidth = 2.dp)
        }
    }
    val still = remember(g.thumb) { Covers.request(ctx, g.thumb) }
    Box(modifier) {
        // 1º quadro (carregador comum: não anima).
        SubcomposeAsyncImage(
            model = still, imageLoader = Covers.loader, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            loading = { spinner() },
            error = {
                Box(Modifier.fillMaxSize().padding(6.dp), contentAlignment = Alignment.Center) {
                    Text("Sem prévia.\nToque para usar.", color = C_MUTED, fontSize = 10.sp, textAlign = TextAlign.Center)
                }
            }
        )
        if (playing) {
            if (isApngUrl(g.url)) {
                ApngPlayer(g.url, Modifier.fillMaxSize(), whileLoading = spinner)
            } else {
                val anim = remember(g.url) { Covers.request(ctx, g.url, animate = true) }
                SubcomposeAsyncImage(
                    model = anim, imageLoader = Covers.animLoader, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = { spinner() },
                    error = {}
                )
            }
        }
    }
}

@Composable
internal fun MainActivity.CoverBatchDialog() {
    val job = coverBatch
    var scope by remember { mutableStateOf("") }
    var askMobile by remember { mutableStateOf(false) }
    val accent = parseColor(accentHex)
    NexusModal("Capas em lote", { popOverlay() }, tall = landscape && job == null && sgdbKey.isNotBlank()) {
        if (job != null && job.running) {
            Text("Buscando capas no SteamGridDB…", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            androidx.compose.material3.LinearProgressIndicator(
                progress = { if (job.total == 0) 0f else job.done.toFloat() / job.total },
                modifier = Modifier.fillMaxWidth(), color = accent
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${job.done} de ${job.total} · ${job.applied} aplicada(s)",
                color = C_MUTED, fontSize = 12.sp
            )
            Spacer(Modifier.height(4.dp))
            Text("Pode minimizar: a busca continua e avisa na notificação.", color = C_MUTED, fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar busca", C_RED, Modifier.weight(1f)) { job.cancelled = true }
                CButton("Minimizar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
            }
        } else if (job != null) {
            Text(
                "${job.applied} capa(s) aplicada(s) de ${job.total}.",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
            if (job.error.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Parou: ${job.error}", color = C_ORANGE, fontSize = 12.sp)
            }
            if (job.cancelled) {
                Spacer(Modifier.height(6.dp))
                Text("Busca cancelada.", color = C_MUTED, fontSize = 12.sp)
            }
            if (job.notFound.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Não encontrados (${job.notFound.size}):", color = C_MUTED, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                job.notFound.take(40).forEach {
                    Text("• $it", color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (job.notFound.size > 40) Text("… e mais ${job.notFound.size - 40}", color = C_MUTED, fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Nova busca", C_GRAY, Modifier.weight(1f)) { coverBatch = null }
                CButton("Fechar", C_BLUE, Modifier.weight(1f)) { coverBatch = null; popOverlay() }
            }
        } else {
            val missing = games.count { coverEligible(it, scope) }
            if (!(landscape && sgdbKey.isNotBlank())) Text(
                "Procura no SteamGridDB a primeira capa vertical de cada jogo sem capa, pelo título. " +
                    "Capas que você já tem nunca são trocadas. O ícone do app não conta como capa.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            if (sgdbKey.isBlank()) {
                Text("Cole sua chave do SteamGridDB em Sistema > SteamGridDB antes de começar.", color = C_ORANGE, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                CButton("Fechar", C_GRAY, Modifier.fillMaxWidth()) { popOverlay() }
            } else {
                if (landscape) {
                    Panes(0.46f, {
                        Text(
                            "Procura no SteamGridDB a primeira capa vertical de cada jogo sem capa, pelo título. " +
                                "Capas que você já tem nunca são trocadas. O ícone do app não conta como capa.",
                            color = Color(0xFFCBD2E0), fontSize = 12.sp
                        )
                        Spacer(Modifier.height(8.dp))
                CButton(
                    "Plataforma: " + scope.ifEmpty { "Todas" }, C_GRAY, Modifier.fillMaxWidth()
                ) {
                    platPicker = PlatPickerRequest(
                        "Capas de qual plataforma?", scope,
                        { p -> games.any { it.shownPlatform == p && coverEligible(it, "") } },
                        { _, _ -> }, { scope = it }
                    )
                }
                if (scope.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    CButton("Usar todas as plataformas", C_GRAY, Modifier.fillMaxWidth()) { scope = "" }
                }
                Spacer(Modifier.height(8.dp))
                Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                    }, {
                        if (askMobile) {
                            val mob = games.count { isMobileGame(it) && coverEligible(it, scope) }
                            Text(
                                "$mob jogo(s) de Android/Web também estão sem capa. Colocar capas nesses jogos?",
                                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(8.dp))
                            CButton("Sim, incluir Android/Web", C_BLUE, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, true) }
                            Spacer(Modifier.height(6.dp))
                            CButton("Não, só os outros jogos", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, false) }
                            Spacer(Modifier.height(6.dp))
                            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false }
                        } else {
                            Spacer(Modifier.weight(1f))
                            CButton("Começar", C_BLUE, Modifier.fillMaxWidth()) {
                                if (games.any { isMobileGame(it) && coverEligible(it, scope) }) askMobile = true
                                else startCoverBatch(scope, true)
                            }
                            Spacer(Modifier.height(8.dp))
                            CButton("Fechar", C_GRAY, Modifier.fillMaxWidth()) { popOverlay() }
                            Spacer(Modifier.weight(1f))
                        }
                    })
                } else {
                    CButton(
                        "Plataforma: " + scope.ifEmpty { "Todas" }, C_GRAY, Modifier.fillMaxWidth()
                    ) {
                        platPicker = PlatPickerRequest(
                            "Capas de qual plataforma?", scope,
                            { p -> games.any { it.shownPlatform == p && coverEligible(it, "") } },
                            { _, _ -> }, { scope = it }
                        )
                    }
                    if (scope.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        CButton("Usar todas as plataformas", C_GRAY, Modifier.fillMaxWidth()) { scope = "" }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                    if (askMobile) {
                        val mob = games.count { isMobileGame(it) && coverEligible(it, scope) }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "$mob jogo(s) de Android/Web também estão sem capa. Colocar capas nesses jogos?",
                            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        CButton("Sim, incluir Android/Web", C_BLUE, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, true) }
                        Spacer(Modifier.height(6.dp))
                        CButton("Não, só os outros jogos", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, false) }
                        Spacer(Modifier.height(6.dp))
                        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CButton("Fechar", C_GRAY, Modifier.weight(1f)) { popOverlay() }
                        CButton("Começar", C_BLUE, Modifier.weight(1f)) {
                            if (games.any { isMobileGame(it) && coverEligible(it, scope) }) askMobile = true
                            else startCoverBatch(scope, true)
                        }
                    }
                }
            }
        }
    }
}
