package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Tela de informações do jogo ----------
@Composable
internal fun MainActivity.InfoOverlay(id: String) {
    val g = games.firstOrNull { it.id == id }
    if (g == null) {
        SideEffect { overlay = Overlay.None }
        return
    }
    LaunchedEffect(id, sgdbKey) { fetchSgdb(g) }
    // 4.7.0: o vídeo é buscado só na 1ª vez que os detalhes abrem (e fica salvo no jogo).
    LaunchedEffect(id, ytKey) { ensureVideo(g) }
    LaunchedEffect(id) { infoNav = false }
    // 4.9.1: com os detalhes abertos, nada atrás (capas, cabeçalho, rodapé) pode receber o foco do D-pad.
    DisposableEffect(Unit) {
        FocusStyle.blockBehind = true
        onDispose { FocusStyle.blockBehind = false }
    }
    // 4.9.5: ao abrir, o foco vai direto para "Jogar" (e fica lá; nada anda sozinho).
    val infoFm = LocalFocusManager.current
    remember(id) { FocusProbe.reset(); 0 }
    val infoPad = padNav
    val optReq = remember { FocusRequester() }
    LaunchedEffect(id, infoPad) {
        if (infoPad) {
            delay(220)
            try {
                val tg = FocusProbe.target
                if (returnKey == "info_opt") {
                    returnKey = ""
                    optReq.requestFocus()
                } else if (tg != null) tg.requestFocus() else infoFm.moveFocus(FocusDirection.Next)
            } catch (_: Exception) {
            }
        }
    }
    LaunchedEffect(landscape) { if (!landscape) ytFull = false }
    DisposableEffect(id) { onDispose { closeVideo() } }
    val info = sgdbCache[id]
    val extra = if (info != null && info.found) GameInfoData(released = fmtReleased(info.released)) else GameInfoData()
    val vState = when {
        g.videoId.isNotEmpty() -> VideoBtn.Ready
        ytKey.isBlank() -> VideoBtn.NoKey
        id in ytBusy || (g.videoTried == 0L && id !in ytErr) -> VideoBtn.Searching
        else -> VideoBtn.Retry
    }
    val dens = LocalDensity.current
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    Box(Modifier.fillMaxSize().onGloballyPositioned { rootPos = it.positionInRoot() }) {
        GameInfoScreen(
            game = g,
            extra = extra,
            landscape = landscape,
            accent = parseColor(accentHex),
            cornerDp = rCard,
            panelDp = rPanel,
            btnDp = rBtn,
            video = vState,
            videoOpen = ytOpen,
            cover = { m -> InfoCover(g, m) },
            onVideo = { onVideoClick(g) },
            onRegion = { ytRegion = it },
            onPlay = { infoPlay(g) },
            onOptions = { returnKey = "info_opt"; overlay = Overlay.Edit(g) },
            optionsFocus = optReq,
            onChangeFile = { changeRomFile(g) },
            onBack = { overlay = Overlay.None },
            onToggleFav = {
                val nowFav = !g.isFavorite
                replaceGame(g.copy(isFavorite = nowFav, favoriteTs = if (nowFav) System.currentTimeMillis() else g.favoriteTs))
            },
            onGenres = {
                genrePickerSel.clear()
                genrePickerSel.addAll(g.genres)
                genrePickerCb = { sel -> replaceGame(g.copy(genres = sel)) }
                genrePickerOpen = true
            },
            onCollections = {
                collPickerSel.clear()
                collPickerSel.addAll(g.collections)
                collPickerCb = { sel -> replaceGame(g.copy(collections = sel)) }
                collPickerOpen = true
            }
        )
        if (ytOpen) {
            val r = ytRegion
            val winMod = when {
                ytFull -> Modifier.fillMaxSize()
                r != null -> Modifier
                    .offset { IntOffset((r.left - rootPos.x).toInt(), (r.top - rootPos.y).toInt()) }
                    .size(with(dens) { r.width.toDp() }, with(dens) { r.height.toDp() })
                else -> Modifier.size(0.dp)
            }
            VideoWindow(
                ctrl = ytCtrl, videoId = g.videoId, noKey = g.videoId.isEmpty(), full = ytFull, landscape = landscape,
                ctl = ytCtl, navOn = ytNav, accent = parseColor(accentHex),
                modifier = winMod,
                onAction = { ytAct(it) }
            )
        }
    }
}

@Composable
internal fun MainActivity.InfoCover(g: Game, modifier: Modifier) {
    Box(modifier.background(Color(0xFF1A1E29))) {
        val appIcon = if (g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()) {
            remember(g.pkg) { bigIconFor(g.pkg) }
        } else null
        if (appIcon != null) {
            Image(
                bitmap = appIcon, contentDescription = g.title,
                modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
            )
        } else {
            Text(
                g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(12.dp)
            )
        }
        if (g.cover.isNotBlank()) {
            val req = remember(g.cover) { Covers.request(this@InfoCover, g.cover) }
            key(coverRev) {
                AsyncImage(
                    model = req, imageLoader = Covers.loader, contentDescription = g.title,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
