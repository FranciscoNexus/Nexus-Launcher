package com.nexus.launcher

import android.graphics.drawable.Animatable
import android.widget.ImageView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.github.penfeizhou.animation.apng.APNGDrawable
import java.io.File

// 4.9.14: capas animadas em APNG (arquivo .png animado). O Android e o Coil mostram só o 1º quadro de um APNG;
// quem toca a animação é a biblioteca APNG4Android, desenhando por cima do 1º quadro.

/** APNG usa a extensão .png (as animadas em WebP/GIF seguem pelo Coil). */
internal fun isApngUrl(url: String): Boolean = url.trim().substringBefore('?').lowercase().endsWith(".png")

/**
 * Toca o APNG [url] (baixa para o disco se ainda não estiver). Enquanto baixa, ou se não for possível tocar,
 * não desenha nada: o 1º quadro que está por baixo continua à vista.
 */
@Composable
internal fun ApngPlayer(url: String, modifier: Modifier = Modifier, whileLoading: @Composable () -> Unit = {}) {
    val ctx = LocalContext.current
    val file by produceState<File?>(null, url) { value = Covers.localFile(ctx, url) }
    val f = file
    if (f == null) { whileLoading(); return }
    val drawable = remember(f) {
        try { APNGDrawable.fromFile(f.absolutePath) } catch (_: Throwable) { null }
    }
    if (drawable == null) return
    DisposableEffect(drawable) {
        onDispose { try { (drawable as? Animatable)?.stop() } catch (_: Throwable) { } }
    }
    AndroidView(
        factory = { c ->
            ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageDrawable(drawable)
                try { (drawable as? Animatable)?.start() } catch (_: Throwable) { }
            }
        },
        modifier = modifier
    )
}
