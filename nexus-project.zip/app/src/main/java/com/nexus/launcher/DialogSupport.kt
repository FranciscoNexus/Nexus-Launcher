package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.HideBarsInDialog(settings: Boolean = false) {
    val view = LocalView.current
    val fm = LocalFocusManager.current
    // 4.9.5: cada janela começa sem "alvo" de foco; o item marcado com initialFocus() se registra durante a composição.
    remember { FocusProbe.reset(); 0 }
    // 4.9.3: controle/controle remoto: setas e alavanca viram um passo só por toque; na janela de Configurações,
    // L1/R1 trocam de aba (L2 = primeira, R2 = última). Antes essas teclas não chegavam até o código que as tratava.
    // 4.9.5: nas demais janelas, L2 foca o primeiro item e R2 o último.
    DialogPad { ev ->
        if (drawerKeyHook?.invoke(ev) == true) return@DialogPad true   // 4.9.22: grade de apps (A, Y, R3, X)
        val c = ev.keyCode
        if (settings && (c == KeyEvent.KEYCODE_BUTTON_L1 || c == KeyEvent.KEYCODE_BUTTON_R1 ||
                c == KeyEvent.KEYCODE_BUTTON_L2 || c == KeyEvent.KEYCODE_BUTTON_R2)
        ) {
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                settingsTab = when (c) {
                    KeyEvent.KEYCODE_BUTTON_R1 -> (settingsTab + 1) % SETTINGS_TABS
                    KeyEvent.KEYCODE_BUTTON_L1 -> (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS
                    KeyEvent.KEYCODE_BUTTON_L2 -> 0
                    else -> SETTINGS_TABS - 1
                }
            }
            true
        } else if (c == KeyEvent.KEYCODE_BUTTON_L2 || c == KeyEvent.KEYCODE_BUTTON_R2) {
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                try {
                    fm.clearFocus(force = true)
                    fm.moveFocus(if (c == KeyEvent.KEYCODE_BUTTON_L2) FocusDirection.Next else FocusDirection.Previous)
                } catch (_: Exception) {
                }
            }
            true
        } else false
    }
    // 4.9.5: ao trocar de aba (L1/R1) o foco vai para o primeiro item da aba nova (o item antigo sumiu da tela).
    if (settings) {
        val tabSeen = remember { intArrayOf(-1) }
        val tabNow = settingsTab
        val tabPad = padNav
        LaunchedEffect(tabNow) {
            val prev = tabSeen[0]
            tabSeen[0] = tabNow
            if (prev >= 0 && prev != tabNow && tabPad) {
                delay(150)
                try {
                    fm.clearFocus(force = true)
                    fm.moveFocus(FocusDirection.Next)
                } catch (_: Exception) {
                }
            }
        }
    }
    // 4.9.5: TV (e celular na horizontal com controle): a janela abre com o foco no item certo, sem andar sozinho.
    val wantPad = padNav
    LaunchedEffect(wantPad) {
        if (wantPad) {
            delay(170)
            FocusProbe.applyOnce(fm)
        }
    }
    SideEffect {
        val win = (view.parent as? DialogWindowProvider)?.window
        if (win != null) {
            WindowCompat.setDecorFitsSystemWindows(win, false)
            // Teclado só aparece quando o usuário toca na caixa de texto.
            win.setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
            val c = WindowInsetsControllerCompat(win, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}

/**
 * 4.9.11: janelas com etapas (ex.: Resetar Jogos). A cada etapa nova o alvo de foco é refeito: o item marcado com
 * initialFocus() da etapa (ex.: "Cancelar" nas confirmações) ou, sem marca, o primeiro botão. Chamar ANTES do NexusModal.
 */
@Composable
internal fun MainActivity.RefocusOnStep(step: Any?) {
    val fm = LocalFocusManager.current
    val first = remember { booleanArrayOf(true) }
    remember(step) { FocusProbe.reset(); 0 }
    val pad = padNav
    LaunchedEffect(step, pad) {
        if (first[0]) { first[0] = false; return@LaunchedEffect } // a abertura já é tratada pelo HideBarsInDialog
        if (pad) {
            delay(170)
            FocusProbe.applyOnce(fm)
        }
    }
}

@Composable
internal fun MainActivity.NexusModal(
    title: String, onDismiss: () -> Unit, tall: Boolean = false,
    footer: (@Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
    leftPane: (@Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog()
        Box(
            modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            val accent = parseColor(accentHex)
            val panelShape = RoundedCornerShape(rPanel.dp)
            val closeShape = RoundedCornerShape(rBtn.dp)
            Column(
                modifier = Modifier
                    .fillMaxWidth(if (landscape) 0.86f else 0.94f)
                    .then(if (tall) Modifier.fillMaxHeight(if (landscape) 0.94f else 0.9f) else Modifier)
                    .shadow(14.dp, panelShape, ambientColor = accent, spotColor = accent)
                    .clip(panelShape)
                    .background(C_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f)) { MarqueeText(title, Color.White, 17, FontWeight.ExtraBold) }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(closeShape)
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, S_LINE, closeShape)
                            // TV: "Voltar" do controle já fecha; o destaque do D-pad começa no conteúdo, não no ✕.
                            .focusProperties { canFocus = !padNav }
                            .focusGlow(closeShape)
                            .clickable(onClick = onDismiss),
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                if (tall && landscape && leftPane != null) {
                    // Paisagem: controles à esquerda, lista inteira à direita.
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(0.38f).fillMaxHeight().verticalScroll(rememberScrollState())
                        ) { leftPane() }
                        Column(modifier = Modifier.weight(0.62f).fillMaxHeight()) { content() }
                    }
                } else if (tall) {
                    Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) { content() }
                } else {
                    // Janelas sem altura fixa rolam quando o conteúdo passa do tamanho da tela.
                    val modalScroll = rememberScrollState()
                    androidx.compose.runtime.CompositionLocalProvider(LocalModalScroll provides modalScroll) {
                        Column(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .fillMaxWidth()
                                .verticalScroll(modalScroll)
                                .padding(16.dp)
                        ) { content() }
                    }
                }
                if (footer != null && !(tall && landscape && leftPane != null)) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) { footer() }
                }
            }
        }
    }
}

// ---------- Diálogos ----------
@Composable
internal fun MainActivity.AppIcon(pkg: String) {
    val bmp = remember(pkg) { iconFor(pkg) }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(36.dp))
    } else {
        Spacer(Modifier.size(36.dp))
    }
}
