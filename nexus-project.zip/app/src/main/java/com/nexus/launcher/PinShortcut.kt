package com.nexus.launcher

import android.app.Activity
import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** 4.9.18: pacote do GameHub original (o app de jogos de PC cujos jogos entram no Nexus por atalho fixado). */
internal const val GAMEHUB_PKG = "com.xiaoji.egggame"

/** Atalho recebido (ainda não virou jogo na biblioteca). */
data class PendingShortcut(val pkg: String, val shortcutId: String, val label: String, val iconPath: String)

/**
 * 4.7.4 – Atalhos de outros apps (ex.: "Adicionar à área de trabalho" do GameHub).
 *
 * Quando o Nexus é o launcher padrão, o Android entrega a ele o pedido de criar o atalho. Esta tela aceita o
 * pedido, guarda o ícone e anota o atalho num arquivo; a tela principal transforma a anotação em jogo.
 */
object PinShortcuts {
    private fun file(ctx: Context) = File(ctx.filesDir, "pending_shortcuts.json")

    @Synchronized
    fun add(ctx: Context, s: PendingShortcut) {
        val arr = readArray(ctx)
        arr.put(
            JSONObject().put("pkg", s.pkg).put("id", s.shortcutId).put("label", s.label).put("icon", s.iconPath)
        )
        try {
            file(ctx).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    /** Devolve os atalhos pendentes e limpa o arquivo. */
    @Synchronized
    fun take(ctx: Context): List<PendingShortcut> {
        val arr = readArray(ctx)
        if (arr.length() == 0) return emptyList()
        file(ctx).delete()
        val out = ArrayList<PendingShortcut>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(PendingShortcut(o.optString("pkg"), o.optString("id"), o.optString("label"), o.optString("icon")))
        }
        return out
    }

    private fun readArray(ctx: Context): JSONArray = try {
        val f = file(ctx)
        if (f.exists()) JSONArray(f.readText()) else JSONArray()
    } catch (_: Exception) {
        JSONArray()
    }

    // ---------- 4.9.18: situação dos atalhos fixados ----------
    // Os atalhos fixados pertencem a ESTA instalação do Nexus: somem ao limpar os dados, desinstalar ou trocar a chave de
    // assinatura, e o backup do Nexus guarda só o ID. A consulta ao Android SEMPRE falha quando o Nexus não é o launcher
    // padrão (mesmo com o atalho vivo), então a situação vem de fatos: "ok" = o Android aceitou o pedido de atalho ou
    // abriu o atalho; "perdido" = abrir falhou de verdade (atalho inexistente para o Nexus). Fica em noBackupFilesDir:
    // sai junto com os dados do app e nunca é restaurado por backup do Android.
    private fun stateFile(ctx: Context) = File(ctx.noBackupFilesDir, "pins_state.json")

    fun key(pkg: String, shortcutId: String): String = "$pkg|$shortcutId"

    @Synchronized
    private fun readState(ctx: Context): Pair<MutableSet<String>, MutableSet<String>> {
        val ok = LinkedHashSet<String>()
        val lost = LinkedHashSet<String>()
        try {
            val f = stateFile(ctx)
            if (f.exists()) {
                val o = JSONObject(f.readText())
                o.optJSONArray("ok")?.let { a -> for (i in 0 until a.length()) ok.add(a.optString(i)) }
                o.optJSONArray("lost")?.let { a -> for (i in 0 until a.length()) lost.add(a.optString(i)) }
            }
        } catch (_: Exception) {
        }
        return Pair(ok, lost)
    }

    @Synchronized
    private fun writeState(ctx: Context, ok: Set<String>, lost: Set<String>) {
        try {
            val o = JSONObject()
            o.put("ok", JSONArray(ok.toList()))
            o.put("lost", JSONArray(lost.toList()))
            stateFile(ctx).writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    /** O Android aceitou o pedido de atalho, ou o atalho abriu: ele existe para este Nexus. */
    @Synchronized
    fun markOk(ctx: Context, pkg: String, shortcutId: String) {
        val (ok, lost) = readState(ctx)
        val k = key(pkg, shortcutId)
        if (ok.contains(k) && !lost.contains(k)) return
        ok.add(k)
        lost.remove(k)
        writeState(ctx, ok, lost)
    }

    /** Abrir o atalho falhou porque o Android não o conhece para este Nexus. */
    @Synchronized
    fun markLost(ctx: Context, pkg: String, shortcutId: String) {
        val (ok, lost) = readState(ctx)
        val k = key(pkg, shortcutId)
        if (lost.contains(k) && !ok.contains(k)) return
        lost.add(k)
        ok.remove(k)
        writeState(ctx, ok, lost)
    }

    fun lostKeys(ctx: Context): Set<String> = readState(ctx).second

    fun okKeys(ctx: Context): Set<String> = readState(ctx).first

    /** O erro de [start] quer dizer "este atalho não existe mais para o Nexus" (e não um problema passageiro do app)? */
    fun isLostError(err: String): Boolean =
        err.contains("SecurityException") || err.contains("não encontrado pelo Android")

    private fun errFile(ctx: Context) = File(ctx.filesDir, "last_shortcut_error.txt")

    /** 4.9.16: último erro ao abrir um atalho (fica no arquivo para o relatório, mesmo se o Nexus for fechado). */
    fun lastError(ctx: Context): String = try {
        val f = errFile(ctx)
        if (f.exists()) f.readText() else ""
    } catch (_: Exception) {
        ""
    }

    private fun saveError(ctx: Context, msg: String) {
        try {
            if (msg.isEmpty()) errFile(ctx).delete()
            else errFile(ctx).writeText(java.text.SimpleDateFormat("dd/MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()) + " - " + msg)
        } catch (_: Exception) {
        }
    }

    private fun describe(e: Throwable): String = e.javaClass.simpleName + ": " + (e.message ?: "sem mensagem")

    /** O Nexus tem permissão de "dono" de atalhos (ser o launcher padrão de verdade)? */
    fun hasHostPermission(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps).hasShortcutHostPermission()
    } catch (_: Exception) {
        false
    }

    private fun queryShortcut(la: LauncherApps, pkg: String, shortcutId: String): android.content.pm.ShortcutInfo? {
        val q = LauncherApps.ShortcutQuery()
            .setPackage(pkg)
            .setShortcutIds(listOf(shortcutId))
            .setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
            )
        return la.getShortcuts(q, Process.myUserHandle())?.firstOrNull()
    }

    /**
     * Abre o atalho de verdade (só funciona com o Nexus como launcher padrão). Devolve null se deu certo.
     * 4.9.16: se o 1º jeito falhar, tenta o 2º (pelo objeto do atalho) e devolve o erro real de cada tentativa.
     */
    fun start(ctx: Context, pkg: String, shortcutId: String): String? {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        try {
            la.startShortcut(pkg, shortcutId, null, null, Process.myUserHandle())
            saveError(ctx, "")
            markOk(ctx, pkg, shortcutId)
            return null
        } catch (e1: Throwable) {
            var msg = "1) " + describe(e1)
            try {
                val info = queryShortcut(la, pkg, shortcutId)
                if (info == null) {
                    msg += " | 2) atalho não encontrado pelo Android"
                } else {
                    la.startShortcut(info, null, null)
                    saveError(ctx, "")
                    markOk(ctx, pkg, shortcutId)
                    return null
                }
            } catch (e2: Throwable) {
                msg += " | 2) " + describe(e2)
            }
            saveError(ctx, "$pkg / $shortcutId: $msg")
            if (isLostError(msg)) markLost(ctx, pkg, shortcutId)
            return msg
        }
    }

    /** 4.9.16: linhas do relatório de diagnóstico sobre atalhos (por que abrir o atalho falha). */
    fun diagnose(ctx: Context, items: List<Triple<String, String, String>>): String {
        val sb = StringBuilder()
        sb.append("Atalhos de jogos\n")
        val home = try {
            val i = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: "nenhum"
        } catch (_: Exception) {
            "erro"
        }
        sb.append("Launcher padrão (HOME): $home\n")
        sb.append("Nexus é o launcher padrão: ${if (home == ctx.packageName) "sim" else "não"}\n")
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = ctx.getSystemService(Context.ROLE_SERVICE) as android.app.role.RoleManager
                sb.append("Papel HOME com o Nexus: ${if (rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)) "sim" else "não"}\n")
            } catch (_: Exception) {
            }
        }
        sb.append("Permissão de dono de atalhos: ${if (hasHostPermission(ctx)) "sim" else "não"}\n")
        sb.append("Fabricante/Android: ${Build.MANUFACTURER} / ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        if (items.isEmpty()) {
            sb.append("Nenhum jogo com atalho na biblioteca\n")
        }
        val la = try { ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps } catch (_: Exception) { null }
        for ((title, pkg, id) in items) {
            sb.append("- $title\n")
            sb.append("   app: $pkg\n   id: $id\n")
            val k = key(pkg, id)
            sb.append(
                "   situação do atalho: " + when {
                    lostKeys(ctx).contains(k) -> "PERDIDO (a última abertura falhou; precisa ser recriado no app do jogo)\n"
                    okKeys(ctx).contains(k) -> "ok (aceito ou aberto com sucesso nesta instalação)\n"
                    else -> "ainda não confirmado (abre-se o jogo uma vez para confirmar)\n"
                }
            )
            if (la == null) {
                sb.append("   (sem acesso ao serviço de atalhos)\n")
                continue
            }
            try {
                val info = queryShortcut(la, pkg, id)
                if (info == null) {
                    sb.append("   Android achou o atalho: não\n")
                    val pinned = la.getShortcuts(
                        LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED),
                        Process.myUserHandle()
                    )
                    sb.append("   Atalhos fixados deste app no Nexus: ${pinned?.size ?: "sem acesso"}\n")
                    pinned?.take(8)?.forEach { sb.append("     * ${it.id} (${it.shortLabel})\n") }
                } else {
                    sb.append("   Android achou o atalho: sim\n")
                    sb.append("   ativo: ${info.isEnabled}, fixado: ${info.isPinned}, dinâmico: ${info.isDynamic}, no manifesto: ${info.isDeclaredInManifest}\n")
                    sb.append("   atividade: ${info.activity?.flattenToShortString() ?: "não informada"}\n")
                    info.disabledMessage?.let { sb.append("   mensagem de desativado: $it\n") }
                    if (Build.VERSION.SDK_INT >= 34) sb.append("   motivo de desativado: ${info.disabledReason}\n")
                }
            } catch (e: Throwable) {
                if (e is SecurityException) {
                    // 4.9.18: o Android só deixa o launcher padrão CONSULTAR atalhos. Isso é normal e não diz se o atalho abre.
                    sb.append("   consulta bloqueada pelo Android (normal quando o Nexus não é o launcher padrão; não indica falha): ${describe(e)}\n")
                } else {
                    sb.append("   erro ao consultar: ${describe(e)}\n")
                }
            }
        }
        val le = lastError(ctx)
        sb.append("Último erro ao abrir atalho: ${if (le.isEmpty()) "nenhum" else le}\n")
        return sb.toString()
    }
}

class PinShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var msg = "Não foi possível receber o atalho."
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
                val req = la.getPinItemRequest(intent)
                val info = req?.shortcutInfo
                if (req != null && req.requestType == LauncherApps.PinItemRequest.REQUEST_TYPE_SHORTCUT && info != null && req.isValid) {
                    var iconPath = ""
                    try {
                        val d = la.getShortcutIconDrawable(info, 0)
                        if (d != null) {
                            val size = 256
                            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                            val c = Canvas(bmp)
                            d.setBounds(0, 0, size, size)
                            d.draw(c)
                            val dir = File(filesDir, "shortcut_icons").apply { mkdirs() }
                            val f = File(dir, UUID.randomUUID().toString() + ".png")
                            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            iconPath = "file://" + f.absolutePath
                        }
                    } catch (_: Exception) {
                    }
                    if (req.accept()) {
                        val label = (info.longLabel?.toString()?.takeIf { it.isNotBlank() }
                            ?: info.shortLabel?.toString() ?: info.id)
                        PinShortcuts.add(this, PendingShortcut(info.`package`, info.id, label, iconPath))
                        PinShortcuts.markOk(this, info.`package`, info.id)
                        msg = "Atalho adicionado ao Nexus: $label"
                    }
                }
            }
        } catch (e: Exception) {
            msg = "Não foi possível receber o atalho: ${e.message}"
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }
}
