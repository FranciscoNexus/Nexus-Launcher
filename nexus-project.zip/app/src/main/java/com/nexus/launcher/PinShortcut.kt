package com.nexus.launcher

import android.app.Activity
import android.content.Context
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Atalho recebido (ainda não virou jogo na biblioteca). */
data class PendingShortcut(val pkg: String, val shortcutId: String, val label: String, val iconPath: String)

/**
 * 4.7.4 – Atalhos de outros apps (ex.: "Atalho na Área" do GameHub).
 *
 * Quando o Nexus é o launcher padrão, o Android entrega a ele o pedido de criar o atalho. Esta tela aceita o
 * pedido, guarda o ícone e anota o atalho num arquivo; a tela principal transforma a anotação em jogo.
 */
object PinShortcuts {
    private fun file(ctx: Context) = File(ctx.filesDir, "pending_shortcuts.json")

    @Synchronized
    fun add(ctx: Context, s: PendingShortcut) {
        val arr = readArray(ctx)
        arr.put(
            JSONObject().put("pkg", s.pkg).put("id", s.shortcutId).put("label", s.label).put("icon", s.iconPath)
        )
        try {
            file(ctx).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    /** Devolve os atalhos pendentes e limpa o arquivo. */
    @Synchronized
    fun take(ctx: Context): List<PendingShortcut> {
        val arr = readArray(ctx)
        if (arr.length() == 0) return emptyList()
        file(ctx).delete()
        val out = ArrayList<PendingShortcut>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(PendingShortcut(o.optString("pkg"), o.optString("id"), o.optString("label"), o.optString("icon")))
        }
        return out
    }

    private fun readArray(ctx: Context): JSONArray = try {
        val f = file(ctx)
        if (f.exists()) JSONArray(f.readText()) else JSONArray()
    } catch (_: Exception) {
        JSONArray()
    }

    /** Abre o atalho de verdade (só funciona com o Nexus como launcher padrão). Devolve null se deu certo. */
    fun start(ctx: Context, pkg: String, shortcutId: String): String? {
        return try {
            val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            la.startShortcut(pkg, shortcutId, null, null, Process.myUserHandle())
            null
        } catch (e: Exception) {
            e.message ?: "erro"
        }
    }
}

class PinShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var msg = "Não foi possível receber o atalho."
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
                val req = la.getPinItemRequest(intent)
                val info = req?.shortcutInfo
                if (req != null && req.requestType == LauncherApps.PinItemRequest.REQUEST_TYPE_SHORTCUT && info != null && req.isValid) {
                    var iconPath = ""
                    try {
                        val d = la.getShortcutIconDrawable(info, 0)
                        if (d != null) {
                            val size = 256
                            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                            val c = Canvas(bmp)
                            d.setBounds(0, 0, size, size)
                            d.draw(c)
                            val dir = File(filesDir, "shortcut_icons").apply { mkdirs() }
                            val f = File(dir, UUID.randomUUID().toString() + ".png")
                            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            iconPath = "file://" + f.absolutePath
                        }
                    } catch (_: Exception) {
                    }
                    if (req.accept()) {
                        val label = (info.longLabel?.toString()?.takeIf { it.isNotBlank() }
                            ?: info.shortLabel?.toString() ?: info.id)
                        PinShortcuts.add(this, PendingShortcut(info.`package`, info.id, label, iconPath))
                        msg = "Atalho adicionado ao Nexus: $label"
                    }
                }
            }
        } catch (e: Exception) {
            msg = "Não foi possível receber o atalho: ${e.message}"
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }
}
