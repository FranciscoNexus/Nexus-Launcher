package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

internal fun MainActivity.fileUri(f: File): String =
    FileProvider.getUriForFile(this, "$packageName.fileprovider", f).toString()

internal fun MainActivity.safReadable(uri: String): Boolean = try {
    val pfd = contentResolver.openFileDescriptor(Uri.parse(uri), "r")
    if (pfd == null) {
        false
    } else {
        pfd.close()
        true
    }
} catch (_: Exception) {
    false
}

// Se o Nexus não tem mais a permissão da pasta (ex.: backup importado), usa o arquivo direto pelo acesso a todos os arquivos.
internal fun MainActivity.effectiveRomUri(uri: String): String {
    if (uri.isEmpty() || !hasAllFiles()) return uri
    val u = Uri.parse(uri)
    if (u.authority != "com.android.externalstorage.documents") return uri
    if (safReadable(uri)) return uri
    val f = File(pathOf(uri))
    if (!f.isFile) return uri
    return try {
        fileUri(f)
    } catch (_: Exception) {
        uri
    }
}

internal fun MainActivity.treePath(tree: String): String {
    val id = try {
        DocumentsContract.getTreeDocumentId(Uri.parse(tree))
    } catch (_: Exception) {
        ""
    }
    val vol = id.substringBefore(':', "")
    val rel = id.substringAfter(':', "")
    return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
}

internal fun MainActivity.walkFiles(dir: File, path: String, exts: Set<String>?, out: MutableList<RomEntry>, depth: Int) {
    if (depth > 12 || out.size > 20000) return
    val kids = dir.listFiles() ?: return
    for (k in kids) {
        if (k.isDirectory) {
            walkFiles(k, "$path${k.name}/", exts, out, depth + 1)
        } else {
            val ext = k.name.substringAfterLast('.', "").lowercase()
            if (exts == null || ext in exts) out.add(RomEntry(k.name, path, fileUri(k)))
        }
    }
}

internal fun MainActivity.pathOf(uri: String): String {
    if (!uri.startsWith("content://")) return Uri.parse(uri).path ?: uri
    val pu = Uri.parse(uri)
    if (pu.authority == "$packageName.fileprovider") return "/" + (pu.path ?: "").removePrefix("/root/")
    val id = docIdOf(uri)
    val vol = id.substringBefore(':', "")
    val rel = id.substringAfter(':', "")
    return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
}

internal fun MainActivity.mimeOf(fileName: String): String {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
}

internal fun MainActivity.foldText(s: String): String =
    java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

internal fun MainActivity.docIdOf(uri: String): String = try {
    DocumentsContract.getDocumentId(Uri.parse(uri))
} catch (_: Exception) {
    Uri.parse(uri).lastPathSegment ?: ""
}

internal fun MainActivity.fileNameOf(uri: String): String =
    docIdOf(uri).substringAfterLast('/').substringAfterLast(':')

internal fun MainActivity.scanRoms(platform: String): ScanResult {
    val link = linkFor(platform) ?: return ScanResult(emptyList(), 0)
    val exts = link.exts.takeIf { it.isNotEmpty() }?.toSet() ?: ROM_EXT[execKey(platform)]
    val out = ArrayList<RomEntry>()
    var failed = 0
    val granted = contentResolver.persistedUriPermissions
        .filter { it.isReadPermission }.map { it.uri.toString() }
    for (f in link.folders) {
        if (f in granted) {
            try {
                val tree = Uri.parse(f)
                walkTree(tree, DocumentsContract.getTreeDocumentId(tree), "", exts, out, 0)
            } catch (_: Exception) {
                failed++
            }
        } else if (hasAllFiles()) {
            // Sem permissão da pasta (ex.: veio de backup): lê direto pelo acesso a todos os arquivos.
            try {
                val dir = File(treePath(f))
                if (dir.isDirectory) walkFiles(dir, "", exts, out, 0) else failed++
            } catch (_: Exception) {
                failed++
            }
        } else {
            failed++
        }
    }
    return ScanResult(out.distinctBy { it.uri }.sortedAlpha { it.name }, failed)
}

internal fun MainActivity.walkTree(
    tree: Uri, docId: String, path: String, exts: Set<String>?,
    out: MutableList<RomEntry>, depth: Int
) {
    if (depth > 12 || out.size > 20000) return
    val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
    val cols = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE
    )
    contentResolver.query(kids, cols, null, null, null)?.use { c ->
        while (c.moveToNext()) {
            val id = c.getString(0) ?: continue
            val name = c.getString(1) ?: continue
            val mime = c.getString(2) ?: ""
            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                walkTree(tree, id, "$path$name/", exts, out, depth + 1)
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                if (exts == null || ext in exts) {
                    out.add(RomEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()))
                }
            }
        }
    }
}

internal fun MainActivity.folderLabel(s: String): String = try {
    val id = DocumentsContract.getTreeDocumentId(Uri.parse(s))
    val vol = id.substringBefore(':')
    val rel = id.substringAfter(':', "")
    (if (vol.equals("primary", true)) "Interno" else vol) + "/" + rel
} catch (_: Exception) {
    s
}

internal fun MainActivity.displayName(uri: Uri): String {
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: ""
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment ?: ""
}

internal fun MainActivity.cleanTitle(file: String, keepId: Boolean): String {
    var s = file.substringBeforeLast('.', file)
    s = s.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
    if (!keepId) s = s.replace(Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$"), "")
    return s.trim()
}

/** Extensões do emulador escolhido; sem elas, a tabela embutida da plataforma. */
internal fun MainActivity.batchExts(platform: String, linkExts: List<String>): List<String> =
    if (linkExts.isNotEmpty()) linkExts
    else (ROM_EXT[execKey(platform)]?.toList()
        ?: if (isCustomPlatform(platform)) ScanEngine.GENERIC_EXTS.toList() else emptyList())

internal fun MainActivity.closeBatch() {
    batch?.cancelled = true
    batch = null
    ScanService.stop(this)
}

internal fun MainActivity.regionLabel(r: String): String = when (r) {
    "Brazil" -> "Brasil"
    "PT-BR" -> "PT-BR (tradução)"
    "World" -> "Mundo"
    "Japan" -> "Japão"
    "Europe" -> "Europa"
    else -> r
}

internal fun MainActivity.regionText(c: ScanCandidate): String =
    if (c.regions.isEmpty()) "Sem região" else c.regions.joinToString(" + ") { regionLabel(it) }

internal fun MainActivity.startBatchScan(platform: String) {
    val link = linkFor(platform) ?: return
    val profile = ScanEngine.profileFor(platform, execBase(platform), batchExts(platform, link.exts))
    if (profile == null) {
        toast("Escolha um emulador para $platform")
        return
    }
    val s = BatchSession(platform, profile)
    batch = s
    askNotifications()
    ScanService.start(this)
    mainScope.launch {
        val raw = withContext(Dispatchers.IO) { collectRaw(link, s) }
        if (batch !== s || s.cancelled) return@launch
        val outcome = withContext(Dispatchers.Default) { ScanEngine.process(raw, profile) }
        if (batch !== s || s.cancelled) return@launch
        finishScan(s, raw, outcome)
    }
}

internal fun MainActivity.collectRaw(link: PlatformLink, s: BatchSession): List<RawEntry> {
    val out = ArrayList<RawEntry>()
    var failed = 0
    val granted = contentResolver.persistedUriPermissions.filter { it.isReadPermission }.map { it.uri.toString() }
    val cancelled = { s.cancelled }
    val onFound: (Int) -> Unit = { n ->
        s.found = n
        ScanNotify.progress(this, s.platform, n)
    }
    for (f in link.folders) {
        if (s.cancelled) break
        val inSaf = f in granted
        if (hasAllFiles()) {
            // Caminho rápido: lê direto pelo sistema de arquivos. Os endereços seguem o mesmo formato do cadastro manual.
            try {
                val root = File(treePath(f))
                if (root.isDirectory) {
                    ScanEngine.walkFiles(
                        root, s.profile, out,
                        uriOf = { file -> if (inSaf) safUri(f, file) else fileUri(file) },
                        cancelled = cancelled, onFound = onFound
                    )
                } else failed++
            } catch (_: Exception) {
                failed++
            }
        } else if (inSaf) {
            try {
                val tree = Uri.parse(f)
                walkTreeRaw(tree, DocumentsContract.getTreeDocumentId(tree), "", s.profile, out, 0, cancelled, onFound)
            } catch (_: Exception) {
                failed++
            }
        } else {
            failed++
        }
    }
    s.failedFolders = failed
    return out.distinctBy { it.uri }
}

/** Endereço SAF (o mesmo que a lista de ROMs gera) de um arquivo dentro de uma pasta já autorizada. */
internal fun MainActivity.safUri(tree: String, file: File): String {
    val tu = Uri.parse(tree)
    val treeId = DocumentsContract.getTreeDocumentId(tu)
    val rel = file.path.removePrefix(treePath(tree)).trim('/')
    val docId = when {
        rel.isEmpty() -> treeId
        treeId.endsWith(":") || treeId.endsWith("/") -> treeId + rel
        else -> "$treeId/$rel"
    }
    return DocumentsContract.buildDocumentUriUsingTree(tu, docId).toString()
}

internal fun MainActivity.walkTreeRaw(
    tree: Uri, docId: String, path: String, p: ScanProfile, out: MutableList<RawEntry>,
    depth: Int, cancelled: () -> Boolean, onFound: (Int) -> Unit
) {
    if (depth > 12 || out.size > 60000 || cancelled()) return
    val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
    val cols = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE
    )
    contentResolver.query(kids, cols, null, null, null)?.use { c ->
        while (c.moveToNext()) {
            if (cancelled()) return
            val id = c.getString(0) ?: continue
            val name = c.getString(1) ?: continue
            val isDir = (c.getString(2) ?: "") == DocumentsContract.Document.MIME_TYPE_DIR
            if (ScanEngine.wanted(p, name, isDir)) {
                out.add(RawEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString(), isDir))
                onFound(out.size)
            } else if (isDir && ScanEngine.shouldDescend(p, name, depth)) {
                walkTreeRaw(tree, id, "$path$name/", p, out, depth + 1, cancelled, onFound)
            }
        }
    }
}

internal fun MainActivity.finishScan(s: BatchSession, raw: List<RawEntry>, outcome: ScanOutcome) {
    val platform = s.platform
    // Jogos que já estão no catálogo (mesmo arquivo): não entram de novo.
    val existing = games.filter { it.platform == platform && it.romUri.isNotEmpty() }.map { pathOf(it.romUri) }.toSet()
    val fresh = outcome.candidates.filter { pathOf(it.uri) !in existing }
    s.alreadyCount = outcome.candidates.size - fresh.size
    s.all = fresh
    s.ignored = outcome.ignored.filter { pathOf(it.candidate.uri) !in existing }

    // Arquivos ausentes: jogos em lote cujo arquivo não foi achado ficam marcados (nunca são removidos).
    if (s.failedFolders == 0) {
        val scanned = raw.map { pathOf(it.uri) }.toSet()
        var changed = false
        for (i in games.indices) {
            val g = games[i]
            if (g.platform == platform && g.isAuto && g.romUri.isNotEmpty()) {
                val miss = pathOf(g.romUri) !in scanned
                if (miss != g.missing) {
                    games[i] = g.copy(missing = miss)
                    changed = true
                }
            }
        }
        if (changed) saveLibrary()
    }

    val text = "${fresh.size} jogo(s) encontrado(s) em $platform"
    val inBackground = !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
    ScanService.stop(this)
    if (inBackground) ScanNotify.done(this, text)

    if (fresh.isEmpty() && s.ignored.isEmpty()) {
        batch = null
        toast(
            if (s.failedFolders > 0) "Não consegui ler as pastas. Vincule-as de novo e libere o acesso."
            else if (s.alreadyCount > 0) "Nenhum jogo novo: os ${s.alreadyCount} jogo(s) encontrados já estão no catálogo."
            else "Nenhum jogo encontrado nessas pastas para ${platform}."
        )
        return
    }
    val groups = ScanEngine.dupGroups(fresh)
    s.dupGroups = groups.size
    if (groups.isNotEmpty()) {
        s.phase = BatchPhase.REGIONS
    } else {
        buildBatchItems(s, ScanEngine.regionPriority("USA"))
    }
}

internal fun MainActivity.buildBatchItems(s: BatchSession, priority: List<String>) {
    val chosen = ScanEngine.resolveRegions(s.all, priority)
    val byKey = s.all.groupBy { it.key }
    s.items.clear()
    s.items.addAll(chosen.map { BatchItem(it.key, byKey[it.key] ?: listOf(it), it) }.sortedAlpha { it.cand.title })
    s.ignoredItems.clear()
    s.ignoredItems.addAll(s.ignored.sortedAlpha { it.name }.map { BatchIgnored(it) })
    s.phase = BatchPhase.LIST
}

internal fun MainActivity.confirmBatch(s: BatchSession) {
    val platform = s.platform
    val exec = DEFAULT_EXEC[execKey(platform)] ?: "native"
    val chosen = ArrayList<ScanCandidate>()
    for (bi in s.items) if (bi.checked) chosen.add(bi.cand)
    for (ig in s.ignoredItems) if (ig.checked) chosen.add(ig.item.candidate)
    val added = chosen.distinctBy { it.uri }.map { c ->
        Game(
            id = UUID.randomUUID().toString(), title = c.title, platform = platform,
            execType = exec, romUri = c.uri, source = SOURCE_AUTO,
            romFileName = c.fileName, region = c.region
        )
    }
    batch = null
    if (added.isEmpty()) return
    games.addAll(added)
    saveLibrary()
    prefetchCovers()
    toast("${added.size} jogo(s) adicionados em $platform")
}

/** Tela de informações: troca o arquivo em que um jogo em lote se baseia. */
internal fun MainActivity.changeRomFile(g: Game) {
    val onRom: (String, String) -> Unit = { uriStr, name ->
        games.firstOrNull { it.id == g.id }?.let { cur ->
            replaceGame(cur.copy(romUri = uriStr, romFileName = name, missing = false))
            toast("Arquivo trocado: $name")
        }
    }
    val link = linkFor(g.platform)
    if (link != null && link.folders.isNotEmpty()) {
        romList = RomListRequest(g.platform, onRom)
    } else {
        dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
        pickRomFile(false)
    }
}
