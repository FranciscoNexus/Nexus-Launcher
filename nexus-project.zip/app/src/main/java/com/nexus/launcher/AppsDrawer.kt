package com.nexus.launcher

import android.view.KeyEvent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import org.json.JSONArray

/**
 * 4.9.22 – Gaveta de apps (modo launcher, só na paisagem) e a lista "Apps ocultos" dos Extras.
 * Plano: claude/nexus-plano-gaveta-de-apps.md.
 */

private const val DRAWER_RECENT_MAX = 24
private const val DRAWER_CELL_DP = 92

/** A gaveta só existe com o Nexus como launcher padrão, no celular/tablet deitado (nunca na TV/Fire OS). */
internal fun MainActivity.drawerAvailable(): Boolean = isHome && landscape && !TvMode.isTv

internal fun MainActivity.openDrawer() {
    if (!drawerAvailable() || modalOpen()) return
    navZone = 0
    appsDrawerOpen = true
}

internal fun MainActivity.loadDrawerPrefs() {
    drawerHidden.clear()
    drawerRecent.clear()
    try {
        prefs.getString("drawerHidden", null)?.let { j ->
            val a = JSONArray(j)
            for (i in 0 until a.length()) {
                val p = a.optString(i, "")
                if (p.isNotBlank() && p !in drawerHidden) drawerHidden.add(p)
            }
        }
        prefs.getString("drawerRecent", null)?.let { j ->
            val a = JSONArray(j)
            for (i in 0 until a.length()) {
                val p = a.optString(i, "")
                if (p.isNotBlank() && p !in drawerRecent) drawerRecent.add(p)
            }
        }
    } catch (_: Exception) {
    }
}

/** Só o que foi aberto pela gaveta conta. Recentes ficam só no aparelho (fora do backup). */
internal fun MainActivity.noteDrawerOpen(pkg: String) {
    drawerRecent.remove(pkg)
    drawerRecent.add(0, pkg)
    while (drawerRecent.size > DRAWER_RECENT_MAX) drawerRecent.removeAt(drawerRecent.lastIndex)
    if (!wiping) prefs.edit().putString("drawerRecent", JSONArray(drawerRecent.toList()).toString()).apply()
}

/**
 * Lista da gaveta: A–Z, com os recentes primeiro (até encher UMA linha de [cols] ícones). O app recente não se repete
 * mais abaixo. Apps ocultos não entram (nem na busca). O Nexus nunca aparece.
 */
internal fun MainActivity.drawerApps(cols: Int, query: String): List<AppItem> {
    val base = allApps.filter { it.pkg != packageName && it.pkg !in drawerHidden }
    val k = foldText(query.trim())
    if (k.isNotEmpty()) return base.filter { foldText(it.label).contains(k) || it.pkg.lowercase().contains(k) }
    val byPkg = base.associateBy { it.pkg }
    val recent = drawerRecent.mapNotNull { byPkg[it] }.take(cols)
    val used = recent.map { it.pkg }.toSet()
    return recent + base.filter { it.pkg !in used }
}

/** Apps que o usuário ocultou da gaveta (em ordem alfabética; desinstalados são ignorados). */
internal fun MainActivity.drawerHiddenApps(): List<AppItem> =
    allApps.filter { it.pkg != packageName && it.pkg in drawerHidden }

// ---------- Botão do rodapé (ícone · R3 · Apps) ----------
@Composable
internal fun MainActivity.DrawerButton(hl: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(rBtn.dp)
    val accent = parseColor(accentHex)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .height(26.dp)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.25f) else Color(0xEB161A23))
            .border(1.dp, Color(0x17FFFFFF), shape)
            .ownRing()
            .navHighlight(hl, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp)
    ) {
        // Círculo com 6 pontos (3x2), fundo transparente, na cor de destaque.
        Canvas(Modifier.size(17.dp)) {
            val sw = 1.5.dp.toPx()
            drawCircle(accent, radius = size.minDimension / 2f - sw / 2f, center = Offset(size.width / 2f, size.height / 2f), style = Stroke(sw))
            for (r in 0..1) for (c in 0..2) {
                drawCircle(
                    accent, radius = 1.25.dp.toPx(),
                    center = Offset(size.width * (0.30f + 0.20f * c), size.height * (0.40f + 0.20f * r))
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        Box(
            modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0x26FFFFFF)).padding(horizontal = 4.dp, vertical = 1.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("R3", color = Color(0xFFCBD2E0), fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.width(6.dp))
        Text(
            "Apps", color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false
        )
    }
}

/** Estado do "segurar A" da grade (a janela tem o próprio Window.Callback: a pressão longa vem pelo evento de tecla). */
private class AHold {
    var owned = false
    var pkg: String? = null
    var long = false
}

/**
 * Grade de apps usada pela gaveta e por "Apps ocultos". Toque/A = [onOpen]; tocar e segurar / segurar A = [onHold];
 * Y = informações do app em foco; R3 = [onR3]. [onExtraKey] recebe as demais teclas (ex.: X = desfazer).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MainActivity.AppsGrid(
    apps: List<AppItem>,
    cols: Int,
    modifier: Modifier = Modifier,
    onOpen: (String) -> Unit,
    onHold: (String) -> Unit,
    onR3: () -> Unit,
    onExtraKey: (KeyEvent) -> Boolean = { false }
) {
    var fp by remember { mutableStateOf<String?>(null) }
    var refocus by remember { mutableStateOf(-1) }
    val appsNow by rememberUpdatedState(apps)
    val openNow by rememberUpdatedState(onOpen)
    val holdNow by rememberUpdatedState(onHold)
    val r3Now by rememberUpdatedState(onR3)
    val extraNow by rememberUpdatedState(onExtraKey)
    val hold = remember { AHold() }

    // Segurar um app: aplica e, no controle, leva o foco para o app que ocupou o lugar.
    val doHold: (String) -> Unit = { pkg ->
        val idx = appsNow.indexOfFirst { it.pkg == pkg }
        holdNow(pkg)
        if (padNav && idx >= 0) refocus = minOf(idx, appsNow.size - 2).coerceAtLeast(0)
    }

    DisposableEffect(Unit) {
        val hook: (KeyEvent) -> Boolean = hook@{ ev ->
            val c = ev.keyCode
            val down = ev.action == KeyEvent.ACTION_DOWN
            val first = down && ev.repeatCount == 0
            when (c) {
                KeyEvent.KEYCODE_BUTTON_A -> {
                    if (down) {
                        if (first) {
                            hold.pkg = fp
                            hold.owned = hold.pkg != null
                            hold.long = false
                        }
                        if (!hold.owned) return@hook false
                        val p = hold.pkg
                        if (p != null && ev.repeatCount > 0 && !hold.long &&
                            (ev.isLongPress || ev.eventTime - ev.downTime >= OK_LONG_MS)
                        ) {
                            hold.long = true
                            doHold(p)
                        }
                        true
                    } else if (ev.action == KeyEvent.ACTION_UP) {
                        if (!hold.owned) return@hook false
                        val p = hold.pkg
                        val wasLong = hold.long
                        hold.owned = false
                        hold.pkg = null
                        hold.long = false
                        if (p != null && !wasLong) {
                            // Alguns controles não repetem a tecla: apertado o tempo do toque longo, vale como longo.
                            if (ev.eventTime - ev.downTime >= OK_LONG_MS) doHold(p) else openNow(p)
                        }
                        true
                    } else false
                }
                KeyEvent.KEYCODE_BUTTON_Y -> {
                    val p = fp
                    if (p == null) false else {
                        if (first) openAppInfo(p)
                        true
                    }
                }
                KeyEvent.KEYCODE_BUTTON_THUMBR -> {
                    if (first) r3Now()
                    true
                }
                else -> extraNow(ev)
            }
        }
        drawerKeyHook = hook
        onDispose { if (drawerKeyHook === hook) drawerKeyHook = null }
    }

    val shape = RoundedCornerShape(10.dp)
    LazyVerticalGrid(
        columns = GridCells.Fixed(cols.coerceAtLeast(1)),
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
    ) {
        itemsIndexed(apps, key = { _, a -> a.pkg }) { i, a ->
            val req = remember { FocusRequester() }
            val haptic = LocalHapticFeedback.current
            val focused = fp == a.pkg
            LaunchedEffect(refocus, i) {
                if (refocus == i) {
                    delay(60)
                    try { req.requestFocus() } catch (_: Exception) { }
                    refocus = -1
                }
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(2.dp)
                    .then(if (i == 0) Modifier.initialFocus() else Modifier)
                    .focusRequester(req)
                    .clip(shape)
                    .focusRing()
                    .onFocusChanged {
                        if (it.isFocused) fp = a.pkg else if (fp == a.pkg) fp = null
                    }
                    .combinedClickable(
                        onClick = { openNow(a.pkg) },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            doHold(a.pkg)
                        }
                    )
                    .padding(horizontal = 4.dp, vertical = 6.dp)
            ) {
                Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    val bmp = remember(a.pkg) { iconFor(a.pkg) }
                    if (bmp != null) Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(44.dp))
                    // ⓘ: no controle só no app em foco (ou Y); no toque, em todos (pequeno).
                    if (if (padNav) focused else true) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color(0x99000000))
                                .focusProperties { canFocus = false }
                                .pointerInput(a.pkg) { detectTapGestures { openAppInfo(a.pkg) } },
                            contentAlignment = Alignment.Center
                        ) { Text("ⓘ", color = Color(0xFFD5DAE5), fontSize = 11.sp, lineHeight = 11.sp) }
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    a.label, color = Color.White, fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// ---------- A gaveta ----------
@Composable
internal fun MainActivity.AppsDrawerDialog() {
    val accent = parseColor(accentHex)
    val close = { appsDrawerOpen = false }
    var shown by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var undo by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { shown = true }
    LaunchedEffect(undo) {
        if (undo != null) {
            delay(3000)
            undo = null
        }
    }
    val undoNow: () -> Unit = {
        val p = undo
        if (p != null) {
            drawerHidden.remove(p)
            savePrefs()
            undo = null
        }
    }
    val panelShape = RoundedCornerShape(topStart = rPanel.dp, topEnd = rPanel.dp)
    Dialog(
        onDismissRequest = close,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog()
        Box(modifier = Modifier.fillMaxSize().imePadding()) {
            // Fundo escurecido: tocar fora fecha.
            Box(
                Modifier.fillMaxSize().background(Color(0x66000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { close() }
            )
            AnimatedVisibility(
                visible = shown,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(animationSpec = tween(260), initialOffsetY = { it }) + fadeIn(animationSpec = tween(200))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.82f)
                        .clip(panelShape)
                        .background(C_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
                        .pointerInput(Unit) { detectTapGestures { } }
                ) {
                    // Alça: deslizar para baixo fecha.
                    Box(
                        modifier = Modifier.fillMaxWidth().height(22.dp).pointerInput(Unit) {
                            var acc = 0f
                            detectVerticalDragGestures(
                                onDragStart = { acc = 0f },
                                onVerticalDrag = { change, dy ->
                                    change.consume()
                                    acc += dy
                                },
                                onDragEnd = { if (acc > 60f) close() }
                            )
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x40FFFFFF)))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Apps", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        val btnShape = RoundedCornerShape(rBtn.dp)
                        Box(
                            modifier = Modifier.size(32.dp).clip(btnShape)
                                .background(if (searching) accent.copy(alpha = 0.30f) else Color(0x0FFFFFFF))
                                .border(1.dp, S_LINE, btnShape)
                                .clickable {
                                    searching = !searching
                                    if (!searching) q = ""
                                },
                            contentAlignment = Alignment.Center
                        ) { Text("🔍", fontSize = 14.sp) }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier.size(32.dp).clip(btnShape)
                                .background(Color(0x0FFFFFFF))
                                .border(1.dp, S_LINE, btnShape)
                                // Controle: o B (e o R3) já fecham; o destaque começa na grade.
                                .focusProperties { canFocus = !padNav }
                                .clickable { close() },
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                    }
                    Text(
                        "Segure um app para ocultar", color = C_MUTED, fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    if (searching) {
                        Spacer(Modifier.height(6.dp))
                        CField(q, { q = it }, "Buscar app", Modifier.fillMaxWidth().padding(horizontal = 12.dp), mic = false)
                    }
                    Spacer(Modifier.height(4.dp))
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                        val cols = (maxWidth / DRAWER_CELL_DP.dp).toInt().coerceIn(3, 10)
                        val list = drawerApps(cols, q)
                        if (list.isEmpty()) {
                            Text(
                                if (q.isNotBlank()) "Nenhum app encontrado." else "Nenhum app para mostrar.",
                                color = C_MUTED, fontSize = 13.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(24.dp)
                            )
                        } else {
                            AppsGrid(
                                apps = list, cols = cols, modifier = Modifier.fillMaxSize(),
                                onOpen = { pkg ->
                                    noteDrawerOpen(pkg)
                                    appsDrawerOpen = false
                                    launchApp(pkg)
                                },
                                onHold = { pkg ->
                                    if (pkg !in drawerHidden) drawerHidden.add(pkg)
                                    savePrefs()
                                    undo = pkg
                                },
                                onR3 = close,
                                onExtraKey = { ev ->
                                    // X desfaz o "App ocultado" enquanto o aviso está na tela.
                                    if (ev.keyCode == KeyEvent.KEYCODE_BUTTON_X && undo != null) {
                                        if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) undoNow()
                                        true
                                    } else false
                                }
                            )
                        }
                        val u = undo
                        if (u != null) {
                            val ubShape = RoundedCornerShape(rBtn.dp)
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 10.dp)
                                    .clip(ubShape)
                                    .background(Color(0xF2232834))
                                    .border(1.dp, accent.copy(alpha = 0.6f), ubShape)
                                    .clickable { undoNow() }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("App ocultado · Toque para desfazer ↩", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Extras > Apps ocultos ----------
@Composable
internal fun MainActivity.HiddenAppsDialog() {
    val close = { hiddenAppsOpen = false }
    NexusModal("Apps ocultos", close, tall = true) {
        Text(
            "Apps que você ocultou da gaveta. Toque para abrir; segure para devolver à gaveta.",
            color = C_MUTED, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val cols = (maxWidth / DRAWER_CELL_DP.dp).toInt().coerceIn(3, 10)
            val list = drawerHiddenApps()
            if (list.isEmpty()) {
                Text(
                    "Nenhum app oculto. Na gaveta de apps, segure um app para ocultá-lo aqui.",
                    color = C_MUTED, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(24.dp)
                )
            } else {
                AppsGrid(
                    apps = list, cols = cols, modifier = Modifier.fillMaxSize(),
                    onOpen = { pkg -> launchApp(pkg) },
                    onHold = { pkg ->
                        drawerHidden.remove(pkg)
                        savePrefs()
                    },
                    onR3 = close
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { close() }
    }
}
