package com.nexus.launcher

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import androidx.compose.foundation.clickable as rawClickable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role

/** Ações que tocam som. */
enum class SfxEvent { NAV, SELECT, BACK, LAUNCH, TAB }

/** Estilos de som. O som "desligado" é o interruptor [Sfx.enabled]. */
enum class SfxStyle(val key: String, val label: String) {
    RETRO("retro", "Retrô"),
    SOFT("soft", "Suave"),
    FUTURE("future", "Futurista");

    companion object {
        fun from(key: String?): SfxStyle = values().firstOrNull { it.key == key } ?: SOFT
    }
}

/**
 * Sons do app (4.3.0). Sons curtos gerados por síntese (res/raw), tocados com SoundPool.
 * Usa o canal de sons de interface do Android (respeita o modo silencioso) e não pausa a música.
 */
object Sfx {
    @Volatile var enabled: Boolean = true
    @Volatile var style: SfxStyle = SfxStyle.SOFT

    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()
    private val last = LongArray(SfxEvent.values().size)

    fun init(ctx: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        val app = ctx.applicationContext
        for (s in SfxStyle.values()) for (e in SfxEvent.values()) {
            ids[s.key + "_" + e.name] = p.load(app, resOf(s, e), 1)
        }
        pool = p
    }

    fun play(e: SfxEvent) {
        if (!enabled) return
        val p = pool ?: return
        val now = SystemClock.uptimeMillis()
        val gap = when (e) {
            SfxEvent.NAV -> 45L
            SfxEvent.SELECT -> 60L
            else -> 80L
        }
        if (now - last[e.ordinal] < gap) return
        // Abrir um jogo já tem som próprio: não soma o som de "selecionar" logo em seguida.
        if (e == SfxEvent.SELECT && now - last[SfxEvent.LAUNCH.ordinal] < 250L) return
        last[e.ordinal] = now
        val id = ids[style.key + "_" + e.name] ?: return
        p.play(id, 1f, 1f, 1, 0, 1f)
    }

    private fun resOf(s: SfxStyle, e: SfxEvent): Int = when (s) {
        SfxStyle.RETRO -> when (e) {
            SfxEvent.NAV -> R.raw.snd_retro_nav
            SfxEvent.SELECT -> R.raw.snd_retro_select
            SfxEvent.BACK -> R.raw.snd_retro_back
            SfxEvent.LAUNCH -> R.raw.snd_retro_launch
            SfxEvent.TAB -> R.raw.snd_retro_tab
        }
        SfxStyle.SOFT -> when (e) {
            SfxEvent.NAV -> R.raw.snd_soft_nav
            SfxEvent.SELECT -> R.raw.snd_soft_select
            SfxEvent.BACK -> R.raw.snd_soft_back
            SfxEvent.LAUNCH -> R.raw.snd_soft_launch
            SfxEvent.TAB -> R.raw.snd_soft_tab
        }
        SfxStyle.FUTURE -> when (e) {
            SfxEvent.NAV -> R.raw.snd_future_nav
            SfxEvent.SELECT -> R.raw.snd_future_select
            SfxEvent.BACK -> R.raw.snd_future_back
            SfxEvent.LAUNCH -> R.raw.snd_future_launch
            SfxEvent.TAB -> R.raw.snd_future_tab
        }
    }
}

/**
 * Substitui o `clickable` do Compose nos arquivos do app (os que não importam o original):
 * todo toque em botão/cartão toca o som de "selecionar". O som vem DEPOIS da ação, assim o
 * interruptor de sons e a troca de estilo já valem no próprio toque.
 */
fun Modifier.clickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier = rawClickable(enabled, onClickLabel, role) {
    onClick()
    Sfx.play(SfxEvent.SELECT)
}
