package com.nexus.launcher

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import androidx.compose.foundation.clickable as rawClickable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role

/**
 * Ações que tocam som. Regra: o que é "positivo" (aceitar, avançar, ligar) termina mais agudo;
 * o que é "negativo" (voltar, recusar, desligar) termina mais grave.
 */
enum class SfxEvent(val key: String) {
    NAV_UP("nav_up"), NAV_DOWN("nav_down"), NAV_LEFT("nav_left"), NAV_RIGHT("nav_right"),
    SELECT("select"), ACCEPT("accept"), BACK("back"), DENY("deny"),
    ON("on"), OFF("off"), LAUNCH("launch"), TAB_NEXT("tab_next"), TAB_PREV("tab_prev")
}

/** Estilos de som. O som "desligado" é o interruptor [Sfx.enabled]. */
enum class SfxStyle(val key: String, val label: String) {
    RETRO("retro", "Retrô"),
    SOFT("soft", "Suave"),
    FUTURE("future", "Futurista");

    companion object {
        fun from(key: String?): SfxStyle = values().firstOrNull { it.key == key } ?: SOFT
    }
}

/**
 * Sons do app. Sons curtos gerados por síntese (res/raw, script em tools/gen_sounds.py), tocados com SoundPool.
 * Usa o canal de sons de interface do Android (respeita o modo silencioso) e não pausa a música.
 */
object Sfx {
    @Volatile var enabled: Boolean = true
    @Volatile var style: SfxStyle = SfxStyle.SOFT

    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()
    private val last = LongArray(SfxEvent.values().size)
    private var lastSpecific = 0L
    private val loaded = HashSet<Int>()
    private var introPending = false
    private var introStream = 0

    fun init(ctx: Context) {
        if (pool != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { sp, sid, status ->
            if (status == 0) {
                synchronized(loaded) { loaded.add(sid) }
                // A abertura pode pedir o som antes de ele terminar de carregar: toca assim que ficar pronto.
                if (introPending && sid == ids[style.key + "_INTRO"]) {
                    introPending = false
                    introStream = sp.play(sid, 1f, 1f, 2, 0, 1f)
                }
            }
        }
        val app = ctx.applicationContext
        for (s in SfxStyle.values()) {
            val ri = app.resources.getIdentifier("snd_" + s.key + "_intro", "raw", app.packageName)
            if (ri != 0) ids[s.key + "_INTRO"] = p.load(app, ri, 1)
        }
        for (s in SfxStyle.values()) for (e in SfxEvent.values()) {
            val res = app.resources.getIdentifier("snd_" + s.key + "_" + e.key, "raw", app.packageName)
            if (res != 0) ids[s.key + "_" + e.name] = p.load(app, res, 1)
        }
        pool = p
    }

    fun play(e: SfxEvent) {
        if (!enabled) return
        val p = pool ?: return
        val now = SystemClock.uptimeMillis()
        val nav = e == SfxEvent.NAV_UP || e == SfxEvent.NAV_DOWN || e == SfxEvent.NAV_LEFT || e == SfxEvent.NAV_RIGHT
        val gap = when {
            nav -> 45L
            e == SfxEvent.SELECT -> 60L
            else -> 80L
        }
        if (now - last[e.ordinal] < gap) return
        // O toque genérico ("selecionar") não soma por cima de um som específico (aceitar, ligar, abrir jogo...).
        if (e == SfxEvent.SELECT && now - lastSpecific < 250L) return
        last[e.ordinal] = now
        if (!nav && e != SfxEvent.SELECT) lastSpecific = now
        val id = ids[style.key + "_" + e.name] ?: return
        p.play(id, 1f, 1f, 1, 0, 1f)
    }

    /** Som da animação de abertura (um por estilo), na duração exata da animação. */
    fun playIntro() {
        if (!enabled) return
        val id = ids[style.key + "_INTRO"] ?: return
        val ready = synchronized(loaded) { id in loaded }
        if (ready) introStream = pool?.play(id, 1f, 1f, 2, 0, 1f) ?: 0 else introPending = true
    }

    /** Pulou a abertura: corta o som dela. */
    fun stopIntro() {
        introPending = false
        if (introStream != 0) pool?.stop(introStream)
        introStream = 0
    }

    /** Som específico de um botão pelo texto dele (null = som genérico de toque). */
    fun forLabel(label: String): SfxEvent? {
        val l = label.trim().lowercase()
        return when {
            l.startsWith("salvar") || l.startsWith("adicionar") || l.startsWith("confirmar") ||
                l.startsWith("aplicar") || l.startsWith("criar") || l.startsWith("importar") ||
                l.startsWith("exportar") || l == "ok" || l == "sim" || l.startsWith("usar") -> SfxEvent.ACCEPT
            l.startsWith("cancelar") || l.startsWith("fechar") || l.startsWith("voltar") ||
                l.startsWith("agora não") || l.startsWith("depois") -> SfxEvent.BACK
            l.startsWith("apagar") || l.startsWith("excluir") || l.startsWith("remover") ||
                l.startsWith("resetar") || l.startsWith("limpar") || l.startsWith("nenhum") || l == "não" -> SfxEvent.DENY
            l.startsWith("todos") -> SfxEvent.ON
            else -> null
        }
    }
}

/**
 * Substitui o `clickable` do Compose nos arquivos do app (os que não importam o original):
 * todo toque em botão/cartão toca o som de "selecionar". O som vem DEPOIS da ação, assim o
 * interruptor de sons e a troca de estilo já valem no próprio toque.
 */
fun Modifier.clickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier = rawClickable(enabled, onClickLabel, role) {
    onClick()
    Sfx.play(SfxEvent.SELECT)
}
