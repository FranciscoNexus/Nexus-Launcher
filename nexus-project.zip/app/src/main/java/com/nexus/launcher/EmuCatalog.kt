package com.nexus.launcher

import android.content.Context
import org.json.JSONArray

/**
 * Catálogo de plataformas e emuladores embutido no Nexus.
 * Os dados ficam em assets/emu_platforms.json (122 plataformas, 1.023 emuladores).
 */
class EmuPlayer(
    val name: String,
    val id: String,
    val pkg: String,
    /** Comando de abertura (uma linha). */
    val args: String,
    /** Extensões de ROM aceitas pelo emulador (minúsculas). */
    val exts: List<String>,
    /** Fecha o app do emulador antes de abrir o jogo. */
    val kill: Boolean
) {
    /** Comando no formato do Nexus; "--nexus-kill" fecha o emulador antes de abrir. */
    val template: String get() = if (kill) "$args --nexus-kill" else args
}

class EmuPlatform(
    val id: String,
    val name: String,
    val manufacturer: String,
    val players: List<EmuPlayer>
)

/** Plataformas embutidas do Nexus -> id da plataforma equivalente no catálogo. */
val EMU_ID_BY_BUILTIN: Map<String, String> = mapOf(
    "PlayStation 1" to "psx",
    "PlayStation 2" to "ps2",
    "PSP" to "psp",
    "PS Vita" to "vita",
    "Super Nintendo" to "snes",
    "Nintendo 64" to "n64",
    "GameCube" to "gc",
    "Wii" to "wii",
    "Nintendo Wii U" to "wiiu",
    "Nintendo Switch" to "switch",
    "Game Boy Advance" to "gba",
    "Nintendo DS" to "nds",
    "Nintendo 3DS" to "3ds",
    "Xbox Clássico" to "xbox",
    "Xbox 360" to "xbox360",
    "PC" to "windows",
    "Sega Mega Drive" to "genesis",
    "Sega Saturn" to "saturn"
)

/** Emulador recomendado: pacote e nome de exibição. */
class EmuRec(val pkg: String, val name: String)

object EmuCatalog {
    @Volatile
    private var recCache: Map<String, List<EmuRec>>? = null

    /** Recomendados por id de plataforma do catálogo (assets/emu_recommended.json), em ordem de prioridade. */
    fun recommended(ctx: Context): Map<String, List<EmuRec>> {
        recCache?.let { return it }
        synchronized(this) {
            recCache?.let { return it }
            val out = HashMap<String, List<EmuRec>>()
            try {
                val text = ctx.applicationContext.assets.open("emu_recommended.json")
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rec = org.json.JSONObject(text).optJSONObject("rec")
                if (rec != null) {
                    for (id in rec.keys()) {
                        val a = rec.optJSONArray(id) ?: continue
                        out[id] = (0 until a.length()).mapNotNull { i ->
                            val o = a.optJSONObject(i) ?: return@mapNotNull null
                            val pk = o.optString("p")
                            if (pk.isEmpty()) null else EmuRec(pk, o.optString("n", pk))
                        }
                    }
                }
            } catch (_: Exception) {
            }
            recCache = out
            return out
        }
    }

    @Volatile
    private var cache: List<EmuPlatform>? = null

    fun all(ctx: Context): List<EmuPlatform> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val list = try {
                val text = ctx.applicationContext.assets.open("emu_platforms.json")
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                parse(text)
            } catch (_: Exception) {
                emptyList()
            }
            cache = list
            return list
        }
    }

    private fun parse(json: String): List<EmuPlatform> {
        val arr = JSONArray(json)
        val out = ArrayList<EmuPlatform>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val pa = o.optJSONArray("pl") ?: JSONArray()
            val players = ArrayList<EmuPlayer>(pa.length())
            for (k in 0 until pa.length()) {
                val p = pa.getJSONObject(k)
                players.add(
                    EmuPlayer(
                        name = p.optString("n"),
                        id = p.optString("id"),
                        pkg = p.optString("p"),
                        args = p.optString("a"),
                        exts = p.optString("x").split(",").map { it.trim() }.filter { it.isNotEmpty() },
                        kill = p.optInt("k", 0) == 1
                    )
                )
            }
            out.add(EmuPlatform(o.optString("id"), o.optString("name"), o.optString("m"), players))
        }
        return out
    }

    /** Plataforma do catálogo equivalente a uma plataforma do Nexus (chave = nome base/embutido). */
    fun forPlatform(ctx: Context, key: String): EmuPlatform? {
        val list = all(ctx)
        val id = EMU_ID_BY_BUILTIN[key]
        if (id != null) return list.firstOrNull { it.id == id }
        return list.firstOrNull { it.name.equals(key, ignoreCase = true) }
    }
}
