package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Game(
    val id: String,
    val title: String,
    val platform: String,
    /** Até [MAX_GENRES] gêneros. Vazio = sem gênero. */
    val genres: List<String> = emptyList(),
    val cover: String = "",
    val webUrl: String = "",
    val execType: String = "native",
    val isFavorite: Boolean = false,
    val favoriteTs: Long = 0L,
    val lastPlayedTs: Long = 0L,
    val romUri: String = "",
    val pkg: String = "",
    val customCmd: String = "",
    val openCount: Int = 0,
    val collections: List<String> = emptyList(),
    /** "manual" (cadastrado pelo usuário) ou "auto" (adicionado pela varredura em lote). */
    val source: String = SOURCE_MANUAL,
    /** Nome do arquivo (ou pasta) em que o jogo adicionado em lote se baseou. */
    val romFileName: String = "",
    /** O arquivo do jogo não foi encontrado na última verificação (o jogo não é removido). */
    val missing: Boolean = false,
    /** Região extraída do nome do arquivo (USA, Europe, Japan, Brazil, World...). */
    val region: String = "",
    /** Máscara de etiqueta (só jogos Android/Web): plataforma original em que o jogo aparece. Vazio = sem máscara. */
    val maskPlatform: String = "",
    /** Cor da etiqueta quando há máscara (hex #RRGGBB). */
    val maskColor: String = ""
) {
    /** Plataforma mostrada ao usuário (etiqueta, tela de plataformas e filtros). A execução usa [platform]. */
    val shownPlatform: String get() = maskPlatform.ifEmpty { platform }
    /** Primeiro gênero (usado em ordenação e nas telas que mostram um só). */
    val genre: String get() = genres.firstOrNull() ?: ""
    val isAuto: Boolean get() = source == SOURCE_AUTO
}

const val SOURCE_MANUAL = "manual"
const val SOURCE_AUTO = "auto"
const val MAX_GENRES = 3

val PLATFORMS = listOf(
    "PlayStation 2", "Super Nintendo", "Game Boy Advance", "PSP", "PS Vita",
    "Nintendo Switch", "GameCube", "Wii", "PC", "PlayStation 1", "Nintendo 64",
    "Nintendo DS", "Nintendo 3DS", "Xbox Clássico", "Xbox 360", "PlayStation 4",
    "Nintendo Wii U", "Sega Mega Drive", "Sega Saturn", "Android", "Web / Navegador"
)

val GENRES = listOf(
    "Ação", "Aventura", "RPG", "Corrida", "Luta", "Esportes",
    "Plataforma", "Tiro", "Estratégia", "Terror", "Puzzle"
)

const val WEB_PLATFORM = "Web / Navegador"
const val ANDROID_PLATFORM = "Android"

val DEFAULT_EXEC = mapOf(
    "PlayStation 2" to "aethersx2",
    "Super Nintendo" to "snes9x",
    "Game Boy Advance" to "pizzaboy",
    "PSP" to "ppsspp",
    "PS Vita" to "vita3k",
    "Nintendo Switch" to "eden",
    "GameCube" to "dolphin",
    "Wii" to "dolphin",
    "PC" to "gamehub",
    "Web / Navegador" to "browser"
)

object LibraryStore {

    /** Lê "genres" (lista, formato novo) ou "genre" (texto único, backups antigos). */
    private fun parseGenres(o: JSONObject): List<String> {
        val a = o.optJSONArray("genres")
        val raw = if (a != null) (0 until a.length()).map { a.optString(it, "") }
        else listOf(o.optString("genre", ""))
        return raw.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(MAX_GENRES)
    }

    fun parse(json: String): List<Game> {
        val arr = JSONObject(json).getJSONArray("games")
        val out = ArrayList<Game>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id", "")
            out.add(
                Game(
                    id = if (id.isEmpty()) UUID.randomUUID().toString() else id,
                    title = o.optString("title", ""),
                    platform = o.optString("platform", ""),
                    genres = parseGenres(o),
                    cover = o.optString("cover", ""),
                    webUrl = o.optString("webUrl", ""),
                    execType = o.optString("execType", "native"),
                    isFavorite = o.optBoolean("isFavorite", false),
                    favoriteTs = o.optLong("favoriteTimestamp", 0L),
                    lastPlayedTs = o.optLong("lastPlayedTimestamp", 0L),
                    romUri = o.optString("romUri", ""),
                    pkg = o.optString("pkg", ""),
                    customCmd = o.optString("customCmd", ""),
                    openCount = o.optInt("openCount", 0),
                    collections = o.optJSONArray("collections")?.let { a ->
                        (0 until a.length()).map { a.optString(it, "") }.filter { it.isNotBlank() }
                    } ?: emptyList(),
                    source = if (o.optString("source", "") == SOURCE_AUTO) SOURCE_AUTO else SOURCE_MANUAL,
                    romFileName = o.optString("romFileName", ""),
                    missing = o.optBoolean("missing", false),
                    region = o.optString("region", ""),
                    maskPlatform = o.optString("maskPlatform", ""),
                    maskColor = o.optString("maskColor", "")
                )
            )
        }
        return out
    }

    fun toJson(games: List<Game>): String {
        val arr = JSONArray()
        for (g in games) {
            val o = JSONObject()
            o.put("id", g.id)
            o.put("title", g.title)
            o.put("platform", g.platform)
            o.put("genres", JSONArray(g.genres))
            o.put("genre", g.genre) // compatível com versões antigas do Nexus
            o.put("cover", g.cover)
            o.put("webUrl", g.webUrl)
            o.put("execType", g.execType)
            o.put("isFavorite", g.isFavorite)
            if (g.favoriteTs > 0) o.put("favoriteTimestamp", g.favoriteTs)
            if (g.lastPlayedTs > 0) o.put("lastPlayedTimestamp", g.lastPlayedTs)
            o.put("romUri", g.romUri)
            o.put("pkg", g.pkg)
            o.put("customCmd", g.customCmd)
            if (g.openCount > 0) o.put("openCount", g.openCount)
            if (g.collections.isNotEmpty()) o.put("collections", JSONArray(g.collections))
            if (g.source == SOURCE_AUTO) o.put("source", SOURCE_AUTO)
            if (g.romFileName.isNotEmpty()) o.put("romFileName", g.romFileName)
            if (g.missing) o.put("missing", true)
            if (g.region.isNotEmpty()) o.put("region", g.region)
            if (g.maskPlatform.isNotEmpty()) o.put("maskPlatform", g.maskPlatform)
            if (g.maskColor.isNotEmpty()) o.put("maskColor", g.maskColor)
            arr.put(o)
        }
        return JSONObject().put("games", arr).toString(2)
    }
}

data class PlatformLink(
    val platform: String,
    val pkg: String = "",
    val template: String = "",
    val folders: List<String> = emptyList(),
    /** Nome do emulador escolhido no catálogo (vazio = app escolhido manualmente). */
    val playerName: String = "",
    /** Extensões de ROM do emulador escolhido (vazio = usa a tabela embutida da plataforma). */
    val exts: List<String> = emptyList()
)

object LinkStore {
    fun parse(json: String): List<PlatformLink> {
        val arr = JSONArray(json)
        val out = ArrayList<PlatformLink>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val fa = o.optJSONArray("folders")
            val folders = ArrayList<String>()
            if (fa != null) for (k in 0 until fa.length()) folders.add(fa.getString(k))
            val ea = o.optJSONArray("exts")
            val exts = ArrayList<String>()
            if (ea != null) for (k in 0 until ea.length()) exts.add(ea.getString(k))
            out.add(
                PlatformLink(
                    o.optString("platform", ""), o.optString("pkg", ""),
                    o.optString("template", ""), folders,
                    o.optString("playerName", ""), exts
                )
            )
        }
        return out
    }

    fun toJsonArray(list: List<PlatformLink>): JSONArray {
        val arr = JSONArray()
        for (l in list) {
            val o = JSONObject()
            o.put("platform", l.platform)
            o.put("pkg", l.pkg)
            o.put("template", l.template)
            o.put("folders", JSONArray(l.folders))
            if (l.playerName.isNotEmpty()) o.put("playerName", l.playerName)
            if (l.exts.isNotEmpty()) o.put("exts", JSONArray(l.exts))
            arr.put(o)
        }
        return arr
    }

    fun toJson(list: List<PlatformLink>): String = toJsonArray(list).toString()
}

// Comandos de abertura por emulador (formato padrão). Chave = pacote do app.
val TEMPLATES = mapOf(
    "org.ppsspp.ppsspp" to "-n org.ppsspp.ppsspp/.PpssppActivity -a android.intent.action.VIEW -c android.intent.category.DEFAULT -d {file.uri} -t application/octet-stream --activity-clear-task --activity-clear-top --activity-no-history",
    "org.ppsspp.ppssppgold" to "-n org.ppsspp.ppssppgold/org.ppsspp.ppsspp.PpssppActivity -a android.intent.action.VIEW -c android.intent.category.DEFAULT -d {file.uri} -t application/octet-stream --activity-clear-task --activity-clear-top --activity-no-history",
    "xyz.aethersx2.android" to "-n xyz.aethersx2.android/.EmulationActivity -a android.intent.action.MAIN -e bootPath {file.uri} --activity-clear-task --activity-clear-top --nexus-kill",
    "org.dolphinemu.dolphinemu" to "-n org.dolphinemu.dolphinemu/.ui.main.MainActivity -a android.intent.action.MAIN -e AutoStartFile {file.uri}",
    "dev.legacy.eden_emulator" to "-n dev.legacy.eden_emulator/org.yuzu.yuzu_emu.activities.EmulationActivity -a android.nfc.action.TECH_DISCOVERED -d {file.uri}",
    "dev.eden.nx2" to "-n dev.eden.nx2/org.yuzu.yuzu_emu.activities.EmulationActivity -a android.nfc.action.TECH_DISCOVERED -d {file.uri}",
    "it.dbtecno.pizzaboygbapro" to "-n it.dbtecno.pizzaboygbapro/it.dbtecno.pizzaboygbapro.MainActivity -e rom_uri {file.uri} --activity-clear-task --activity-clear-top",
    "com.explusalpha.Snes9xPlus" to "-n com.explusalpha.Snes9xPlus/com.imagine.BaseActivity -a android.intent.action.VIEW -d {file.uri} -t application/zip",
    "org.vita3kplus.emulator" to "-n org.vita3kplus.emulator/org.vita3k.emulator.Emulator --esa AppStartParameters -r,{tags.vita_game_id}",
    "emu.x360.mobile" to "-n emu.x360.mobile/.X360MobileGameLaunchActivity -a android.intent.action.VIEW -d {file.uri}"
)

// Extensões de ROM listadas por plataforma (plataforma sem entrada = lista todos os arquivos).
val ROM_EXT: Map<String, Set<String>> = mapOf(
    "PlayStation 2" to setOf("iso", "chd", "gz", "mdf", "bin", "cso"),
    "PSP" to setOf("cso", "chd", "elf", "iso", "pbp", "prx"),
    "PS Vita" to setOf("zip", "vpk", "dpt"),
    "Nintendo Switch" to setOf("nro", "nso", "nca", "xci", "nsp"),
    "GameCube" to setOf("ciso", "dff", "dol", "elf", "gcm", "gcz", "iso", "json", "m3u", "rvz", "tgc", "wad", "wbfs", "wia"),
    "Wii" to setOf("ciso", "dff", "dol", "elf", "gcm", "gcz", "iso", "json", "m3u", "rvz", "tgc", "wad", "wbfs", "wia"),
    "Game Boy Advance" to setOf("bin", "gba", "zip", "7z"),
    "Super Nintendo" to setOf("bml", "bs", "bsx", "dx2", "fig", "gb", "gbc", "sfc", "smc", "swc", "zip", "7z"),
    "Xbox 360" to setOf("iso", "xex")
)

/** Coleções que já vêm no Nexus (4.3.0): ficam sempre na lista e não podem ser renomeadas nem apagadas. */
val FIXED_COLLECTIONS = listOf("Já zerei", "Jogando agora", "Quero jogar", "Clássicos", "Abandonados")

fun isFixedCollection(name: String): Boolean = name in FIXED_COLLECTIONS
