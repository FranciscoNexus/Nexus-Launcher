package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Game(
    val id: String,
    val title: String,
    val platform: String,
    val genre: String,
    val cover: String = "",
    val webUrl: String = "",
    val execType: String = "native",
    val isFavorite: Boolean = false,
    val favoriteTs: Long = 0L,
    val lastPlayedTs: Long = 0L,
    val romUri: String = "",
    val pkg: String = "",
    val customCmd: String = ""
)

val PLATFORMS = listOf(
    "PlayStation 2", "Super Nintendo", "Game Boy Advance", "PSP", "PS Vita",
    "Nintendo Switch", "GameCube", "Wii", "PC", "PlayStation 1", "Nintendo 64",
    "Nintendo DS", "Nintendo 3DS", "Xbox Clássico", "Xbox 360", "PlayStation 4",
    "Nintendo Wii U", "Sega Mega Drive", "Sega Saturn", "Android", "Web / Navegador"
)

val GENRES = listOf(
    "Ação", "Aventura", "RPG", "Corrida", "Luta", "Esportes",
    "Plataforma", "Tiro", "Estratégia", "Terror", "Puzzle"
)

const val WEB_PLATFORM = "Web / Navegador"
const val ANDROID_PLATFORM = "Android"

val DEFAULT_EXEC = mapOf(
    "PlayStation 2" to "aethersx2",
    "Super Nintendo" to "snes9x",
    "Game Boy Advance" to "pizzaboy",
    "PSP" to "ppsspp",
    "PS Vita" to "vita3k",
    "Nintendo Switch" to "eden",
    "GameCube" to "dolphin",
    "Wii" to "dolphin",
    "PC" to "gamehub",
    "Web / Navegador" to "browser"
)

object LibraryStore {

    fun parse(json: String): List<Game> {
        val arr = JSONObject(json).getJSONArray("games")
        val out = ArrayList<Game>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id", "")
            out.add(
                Game(
                    id = if (id.isEmpty()) UUID.randomUUID().toString() else id,
                    title = o.optString("title", ""),
                    platform = o.optString("platform", ""),
                    genre = o.optString("genre", ""),
                    cover = o.optString("cover", ""),
                    webUrl = o.optString("webUrl", ""),
                    execType = o.optString("execType", "native"),
                    isFavorite = o.optBoolean("isFavorite", false),
                    favoriteTs = o.optLong("favoriteTimestamp", 0L),
                    lastPlayedTs = o.optLong("lastPlayedTimestamp", 0L),
                    romUri = o.optString("romUri", ""),
                    pkg = o.optString("pkg", ""),
                    customCmd = o.optString("customCmd", "")
                )
            )
        }
        return out
    }

    fun toJson(games: List<Game>): String {
        val arr = JSONArray()
        for (g in games) {
            val o = JSONObject()
            o.put("id", g.id)
            o.put("title", g.title)
            o.put("platform", g.platform)
            o.put("genre", g.genre)
            o.put("cover", g.cover)
            o.put("webUrl", g.webUrl)
            o.put("execType", g.execType)
            o.put("isFavorite", g.isFavorite)
            if (g.favoriteTs > 0) o.put("favoriteTimestamp", g.favoriteTs)
            if (g.lastPlayedTs > 0) o.put("lastPlayedTimestamp", g.lastPlayedTs)
            o.put("romUri", g.romUri)
            o.put("pkg", g.pkg)
            o.put("customCmd", g.customCmd)
            arr.put(o)
        }
        return JSONObject().put("games", arr).toString(2)
    }
}

data class PlatformLink(
    val platform: String,
    val pkg: String = "",
    val template: String = "",
    val folders: List<String> = emptyList()
)

object LinkStore {
    fun parse(json: String): List<PlatformLink> {
        val arr = JSONArray(json)
        val out = ArrayList<PlatformLink>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val fa = o.optJSONArray("folders")
            val folders = ArrayList<String>()
            if (fa != null) for (k in 0 until fa.length()) folders.add(fa.getString(k))
            out.add(
                PlatformLink(
                    o.optString("platform", ""), o.optString("pkg", ""),
                    o.optString("template", ""), folders
                )
            )
        }
        return out
    }

    fun toJsonArray(list: List<PlatformLink>): JSONArray {
        val arr = JSONArray()
        for (l in list) {
            val o = JSONObject()
            o.put("platform", l.platform)
            o.put("pkg", l.pkg)
            o.put("template", l.template)
            o.put("folders", JSONArray(l.folders))
            arr.put(o)
        }
        return arr
    }

    fun toJson(list: List<PlatformLink>): String = toJsonArray(list).toString()
}

// Comandos de abertura por emulador (mesmo formato do Daijishō). Chave = pacote do app.
val TEMPLATES = mapOf(
    "org.ppsspp.ppsspp" to "-n org.ppsspp.ppsspp/.PpssppActivity -a android.intent.action.VIEW -c android.intent.category.DEFAULT -d {file.uri} -t application/octet-stream --activity-clear-task --activity-clear-top --activity-no-history",
    "org.ppsspp.ppssppgold" to "-n org.ppsspp.ppssppgold/org.ppsspp.ppsspp.PpssppActivity -a android.intent.action.VIEW -c android.intent.category.DEFAULT -d {file.uri} -t application/octet-stream --activity-clear-task --activity-clear-top --activity-no-history",
    "xyz.aethersx2.android" to "-n xyz.aethersx2.android/.EmulationActivity -a android.intent.action.MAIN -e bootPath {file.uri} --activity-clear-task --activity-clear-top --nexus-kill",
    "org.dolphinemu.dolphinemu" to "-n org.dolphinemu.dolphinemu/.ui.main.MainActivity -a android.intent.action.MAIN -e AutoStartFile {file.uri}",
    "dev.legacy.eden_emulator" to "-n dev.legacy.eden_emulator/org.yuzu.yuzu_emu.activities.EmulationActivity -a android.nfc.action.TECH_DISCOVERED -d {file.uri}",
    "it.dbtecno.pizzaboygbapro" to "-n it.dbtecno.pizzaboygbapro/it.dbtecno.pizzaboygbapro.MainActivity -e rom_uri {file.uri} --activity-clear-task --activity-clear-top",
    "com.explusalpha.Snes9xPlus" to "-n com.explusalpha.Snes9xPlus/com.imagine.BaseActivity -a android.intent.action.VIEW -d {file.uri} -t application/zip",
    "org.vita3kplus.emulator" to "-n org.vita3kplus.emulator/org.vita3k.emulator.Emulator --esa AppStartParameters -r,{tags.vita_game_id}",
    "emu.x360.mobile" to "-n emu.x360.mobile/.X360MobileGameLaunchActivity -a android.intent.action.VIEW -d {file.uri}"
)

// Extensões de ROM listadas por plataforma (plataforma sem entrada = lista todos os arquivos).
val ROM_EXT: Map<String, Set<String>> = mapOf(
    "PlayStation 2" to setOf("iso", "chd", "gz", "mdf", "bin", "cso"),
    "PSP" to setOf("cso", "chd", "elf", "iso", "pbp", "prx"),
    "PS Vita" to setOf("zip", "vpk", "dpt"),
    "Nintendo Switch" to setOf("nro", "nso", "nca", "xci", "nsp"),
    "GameCube" to setOf("ciso", "dff", "dol", "elf", "gcm", "gcz", "iso", "json", "m3u", "rvz", "tgc", "wad", "wbfs", "wia"),
    "Wii" to setOf("ciso", "dff", "dol", "elf", "gcm", "gcz", "iso", "json", "m3u", "rvz", "tgc", "wad", "wbfs", "wia"),
    "Game Boy Advance" to setOf("bin", "gba", "zip", "7z"),
    "Super Nintendo" to setOf("bml", "bs", "bsx", "dx2", "fig", "gb", "gbc", "sfc", "smc", "swc", "zip", "7z"),
    "Xbox 360" to setOf("iso", "xex")
)
