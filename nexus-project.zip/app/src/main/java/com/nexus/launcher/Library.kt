package com.nexus.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Game(
    val id: String,
    val title: String,
    val platform: String,
    val genre: String,
    val cover: String = "",
    val webUrl: String = "",
    val execType: String = "native",
    val isFavorite: Boolean = false,
    val favoriteTs: Long = 0L,
    val lastPlayedTs: Long = 0L,
    val romUri: String = "",
    val pkg: String = ""
)

val PLATFORMS = listOf(
    "PlayStation 2", "Super Nintendo", "Game Boy Advance", "PSP", "PS Vita",
    "Nintendo Switch", "GameCube", "Wii", "PC", "PlayStation 1", "Nintendo 64",
    "Nintendo DS", "Nintendo 3DS", "Xbox Clássico", "Xbox 360", "PlayStation 4",
    "Nintendo Wii U", "Sega Mega Drive", "Sega Saturn", "Web / Navegador"
)

val GENRES = listOf(
    "Ação", "Aventura", "RPG", "Corrida", "Luta", "Esportes",
    "Plataforma", "Tiro", "Estratégia", "Terror", "Puzzle"
)

const val WEB_PLATFORM = "Web / Navegador"

val DEFAULT_EXEC = mapOf(
    "PlayStation 2" to "aethersx2",
    "Super Nintendo" to "snes9x",
    "Game Boy Advance" to "pizzaboy",
    "PSP" to "ppsspp",
    "PS Vita" to "vita3k",
    "Nintendo Switch" to "eden",
    "GameCube" to "dolphin",
    "Wii" to "dolphin",
    "PC" to "gamehub",
    "Web / Navegador" to "browser"
)

object LibraryStore {

    fun parse(json: String): List<Game> {
        val arr = JSONObject(json).getJSONArray("games")
        val out = ArrayList<Game>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.optString("id", "")
            out.add(
                Game(
                    id = if (id.isEmpty()) UUID.randomUUID().toString() else id,
                    title = o.optString("title", ""),
                    platform = o.optString("platform", ""),
                    genre = o.optString("genre", ""),
                    cover = o.optString("cover", ""),
                    webUrl = o.optString("webUrl", ""),
                    execType = o.optString("execType", "native"),
                    isFavorite = o.optBoolean("isFavorite", false),
                    favoriteTs = o.optLong("favoriteTimestamp", 0L),
                    lastPlayedTs = o.optLong("lastPlayedTimestamp", 0L),
                    romUri = o.optString("romUri", ""),
                    pkg = o.optString("pkg", "")
                )
            )
        }
        return out
    }

    fun toJson(games: List<Game>): String {
        val arr = JSONArray()
        for (g in games) {
            val o = JSONObject()
            o.put("id", g.id)
            o.put("title", g.title)
            o.put("platform", g.platform)
            o.put("genre", g.genre)
            o.put("cover", g.cover)
            o.put("webUrl", g.webUrl)
            o.put("execType", g.execType)
            o.put("isFavorite", g.isFavorite)
            if (g.favoriteTs > 0) o.put("favoriteTimestamp", g.favoriteTs)
            if (g.lastPlayedTs > 0) o.put("lastPlayedTimestamp", g.lastPlayedTs)
            o.put("romUri", g.romUri)
            o.put("pkg", g.pkg)
            arr.put(o)
        }
        return JSONObject().put("games", arr).toString(2)
    }
}
