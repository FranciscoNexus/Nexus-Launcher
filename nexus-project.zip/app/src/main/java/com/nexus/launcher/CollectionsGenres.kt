package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.CollectionsDialog() {
    var newName by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    NexusModal("Coleções", { back() }, tall = true) {
        val addUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(newName, { newName = it }, "Nova coleção (franquia ou grupo)", Modifier.weight(1f))
            CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                addCollection(newName)
                newName = ""
            }
        }
        Spacer(Modifier.height(8.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            if (collections.isEmpty()) {
                item {
                    Text("Nenhuma coleção ainda.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                }
            }
            items(orderedCollections(), key = { it }) { c ->
                Row(
                    modifier = Modifier.fillMaxWidth().cardRow(null),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (editing == c) {
                        CField(editText, { editText = it }, "Nome da coleção", Modifier.weight(1f))
                        CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                            renameCollection(c, editText)
                            editing = null
                        }
                        CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                    } else {
                        val used = games.count { c in it.collections }
                        Text(
                            "$c  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        if (isFixedCollection(c)) {
                            Box(Modifier.width(102.dp).height(40.dp), contentAlignment = Alignment.Center) {
                                Text("🔒 Fixa", color = C_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                            }
                        } else {
                            CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                editing = c
                                editText = c
                            }
                            CButton("🗑", C_RED, Modifier.width(48.dp)) { overlay = Overlay.ConfirmDeleteCollection(c) }
                        }
                    }
                }
            }
        }
        }
        if (landscape) {
            Panes(0.4f, {
                addUi()
                Spacer(Modifier.height(10.dp))
                Text(
                    "As coleções com 🔒 já vêm no Nexus e não podem ser renomeadas nem apagadas. Um jogo pode estar em várias coleções: escolha ao editar o jogo.",
                    color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
            }, { listUi() })
        } else {
            addUi()
            Spacer(Modifier.height(8.dp))
            listUi()
        Spacer(Modifier.height(8.dp))
        Text(
            "As coleções com 🔒 já vêm no Nexus e não podem ser renomeadas nem apagadas. Um jogo pode estar em várias coleções: escolha ao editar o jogo.",
            color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }
}

@Composable
internal fun MainActivity.ConfirmDeleteCollectionDialog(name: String) {
    NexusModal("Apagar coleção?", { overlay = Overlay.Collections }) {
        Text(
            "Apagar a coleção \"$name\"? Os jogos continuam na biblioteca, só saem dessa coleção.",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Cancelar", C_GRAY, Modifier.weight(1f).returnFocus("col").initialFocus()) { returnKey = "col"; overlay = Overlay.Collections }
            CButton("Apagar", C_RED, Modifier.weight(1f)) {
                deleteCollection(name)
                overlay = Overlay.Collections
            }
        }
    }
}

@Composable
internal fun MainActivity.CollectionPickerDialog() {
    var newName by remember { mutableStateOf("") }
    NexusModal("Coleções do jogo", { collPickerOpen = false }, tall = true) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(newName, { newName = it }, "Nova coleção (ex.: Zelda)", Modifier.weight(1f))
            CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                val n = newName.trim()
                if (n.isNotEmpty()) {
                    if (collections.none { it.equals(n, ignoreCase = true) }) {
                        collections.add(n)
                        savePrefs()
                    }
                    val canon = collections.first { it.equals(n, ignoreCase = true) }
                    if (canon !in collPickerSel) collPickerSel.add(canon)
                }
                newName = ""
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            if (collections.isEmpty()) {
                item {
                    Text("Nenhuma coleção ainda. Crie uma acima.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                }
            }
            items(orderedCollections(), key = { it }) { c ->
                val on = c in collPickerSel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .cardRow { if (on) collPickerSel.remove(c) else collPickerSel.add(c) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (on) "☑" else "☐", color = if (on) C_BLUE else C_MUTED, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(c, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) {
            collPickerCb?.invoke(collections.filter { it in collPickerSel })
            collPickerOpen = false
        }
        Spacer(Modifier.height(6.dp))
        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { collPickerOpen = false }
    }
}

@Composable
internal fun MainActivity.GenresDialog() {
    var newGenre by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    NexusModal("Gêneros", { back() }, tall = true) {
        val addUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(newGenre, { newGenre = it }, "Novo gênero", Modifier.weight(1f))
            CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                val g = newGenre.trim()
                if (g.isNotEmpty() && g !in genres) {
                    genres.add(g)
                    savePrefs()
                }
                newGenre = ""
            }
        }
        Spacer(Modifier.height(8.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(genres.sortedAlpha { it }, key = { it }) { g ->
                Row(
                    modifier = Modifier.fillMaxWidth().cardRow(null),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (editing == g) {
                        CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                        CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                            renameGenre(g, editText)
                            editing = null
                        }
                        CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                    } else {
                        val used = games.count { g in it.genres }
                        Text(
                            "$g  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                            editing = g
                            editText = g
                        }
                        CButton("🗑", C_RED, Modifier.width(48.dp)) { deleteGenre(g) }
                    }
                }
            }
        }
        }
        if (landscape) {
            Panes(0.4f, {
                addUi()
                Spacer(Modifier.height(10.dp))
                Text(
                    "Ao apagar, os jogos desse gênero ficam sem gênero.",
                    color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
            }, { listUi() })
        } else {
            addUi()
            Spacer(Modifier.height(8.dp))
            listUi()
        Spacer(Modifier.height(8.dp))
        Text(
            "Ao apagar, os jogos desse gênero ficam sem gênero.",
            color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }
}

@Composable
internal fun MainActivity.GenrePickerDialog() {
    var newName by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    var delAsk by remember { mutableStateOf<String?>(null) }
    NexusModal("Gêneros do jogo", { genrePickerOpen = false }, tall = true) {
        val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(newName, { newName = it }, "Novo gênero (ex.: RPG)", Modifier.weight(1f))
            CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                val n = newName.trim()
                if (n.isNotEmpty()) {
                    if (genres.none { it.equals(n, ignoreCase = true) }) {
                        genres.add(n)
                        savePrefs()
                    }
                    val canon = genres.first { it.equals(n, ignoreCase = true) }
                    if (canon !in genrePickerSel) {
                        if (genrePickerSel.size >= MAX_GENRES) toast("No máximo $MAX_GENRES gêneros por jogo")
                        else genrePickerSel.add(canon)
                    }
                }
                newName = ""
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Marque até $MAX_GENRES. Sem nada marcado, o jogo fica em \"$NO_GENRE\".",
            color = C_MUTED, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            if (genres.isEmpty()) {
                item {
                    Text("Nenhum gênero ainda. Crie um acima.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                }
            }
            items(genres.sortedAlpha { it }, key = { it }) { g ->
                val on = g in genrePickerSel
                Row(
                    modifier = Modifier.fillMaxWidth().cardRow(
                        if (editing == g || delAsk == g) null else ({
                            if (on) genrePickerSel.remove(g)
                            else if (genrePickerSel.size >= MAX_GENRES) toast("No máximo $MAX_GENRES gêneros por jogo")
                            else genrePickerSel.add(g)
                        })
                    ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (editing == g) {
                        CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                        CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                            val nn = editText.trim()
                            if (nn.isNotEmpty() && (nn == g || genres.none { it.equals(nn, ignoreCase = true) })) {
                                renameGenre(g, nn)
                                val i = genrePickerSel.indexOf(g)
                                if (i >= 0) genrePickerSel[i] = nn
                                editing = null
                            } else toast("Esse nome já existe")
                        }
                        CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                    } else if (delAsk == g) {
                        Text(
                            "Apagar \"$g\"? Os jogos ficam sem esse gênero.", color = Color(0xFFFFB4BF),
                            fontSize = 12.sp, modifier = Modifier.weight(1f)
                        )
                        CButton("Apagar", C_RED, Modifier.width(78.dp)) {
                            deleteGenre(g)
                            genrePickerSel.remove(g)
                            delAsk = null
                        }
                        CButton("✖", C_GRAY, Modifier.width(48.dp)) { delAsk = null }
                    } else {
                        Text(if (on) "☑" else "☐", color = if (on) C_BLUE else C_MUTED, fontSize = 20.sp)
                        Text(
                            g, color = Color.White, fontSize = 14.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { editing = g; editText = g }
                        MiniIcon("🗑", Color(0xFFFF6B81), Color(0x26E11D48)) { delAsk = g }
                    }
                }
            }
        }
        }
        val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Spacer(Modifier.height(8.dp))
        CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) {
            genrePickerCb?.invoke(genres.filter { it in genrePickerSel })
            genrePickerOpen = false
        }
        Spacer(Modifier.height(6.dp))
        CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { genrePickerOpen = false }
        }
        if (landscape) {
            Panes(0.4f, {
                topUi()
                Spacer(Modifier.height(10.dp))
                botUi()
            }, { listUi() })
        } else {
            topUi()
            listUi()
            botUi()
        }
    }
}
