package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Seletores de arquivo/pasta (4.6.0): na TV usam o explorador embutido ----------
internal fun MainActivity.openExplorerFile(forPlay: Boolean) {
    explorer = ExplorerState(false, "Escolher o arquivo do jogo", null, null) { f ->
        val uri = Uri.parse(fileUri(f))
        if (forPlay) {
            val g = pendingPlay
            pendingPlay = null
            if (g != null) {
                val updated = g.copy(romUri = uri.toString())
                replaceGame(updated)
                launchGame(updated)
            }
        } else {
            dialogRomCb?.invoke(uri)
        }
    }
}

internal fun MainActivity.pickRomFile(forPlay: Boolean) {
    if (TvMode.isTv) {
        openExplorerFile(forPlay)
        return
    }
    try {
        if (forPlay) pickRomForPlay.launch(arrayOf("*/*")) else pickRomForDialog.launch(arrayOf("*/*"))
    } catch (_: Exception) {
        openExplorerFile(forPlay)
    }
}

internal fun MainActivity.openExplorerFolder() {
    explorer = ExplorerState(true, "Escolher a pasta", null, null) { f ->
        treeCb?.invoke(ExplorerFs.treeUriFor(f.path))
    }
}

internal fun MainActivity.pickFolder() {
    if (TvMode.isTv) {
        openExplorerFolder()
        return
    }
    try {
        treePicker.launch(null)
    } catch (_: Exception) {
        openExplorerFolder()
    }
}

internal fun MainActivity.applyFullscreen() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    val c = WindowInsetsControllerCompat(window, window.decorView)
    c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    c.hide(WindowInsetsCompat.Type.systemBars())
}

/** O giro automático do Android está ligado? (false = o usuário bloqueou a rotação) */
internal fun MainActivity.autoRotateOn(): Boolean = try {
    android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.ACCELEROMETER_ROTATION, 0) == 1
} catch (e: Exception) { true }

/**
 * O botão gira a tela na hora, mesmo com o giro automático bloqueado. Com o giro automático LIGADO, quando
 * o aparelho for girado de verdade para a mesma posição o Android volta a mandar. Com o giro BLOQUEADO, o
 * Nexus fica na orientação escolhida até o botão ser tocado de novo.
 */
internal fun MainActivity.toggleOrientation() {
    val target = !landscape
    forcedLandscape = target
    landscape = target
    requestedOrientation =
        if (target) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
}

internal fun MainActivity.startOrientationWatch() {
    if (orientListener == null) {
        orientListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(deg: Int) {
                val forced = forcedLandscape ?: return
                if (deg == OrientationEventListener.ORIENTATION_UNKNOWN) return
                if (!autoRotateOn()) return
                val physLand = deg in 60..120 || deg in 240..300
                val physPort = deg <= 30 || deg >= 330 || deg in 150..210
                if ((forced && physLand) || (!forced && physPort)) {
                    forcedLandscape = null
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                }
            }
        }
    }
    orientListener?.let { if (it.canDetectOrientation()) it.enable() }
}

// ---------- Tema ao vivo (3.9.5) ----------
// 0 = Reto, 1 = Padrão, 2 = Suave. Tudo (painéis, cards, botões, campos) lê estes valores.
internal fun MainActivity.styleOf(r: Int): Int = when {
    r <= 6 -> 0
    r <= 17 -> 1
    else -> 2
}

internal fun MainActivity.canonicalRadius(r: Int): Int = intArrayOf(4, 14, 22)[styleOf(r)]

internal fun MainActivity.normalizeAccent(hex: String): String {
    if (hex.equals("#FF375F", true)) return ACCENTS[8].second // rosa antigo (parecido com o vermelho)
    ACCENTS.firstOrNull { it.second.equals(hex, true) }?.let { return it.second }
    val i = OLD_COLORS.indexOfFirst { it.equals(hex, true) }
    return if (i >= 0) ACCENTS[i].second else hex
}

internal fun MainActivity.onAccent(c: Color): Color = if (c.luminance() > 0.55f) Color(0xFF07090D) else Color.White

internal fun MainActivity.parseColor(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (_: Exception) {
    Color(0xFF0A84FF)
}

internal fun MainActivity.applyCarouselOn(v: Boolean) {
    carouselOn = v
    prefs.edit().putBoolean("carouselOn", v).apply()
    // "Padrão" e "Carrossel" são os dois estados desta opção; Grade e Lista não mudam.
    if (tvView <= TV_VIEW_CAROUSEL) {
        tvView = if (v) TV_VIEW_CAROUSEL else TV_VIEW_STD
        prefs.edit().putInt("tvView", tvView).apply()
    }
}

/** Escolhe o modo de visualização da TV (olho do cabeçalho). */
internal fun MainActivity.applyTvView(v: Int) {
    tvView = v.coerceIn(0, 3)
    prefs.edit().putInt("tvView", tvView).apply()
    if (tvView == TV_VIEW_STD) applyCarouselOn(false)
    else if (tvView == TV_VIEW_CAROUSEL) applyCarouselOn(true)
}

internal fun MainActivity.applyFloatSmall(v: Boolean) {
    floatSmall = v
    prefs.edit().putBoolean("floatSmall", v).apply()
    FloatingPanelService.instance?.applySize()
}

/** 4.9.12: capas animadas só no celular/tablet (nunca na TV) e só no Android 9+ (WebP animado). */
internal val MainActivity.animCoversSupported: Boolean
    get() = android.os.Build.VERSION.SDK_INT >= 28 && !TvMode.isTv

/** A capa em foco / dos Detalhes pode tocar a animação agora? */
internal fun MainActivity.coverAnimates(g: Game): Boolean = g.coverAnim && animCovers && animCoversSupported

internal fun MainActivity.applyAnimCovers(v: Boolean) {
    animCovers = v
    prefs.edit().putBoolean("animCovers", v).apply()
}

internal fun MainActivity.applyIntroOn(v: Boolean) {
    introOn = v
    prefs.edit().putBoolean("introOn", v).apply()
}

internal fun MainActivity.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

internal fun MainActivity.clipboardText(): String {
    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip ?: return ""
    if (clip.itemCount == 0) return ""
    return clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
}

internal fun MainActivity.aboutDeviceLines(): List<Pair<String, String>> {
    val dm = resources.displayMetrics
    val mi = ActivityManager.MemoryInfo()
    (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    val ramGb = mi.totalMem / (1024.0 * 1024.0 * 1024.0)
    val webView = try {
        android.webkit.WebView.getCurrentWebViewPackage()?.let { "${it.packageName} ${it.versionName}" } ?: "indisponível"
    } catch (_: Throwable) { "indisponível" }
    val kind = when {
        TvMode.isFireTv -> "Fire TV"
        TvMode.isRealTv -> "TV (Google TV / Android TV)"
        TvMode.isTv -> "TV (modo TV)"
        else -> "Celular / tablet"
    }
    val pads = padNames()
    return listOf(
        "Nexus" to "v$APP_VERSION",
        "Aparelho" to "${Build.MANUFACTURER} ${Build.MODEL}",
        "Tipo" to kind,
        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "Escala da interface" to if (TvMode.isTv) "ampliada ×${TvMode.UI_SCALE} (modo TV)" else "normal ×1,0",
        "Tela" to "${dm.widthPixels}x${dm.heightPixels} px · ${"%.0f".format(dm.densityDpi.toFloat())} dpi · ${if (landscape) "paisagem" else "retrato"}",
        "Memória" to "%.1f GB".format(ramGb),
        "WebView" to webView,
        "Controles" to if (pads.isEmpty()) "nenhum conectado" else pads.joinToString(", ")
    )
}

internal fun MainActivity.padNames(): List<String> {
    val out = ArrayList<String>()
    for (id in InputDevice.getDeviceIds()) {
        val d = InputDevice.getDevice(id) ?: continue
        val src = d.sources
        val pad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (pad && !d.isVirtual) out.add(d.name)
    }
    return out
}

internal fun MainActivity.diagnosticReport(): String {
    val sb = StringBuilder()
    sb.append("Relatório do Nexus\n")
    for ((k, v) in aboutDeviceLines()) sb.append(k).append(": ").append(v).append('\n')
    sb.append("Jogos: ${games.size} (favoritos ${games.count { it.isFavorite }}, arquivo não encontrado ${games.count { it.missing }})\n")
    sb.append("Plataformas com vínculo: ${links.size}\n")
    sb.append("Chave SteamGridDB: ${if (sgdbKey.isNotBlank()) "configurada" else "não configurada"}\n")
    sb.append("Chave YouTube: ${if (ytKey.isNotBlank()) "configurada" else "não configurada"}\n")
    sb.append("Acesso a todos os arquivos: ${if (hasAllFiles()) "sim" else "não"}\n")
    sb.append("Visualização: ${listOf("padrão", "carrossel", "grade", "lista")[tvView.coerceIn(0, 3)]}\n")
    sb.append("Tamanho (padrão/carrossel/retrato): $widthLStd / $widthLCar / $widthP px\n")
    sb.append("Capas por linha (retrato/paisagem): ${gridColsFor(resources.displayMetrics.widthPixels / resources.displayMetrics.density, gridSizeP, false)} / ${gridColsFor(resources.displayMetrics.widthPixels / resources.displayMetrics.density, gridSizeL, false)}\n")
    sb.append("Modo leve: ${TvMode.light}\n")
    // 4.9.16: diagnóstico dos atalhos de outros apps (ex.: GameHub): por que abrir o atalho direto falha.
    sb.append('\n').append(
        PinShortcuts.diagnose(this, games.filter { it.shortcutId.isNotEmpty() }.map { Triple(it.title, it.pkg, it.shortcutId) })
    )
    return sb.toString()
}

internal fun MainActivity.listDate(ts: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(ts))
