package com.nexus.launcher

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/** Índices dos controles do player (usados também pelo controle remoto/gamepad na MainActivity). */
const val YT_CLOSE = 0
const val YT_BACK = 1
const val YT_PLAY = 2
const val YT_FWD = 3
const val YT_FULL = 4
const val YT_EXT = 5


/**
 * O YouTube só toca o player embutido quando a página se identifica (cabeçalho Referer). Sem isso aparece o
 * "erro 153". Por isso o Nexus tenta, em ordem, estas formas de identificação e passa para a próxima sozinho
 * quando recebe o erro 153. [baseUrl] é apenas um endereço https que identifica o app (não precisa existir).
 */
private class YtAttempt(val baseUrl: String, val host: String?)

private val YT_ATTEMPTS = listOf(
    YtAttempt("https://app.nexus-launcher.dev/", null),
    YtAttempt("https://app.nexus-launcher.dev/", "https://www.youtube-nocookie.com"),
    YtAttempt("https://www.youtube.com/", null)
)

private const val YT_LOAD_TIMEOUT_MS = 12000L

/**
 * Controle do player de vídeo (WebView com a IFrame Player API do YouTube).
 * O WebView nunca recebe o foco do D-pad: tudo é comandado por este objeto e pelos botões do Nexus.
 */
class YtController {
    var playing by mutableStateOf(false)
    var ready by mutableStateOf(false)
    var pos by mutableStateOf(0f)
    var dur by mutableStateOf(0f)
    /** 0 = sem erro; -1 = tempo esgotado; senão o código de erro do player (100, 101, 150, 153...). */
    var error by mutableStateOf(0)
    /** Qual forma de identificação está em uso (índice de YT_ATTEMPTS). Ao mudar, o WebView é recriado. */
    var attempt by mutableStateOf(0)
    /** 4.7.5: em tela cheia os controles somem depois de 3 s sem toque/tecla; qualquer toque/tecla só os traz de volta. */
    var uiVisible by mutableStateOf(true)
    var wakeTick by mutableStateOf(0)
    /** Chamado quando os controles voltam a aparecer depois de escondidos (o foco volta para o play/pause). */
    var onRevealed: (() -> Unit)? = null
    fun wake() {
        val wasHidden = !uiVisible
        uiVisible = true
        wakeTick++
        if (wasHidden) onRevealed?.invoke()
    }

    private var wv: WebView? = null
    private val main = Handler(Looper.getMainLooper())

    /** Última forma de identificação que funcionou (-1 = nenhuma ainda): as próximas aberturas já começam por ela. */
    private var good = -1

    /** Zera tudo para uma nova abertura do player. */
    fun reset() {
        attempt = if (good >= 0) good else 0
        error = 0
        ready = false
        playing = false
        pos = 0f
        dur = 0f
    }

    fun attach(w: WebView) {
        wv = w
        if (playing) playing = false
        if (ready) ready = false
        if (pos != 0f) pos = 0f
        if (dur != 0f) dur = 0f
        if (error != 0) error = 0
    }

    fun detach(w: WebView) {
        if (wv === w) wv = null
    }

    /** Passa para a próxima forma de identificação. Retorna false se não há mais. */
    private fun nextAttempt(): Boolean {
        if (attempt >= YT_ATTEMPTS.lastIndex) return false
        attempt += 1
        return true
    }

    /** Chamado pelo tempo limite: tenta a próxima forma ou mostra "tempo esgotado". */
    fun onLoadTimeout() {
        if (ready || error != 0) return
        if (!nextAttempt()) error = -1
    }

    private fun js(code: String) {
        wv?.evaluateJavascript(code, null)
    }

    fun play() = js("nxPlay()")
    fun pause() = js("nxPause()")
    fun toggle() { if (playing) pause() else play() }
    fun seekBy(seconds: Int) = js("nxSeekBy($seconds)")
    fun seekToFraction(f: Float) {
        if (dur > 0f) js("nxSeekTo(" + (f.coerceIn(0f, 1f) * dur) + ")")
    }

    /** A Activity saiu de cena: pausa o vídeo e os temporizadores do WebView. */
    fun onHostPause() {
        pause()
        wv?.onPause()
    }

    fun onHostResume() {
        wv?.onResume()
    }

    /** [gen] = tentativa a que este WebView pertence; avisos de WebViews antigos são ignorados. */
    inner class Bridge(private val gen: Int) {
        @JavascriptInterface
        fun onReady() { main.post { if (gen == attempt) { ready = true; good = gen } } }

        @JavascriptInterface
        fun onState(code: Int) {
            main.post {
                if (gen != attempt) return@post
                playing = code == 1 || code == 3
                if (code == 1 || code == 3) error = 0
            }
        }

        @JavascriptInterface
        fun onTime(cur: Double, d: Double) {
            main.post {
                if (gen != attempt) return@post
                if (!cur.isNaN()) pos = cur.toFloat()
                if (!d.isNaN() && d > 0) dur = d.toFloat()
            }
        }

        @JavascriptInterface
        fun onError(code: Int) {
            main.post {
                if (gen != attempt) return@post
                // 153 = o YouTube não recebeu a identificação do app: tenta a próxima forma antes de desistir.
                if (code == 153 && nextAttempt()) return@post
                error = code
            }
        }
    }
}

private fun ytHtml(videoId: String, host: String?): String {
    val hostOpt = if (host != null) "host:'$host'," else ""
    return """
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="strict-origin-when-cross-origin">
<style>html,body{margin:0;width:100vw;height:100vh;background:#000;overflow:hidden}#p,iframe{position:absolute!important;left:0!important;top:0!important;width:100vw!important;height:100vh!important;min-height:100px;border:0;display:block}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var pl=null;
// 4.7.3 mostrou o iframe com altura 0 (if=829x0): o tamanho agora é forçado em pixels, sempre.
function nxFit(){
  var f=document.querySelector('iframe');if(!f)return;
  var w=Math.max(innerWidth,document.documentElement.clientWidth||0),h=Math.max(innerHeight,document.documentElement.clientHeight||0);
  if(h<50)h=Math.round(w*9/16);
  f.setAttribute('width',w);f.setAttribute('height',h);
  var st=f.style;st.setProperty('position','absolute','important');st.setProperty('left','0','important');st.setProperty('top','0','important');
  st.setProperty('width',w+'px','important');st.setProperty('height',h+'px','important');st.setProperty('display','block','important');
}
addEventListener('resize',nxFit);
setInterval(nxFit,400);
function onYouTubeIframeAPIReady(){
  pl=new YT.Player('p',{${hostOpt}width:String(innerWidth),height:String(innerHeight),videoId:'$videoId',
    playerVars:{autoplay:1,controls:0,rel:0,playsinline:1,modestbranding:1,fs:0,iv_load_policy:3,disablekb:1,origin:location.origin},
    events:{
      onReady:function(e){NexusYt.onReady();e.target.playVideo();setInterval(nxTick,500);},
      onStateChange:function(e){NexusYt.onState(e.data);},
      onError:function(e){NexusYt.onError(e.data);}
    }});
  nxFit();
}
function nxTick(){if(pl&&pl.getCurrentTime){NexusYt.onTime(pl.getCurrentTime(),pl.getDuration());}}
function nxPlay(){if(pl&&pl.playVideo)pl.playVideo();}
function nxPause(){if(pl&&pl.pauseVideo)pl.pauseVideo();}
function nxSeekBy(d){if(pl&&pl.seekTo){var t=pl.getCurrentTime()+d;if(t<0)t=0;pl.seekTo(t,true);}}
function nxSeekTo(s){if(pl&&pl.seekTo){pl.seekTo(s,true);}}
</script></body></html>
"""
}

private fun fmtTime(sec: Float): String {
    val s = sec.toInt().coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%d:%02d".format(m, r)
}

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
private fun YtWebView(videoId: String, ctrl: YtController, attempt: Int, modifier: Modifier) {
    val cfg = YT_ATTEMPTS[attempt.coerceIn(0, YT_ATTEMPTS.lastIndex)]
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                // O D-pad nunca entra no WebView: os controles são do Nexus.
                isFocusable = false
                isFocusableInTouchMode = false
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = object : WebViewClient() {
                    // Bloqueia qualquer navegação da página principal (o player não deve sair daqui).
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                        request.isForMainFrame
                }
                webChromeClient = WebChromeClient()
                addJavascriptInterface(ctrl.Bridge(attempt), "NexusYt")
                ctrl.attach(this)
                loadDataWithBaseURL(cfg.baseUrl, ytHtml(videoId, cfg.host), "text/html", "utf-8", null)
            }
        },
        onRelease = { w ->
            ctrl.detach(w)
            try {
                w.stopLoading()
                w.removeJavascriptInterface("NexusYt")
                w.destroy()
            } catch (_: Exception) {
            }
        }
    )
}

/** Símbolo do YouTube (retângulo vermelho arredondado com o triângulo de play), desenhado em código. */
@Composable
fun YtLogo(width: Dp = 20.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width, width * 0.7f)) {
        val w = size.width
        val h = size.height
        drawRoundRect(Color(0xFFFF0000), Offset.Zero, Size(w, h), CornerRadius(h * 0.3f, h * 0.3f))
        val tri = Path().apply {
            moveTo(w * 0.40f, h * 0.30f)
            lineTo(w * 0.40f, h * 0.70f)
            lineTo(w * 0.66f, h * 0.50f)
            close()
        }
        drawPath(tri, Color.White)
    }
}

@Composable
private fun VBtnC(on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier = modifier
            .height(34.dp)
            .clip(shape)
            .background(Color(0xB3000000))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .navHighlight(on, shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        content = content
    )
}

@Composable
private fun VBtn(label: String, on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    VBtnC(on, accent, modifier, onClick) {
        Text(label, color = if (on) accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun YtExtBtn(on: Boolean, accent: Color, onClick: () -> Unit) {
    VBtnC(on, accent, Modifier, onClick) {
        YtLogo(18.dp)
        Spacer(Modifier.width(6.dp))
        Text("YouTube", color = if (on) accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/** Botões -10s / play-pause / +10s. [compact] = rótulos curtos (retrato). */
@Composable
private fun TransportButtons(ctrl: YtController, compact: Boolean, ctl: Int, navOn: Boolean, accent: Color, onAction: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        VBtn("−10s", navOn && ctl == YT_BACK, accent) { onAction(YT_BACK) }
        VBtn(
            if (compact) (if (ctrl.playing) "❚❚" else "▶") else if (ctrl.playing) "❚❚ Pausar" else "▶ Reproduzir",
            navOn && ctl == YT_PLAY, accent
        ) { onAction(YT_PLAY) }
        VBtn("+10s", navOn && ctl == YT_FWD, accent) { onAction(YT_FWD) }
    }
}

/**
 * Janela do vídeo de gameplay. A mesma janela serve para o modo normal (dentro da área indicada por [modifier])
 * e para a tela inteira ([full]); ela não é recriada ao alternar, então o vídeo continua de onde estava.
 * [ctl] é o botão destacado pelo D-pad (YT_*); [navOn] liga esse destaque.
 *
 * 4.7.6:
 * - Retrato ([landscape] = false): o player fica centralizado e os botões ficam FORA dele, numa linha embaixo:
 *   YouTube à esquerda e (−10s, play/pause, +10s) centralizados.
 * - Paisagem (celular ou TV): os botões ficam DENTRO do player: YouTube à esquerda, (−10s, play/pause, +10s) no
 *   centro e Tela cheia à direita. Somem sozinhos depois de 3 s; toque, D-pad ou analógico os trazem de volta
 *   (com o foco no play/pause).
 * - [noKey]: sem chave de API (e sem vídeo salvo) o player mostra um aviso e só o botão YouTube.
 */
@Composable
fun VideoWindow(
    ctrl: YtController,
    videoId: String,
    noKey: Boolean,
    full: Boolean,
    landscape: Boolean,
    ctl: Int,
    navOn: Boolean,
    accent: Color,
    modifier: Modifier,
    onAction: (Int) -> Unit
) {
    val transport = !noKey && ctrl.error == 0
    val autoHide = landscape && transport
    Box(
        modifier = modifier
            .then(if (full) Modifier.background(Color.Black) else Modifier)
            // Qualquer toque (nos botões ou fora deles) reinicia os 3 s; com os controles escondidos o toque só os
            // traz de volta. Também não "vaza" para os botões escondidos atrás.
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        if (e.changes.any { it.pressed }) ctrl.wake()
                    }
                }
            }
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        // Paisagem: depois de 3 s sem toque/tecla os controles somem (o vídeo fica limpo).
        LaunchedEffect(autoHide, ctrl.wakeTick) {
            ctrl.uiVisible = true
            if (autoHide) {
                delay(3000)
                ctrl.uiVisible = false
            }
        }
        // Tempo limite: se o player não ficar pronto, tenta a próxima forma de identificação ou avisa.
        if (!noKey) {
            LaunchedEffect(ctrl.attempt) {
                delay(YT_LOAD_TIMEOUT_MS)
                ctrl.onLoadTimeout()
            }
        }
        if (landscape) {
            BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val vw = if (full) maxWidth else minOf(maxWidth, maxHeight * (16f / 9f))
                val vh = if (full) maxHeight else vw * (9f / 16f)
                VideoSurface(ctrl, videoId, noKey, full, true, transport, ctl, navOn, accent, Modifier.size(vw, vh), onAction)
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val vw = minOf(maxWidth, maxHeight * (16f / 9f))
                    val vh = vw * (9f / 16f)
                    VideoSurface(ctrl, videoId, noKey, false, false, transport, ctl, navOn, accent, Modifier.size(vw, vh), onAction)
                }
                // Botões fora do player: YouTube à esquerda, transporte centralizado.
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(34.dp)) {
                    Box(Modifier.align(Alignment.CenterStart)) {
                        YtExtBtn(navOn && (ctl == YT_EXT || (!transport && ctl != YT_CLOSE)), accent) { onAction(YT_EXT) }
                    }
                    if (transport) {
                        Box(Modifier.align(Alignment.Center)) { TransportButtons(ctrl, true, ctl, navOn, accent, onAction) }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoSurface(
    ctrl: YtController,
    videoId: String,
    noKey: Boolean,
    full: Boolean,
    landscape: Boolean,
    transport: Boolean,
    ctl: Int,
    navOn: Boolean,
    accent: Color,
    modifier: Modifier,
    onAction: (Int) -> Unit
) {
    Box(modifier.background(Color.Black)) {
        if (!noKey) {
            key(ctrl.attempt) { YtWebView(videoId, ctrl, ctrl.attempt, Modifier.fillMaxSize()) }
        }
        // Camada transparente: o toque nunca chega ao player da página (os controles são todos do Nexus).
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } })

        if (noKey) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Para assistir ao vídeo no player integrado, crie uma chave de API do YouTube na aba Sistema, " +
                        "nas Configurações do Nexus.\n\nSe preferir, toque no botão YouTube para abrir a busca no app " +
                        "do YouTube (ou no navegador).",
                    color = Color(0xFFE2E6EF), fontSize = 12.sp, lineHeight = 16.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 22.dp)
                )
            }
        } else if (ctrl.error != 0) {
            Box(Modifier.fillMaxSize().background(Color(0xE6000000)), contentAlignment = Alignment.Center) {
                Text(
                    "Este vídeo não pode ser exibido aqui (" +
                        (if (ctrl.error == -1) "tempo esgotado" else "erro ${ctrl.error}") +
                        "). Toque em YouTube para abrir no app ou troque o vídeo em Opções.",
                    color = Color(0xFFE2E6EF), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        } else if (!ctrl.ready) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Carregando vídeo…", color = Color(0xFF9AA3B5), fontSize = 12.sp)
            }
        }

        // Paisagem: os controles (inclusive o ✕ e a barra) somem juntos; retrato: ✕ e barra sempre à vista.
        val ui = ctrl.uiVisible || !landscape || !transport
        if (ui) {
            VBtn("✕", navOn && ctl == YT_CLOSE, accent, Modifier.align(Alignment.TopEnd).padding(6.dp)) { onAction(YT_CLOSE) }
        }
        if (transport && ui) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Barra de progresso (toque para ir a um ponto do vídeo).
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtTime(ctrl.pos), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .weight(1f)
                            .height(16.dp)
                            .pointerInput(Unit) {
                                detectTapGestures { off -> ctrl.seekToFraction(off.x / size.width.toFloat()) }
                            },
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x55FFFFFF)))
                        val frac = if (ctrl.dur > 0f) (ctrl.pos / ctrl.dur).coerceIn(0f, 1f) else 0f
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(accent)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(fmtTime(ctrl.dur), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
                }
                if (landscape) {
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(34.dp)) {
                        Box(Modifier.align(Alignment.CenterStart)) { YtExtBtn(navOn && ctl == YT_EXT, accent) { onAction(YT_EXT) } }
                        Box(Modifier.align(Alignment.Center)) { TransportButtons(ctrl, false, ctl, navOn, accent, onAction) }
                        Box(Modifier.align(Alignment.CenterEnd)) {
                            VBtn(if (full) "Sair da tela cheia" else "Tela cheia", navOn && ctl == YT_FULL, accent) { onAction(YT_FULL) }
                        }
                    }
                }
            }
        }
        // Paisagem sem transporte (sem chave de API ou erro): só o botão YouTube, dentro do player, canto esquerdo.
        if (landscape && !transport) {
            Box(Modifier.align(Alignment.BottomStart).padding(8.dp)) {
                YtExtBtn(navOn && ctl != YT_CLOSE, accent) { onAction(YT_EXT) }
            }
        }
    }
}
