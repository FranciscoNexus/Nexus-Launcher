package com.nexus.launcher

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Índices dos controles do player (usados também pelo controle remoto/gamepad na MainActivity). */
const val YT_CLOSE = 0
const val YT_BACK = 1
const val YT_PLAY = 2
const val YT_FWD = 3
const val YT_FULL = 4

/**
 * Controle do player de vídeo (WebView com a IFrame Player API do YouTube).
 * O WebView nunca recebe o foco do D-pad: tudo é comandado por este objeto e pelos botões do Nexus.
 */
class YtController {
    var playing by mutableStateOf(false)
    var ready by mutableStateOf(false)
    var pos by mutableStateOf(0f)
    var dur by mutableStateOf(0f)
    /** 0 = sem erro; senão o código de erro do player (100, 101, 150...). */
    var error by mutableStateOf(0)

    private var wv: WebView? = null
    private val main = Handler(Looper.getMainLooper())

    fun attach(w: WebView) {
        wv = w
        playing = false
        ready = false
        pos = 0f
        dur = 0f
        error = 0
    }

    fun detach() {
        wv = null
    }

    private fun js(code: String) {
        wv?.evaluateJavascript(code, null)
    }

    fun play() = js("nxPlay()")
    fun pause() = js("nxPause()")
    fun toggle() { if (playing) pause() else play() }
    fun seekBy(seconds: Int) = js("nxSeekBy($seconds)")
    fun seekToFraction(f: Float) {
        if (dur > 0f) js("nxSeekTo(" + (f.coerceIn(0f, 1f) * dur) + ")")
    }

    /** A Activity saiu de cena: pausa o vídeo e os temporizadores do WebView. */
    fun onHostPause() {
        pause()
        wv?.onPause()
    }

    fun onHostResume() {
        wv?.onResume()
    }

    inner class Bridge {
        @JavascriptInterface
        fun onReady() { main.post { ready = true } }

        @JavascriptInterface
        fun onState(code: Int) {
            main.post {
                playing = code == 1 || code == 3
                if (code == 1 || code == 3) error = 0
            }
        }

        @JavascriptInterface
        fun onTime(cur: Double, d: Double) {
            main.post {
                if (!cur.isNaN()) pos = cur.toFloat()
                if (!d.isNaN() && d > 0) dur = d.toFloat()
            }
        }

        @JavascriptInterface
        fun onError(code: Int) { main.post { error = code } }
    }

    val bridge = Bridge()
}

private fun ytHtml(videoId: String): String = """
<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}#p{position:absolute;left:0;top:0;width:100%;height:100%}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var pl=null;
function onYouTubeIframeAPIReady(){
  pl=new YT.Player('p',{width:'100%',height:'100%',videoId:'$videoId',
    playerVars:{autoplay:1,controls:0,rel:0,playsinline:1,modestbranding:1,fs:0,iv_load_policy:3,disablekb:1},
    events:{
      onReady:function(e){NexusYt.onReady();e.target.playVideo();setInterval(nxTick,500);},
      onStateChange:function(e){NexusYt.onState(e.data);},
      onError:function(e){NexusYt.onError(e.data);}
    }});
}
function nxTick(){if(pl&&pl.getCurrentTime){NexusYt.onTime(pl.getCurrentTime(),pl.getDuration());}}
function nxPlay(){if(pl&&pl.playVideo)pl.playVideo();}
function nxPause(){if(pl&&pl.pauseVideo)pl.pauseVideo();}
function nxSeekBy(d){if(pl&&pl.seekTo){var t=pl.getCurrentTime()+d;if(t<0)t=0;pl.seekTo(t,true);}}
function nxSeekTo(s){if(pl&&pl.seekTo){pl.seekTo(s,true);}}
</script></body></html>
"""

private fun fmtTime(sec: Float): String {
    val s = sec.toInt().coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%d:%02d".format(m, r)
}

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
private fun YtWebView(videoId: String, ctrl: YtController, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                // O D-pad nunca entra no WebView: os controles são do Nexus.
                isFocusable = false
                isFocusableInTouchMode = false
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = object : WebViewClient() {
                    // Bloqueia qualquer navegação da página principal (o player não deve sair daqui).
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                        request.isForMainFrame
                }
                webChromeClient = WebChromeClient()
                addJavascriptInterface(ctrl.bridge, "NexusYt")
                ctrl.attach(this)
                loadDataWithBaseURL("https://www.youtube.com", ytHtml(videoId), "text/html", "utf-8", null)
            }
        },
        onRelease = { w ->
            ctrl.detach()
            try {
                w.stopLoading()
                w.removeJavascriptInterface("NexusYt")
                w.destroy()
            } catch (_: Exception) {
            }
        }
    )
}

@Composable
private fun VBtn(label: String, on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(shape)
            .background(Color(0xB3000000))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .navHighlight(on, shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/**
 * Janela do vídeo de gameplay. A mesma janela serve para o modo normal (dentro da área indicada por [modifier])
 * e para a tela inteira ([full]); ela não é recriada ao alternar, então o vídeo continua de onde estava.
 * [ctl] é o botão destacado pelo D-pad (YT_*); [navOn] liga esse destaque.
 */
@Composable
fun VideoWindow(
    ctrl: YtController,
    videoId: String,
    full: Boolean,
    canFull: Boolean,
    ctl: Int,
    navOn: Boolean,
    accent: Color,
    cornerDp: Int,
    panelBg: Color,
    modifier: Modifier,
    onAction: (Int) -> Unit
) {
    Box(
        modifier = modifier
            .background(if (full) Color.Black else panelBg)
            // Consome toques para não "vazar" para os botões escondidos atrás.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val vw = if (full) maxWidth else minOf(maxWidth, maxHeight * (16f / 9f))
            val vh = if (full) maxHeight else vw * (9f / 16f)
            Box(
                Modifier
                    .size(vw, vh)
                    .clip(RoundedCornerShape(if (full) 0.dp else cornerDp.dp))
                    .background(Color.Black)
            ) {
                YtWebView(videoId, ctrl, Modifier.fillMaxSize())

                if (ctrl.error != 0) {
                    Box(Modifier.fillMaxSize().background(Color(0xE6000000)), contentAlignment = Alignment.Center) {
                        Text(
                            "Este vídeo não pode ser exibido aqui. Abra no YouTube ou troque o vídeo em Opções.",
                            color = Color(0xFFE2E6EF), fontSize = 12.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                } else if (!ctrl.ready) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Carregando vídeo…", color = Color(0xFF9AA3B5), fontSize = 12.sp)
                    }
                }

                VBtn("✕", navOn && ctl == YT_CLOSE, accent, Modifier.align(Alignment.TopEnd).padding(6.dp)) { onAction(YT_CLOSE) }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    // Barra de progresso (toque para ir a um ponto do vídeo).
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmtTime(ctrl.pos), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
                        Spacer(Modifier.width(8.dp))
                        Box(
                            Modifier
                                .weight(1f)
                                .height(16.dp)
                                .pointerInput(Unit) {
                                    detectTapGestures { off -> ctrl.seekToFraction(off.x / size.width.toFloat()) }
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x55FFFFFF)))
                            val frac = if (ctrl.dur > 0f) (ctrl.pos / ctrl.dur).coerceIn(0f, 1f) else 0f
                            Box(
                                Modifier
                                    .fillMaxWidth(frac)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(accent)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(fmtTime(ctrl.dur), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        VBtn("−10s", navOn && ctl == YT_BACK, accent) { onAction(YT_BACK) }
                        VBtn(
                            if (ctrl.error != 0) "Abrir no YouTube" else if (ctrl.playing) "❚❚ Pausar" else "▶ Reproduzir",
                            navOn && ctl == YT_PLAY, accent
                        ) { onAction(YT_PLAY) }
                        VBtn("+10s", navOn && ctl == YT_FWD, accent) { onAction(YT_FWD) }
                        if (canFull) VBtn(if (full) "Sair da tela cheia" else "Tela cheia", navOn && ctl == YT_FULL, accent) { onAction(YT_FULL) }
                    }
                }
            }
        }
    }
}
