package com.nexus.launcher

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/** Índices dos controles do player (usados também pelo controle remoto/gamepad na MainActivity). */
const val YT_CLOSE = 0
const val YT_BACK = 1
const val YT_PLAY = 2
const val YT_FWD = 3
const val YT_FULL = 4
const val YT_EXT = 5


/**
 * O YouTube só toca o player embutido quando a página se identifica (cabeçalho Referer). Sem isso aparece o
 * "erro 153". Por isso o Nexus tenta, em ordem, estas formas de identificação e passa para a próxima sozinho
 * quando recebe o erro 153. [baseUrl] é apenas um endereço https que identifica o app (não precisa existir).
 */
private class YtAttempt(val baseUrl: String, val host: String?)

private val YT_ATTEMPTS = listOf(
    YtAttempt("https://app.nexus-launcher.dev/", null),
    YtAttempt("https://app.nexus-launcher.dev/", "https://www.youtube-nocookie.com"),
    YtAttempt("https://www.youtube.com/", null)
)

private const val YT_LOAD_TIMEOUT_MS = 12000L

/**
 * Controle do player de vídeo (WebView com a IFrame Player API do YouTube).
 * O WebView nunca recebe o foco do D-pad: tudo é comandado por este objeto e pelos botões do Nexus.
 */
class YtController {
    var playing by mutableStateOf(false)
    var ready by mutableStateOf(false)
    var pos by mutableStateOf(0f)
    var dur by mutableStateOf(0f)
    /** 0 = sem erro; -1 = tempo esgotado; senão o código de erro do player (100, 101, 150, 153...). */
    var error by mutableStateOf(0)
    /** Qual forma de identificação está em uso (índice de YT_ATTEMPTS). Ao mudar, o WebView é recriado. */
    var attempt by mutableStateOf(0)
    /** 4.7.5: em tela cheia os controles somem depois de 3 s sem toque/tecla; qualquer toque/tecla só os traz de volta. */
    var uiVisible by mutableStateOf(true)
    var wakeTick by mutableStateOf(0)
    fun wake() { uiVisible = true; wakeTick++ }

    private var wv: WebView? = null
    private val main = Handler(Looper.getMainLooper())

    /** Última forma de identificação que funcionou (-1 = nenhuma ainda): as próximas aberturas já começam por ela. */
    private var good = -1

    /** Zera tudo para uma nova abertura do player. */
    fun reset() {
        attempt = if (good >= 0) good else 0
        error = 0
        ready = false
        playing = false
        pos = 0f
        dur = 0f
    }

    fun attach(w: WebView) {
        wv = w
        if (playing) playing = false
        if (ready) ready = false
        if (pos != 0f) pos = 0f
        if (dur != 0f) dur = 0f
        if (error != 0) error = 0
    }

    fun detach(w: WebView) {
        if (wv === w) wv = null
    }

    /** Passa para a próxima forma de identificação. Retorna false se não há mais. */
    private fun nextAttempt(): Boolean {
        if (attempt >= YT_ATTEMPTS.lastIndex) return false
        attempt += 1
        return true
    }

    /** Chamado pelo tempo limite: tenta a próxima forma ou mostra "tempo esgotado". */
    fun onLoadTimeout() {
        if (ready || error != 0) return
        if (!nextAttempt()) error = -1
    }

    private fun js(code: String) {
        wv?.evaluateJavascript(code, null)
    }

    fun play() = js("nxPlay()")
    fun pause() = js("nxPause()")
    fun toggle() { if (playing) pause() else play() }
    fun seekBy(seconds: Int) = js("nxSeekBy($seconds)")
    fun seekToFraction(f: Float) {
        if (dur > 0f) js("nxSeekTo(" + (f.coerceIn(0f, 1f) * dur) + ")")
    }

    /** A Activity saiu de cena: pausa o vídeo e os temporizadores do WebView. */
    fun onHostPause() {
        pause()
        wv?.onPause()
    }

    fun onHostResume() {
        wv?.onResume()
    }

    /** [gen] = tentativa a que este WebView pertence; avisos de WebViews antigos são ignorados. */
    inner class Bridge(private val gen: Int) {
        @JavascriptInterface
        fun onReady() { main.post { if (gen == attempt) { ready = true; good = gen } } }

        @JavascriptInterface
        fun onState(code: Int) {
            main.post {
                if (gen != attempt) return@post
                playing = code == 1 || code == 3
                if (code == 1 || code == 3) error = 0
            }
        }

        @JavascriptInterface
        fun onTime(cur: Double, d: Double) {
            main.post {
                if (gen != attempt) return@post
                if (!cur.isNaN()) pos = cur.toFloat()
                if (!d.isNaN() && d > 0) dur = d.toFloat()
            }
        }

        @JavascriptInterface
        fun onError(code: Int) {
            main.post {
                if (gen != attempt) return@post
                // 153 = o YouTube não recebeu a identificação do app: tenta a próxima forma antes de desistir.
                if (code == 153 && nextAttempt()) return@post
                error = code
            }
        }
    }
}

private fun ytHtml(videoId: String, host: String?): String {
    val hostOpt = if (host != null) "host:'$host'," else ""
    return """
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="strict-origin-when-cross-origin">
<style>html,body{margin:0;width:100vw;height:100vh;background:#000;overflow:hidden}#p,iframe{position:absolute!important;left:0!important;top:0!important;width:100vw!important;height:100vh!important;min-height:100px;border:0;display:block}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var pl=null;
// 4.7.3 mostrou o iframe com altura 0 (if=829x0): o tamanho agora é forçado em pixels, sempre.
function nxFit(){
  var f=document.querySelector('iframe');if(!f)return;
  var w=Math.max(innerWidth,document.documentElement.clientWidth||0),h=Math.max(innerHeight,document.documentElement.clientHeight||0);
  if(h<50)h=Math.round(w*9/16);
  f.setAttribute('width',w);f.setAttribute('height',h);
  var st=f.style;st.setProperty('position','absolute','important');st.setProperty('left','0','important');st.setProperty('top','0','important');
  st.setProperty('width',w+'px','important');st.setProperty('height',h+'px','important');st.setProperty('display','block','important');
}
addEventListener('resize',nxFit);
setInterval(nxFit,400);
function onYouTubeIframeAPIReady(){
  pl=new YT.Player('p',{${hostOpt}width:String(innerWidth),height:String(innerHeight),videoId:'$videoId',
    playerVars:{autoplay:1,controls:0,rel:0,playsinline:1,modestbranding:1,fs:0,iv_load_policy:3,disablekb:1,origin:location.origin},
    events:{
      onReady:function(e){NexusYt.onReady();e.target.playVideo();setInterval(nxTick,500);},
      onStateChange:function(e){NexusYt.onState(e.data);},
      onError:function(e){NexusYt.onError(e.data);}
    }});
  nxFit();
}
function nxTick(){if(pl&&pl.getCurrentTime){NexusYt.onTime(pl.getCurrentTime(),pl.getDuration());}}
function nxPlay(){if(pl&&pl.playVideo)pl.playVideo();}
function nxPause(){if(pl&&pl.pauseVideo)pl.pauseVideo();}
function nxSeekBy(d){if(pl&&pl.seekTo){var t=pl.getCurrentTime()+d;if(t<0)t=0;pl.seekTo(t,true);}}
function nxSeekTo(s){if(pl&&pl.seekTo){pl.seekTo(s,true);}}
</script></body></html>
"""
}

private fun fmtTime(sec: Float): String {
    val s = sec.toInt().coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%d:%02d".format(m, r)
}

@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
@Composable
private fun YtWebView(videoId: String, ctrl: YtController, attempt: Int, modifier: Modifier) {
    val cfg = YT_ATTEMPTS[attempt.coerceIn(0, YT_ATTEMPTS.lastIndex)]
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                // O D-pad nunca entra no WebView: os controles são do Nexus.
                isFocusable = false
                isFocusableInTouchMode = false
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = object : WebViewClient() {
                    // Bloqueia qualquer navegação da página principal (o player não deve sair daqui).
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                        request.isForMainFrame
                }
                webChromeClient = WebChromeClient()
                addJavascriptInterface(ctrl.Bridge(attempt), "NexusYt")
                ctrl.attach(this)
                loadDataWithBaseURL(cfg.baseUrl, ytHtml(videoId, cfg.host), "text/html", "utf-8", null)
            }
        },
        onRelease = { w ->
            ctrl.detach(w)
            try {
                w.stopLoading()
                w.removeJavascriptInterface("NexusYt")
                w.destroy()
            } catch (_: Exception) {
            }
        }
    )
}

@Composable
private fun VBtn(label: String, on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(shape)
            .background(Color(0xB3000000))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .navHighlight(on, shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/**
 * Janela do vídeo de gameplay. A mesma janela serve para o modo normal (dentro da área indicada por [modifier])
 * e para a tela inteira ([full]); ela não é recriada ao alternar, então o vídeo continua de onde estava.
 * [ctl] é o botão destacado pelo D-pad (YT_*); [navOn] liga esse destaque.
 */
@Composable
fun VideoWindow(
    ctrl: YtController,
    videoId: String,
    full: Boolean,
    canFull: Boolean,
    ctl: Int,
    navOn: Boolean,
    accent: Color,
    cornerDp: Int,
    alignTop: Boolean,
    modifier: Modifier,
    onAction: (Int) -> Unit
) {
    Box(
        modifier = modifier
            .then(if (full) Modifier.background(Color.Black) else Modifier)
            // 4.7.5: qualquer toque (nos botões ou fora deles) reinicia os 3 s da tela cheia; com os controles
            // escondidos o toque só os traz de volta. Também não "vaza" para os botões escondidos atrás.
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        if (e.changes.any { it.pressed }) ctrl.wake()
                    }
                }
            }
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        // Tela cheia: depois de 3 s sem toque/tecla os controles somem (o vídeo fica limpo).
        LaunchedEffect(full, ctrl.wakeTick) {
            ctrl.uiVisible = true
            if (full) {
                delay(3000)
                ctrl.uiVisible = false
            }
        }
        // Tempo limite: se o player não ficar pronto, tenta a próxima forma de identificação ou avisa.
        LaunchedEffect(ctrl.attempt) {
            delay(YT_LOAD_TIMEOUT_MS)
            ctrl.onLoadTimeout()
        }
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = if (alignTop && !full) Alignment.TopCenter else Alignment.Center) {
            val vw = if (full) maxWidth else minOf(maxWidth, maxHeight * (16f / 9f))
            val vh = if (full) maxHeight else vw * (9f / 16f)
            VideoContent(ctrl, videoId, full, canFull, ctl, navOn, accent, Modifier.size(vw, vh).background(Color.Black), onAction)
        }
    }
}

@Composable
private fun VideoContent(
    ctrl: YtController,
    videoId: String,
    full: Boolean,
    canFull: Boolean,
    ctl: Int,
    navOn: Boolean,
    accent: Color,
    modifier: Modifier,
    onAction: (Int) -> Unit
) {
    Box(modifier.background(Color.Black)) {
        key(ctrl.attempt) { YtWebView(videoId, ctrl, ctrl.attempt, Modifier.fillMaxSize()) }
        // Camada transparente: o toque nunca chega ao player da página (os controles são todos do Nexus).
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } })

        if (ctrl.error != 0) {
            Box(Modifier.fillMaxSize().background(Color(0xE6000000)), contentAlignment = Alignment.Center) {
                Text(
                    "Este vídeo não pode ser exibido aqui (" +
                        (if (ctrl.error == -1) "tempo esgotado" else "erro ${ctrl.error}") +
                        "). Abra no YouTube ou troque o vídeo em Opções.",
                    color = Color(0xFFE2E6EF), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        } else if (!ctrl.ready) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Carregando vídeo…", color = Color(0xFF9AA3B5), fontSize = 12.sp)
            }
        }

        val ui = ctrl.uiVisible || !full
        if (ui) {
        VBtn("✕", navOn && ctl == YT_CLOSE, accent, Modifier.align(Alignment.TopEnd).padding(6.dp)) { onAction(YT_CLOSE) }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            // Barra de progresso (toque para ir a um ponto do vídeo).
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmtTime(ctrl.pos), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .weight(1f)
                        .height(16.dp)
                        .pointerInput(Unit) {
                            detectTapGestures { off -> ctrl.seekToFraction(off.x / size.width.toFloat()) }
                        },
                    contentAlignment = Alignment.CenterStart
                ) {
                    Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x55FFFFFF)))
                    val frac = if (ctrl.dur > 0f) (ctrl.pos / ctrl.dur).coerceIn(0f, 1f) else 0f
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(accent)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(fmtTime(ctrl.dur), color = Color.White, fontSize = 10.sp, maxLines = 1, softWrap = false)
            }
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VBtn("−10s", navOn && ctl == YT_BACK, accent) { onAction(YT_BACK) }
                VBtn(
                    if (ctrl.error != 0) "Abrir no YouTube" else if (ctrl.playing) "❚❚ Pausar" else "▶ Reproduzir",
                    navOn && ctl == YT_PLAY, accent
                ) { onAction(YT_PLAY) }
                VBtn("+10s", navOn && ctl == YT_FWD, accent) { onAction(YT_FWD) }
                if (canFull) VBtn(if (full) "Sair da tela cheia" else "Tela cheia", navOn && ctl == YT_FULL, accent) { onAction(YT_FULL) }
                // Plano B sempre à mão: abre o vídeo no app do YouTube.
                VBtn("YouTube", navOn && ctl == YT_EXT, accent) { onAction(YT_EXT) }
            }
        }
        }
    }
}
