package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.10: funções do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Backup ----------
internal fun MainActivity.writeBackup(uri: Uri) {
    try {
        val o = JSONObject(LibraryStore.toJson(games.toList()))
        o.put("platforms", PlatformStore.toJsonArray(platforms.toList()))
        o.put("genresList", JSONArray(genres.toList()))
        o.put("platformLinks", LinkStore.toJsonArray(links.toList()))
        o.put(
            "visualPrefs",
            JSONObject().put("widthP", widthP).put("widthL", widthLStd).put("widthLCar", widthLCar)
                .put("gridSizeP", gridSizeP).put("gridSizeL", gridSizeL).put("listRowH", listRowH)
                .put("radius", "${radius}px").put("color", accentHex)
        )
        o.put("cutoutPad", cutoutPad)
        o.put("dashboardMode", dashMode)
        o.put("collectionsList", JSONArray(collections.toList()))
        o.put("drawerHidden", JSONArray(drawerHidden.toList()))   // 4.9.22: apps ocultos da gaveta (só nomes de pacote)
        o.put("extras", JSONObject().put("carousel", carouselOn).put("tvView", tvView).put("intro", introOn).put("floatSmall", floatSmall).put("animCovers", animCovers))
        o.put("backupFormat", 3)
        contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray(Charsets.UTF_8)) }
        toast("Backup salvo")
    } catch (e: Exception) {
        toast("Erro ao exportar: ${e.message}")
    }
}

internal fun MainActivity.readBackup(uri: Uri) {
    try {
        val raw = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        if (raw.isNullOrBlank()) {
            toast("Arquivo de backup vazio")
            return
        }
        val text = raw.removePrefix("\uFEFF")
        val o = JSONObject(text)
        if (!o.has("games")) {
            toast("Este arquivo não parece um backup do Nexus")
            return
        }
        // Lê tudo ANTES de mexer no estado: se algo falhar, nada é alterado.
        val list = LibraryStore.parse(text)
        val newGenres = o.optJSONArray("genresList")?.let { arr ->
            (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        } ?: emptyList()
        val newLinks = o.optJSONArray("platformLinks")?.let { LinkStore.parse(it.toString()) }
        val newPlatforms = o.optJSONArray("platforms")?.let { PlatformStore.parse(it.toString()) }

        games.clear()
        games.addAll(list)
        saveLibrary()

        if (newGenres.isNotEmpty()) {
            genres.clear()
            genres.addAll(newGenres)
        }
        o.optJSONObject("visualPrefs")?.let { v ->
            widthP = v.optInt("widthP", widthP)
            widthLStd = v.optInt("widthL", widthLStd)
            widthLCar = v.optInt("widthLCar", widthLStd)
            val oldGrid = v.optInt("gridSize", gridSizeL)
            gridSizeP = v.optInt("gridSizeP", oldGrid).coerceIn(0, 2)
            gridSizeL = v.optInt("gridSizeL", oldGrid).coerceIn(0, 2)
            listRowH = v.optInt("listRowH", listRowH).coerceIn(LIST_ROW_MIN_DP, LIST_ROW_MAX_DP)
            val r = v.optString("radius", "").filter { it.isDigit() }
            if (r.isNotEmpty()) radius = canonicalRadius(r.toInt())
            val c = v.optString("color", "")
            if (c.startsWith("#")) {
                try {
                    android.graphics.Color.parseColor(c)
                    accentHex = normalizeAccent(c)
                } catch (_: Exception) {
                }
            }
        }
        if (o.has("cutoutPad")) cutoutPad = o.optBoolean("cutoutPad", cutoutPad)
        if (o.has("dashboardMode")) dashMode = if (o.optInt("dashboardMode", 0) == 1) 1 else 0
        dashPlatform = ""
        collections.clear()
        o.optJSONArray("collectionsList")?.let { arr ->
            for (i in 0 until arr.length()) {
                val n = arr.optString(i, "").trim()
                if (n.isNotEmpty() && n !in collections) collections.add(n)
            }
        }
        for (g in list) for (c in g.collections) if (c !in collections) collections.add(c)
        if (o.has("drawerHidden")) {   // 4.9.22: backups antigos não mexem nos apps ocultos
            drawerHidden.clear()
            o.optJSONArray("drawerHidden")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val p = arr.optString(i, "").trim()
                    if (p.isNotEmpty() && p !in drawerHidden) drawerHidden.add(p)
                }
            }
        }
        ensureFixedCollections()
        o.optJSONObject("extras")?.let { ex ->
            applyCarouselOn(ex.optBoolean("carousel", carouselOn))
            if (ex.has("tvView")) {
                tvView = ex.optInt("tvView", tvView).coerceIn(0, 3)
                prefs.edit().putInt("tvView", tvView).apply()
            }
            applyIntroOn(ex.optBoolean("intro", introOn))
            applyAnimCovers(ex.optBoolean("animCovers", animCovers))
            applyFloatSmall(ex.optBoolean("floatSmall", floatSmall))
        }
        if (newLinks != null) {
            links.clear()
            links.addAll(newLinks)
        }
        if (!newPlatforms.isNullOrEmpty()) {
            platforms.clear()
            platforms.addAll(newPlatforms)
        }
        syncPlatforms()
        savePrefs()
        resetFilters()
        prefetchCovers()
        selectedId = firstNavId()
        if (!storageOk && links.any { it.folders.isNotEmpty() }) overlay = Overlay.StoragePrompt
        toast("Backup importado: ${list.size} jogos")
    } catch (e: Exception) {
        toast("Erro ao importar: ${e.message}")
    }
}

internal fun MainActivity.doExport() {
    val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    if (TvMode.isTv) {
        // TV: escolhe a pasta no explorador do Nexus e grava o arquivo lá.
        explorer = ExplorerState(true, "Salvar o backup em qual pasta?", null, null) { dir ->
            writeBackup(Uri.fromFile(File(dir, "nexus_backup_$d.json")))
        }
        return
    }
    exportLauncher.launch("nexus_backup_$d.json")
}

internal fun MainActivity.doImport() {
    if (TvMode.isTv) {
        explorer = ExplorerState(false, "Escolher o arquivo de backup (.json)", setOf("json"), null) { f ->
            readBackup(Uri.fromFile(f))
        }
        return
    }
    importLauncher.launch(arrayOf("*/*"))
}

internal fun MainActivity.doStorage() {
    if (storageOk) toast("O acesso ao armazenamento já está concedido") else askStorage()
}

/** 4.7.8: apaga TUDO (jogos, configurações, vínculos, gêneros, coleções, chaves de API, capas) e reinicia o Nexus. */
internal fun MainActivity.factoryReset() {
    wiping = true
    try { stopService(Intent(this, FloatingPanelService::class.java)) } catch (_: Exception) { }
    try { Covers.clearAll() } catch (_: Exception) { }
    try { prefs.edit().clear().commit() } catch (_: Exception) { }
    try { filesDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
    try { cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
    try {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    } catch (_: Exception) { }
    // O processo termina logo depois para que o Nexus volte do zero (nada em memória é regravado).
    Handler(Looper.getMainLooper()).postDelayed({ Runtime.getRuntime().exit(0) }, 500)
}
