package com.nexus.launcher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Dados vindos do SteamGridDB. O SteamGridDB só informa a data de lançamento (além das imagens). */
data class GameInfoData(
    val released: String = ""
)

enum class SgdbStatus { NoKey, Loading, Found, NotFound, Failed }

/** Estado da busca no SteamGridDB para mostrar o aviso da tela (crédito com link e atualizar). */
data class SgdbView(
    val status: SgdbStatus = SgdbStatus.NoKey,
    val message: String = "",
    val url: String = "https://www.steamgriddb.com"
)

// Altura de linha igual ao tamanho da fonte e centralizada: a letra fica no meio do círculo.
@OptIn(ExperimentalTextApi::class)
internal val CenteredLine = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.Both
)

private val IN_PANEL = Color(0xFF141720)
private val IN_CARD = Color(0xFF1A1E29)
private val IN_LINE = Color(0x1AFFFFFF)
private val IN_MUTED = Color(0xFF9AA3B5)
private val IN_AMBER = Color(0xFFFFC53D)
private val IN_GREEN_A = Color(0xFF34C759)
private val IN_GREEN_B = Color(0xFF28CD41)
private val IN_DARK = Color(0xFF1E222B)
private val IN_LINK = Color(0xFF38BDF8)

/**
 * Tela de informações do jogo (UI pura: não conhece o resto do app).
 * Segue o tema do app: cor de destaque e cantos (painel, cartões e botões) mudam ao vivo.
 * Retrato: painel único sem rolagem, capa no topo (ocupa o espaço que sobra), dados em duas colunas.
 * Paisagem: capa à esquerda; título, dados em 3 colunas, aviso e botões à direita.
 */
@Composable
fun GameInfoScreen(
    game: Game,
    extra: GameInfoData,
    landscape: Boolean,
    accent: Color,
    cornerDp: Int,
    panelDp: Int,
    btnDp: Int,
    source: SgdbView,
    hintHidden: Boolean,
    cover: @Composable (Modifier) -> Unit,
    onLink: (String) -> Unit,
    onRefresh: () -> Unit,
    onPlay: () -> Unit,
    onOptions: () -> Unit,
    onBack: () -> Unit,
    onToggleFav: () -> Unit,
    onCollections: () -> Unit,
    onHideHint: () -> Unit
) {
    val lastPlayed = if (game.lastPlayedTs > 0) {
        SimpleDateFormat("dd/MM/yy HH:mm", Locale("pt", "BR")).format(Date(game.lastPlayedTs))
    } else "Nunca"
    val collectionsText = game.collections.joinToString(", ")
    val none = remember { MutableInteractionSource() }
    val panel = RoundedCornerShape(panelDp.dp)
    val frame = RoundedCornerShape((cornerDp + 4).dp)
    val showBanner = source.status != SgdbStatus.NoKey || !hintHidden

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(interactionSource = none, indication = null) { onBack() }
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.94f)
                .fillMaxHeight(if (landscape) 0.94f else 0.93f)
                .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                .clip(panel)
                .background(IN_PANEL)
                .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .padding(14.dp)
        ) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .aspectRatio(0.69f, matchHeightConstraintsFirst = true)
                    ) { CoverFrame(frame, accent, cover) }
                    Column(
                        modifier = Modifier.weight(1f).fillMaxHeight().padding(start = 16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { InfoMarquee(game.title, Color.White, 24, FontWeight.ExtraBold) }
                            Spacer(Modifier.width(10.dp))
                            FavPill(game.isFavorite, CircleShape, onToggleFav)
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetaCard("▭", Color(0xFF38BDF8), "Plataforma", game.platform, cornerDp, Modifier.weight(1f))
                                MetaCard("◈", Color(0xFF60A5FA), "Gênero", game.genre, cornerDp, Modifier.weight(1f))
                                MetaCard("▦", Color(0xFFCBD2E0), "Lançamento", extra.released, cornerDp, Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetaCard("▶", Color(0xFF34D399), "Vezes aberto", game.openCount.toString(), cornerDp, Modifier.weight(1f))
                                MetaCard("◔", Color(0xFFCBD2E0), "Último acesso", lastPlayed, cornerDp, Modifier.weight(1f))
                                MetaCard("▣", IN_AMBER, "Coleções", collectionsText, cornerDp, Modifier.weight(1f), accent, onCollections)
                            }
                        }
                        if (showBanner) {
                            SgdbBanner(source, accent, cornerDp, false, onLink, onRefresh, onHideHint)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PlayButton(btnDp, 42, Modifier.weight(5f), onPlay)
                            DarkButton("≡", Color(0x1AFFFFFF), Color(0xFFE2E6EF), "Opções", btnDp, Modifier.weight(4f), onOptions)
                            DarkButton("B", Color(0xFFF43F5E), Color.White, "Voltar", btnDp, Modifier.weight(3f), onBack)
                        }
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        FavPill(game.isFavorite, RoundedCornerShape(btnDp.dp), onToggleFav)
                    }
                    // A capa ocupa o espaço que sobrar, então tudo cabe sem rolagem em qualquer tela.
                    BoxWithConstraints(
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val h0 = minOf(maxHeight, 290.dp)
                        val w0 = minOf(h0 * 0.72f, maxWidth)
                        val h1 = w0 / 0.72f
                        Box(Modifier.size(w0, h1)) { CoverFrame(frame, accent, cover) }
                    }
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        InfoMarquee(game.title, Color.White, 22, FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconCell("▭", Color(0xFF38BDF8), "Plataforma", game.platform, false, btnDp, cornerDp, Modifier.weight(1f))
                            IconCell("◈", Color(0xFF60A5FA), "Gênero", game.genre, false, btnDp, cornerDp, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconCell("▦", Color(0xFFCBD2E0), "Lançamento", extra.released, false, btnDp, cornerDp, Modifier.weight(1f))
                            IconCell("▶", Color(0xFF34D399), "Vezes aberto", game.openCount.toString(), false, btnDp, cornerDp, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconCell("◔", Color(0xFFCBD2E0), "Último acesso", lastPlayed, true, btnDp, cornerDp, Modifier.weight(1f))
                            IconCell("▣", IN_AMBER, "Coleções", collectionsText, false, btnDp, cornerDp, Modifier.weight(1f), accent, onCollections)
                        }
                    }
                    if (showBanner) {
                        Spacer(Modifier.height(10.dp))
                        SgdbBanner(source, accent, cornerDp, true, onLink, onRefresh, onHideHint)
                    }
                    Spacer(Modifier.height(12.dp))
                    PlayButton(btnDp, 50, Modifier.fillMaxWidth(), onPlay)
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DarkButton("≡", Color(0x1AFFFFFF), Color(0xFFE2E6EF), "Opções", btnDp, Modifier.weight(1f), onOptions)
                        DarkButton("B", Color(0xFFF43F5E), Color.White, "Voltar", btnDp, Modifier.weight(1f), onBack)
                    }
                }
            }
        }
    }
}

@Composable
private fun CoverFrame(frame: RoundedCornerShape, accent: Color, cover: @Composable (Modifier) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .shadow(14.dp, frame, ambientColor = accent, spotColor = accent)
            .clip(frame)
            .background(Color(0xFF1C1C1E))
            .border(2.dp, accent, frame)
    ) { cover(Modifier.fillMaxSize()) }
}

/** Texto de uma linha que rola sozinho, devagar, quando é maior que o espaço disponível. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun InfoMarquee(
    text: String, color: Color, size: Int,
    weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight,
        maxLines = 1, softWrap = false,
        modifier = modifier.basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
    )
}

@Composable
private fun FavPill(on: Boolean, shape: androidx.compose.ui.graphics.Shape, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .then(if (on) Modifier.shadow(8.dp, shape, ambientColor = IN_AMBER, spotColor = IN_AMBER) else Modifier)
            .clip(shape)
            .background(IN_CARD)
            .border(1.5.dp, if (on) IN_AMBER.copy(alpha = 0.75f) else IN_LINE, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (on) "★" else "☆", color = if (on) IN_AMBER else IN_MUTED, fontSize = 13.sp)
        Spacer(Modifier.width(6.dp))
        Text(
            "Favorito", color = if (on) IN_AMBER else Color(0xFFE2E6EF), fontSize = 12.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
        )
    }
}

/** Retrato: célula com ícone, rótulo e valor. */
@Composable
private fun IconCell(
    glyph: String, tint: Color, label: String, value: String, small: Boolean,
    btnDp: Int, cardDp: Int, modifier: Modifier,
    accent: Color? = null, onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(cardDp.dp)
    val icon = RoundedCornerShape(btnDp.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(IN_CARD)
            .border(1.dp, if (accent != null) accent.copy(alpha = 0.4f) else IN_LINE, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(28.dp).clip(icon).background(Color(0x0DFFFFFF)).border(1.dp, IN_LINE, icon),
            contentAlignment = Alignment.Center
        ) { Text(glyph, color = tint, fontSize = 13.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = IN_MUTED, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            Spacer(Modifier.height(3.dp))
            InfoMarquee(value.ifBlank { "—" }, Color.White, if (small) 11 else 13)
        }
    }
}

/** Paisagem: cartão com ícone, rótulo e valor (mesmo visual do retrato, mais compacto). */
@Composable
private fun MetaCard(
    glyph: String, tint: Color, label: String, value: String, cardDp: Int, modifier: Modifier,
    accent: Color? = null, onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(cardDp.dp)
    val icon = RoundedCornerShape(8.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(IN_CARD)
            .border(1.dp, if (accent != null) accent.copy(alpha = 0.4f) else IN_LINE, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(24.dp).clip(icon).background(Color(0x0DFFFFFF)).border(1.dp, IN_LINE, icon),
            contentAlignment = Alignment.Center
        ) { Text(glyph, color = tint, fontSize = 12.sp) }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = IN_MUTED, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            Spacer(Modifier.height(2.dp))
            InfoMarquee(value.ifBlank { "—" }, Color.White, 13)
        }
    }
}

@Composable
private fun LinkText(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Text(
        text, color = IN_LINK, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        textDecoration = TextDecoration.Underline,
        modifier = modifier.clickable(onClick = onClick).padding(vertical = 3.dp)
    )
}

/** Aviso/crédito do SteamGridDB (link ativo para o site onde os dados são usados). */
@Composable
private fun SgdbBanner(
    v: SgdbView, accent: Color, cardDp: Int, withHide: Boolean,
    onLink: (String) -> Unit, onRefresh: () -> Unit, onHide: () -> Unit
) {
    val shape = RoundedCornerShape(cardDp.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(IN_CARD)
            .border(1.dp, IN_LINE, shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text("ⓘ", color = accent, fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            when (v.status) {
                SgdbStatus.NoKey -> {
                    Text(
                        "Para ver a data de lançamento e buscar capas, adicione sua chave grátis do SteamGridDB em Configurações.",
                        color = Color(0xFFCBD2E0), fontSize = 10.5.sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LinkText("Criar chave grátis (steamgriddb.com)", Modifier.weight(1f)) {
                            onLink("https://www.steamgriddb.com/profile/preferences/api")
                        }
                        if (withHide) {
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Ocultar", color = IN_MUTED, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clickable(onClick = onHide).padding(vertical = 3.dp)
                            )
                        }
                    }
                }
                SgdbStatus.Loading -> Text("Buscando dados no SteamGridDB…", color = Color(0xFFCBD2E0), fontSize = 10.5.sp)
                SgdbStatus.Found -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dados: ", color = Color(0xFFCBD2E0), fontSize = 10.5.sp)
                    LinkText("SteamGridDB") { onLink(v.url) }
                    Spacer(Modifier.width(16.dp))
                    LinkText("↻ Atualizar") { onRefresh() }
                }
                SgdbStatus.NotFound -> {
                    Text("Jogo não encontrado no SteamGridDB. Confira o título.", color = Color(0xFFCBD2E0), fontSize = 10.5.sp)
                    LinkText("↻ Tentar de novo") { onRefresh() }
                }
                SgdbStatus.Failed -> {
                    Text(
                        v.message.ifBlank { "Não foi possível buscar no SteamGridDB." },
                        color = Color(0xFFCBD2E0), fontSize = 10.5.sp
                    )
                    LinkText("↻ Tentar de novo") { onRefresh() }
                }
            }
        }
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
private fun PlayButton(btnDp: Int, heightDp: Int, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape((btnDp + 4).dp)
    Row(
        modifier = modifier
            .height(heightDp.dp)
            .shadow(8.dp, shape, ambientColor = IN_GREEN_B, spotColor = IN_GREEN_B)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(IN_GREEN_A, IN_GREEN_B)))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF062814)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "A", color = IN_GREEN_A, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp,
                lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "Jogar", color = Color(0xFF051B0C), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
            maxLines = 1, softWrap = false
        )
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
private fun DarkButton(
    letter: String, badge: Color, badgeText: Color, label: String, btnDp: Int, modifier: Modifier, onClick: () -> Unit
) {
    val shape = RoundedCornerShape((btnDp + 4).dp)
    Row(
        modifier = modifier
            .height(42.dp)
            .clip(shape)
            .background(IN_DARK)
            .border(1.dp, Color(0x1FFFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(20.dp).clip(CircleShape).background(badge),
            contentAlignment = Alignment.Center
        ) {
            Text(
                letter, color = badgeText, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp,
                lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            label, color = Color(0xFFF4F6FB), fontSize = 13.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false
        )
    }
}
