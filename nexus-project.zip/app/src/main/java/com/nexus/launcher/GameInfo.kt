package com.nexus.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Dados vindos da internet (RAWG). Vazios por enquanto: aparecem como "—" na tela. */
data class GameInfoData(
    val platforms: String = "",
    val released: String = "",
    val publisher: String = "",
    val developer: String = "",
    val metascore: Int? = null
)

enum class RawgStatus { NoKey, Loading, Found, NotFound, Failed }

/** Estado da busca na RAWG para mostrar o rodapé da tela (aviso, crédito com link e atualizar). */
data class RawgView(
    val status: RawgStatus = RawgStatus.NoKey,
    val message: String = "",
    val url: String = "https://rawg.io"
)

private val INFO_MUTED = Color(0xFF8E8E93)
private val INFO_LINK = Color(0xFF5AA9FF)
private val INFO_PANEL = Color(0xF2121214)

/**
 * Tela de informações do jogo (UI pura: não conhece o resto do app).
 * Paisagem: capa grande à esquerda com moldura, dados à direita, nota no canto superior direito.
 * Retrato: folha subindo de baixo, capa centralizada, dados em duas colunas e botões fixos embaixo.
 */
@Composable
fun GameInfoScreen(
    game: Game,
    extra: GameInfoData,
    landscape: Boolean,
    accent: Color,
    cornerDp: Int,
    rawg: RawgView,
    cover: @Composable (Modifier) -> Unit,
    onLink: (String) -> Unit,
    onRefresh: () -> Unit,
    onPlay: () -> Unit,
    onOptions: () -> Unit,
    onBack: () -> Unit
) {
    val lastPlayed = if (game.lastPlayedTs > 0) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(game.lastPlayedTs))
    } else "Nunca"
    val items = listOf(
        "Plataforma" to game.platform,
        "Gênero" to game.genre,
        "Lançado para" to extra.platforms,
        "Lançamento" to extra.released,
        "Publicadora" to extra.publisher,
        "Desenvolvedora" to extra.developer,
        "Vezes aberto" to game.openCount.toString(),
        "Último acesso" to lastPlayed,
        "Coleções" to game.collections.joinToString(", ")
    )
    val subtitle = listOf(game.platform, game.genre).filter { it.isNotBlank() }.joinToString(" · ") +
        (if (game.isFavorite) "  ⭐" else "")
    val none = remember { MutableInteractionSource() }
    val frameShape = RoundedCornerShape((cornerDp + 4).dp)
    val coverShape = RoundedCornerShape(cornerDp.dp)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(interactionSource = none, indication = null) { onBack() }
    ) {
        if (landscape) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.88f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(INFO_PANEL)
                    .border(1.dp, Color(0xFF2C2C2E), RoundedCornerShape(20.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(16.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .aspectRatio(0.69f, matchHeightConstraintsFirst = true)
                            .clip(frameShape)
                            .background(Color(0xFF2C2C2E))
                            .border(2.dp, accent, frameShape)
                            .padding(5.dp)
                    ) { cover(Modifier.fillMaxSize().clip(coverShape)) }
                    Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(start = 18.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    game.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                Text(subtitle, color = INFO_MUTED, fontSize = 12.sp, maxLines = 1)
                            }
                            Spacer(Modifier.width(12.dp))
                            ScoreBadge(extra.metascore)
                        }
                        Spacer(Modifier.height(8.dp))
                        Column(modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                            InfoGrid(items)
                            RawgFooter(rawg, onLink, onRefresh)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            InfoButton("A", "Jogar", Color(0xFF6BBE45), Modifier.weight(1.3f), filled = true, onClick = onPlay)
                            InfoButton("≡", "Opções", Color(0xFF5E5E63), Modifier.weight(1f), onClick = onOptions)
                            InfoButton("B", "Voltar", Color(0xFFE8453C), Modifier.weight(1f), onClick = onBack)
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(0.88f)
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(INFO_PANEL)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 14.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.54f)
                            .aspectRatio(0.69f)
                            .clip(frameShape)
                            .background(Color(0xFF2C2C2E))
                            .border(2.dp, accent, frameShape)
                            .padding(5.dp)
                    ) {
                        cover(Modifier.fillMaxSize().clip(coverShape))
                        ScoreBadge(extra.metascore, Modifier.align(Alignment.TopEnd).padding(6.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        game.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text(subtitle, color = INFO_MUTED, fontSize = 12.sp, maxLines = 1)
                    Spacer(Modifier.height(10.dp))
                    InfoGrid(items)
                    RawgFooter(rawg, onLink, onRefresh)
                }
                Spacer(Modifier.height(10.dp))
                InfoButton("A", "Jogar", Color(0xFF6BBE45), Modifier.fillMaxWidth(), filled = true, onClick = onPlay)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoButton("≡", "Opções", Color(0xFF5E5E63), Modifier.weight(1f), onClick = onOptions)
                    InfoButton("B", "Voltar", Color(0xFFE8453C), Modifier.weight(1f), onClick = onBack)
                }
            }
        }
    }
}

@Composable
private fun LinkText(text: String, modifier: Modifier = Modifier, size: Int = 12, onClick: () -> Unit) {
    Text(
        text, color = INFO_LINK, fontSize = size.sp, textDecoration = TextDecoration.Underline,
        modifier = modifier.clickable(onClick = onClick).padding(vertical = 4.dp)
    )
}

/** Aviso/crédito da RAWG. Os termos da RAWG exigem um link ativo onde os dados são usados. */
@Composable
private fun RawgFooter(v: RawgView, onLink: (String) -> Unit, onRefresh: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        when (v.status) {
            RawgStatus.NoKey -> {
                Text(
                    "Para ver lançamento, empresas e a nota do Metacritic, adicione sua chave grátis da RAWG em Configurações.",
                    color = INFO_MUTED, fontSize = 11.sp
                )
                LinkText("Criar chave grátis (rawg.io/apidocs)") { onLink("https://rawg.io/apidocs") }
            }
            RawgStatus.Loading -> Text("Buscando dados na RAWG…", color = INFO_MUTED, fontSize = 11.sp)
            RawgStatus.Found -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dados: ", color = INFO_MUTED, fontSize = 11.sp)
                LinkText("RAWG") { onLink(v.url) }
                Spacer(Modifier.width(16.dp))
                LinkText("↻ Atualizar") { onRefresh() }
            }
            RawgStatus.NotFound -> {
                Text("Jogo não encontrado na RAWG. Confira o título.", color = INFO_MUTED, fontSize = 11.sp)
                LinkText("↻ Tentar de novo") { onRefresh() }
            }
            RawgStatus.Failed -> {
                Text(v.message.ifBlank { "Não foi possível buscar na RAWG." }, color = INFO_MUTED, fontSize = 11.sp)
                LinkText("↻ Tentar de novo") { onRefresh() }
            }
        }
    }
}

@Composable
private fun InfoGrid(items: List<Pair<String, String>>) {
    Column(modifier = Modifier.fillMaxWidth()) {
        for (row in items.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                for (cell in row) InfoCell(cell.first, cell.second, Modifier.weight(1f))
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun InfoCell(label: String, value: String, modifier: Modifier) {
    Column(modifier = modifier.padding(vertical = 5.dp, horizontal = 2.dp)) {
        Text(label, color = INFO_MUTED, fontSize = 10.sp, maxLines = 1)
        Text(
            value.ifBlank { "—" }, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ScoreBadge(score: Int?, modifier: Modifier = Modifier) {
    val bg = when {
        score == null -> Color(0xFF3A3A3C)
        score >= 75 -> Color(0xFF3DBA4E)
        score >= 50 -> Color(0xFFFFC800)
        else -> Color(0xFFE8453C)
    }
    val fg = if (score != null && score in 50..74) Color.Black else Color.White
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) {
            Text(score?.toString() ?: "—", color = fg, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
        Text("Metacritic", color = INFO_MUTED, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun InfoButton(
    letter: String,
    label: String,
    color: Color,
    modifier: Modifier,
    filled: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (filled) color else Color(0xFF1F1F22))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(26.dp).clip(CircleShape).background(if (filled) Color(0x55000000) else color),
            contentAlignment = Alignment.Center
        ) {
            Text(letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
