package com.nexus.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Dados vindos do SteamGridDB. O SteamGridDB só informa a data de lançamento (além das imagens). */
data class GameInfoData(
    val released: String = ""
)

enum class SgdbStatus { NoKey, Loading, Found, NotFound, Failed }

/** Estado da busca no SteamGridDB para mostrar o rodapé da tela (aviso, crédito com link e atualizar). */
data class SgdbView(
    val status: SgdbStatus = SgdbStatus.NoKey,
    val message: String = "",
    val url: String = "https://www.steamgriddb.com"
)

// Altura de linha igual ao tamanho da fonte e centralizada: a letra fica no meio do círculo.
@OptIn(ExperimentalTextApi::class)
internal val CenteredLine = LineHeightStyle(
    alignment = LineHeightStyle.Alignment.Center,
    trim = LineHeightStyle.Trim.Both
)

private val INFO_MUTED = Color(0xFF8E8E93)
private val INFO_LINK = Color(0xFF5AA9FF)
private val INFO_PANEL = Color(0xF2121214)

/**
 * Tela de informações do jogo (UI pura: não conhece o resto do app).
 * Paisagem: capa grande à esquerda com moldura, dados à direita, nota no canto superior direito.
 * Retrato: folha subindo de baixo, capa centralizada, dados em duas colunas e botões fixos embaixo.
 */
@Composable
fun GameInfoScreen(
    game: Game,
    extra: GameInfoData,
    landscape: Boolean,
    accent: Color,
    cornerDp: Int,
    source: SgdbView,
    cover: @Composable (Modifier) -> Unit,
    onLink: (String) -> Unit,
    onRefresh: () -> Unit,
    onPlay: () -> Unit,
    onOptions: () -> Unit,
    onBack: () -> Unit
) {
    val lastPlayed = if (game.lastPlayedTs > 0) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(game.lastPlayedTs))
    } else "Nunca"
    val items = listOf(
        "Plataforma" to game.platform,
        "Gênero" to game.genre,
        "Lançamento" to extra.released,
        "Vezes aberto" to game.openCount.toString(),
        "Último acesso" to lastPlayed,
        "Coleções" to game.collections.joinToString(", ")
    )
    val subtitle = listOf(game.platform, game.genre).filter { it.isNotBlank() }.joinToString(" · ") +
        (if (game.isFavorite) "  ⭐" else "")
    val none = remember { MutableInteractionSource() }
    val frameShape = RoundedCornerShape((cornerDp + 4).dp)
    val coverShape = RoundedCornerShape(cornerDp.dp)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(interactionSource = none, indication = null) { onBack() }
    ) {
        if (landscape) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.88f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(INFO_PANEL)
                    .border(1.dp, Color(0xFF2C2C2E), RoundedCornerShape(20.dp))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(16.dp)
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .aspectRatio(0.69f, matchHeightConstraintsFirst = true)
                            .clip(frameShape)
                            .background(Color(0xFF2C2C2E))
                            .border(2.dp, accent, frameShape)
                            .padding(5.dp)
                    ) { cover(Modifier.fillMaxSize().clip(coverShape)) }
                    Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(start = 18.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    game.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                Text(subtitle, color = INFO_MUTED, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Column(modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                            InfoGrid(items)
                            SgdbFooter(source, onLink, onRefresh)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            InfoButton("A", "Jogar", Color(0xFF77D773), Modifier.weight(1.3f), filled = true, onClick = onPlay)
                            InfoButton("≡", "Opções", Color(0xFF5E5E63), Modifier.weight(1f), onClick = onOptions)
                            InfoButton("B", "Voltar", Color(0xFFEB4E3D), Modifier.weight(1f), onClick = onBack)
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(0.88f)
                    .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                    .background(INFO_PANEL)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 14.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.54f)
                            .aspectRatio(0.69f)
                            .clip(frameShape)
                            .background(Color(0xFF2C2C2E))
                            .border(2.dp, accent, frameShape)
                            .padding(5.dp)
                    ) {
                        cover(Modifier.fillMaxSize().clip(coverShape))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        game.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text(subtitle, color = INFO_MUTED, fontSize = 12.sp, maxLines = 1)
                    Spacer(Modifier.height(10.dp))
                    InfoGrid(items)
                    SgdbFooter(source, onLink, onRefresh)
                }
                Spacer(Modifier.height(10.dp))
                InfoButton("A", "Jogar", Color(0xFF77D773), Modifier.fillMaxWidth(), filled = true, onClick = onPlay)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoButton("≡", "Opções", Color(0xFF5E5E63), Modifier.weight(1f), onClick = onOptions)
                    InfoButton("B", "Voltar", Color(0xFFEB4E3D), Modifier.weight(1f), onClick = onBack)
                }
            }
        }
    }
}

@Composable
private fun LinkText(text: String, modifier: Modifier = Modifier, size: Int = 12, onClick: () -> Unit) {
    Text(
        text, color = INFO_LINK, fontSize = size.sp, textDecoration = TextDecoration.Underline,
        modifier = modifier.clickable(onClick = onClick).padding(vertical = 4.dp)
    )
}

/** Aviso/crédito do SteamGridDB (link ativo para o site onde os dados são usados). */
@Composable
private fun SgdbFooter(v: SgdbView, onLink: (String) -> Unit, onRefresh: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        when (v.status) {
            SgdbStatus.NoKey -> {
                Text(
                    "Para ver a data de lançamento e buscar capas, adicione sua chave grátis do SteamGridDB em Configurações.",
                    color = INFO_MUTED, fontSize = 11.sp
                )
                LinkText("Criar chave grátis (steamgriddb.com)") {
                    onLink("https://www.steamgriddb.com/profile/preferences/api")
                }
            }
            SgdbStatus.Loading -> Text("Buscando dados no SteamGridDB…", color = INFO_MUTED, fontSize = 11.sp)
            SgdbStatus.Found -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dados: ", color = INFO_MUTED, fontSize = 11.sp)
                LinkText("SteamGridDB") { onLink(v.url) }
                Spacer(Modifier.width(16.dp))
                LinkText("↻ Atualizar") { onRefresh() }
            }
            SgdbStatus.NotFound -> {
                Text("Jogo não encontrado no SteamGridDB. Confira o título.", color = INFO_MUTED, fontSize = 11.sp)
                LinkText("↻ Tentar de novo") { onRefresh() }
            }
            SgdbStatus.Failed -> {
                Text(v.message.ifBlank { "Não foi possível buscar no SteamGridDB." }, color = INFO_MUTED, fontSize = 11.sp)
                LinkText("↻ Tentar de novo") { onRefresh() }
            }
        }
    }
}

@Composable
private fun InfoGrid(items: List<Pair<String, String>>) {
    Column(modifier = Modifier.fillMaxWidth()) {
        for (row in items.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                for (cell in row) InfoCell(cell.first, cell.second, Modifier.weight(1f))
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun InfoCell(label: String, value: String, modifier: Modifier) {
    Column(modifier = modifier.padding(vertical = 5.dp, horizontal = 2.dp)) {
        Text(label, color = INFO_MUTED, fontSize = 10.sp, maxLines = 1)
        Text(
            value.ifBlank { "—" }, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
private fun InfoButton(
    letter: String,
    label: String,
    color: Color,
    modifier: Modifier,
    filled: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .height(46.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (filled) color else Color(0xFF1F1F22))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(26.dp).clip(CircleShape).background(if (filled) Color(0x55000000) else color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                lineHeight = 13.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            lineHeight = 15.sp, style = TextStyle(lineHeightStyle = CenteredLine)
        )
    }
}
