package com.nexus.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * 4.9.21: tela auxiliar invisível usada para o Nexus "nascer de novo" numa tarefa normal.
 *
 * Quando o Nexus abre como launcher (tela inicial), o Android cria a tarefa dele como do tipo "tela inicial", e tarefas
 * desse tipo NÃO aparecem nos apps recentes. O Android não troca o tipo depois, mesmo que o usuário volte ao launcher
 * anterior (só forçar a parada resolvia). Como o Nexus é `singleTask`, abrir o Nexus de novo reaproveitaria a mesma tarefa.
 * Então: [MainActivity.relaunchInFreshTask] abre esta tela (tarefa própria, sem aparecer nos recentes), remove a tarefa
 * antiga e esta tela, passado um instante, abre o Nexus de novo, agora numa tarefa nova e comum.
 */
class RelaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                )
            } catch (_: Exception) {
            }
            finish()
            overridePendingTransition(0, 0)
        }, 450)
    }
}
