package com.nexus.launcher

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Window
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * 4.9.3: camada única de entrada para controle remoto e gamepad.
 *
 * Problemas que ela resolve:
 * - Gamepads (como o GameSir T4 Nova Lite) mandam o D-pad por TECLA e também por EIXO (hat). O Android ainda cria teclas
 *   a partir do eixo, e o mesmo toque virava 2 ou 3 passos (o foco "pulava" botões). Aqui tecla e eixo viram UMA direção só.
 * - Segurar a direção repete em ritmo fixo e suave (o auto-repeat do sistema era irregular).
 * - Nas janelas (Dialog) as teclas L1/R1/L2/R2 não chegavam à MainActivity; agora a própria janela as trata.
 */
object PadInput {
    /** Tempo segurando até começar a repetir, e intervalo da repetição. */
    const val HOLD_MS = 380L
    const val REPEAT_MS = 130L

    private const val ON = 0.6f
    private const val OFF = 0.4f

    fun isDpad(code: Int): Boolean =
        code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

    fun isJoystick(ev: MotionEvent): Boolean = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK

    /**
     * Direção (KEYCODE_DPAD_*) indicada pelos eixos do controle: D-pad por eixo (hat) ou alavanca esquerda; 0 = solto.
     * [prev] é a direção anterior (histerese: para soltar basta passar de 40%, para apertar é preciso passar de 60%).
     */
    fun axisDir(ev: MotionEvent, prev: Int): Int {
        val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val sx = ev.getAxisValue(MotionEvent.AXIS_X)
        val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
        val ax = if (abs(hx) > 0.5f) hx else sx
        val ay = if (abs(hy) > 0.5f) hy else sy
        val limit = if (prev != 0) OFF else ON
        if (abs(ax) <= limit && abs(ay) <= limit) return 0
        return if (abs(ax) >= abs(ay)) {
            if (ax > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        } else {
            if (ay > 0) KeyEvent.KEYCODE_DPAD_DOWN else KeyEvent.KEYCODE_DPAD_UP
        }
    }

    /** Gatilhos analógicos (L2/R2): alguns controles usam LTRIGGER/RTRIGGER, outros BRAKE/GAS. */
    fun leftTrigger(ev: MotionEvent): Float =
        maxOf(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))

    fun rightTrigger(ev: MotionEvent): Float =
        maxOf(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))

    /** Nome curto de uma tecla, para a tela "Testar controle". */
    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

/**
 * Junta o que o D-pad manda por tecla e por eixo numa direção só e chama [emit] com o KEYCODE_DPAD_* a cada passo:
 * um passo na hora, e repetição (depois de [PadInput.HOLD_MS]) enquanto estiver segurado.
 */
class PadFilter(private val emit: (Int) -> Unit) {
    private val handler = Handler(Looper.getMainLooper())
    private var keyDir = 0
    var axisDir = 0
        private set
    private var cur = 0

    private val tick = object : Runnable {
        override fun run() {
            if (cur == 0) return
            emit(cur)
            handler.postDelayed(this, PadInput.REPEAT_MS)
        }
    }

    fun key(code: Int, down: Boolean) {
        if (down) keyDir = code else if (keyDir == code) keyDir = 0
        update()
    }

    fun axis(code: Int) {
        axisDir = code
        update()
    }

    /** Solta tudo (janela perdeu o foco, tela fechou...). */
    fun reset() {
        keyDir = 0
        axisDir = 0
        cur = 0
        handler.removeCallbacks(tick)
    }

    private fun update() {
        val d = if (keyDir != 0) keyDir else axisDir
        if (d == cur) return
        cur = d
        handler.removeCallbacks(tick)
        if (d != 0) {
            emit(d)
            handler.postDelayed(tick, PadInput.HOLD_MS)
        }
    }
}

/** Envia um "toque" (aperta e solta) de uma tecla para [target]. */
private fun sendTap(target: Window.Callback, code: Int) {
    val t = SystemClock.uptimeMillis()
    target.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
    target.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
}

/**
 * Envolve o tratador de eventos da janela do Dialog: setas e alavanca passam pelo [PadFilter] (um passo por toque,
 * sem duplicar), o botão A vira OK, e as demais teclas de controle vão primeiro para [extra].
 */
private class PadWindowCallback(
    private val orig: Window.Callback,
    private val pad: PadFilter,
    private val extra: (KeyEvent) -> Boolean
) : Window.Callback by orig {

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (PadInput.isDpad(code)) {
            // O auto-repeat do sistema é ignorado: quem repete é o PadFilter.
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) pad.key(code, true)
            } else if (event.action == KeyEvent.ACTION_UP) {
                pad.key(code, false)
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_BUTTON_A) {
            // A = OK (o Compose só reconhece DPAD_CENTER/ENTER como clique).
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0) return true
            return orig.dispatchKeyEvent(
                KeyEvent(event.downTime, event.eventTime, event.action, KeyEvent.KEYCODE_DPAD_CENTER, event.repeatCount)
            )
        }
        if (extra(event)) return true
        return orig.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (PadInput.isJoystick(event) && event.action == MotionEvent.ACTION_MOVE) {
            pad.axis(PadInput.axisDir(event, pad.axisDir))
            return true
        }
        return orig.dispatchGenericMotionEvent(event)
    }
}

/**
 * Chame dentro do conteúdo de um Dialog (junto de HideBarsInDialog). [extra] recebe as teclas que não são setas
 * (L1, R1, L2, R2, Start, Select...) e devolve true se tratou.
 */
@Composable
fun DialogPad(extra: (KeyEvent) -> Boolean = { false }) {
    val view = LocalView.current
    val extraNow by rememberUpdatedState(extra)
    DisposableEffect(view) {
        val win = (view.parent as? DialogWindowProvider)?.window
        val orig = win?.callback
        var pad: PadFilter? = null
        if (win != null && orig != null && orig !is PadWindowCallback) {
            val p = PadFilter { code -> sendTap(orig, code) }
            pad = p
            win.callback = PadWindowCallback(orig, p) { ev -> extraNow(ev) }
        }
        onDispose {
            pad?.reset()
            if (win != null && orig != null && win.callback is PadWindowCallback) win.callback = orig
        }
    }
}


// ---------- Tela "Testar controle" (Configurações > Sistema) ----------

private class PadTestCallback(
    private val orig: Window.Callback,
    private val log: (String) -> Unit
) : Window.Callback by orig {
    private val last = HashMap<Int, Float>()
    private val axes = intArrayOf(
        MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
        MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y,
        MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_BRAKE, MotionEvent.AXIS_GAS
    )

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // "Voltar" do controle remoto continua fechando a tela.
        if (event.keyCode == KeyEvent.KEYCODE_BACK) return orig.dispatchKeyEvent(event)
        val dev = event.device?.name ?: "?"
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            log("TECLA  ${PadInput.keyName(event.keyCode)}  (${event.keyCode})  apertou  [$dev]")
        } else if (event.action == KeyEvent.ACTION_UP) {
            log("TECLA  ${PadInput.keyName(event.keyCode)}  (${event.keyCode})  soltou")
        }
        return true
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (PadInput.isJoystick(event) && event.action == MotionEvent.ACTION_MOVE) {
            for (a in axes) {
                val v = event.getAxisValue(a)
                val prev = last[a] ?: 0f
                if (abs(v - prev) >= 0.25f || (v == 0f && prev != 0f)) {
                    last[a] = v
                    log("EIXO  ${MotionEvent.axisToString(a).removePrefix("AXIS_")}  =  " + String.format(java.util.Locale.US, "%.2f", v))
                }
            }
            return true
        }
        return orig.dispatchGenericMotionEvent(event)
    }
}

/**
 * 4.9.3: mostra, ao vivo, o que o controle manda (código de cada tecla e valor de cada eixo). Serve para conferir
 * em qual modo de conexão o controle está falando e se L1/R1/L2/R2 chegam ao Nexus. Fecha com "Voltar" do controle
 * remoto, tocando em Fechar ou sozinha depois de 30 s sem nenhum botão.
 */
@Composable
fun PadTestDialog(accent: Color, onClose: () -> Unit) {
    val lines = remember { mutableStateListOf<String>() }
    var tick by remember { mutableStateOf(0) }
    val view = LocalView.current
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val dv = LocalView.current
        DisposableEffect(dv) {
            val win = (dv.parent as? DialogWindowProvider)?.window
            val orig = win?.callback
            if (win != null && orig != null && orig !is PadTestCallback) {
                win.callback = PadTestCallback(orig) { msg ->
                    lines.add(msg)
                    while (lines.size > 40) lines.removeAt(0)
                    tick++
                }
            }
            onDispose {
                if (win != null && orig != null && win.callback is PadTestCallback) win.callback = orig
            }
        }
        LaunchedEffect(tick) {
            delay(30000)
            onClose()
        }
        val shape = RoundedCornerShape(16.dp)
        Box(Modifier.fillMaxSize().background(Color(0xCC000000)), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .clip(shape)
                    .background(Color(0xFF141720))
                    .border(1.5.dp, accent.copy(alpha = 0.75f), shape)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Testar controle", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Aperte os botões, as setas, a alavanca e os gatilhos (L1, R1, L2, R2). O que o Nexus recebe aparece abaixo. " +
                        "Para sair: Voltar do controle remoto, ou toque em Fechar (fecha sozinha em 30 s sem botões).",
                    color = Color(0xFF9AA3B5), fontSize = 12.sp
                )
                Spacer(Modifier.height(4.dp))
                val shown = lines.takeLast(14)
                if (shown.isEmpty()) {
                    Text("Nada recebido ainda…", color = Color(0xFF9AA3B5), fontSize = 13.sp)
                } else {
                    for (l in shown.reversed()) {
                        Text(l, color = Color(0xFFE2E8F0), fontSize = 12.sp, maxLines = 1)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.2f))
                        .border(1.dp, accent, RoundedCornerShape(10.dp))
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) { Text("Fechar", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}
