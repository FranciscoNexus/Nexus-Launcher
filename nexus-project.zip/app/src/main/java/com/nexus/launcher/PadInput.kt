package com.nexus.launcher

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.Window
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import kotlinx.coroutines.delay
import android.os.Build
import android.os.VibrationEffect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.abs

/**
 * 4.9.3: camada única de entrada para controle remoto e gamepad.
 *
 * Problemas que ela resolve:
 * - Gamepads (como o GameSir T4 Nova Lite) mandam o D-pad por TECLA e também por EIXO (hat). O Android ainda cria teclas
 *   a partir do eixo, e o mesmo toque virava 2 ou 3 passos (o foco "pulava" botões). Aqui tecla e eixo viram UMA direção só.
 * - Segurar a direção repete em ritmo fixo e suave (o auto-repeat do sistema era irregular).
 * - Nas janelas (Dialog) as teclas L1/R1/L2/R2 não chegavam à MainActivity; agora a própria janela as trata.
 */
object PadInput {
    /** Tempo segurando até começar a repetir, e intervalo da repetição. */
    const val HOLD_MS = 380L
    const val REPEAT_MS = 130L

    private const val ON = 0.6f
    private const val OFF = 0.4f

    fun isDpad(code: Int): Boolean =
        code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

    /** 4.9.17: teclas de controle de jogo (A, B, X, Y, L1, R1, L2, R2, L3, R3, START, SELECT, HOME) e setas. */
    fun isPadKey(code: Int): Boolean = isDpad(code) || code in KeyEvent.KEYCODE_BUTTON_A..KeyEvent.KEYCODE_BUTTON_MODE

    fun isJoystick(ev: MotionEvent): Boolean = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK

    /**
     * Direção (KEYCODE_DPAD_*) indicada pelos eixos do controle: D-pad por eixo (hat) ou alavanca esquerda; 0 = solto.
     * [prev] é a direção anterior (histerese: para soltar basta passar de 40%, para apertar é preciso passar de 60%).
     */
    fun axisDir(ev: MotionEvent, prev: Int): Int {
        val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val sx = ev.getAxisValue(MotionEvent.AXIS_X)
        val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
        val ax = if (abs(hx) > 0.5f) hx else sx
        val ay = if (abs(hy) > 0.5f) hy else sy
        val limit = if (prev != 0) OFF else ON
        if (abs(ax) <= limit && abs(ay) <= limit) return 0
        return if (abs(ax) >= abs(ay)) {
            if (ax > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        } else {
            if (ay > 0) KeyEvent.KEYCODE_DPAD_DOWN else KeyEvent.KEYCODE_DPAD_UP
        }
    }

    /** Gatilhos analógicos (L2/R2): alguns controles usam LTRIGGER/RTRIGGER, outros BRAKE/GAS. */
    fun leftTrigger(ev: MotionEvent): Float =
        maxOf(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))

    fun rightTrigger(ev: MotionEvent): Float =
        maxOf(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))

    /** 4.9.5: primeiro controle de jogo conectado (null se não houver). Controle remoto de TV não conta. */
    fun gamepadDevice(): InputDevice? {
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            if (d.isVirtual) continue
            val src = d.sources
            if ((src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            ) return d
        }
        return null
    }

    /** Nome curto de uma tecla, para a tela "Testar controle". */
    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

/**
 * 4.9.17: ponte entre as janelas (Dialog) e a tela principal. As janelas têm o próprio tratador de teclas e NUNCA
 * passam pela MainActivity; por isso, no celular na horizontal, o controle só funcionava no catálogo e nas abas
 * (L1/R1): ao abrir uma janela com o toque, "controle em uso" estava desligado, ninguém ligava de novo e o foco
 * inicial nunca era dado. Agora a primeira tecla/alavanca de controle numa janela liga o modo controle (e dá o foco
 * inicial); tocar na janela desliga, como na tela principal. Na TV nada disso se aplica.
 */
object PadBridge {
    /** true se o modo controle já está ligado (ou se não se aplica: TV, celular em pé). */
    @Volatile var isActive: (() -> Boolean)? = null
    @Volatile var activate: (() -> Unit)? = null
    @Volatile var touched: (() -> Unit)? = null

    @Volatile var events = 0
    @Volatile var last = "nenhuma tecla de controle chegou a uma janela ainda"

    fun note(touchMode: Boolean, viewFocused: Boolean, windowFocus: Boolean, active: Boolean, nothingFocused: Boolean) {
        events++
        last = "modo toque ${if (touchMode) "sim" else "não"}, foco da vista ${if (viewFocused) "sim" else "não"}, " +
            "janela com foco ${if (windowFocus) "sim" else "não"}, controle ligado antes ${if (active) "sim" else "não"}, " +
            "nenhum item focado ${if (nothingFocused) "sim" else "não"}"
    }

    fun report(): String = "$events teclas/alavancas; última: $last"
}

/**
 * Chamado quando chega a primeira ação de controle numa janela. Sai do "modo toque" do Android, dá o foco de vista ao
 * Compose e, se o modo controle estava desligado, liga e dá o foco inicial. Devolve true se esta ação deve ser
 * engolida (foi usada só para pôr o foco no lugar; evita "apertar A" no item errado).
 */
private fun dialogPadGate(view: View, fm: FocusManager): Boolean {
    if (TvMode.isTv) return false
    val active = PadBridge.isActive?.invoke() ?: true
    val touchMode = view.isInTouchMode
    val viewFocused = view.isFocused
    val nothingFocused = FocusProbe.lastFocusMs == 0L
    PadBridge.note(touchMode, viewFocused, view.hasWindowFocus(), active, nothingFocused)
    try {
        if (touchMode) view.requestFocusFromTouch() else if (!viewFocused) view.requestFocus()
    } catch (_: Throwable) {
    }
    if (!active) PadBridge.activate?.invoke()
    if (!active && nothingFocused) {
        Handler(Looper.getMainLooper()).postDelayed({ FocusProbe.applyOnce(fm) }, 40L)
        return true
    }
    return false
}

/**
 * Junta o que o D-pad manda por tecla e por eixo numa direção só e chama [emit] com o KEYCODE_DPAD_* a cada passo:
 * um passo na hora, e repetição (depois de [PadInput.HOLD_MS]) enquanto estiver segurado.
 */
class PadFilter(private val emit: (Int) -> Unit) {
    private val handler = Handler(Looper.getMainLooper())
    private var keyDir = 0
    var axisDir = 0
        private set
    private var cur = 0

    private val tick = object : Runnable {
        override fun run() {
            if (cur == 0) return
            emit(cur)
            handler.postDelayed(this, PadInput.REPEAT_MS)
        }
    }

    fun key(code: Int, down: Boolean) {
        if (down) keyDir = code else if (keyDir == code) keyDir = 0
        update()
    }

    fun axis(code: Int) {
        axisDir = code
        update()
    }

    /** Solta tudo (janela perdeu o foco, tela fechou...). */
    fun reset() {
        keyDir = 0
        axisDir = 0
        cur = 0
        handler.removeCallbacks(tick)
    }

    private fun update() {
        val d = if (keyDir != 0) keyDir else axisDir
        if (d == cur) return
        cur = d
        handler.removeCallbacks(tick)
        if (d != 0) {
            emit(d)
            handler.postDelayed(tick, PadInput.HOLD_MS)
        }
    }
}

/** Envia um "toque" (aperta e solta) de uma tecla para [target]. */
private fun sendTap(target: Window.Callback, code: Int) {
    val t = SystemClock.uptimeMillis()
    target.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
    target.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
}

/**
 * Envolve o tratador de eventos da janela do Dialog: setas e alavanca passam pelo [PadFilter] (um passo por toque,
 * sem duplicar), o botão A vira OK, e as demais teclas de controle vão primeiro para [extra].
 */
private class PadWindowCallback(
    private val orig: Window.Callback,
    private val pad: PadFilter,
    private val gate: () -> Boolean,
    private val extra: (KeyEvent) -> Boolean
) : Window.Callback by orig {

    /** 4.9.17: tecla engolida na ativação do modo controle (o "soltar" dela também some). */
    private var swallowed = 0

    private val handler = Handler(Looper.getMainLooper())
    private var scrollDir = 0
    private var scrollMag = 0f

    /** 4.9.5: alavanca direita = rolagem rápida de listas (repete setas para cima/baixo, mais rápido quanto mais inclinada). */
    private val scrollTick = object : Runnable {
        override fun run() {
            if (scrollDir == 0) return
            sendTap(orig, scrollDir)
            val gap = (150f - 105f * scrollMag).toLong().coerceIn(40L, 150L)
            handler.postDelayed(this, gap)
        }
    }

    fun stopScroll() {
        scrollDir = 0
        handler.removeCallbacks(scrollTick)
    }

    private fun rightStick(event: MotionEvent) {
        val a = event.getAxisValue(MotionEvent.AXIS_RZ)
        val b = event.getAxisValue(MotionEvent.AXIS_RY)
        val y = if (abs(a) >= abs(b)) a else b
        val dir = when {
            y > 0.35f -> KeyEvent.KEYCODE_DPAD_DOWN
            y < -0.35f -> KeyEvent.KEYCODE_DPAD_UP
            else -> 0
        }
        scrollMag = ((abs(y) - 0.35f) / 0.65f).coerceIn(0f, 1f)
        if (dir == scrollDir) return
        handler.removeCallbacks(scrollTick)
        scrollDir = dir
        if (dir != 0) handler.post(scrollTick)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        // 4.9.17: tocou na janela = volta ao modo toque (sem contorno de navegação), como na tela principal.
        if (event.actionMasked == MotionEvent.ACTION_DOWN) PadBridge.touched?.invoke()
        return orig.dispatchTouchEvent(event)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (event.action == KeyEvent.ACTION_UP && swallowed == code) {
            swallowed = 0
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && PadInput.isPadKey(code)) {
            val eat = gate()
            if (eat && (PadInput.isDpad(code) || code == KeyEvent.KEYCODE_BUTTON_A)) {
                swallowed = code
                return true
            }
        }
        if (PadInput.isDpad(code)) {
            // O auto-repeat do sistema é ignorado: quem repete é o PadFilter.
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) pad.key(code, true)
            } else if (event.action == KeyEvent.ACTION_UP) {
                pad.key(code, false)
            }
            return true
        }
        // 4.9.22: a grade de apps trata o A (toque curto abre, segurar oculta) antes de virar OK.
        if (code == KeyEvent.KEYCODE_BUTTON_A && extra(event)) return true
        if (code == KeyEvent.KEYCODE_BUTTON_A) {
            // A = OK (o Compose só reconhece DPAD_CENTER/ENTER como clique).
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0) return true
            return orig.dispatchKeyEvent(
                KeyEvent(event.downTime, event.eventTime, event.action, KeyEvent.KEYCODE_DPAD_CENTER, event.repeatCount)
            )
        }
        if (code == KeyEvent.KEYCODE_BUTTON_B) {
            // 4.9.5: B = Voltar (a janela só entende a tecla BACK).
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) sendTap(orig, KeyEvent.KEYCODE_BACK)
            return true
        }
        if (extra(event)) return true
        return orig.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (PadInput.isJoystick(event) && event.action == MotionEvent.ACTION_MOVE) {
            val d = PadInput.axisDir(event, pad.axisDir)
            // 4.9.17: só uma direção de verdade ativa o modo controle (o repouso do analógico sempre "mexe" um pouco).
            if (d != 0 && pad.axisDir == 0 && gate()) return true
            pad.axis(d)
            rightStick(event)
            return true
        }
        return orig.dispatchGenericMotionEvent(event)
    }
}

/**
 * Chame dentro do conteúdo de um Dialog (junto de HideBarsInDialog). [extra] recebe as teclas que não são setas
 * (L1, R1, L2, R2, Start, Select...) e devolve true se tratou.
 */
@Composable
fun DialogPad(extra: (KeyEvent) -> Boolean = { false }) {
    val view = LocalView.current
    val fm = LocalFocusManager.current
    val extraNow by rememberUpdatedState(extra)
    DisposableEffect(view) {
        val win = (view.parent as? DialogWindowProvider)?.window
        val orig = win?.callback
        var pad: PadFilter? = null
        var cb: PadWindowCallback? = null
        if (win != null && orig != null && orig !is PadWindowCallback) {
            val p = PadFilter { code -> sendTap(orig, code) }
            pad = p
            val c = PadWindowCallback(orig, p, { dialogPadGate(view, fm) }) { ev -> extraNow(ev) }
            cb = c
            win.callback = c
        }
        onDispose {
            pad?.reset()
            cb?.stopScroll()
            if (win != null && orig != null && win.callback is PadWindowCallback) win.callback = orig
        }
    }
}


// ---------- Tela "Testar controle" (Configurações > Sistema) ----------

private const val PT_BINS = 24

/** 4.9.4: tudo o que o teste mede, ao vivo. */
private class PadTestState {
    val down = mutableStateMapOf<Int, Boolean>()
    val tested = mutableStateMapOf<Int, Boolean>()
    var lx by mutableStateOf(0f)
    var ly by mutableStateOf(0f)
    var rx by mutableStateOf(0f)
    var ry by mutableStateOf(0f)
    var lt by mutableStateOf(0f)
    var rt by mutableStateOf(0f)
    var hx by mutableStateOf(0f)
    var hy by mutableStateOf(0f)
    var ltMax by mutableStateOf(0f)
    var rtMax by mutableStateOf(0f)
    var ltAnalog by mutableStateOf(false)
    var rtAnalog by mutableStateOf(false)
    val lBins = FloatArray(PT_BINS)
    val rBins = FloatArray(PT_BINS)
    var rev by mutableStateOf(0)
    var lRestX by mutableStateOf(Float.NaN)
    var lRestY by mutableStateOf(Float.NaN)
    var rRestX by mutableStateOf(Float.NaN)
    var rRestY by mutableStateOf(Float.NaN)
    var deviceId by mutableStateOf(-1)
    var deviceName by mutableStateOf("")
    var anyInput by mutableStateOf(0)

    /** 4.9.11: a tela abre PARADA; só captura o controle (gamepad) depois de "Iniciar teste". */
    var running by mutableStateOf(false)

    fun reset() {
        down.clear(); tested.clear()
        lx = 0f; ly = 0f; rx = 0f; ry = 0f; lt = 0f; rt = 0f; hx = 0f; hy = 0f
        ltMax = 0f; rtMax = 0f; ltAnalog = false; rtAnalog = false
        java.util.Arrays.fill(lBins, 0f); java.util.Arrays.fill(rBins, 0f)
        lRestX = Float.NaN; lRestY = Float.NaN; rRestX = Float.NaN; rRestY = Float.NaN
        rev++
    }

    fun key(code: Int, isDown: Boolean) {
        if (isDown) { down[code] = true; tested[code] = true } else down[code] = false
        anyInput++
    }

    private fun bin(b: FloatArray, x: Float, y: Float) {
        val r = hypot(x, y)
        if (r < 0.2f) return
        val a = atan2(y, x)
        var i = ((a + Math.PI) / (2 * Math.PI) * PT_BINS).toInt()
        if (i >= PT_BINS) i = PT_BINS - 1
        if (i < 0) i = 0
        if (r > b[i]) b[i] = minOf(r, 1.2f)
    }

    fun motion(ev: MotionEvent) {
        deviceId = ev.deviceId
        deviceName = ev.device?.name ?: ""
        fun ax(a: Int) = ev.getAxisValue(a)
        lx = ax(MotionEvent.AXIS_X); ly = ax(MotionEvent.AXIS_Y)
        val zx = ax(MotionEvent.AXIS_Z); val rxx = ax(MotionEvent.AXIS_RX)
        val rzy = ax(MotionEvent.AXIS_RZ); val ryy = ax(MotionEvent.AXIS_RY)
        rx = if (abs(zx) >= abs(rxx)) zx else rxx
        ry = if (abs(rzy) >= abs(ryy)) rzy else ryy
        lt = max(ax(MotionEvent.AXIS_LTRIGGER), ax(MotionEvent.AXIS_BRAKE))
        rt = max(ax(MotionEvent.AXIS_RTRIGGER), ax(MotionEvent.AXIS_GAS))
        hx = ax(MotionEvent.AXIS_HAT_X); hy = ax(MotionEvent.AXIS_HAT_Y)
        if (hx < -0.5f) tested[KeyEvent.KEYCODE_DPAD_LEFT] = true
        if (hx > 0.5f) tested[KeyEvent.KEYCODE_DPAD_RIGHT] = true
        if (hy < -0.5f) tested[KeyEvent.KEYCODE_DPAD_UP] = true
        if (hy > 0.5f) tested[KeyEvent.KEYCODE_DPAD_DOWN] = true
        if (lt > ltMax) ltMax = lt
        if (rt > rtMax) rtMax = rt
        if (lt in 0.08f..0.92f) ltAnalog = true
        if (rt in 0.08f..0.92f) rtAnalog = true
        bin(lBins, lx, ly)
        bin(rBins, rx, ry)
        if (hypot(lx, ly) < 0.25f) { lRestX = lx; lRestY = ly }
        if (hypot(rx, ry) < 0.25f) { rRestX = rx; rRestY = ry }
        rev++
        anyInput++
    }
}

private class PadTestCallback(
    private val orig: Window.Callback,
    private val st: PadTestState,
    private val view: View
) : Window.Callback by orig {
    /** Só o que vem de um gamepad/joystick é capturado; controle remoto (teclado/DPAD) nunca é. */
    private fun fromPad(src: Int): Boolean =
        (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // "Voltar" (controle remoto ou gesto) continua fechando a tela, com teste rodando ou não.
        if (event.keyCode == KeyEvent.KEYCODE_BACK) return orig.dispatchKeyEvent(event)
        val pad = fromPad(event.source)
        // 4.9.17: celular em "modo toque": o primeiro botão do controle sai dele, para as setas moverem o foco.
        if (pad && !st.running && !TvMode.isTv && event.action == KeyEvent.ACTION_DOWN && view.isInTouchMode) {
            try { view.requestFocusFromTouch() } catch (_: Throwable) {}
        }
        if (st.running && pad) {
            st.deviceId = event.deviceId
            st.deviceName = event.device?.name ?: st.deviceName
            if (event.action == KeyEvent.ACTION_DOWN) st.key(event.keyCode, true)
            else if (event.action == KeyEvent.ACTION_UP) st.key(event.keyCode, false)
            return true
        }
        // Parado: o gamepad navega pelos botões (A = confirmar), como nas outras janelas.
        if (pad && (event.keyCode == KeyEvent.KEYCODE_BUTTON_A || event.keyCode == KeyEvent.KEYCODE_BUTTON_B)) {
            val code = if (event.keyCode == KeyEvent.KEYCODE_BUTTON_A) KeyEvent.KEYCODE_DPAD_CENTER else KeyEvent.KEYCODE_BACK
            val ev = KeyEvent(event.downTime, event.eventTime, event.action, code, event.repeatCount, event.metaState,
                event.deviceId, event.scanCode, event.flags, event.source)
            return orig.dispatchKeyEvent(ev)
        }
        return orig.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (st.running && PadInput.isJoystick(event) && event.action == MotionEvent.ACTION_MOVE) {
            st.motion(event)
            return true
        }
        return orig.dispatchGenericMotionEvent(event)
    }
}

private fun padKeyLabel(code: Int): String = when (code) {
    KeyEvent.KEYCODE_BUTTON_A -> "A"
    KeyEvent.KEYCODE_BUTTON_B -> "B"
    KeyEvent.KEYCODE_BUTTON_X -> "X"
    KeyEvent.KEYCODE_BUTTON_Y -> "Y"
    KeyEvent.KEYCODE_BUTTON_L1 -> "L1"
    KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
    KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
    KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
    KeyEvent.KEYCODE_BUTTON_THUMBL -> "L3 (analógico esquerdo)"
    KeyEvent.KEYCODE_BUTTON_THUMBR -> "R3 (analógico direito)"
    KeyEvent.KEYCODE_BUTTON_START -> "START"
    KeyEvent.KEYCODE_BUTTON_SELECT -> "SELECT"
    KeyEvent.KEYCODE_BUTTON_MODE -> "HOME"
    KeyEvent.KEYCODE_DPAD_UP -> "Cima"
    KeyEvent.KEYCODE_DPAD_DOWN -> "Baixo"
    KeyEvent.KEYCODE_DPAD_LEFT -> "Esquerda"
    KeyEvent.KEYCODE_DPAD_RIGHT -> "Direita"
    else -> PadInput.keyName(code)
}

/** Botões que contam no resultado (os que existem em praticamente todo controle). */
private val PT_BUTTONS = intArrayOf(
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT
)
private val PT_DPAD = intArrayOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT
)

private fun padVibrate(deviceId: Int): Boolean {
    return try {
        val d = InputDevice.getDevice(deviceId) ?: return false
        if (Build.VERSION.SDK_INT >= 31) {
            val v = d.vibratorManager.defaultVibrator
            if (!v.hasVibrator()) return false
            v.vibrate(VibrationEffect.createOneShot(450, VibrationEffect.DEFAULT_AMPLITUDE))
            true
        } else {
            @Suppress("DEPRECATION")
            val v = d.vibrator
            if (!v.hasVibrator()) return false
            @Suppress("DEPRECATION")
            v.vibrate(450)
            true
        }
    } catch (_: Throwable) {
        false
    }
}

private fun f2(v: Float): String = if (v.isNaN()) "—" else String.format(java.util.Locale.US, "%+.2f", v)

private fun coverage(b: FloatArray): Int = b.count { it >= 0.85f }

private fun roundness(b: FloatArray): Int? {
    if (coverage(b) < PT_BINS - 3) return null
    val vals = b.filter { it > 0.3f }
    if (vals.isEmpty()) return null
    return (vals.min() / vals.max() * 100f).toInt()
}

/**
 * 4.9.4: teste completo do controle. A imagem do controle acende (na cor de destaque) o botão apertado, uma legenda
 * diz qual é, e ao lado ficam as medidas: posição e redondeza dos analógicos, repouso (drift), gatilhos e resultado.
 * Sai com "Voltar" do controle remoto, tocando em Fechar ou segurando SELECT + START por 1,5 s.
 */
@Composable
fun PadTestDialog(accent: Color, onClose: () -> Unit) {
    val st = remember {
        PadTestState().also { t ->
            PadInput.gamepadDevice()?.let { d -> t.deviceId = d.id; t.deviceName = d.name ?: "" }
        }
    }
    val ctx = LocalContext.current
    val startReq = remember { FocusRequester() }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val dv = LocalView.current
        // 4.9.11: abre PARADA, com o foco em "Iniciar teste".
        LaunchedEffect(Unit) { delay(150); startReq.requestFocusSafe() }
        DisposableEffect(dv) {
            val win = (dv.parent as? DialogWindowProvider)?.window
            val orig = win?.callback
            if (win != null && orig != null && orig !is PadTestCallback) win.callback = PadTestCallback(orig, st, dv)
            onDispose {
                if (win != null && orig != null && win.callback is PadTestCallback) win.callback = orig
            }
        }
        val exitCombo = st.down[KeyEvent.KEYCODE_BUTTON_SELECT] == true && st.down[KeyEvent.KEYCODE_BUTTON_START] == true
        // 4.9.11: SELECT + START por 1,5 s ENCERRA O TESTE (a tela continua aberta, com o resultado).
        LaunchedEffect(exitCombo, st.running) {
            if (exitCombo && st.running) {
                delay(1500)
                st.running = false
                st.down.clear()
                startReq.requestFocusSafe()
            }
        }
        // 90 s sem apertar nada: encerra o teste (não fecha a tela).
        LaunchedEffect(st.anyInput, st.running) {
            if (st.running) {
                delay(90000)
                st.running = false
                st.down.clear()
                startReq.requestFocusSafe()
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
                if (maxWidth > maxHeight) {
                    // 4.9.7: duas colunas, sem rolagem. O tamanho dos analógicos acompanha a altura disponível
                    // (na TV de 1080p com a interface ampliada a altura útil é de uns 390 dp).
                    val compact = maxHeight < 560.dp
                    val dial = (maxHeight - 270.dp).coerceIn(64.dp, 104.dp)
                    val gap = if (compact) 6.dp else 10.dp
                    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Column(
                            Modifier.weight(1f).fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
                        ) {
                            PadFigure(st, accent, Modifier.weight(1f, fill = false))
                            PadResults(st, accent, compact)
                        }
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(gap)) {
                            PadHeader(st, accent, ctx, onClose, startReq)
                            Column(
                                Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                PadSticksAndTriggers(st, accent, dial, gap)
                                PadExitHint(st, accent)
                            }
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PadFigure(st, accent, Modifier.fillMaxWidth())
                        PadPanel(st, accent, ctx, onClose, startReq, Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

@Composable
private fun PadFigure(st: PadTestState, accent: Color, modifier: Modifier) {
    val caption = run {
        val names = ArrayList<String>()
        for ((code, on) in st.down) if (on) names.add(padKeyLabel(code))
        if (st.lt > 0.1f && names.none { it == "L2" }) names.add("L2 ${(st.lt * 100).toInt()}%")
        if (st.rt > 0.1f && names.none { it == "R2" }) names.add("R2 ${(st.rt * 100).toInt()}%")
        if (st.hx < -0.5f) names.add("Esquerda") else if (st.hx > 0.5f) names.add("Direita")
        if (st.hy < -0.5f) names.add("Cima") else if (st.hy > 0.5f) names.add("Baixo")
        if (names.isEmpty()) "Aperte um botão" else names.joinToString(" + ")
    }
    BoxWithConstraints(modifier.aspectRatio(1024f / 720f)) {
        val w = maxWidth
        val h = maxHeight
        Image(
            painter = painterResource(R.drawable.pad_generic), contentDescription = null,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Canvas(Modifier.fillMaxSize()) {
            val k = size.width / 1024f
            val oy = 152f
            fun p(x: Float, y: Float) = Offset(x * k, (y - oy) * k)
            fun dn(c: Int) = st.down[c] == true
            fun disc(on: Boolean, x: Float, y: Float, r: Float) {
                if (!on) return
                drawCircle(color = accent.copy(alpha = 0.28f), radius = r * 1.7f * k, center = p(x, y))
                drawCircle(color = accent.copy(alpha = 0.92f), radius = r * k, center = p(x, y))
            }
            fun bar(on: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
                if (on <= 0.02f) return
                drawLine(color = accent.copy(alpha = 0.25f * on), start = p(x1, y1), end = p(x2, y2), strokeWidth = 26f * k, cap = StrokeCap.Round)
                drawLine(color = accent.copy(alpha = 0.95f * on), start = p(x1, y1), end = p(x2, y2), strokeWidth = 11f * k, cap = StrokeCap.Round)
            }
            fun ring(on: Boolean, x: Float, y: Float, r: Float) {
                if (!on) return
                drawCircle(color = accent.copy(alpha = 0.95f), radius = r * k, center = p(x, y), style = Stroke(width = 11f * k))
            }
            // botões de ação
            disc(dn(KeyEvent.KEYCODE_BUTTON_Y), 748f, 300f, 30f)
            disc(dn(KeyEvent.KEYCODE_BUTTON_B), 806f, 358f, 30f)
            disc(dn(KeyEvent.KEYCODE_BUTTON_A), 748f, 413f, 30f)
            disc(dn(KeyEvent.KEYCODE_BUTTON_X), 690f, 358f, 30f)
            // direcional (tecla ou eixo)
            disc(dn(KeyEvent.KEYCODE_DPAD_UP) || st.hy < -0.5f, 395f, 430f, 24f)
            disc(dn(KeyEvent.KEYCODE_DPAD_DOWN) || st.hy > 0.5f, 395f, 525f, 24f)
            disc(dn(KeyEvent.KEYCODE_DPAD_LEFT) || st.hx < -0.5f, 345f, 478f, 24f)
            disc(dn(KeyEvent.KEYCODE_DPAD_RIGHT) || st.hx > 0.5f, 445f, 478f, 24f)
            // SELECT / START / HOME
            disc(dn(KeyEvent.KEYCODE_BUTTON_SELECT), 422f, 283f, 17f)
            disc(dn(KeyEvent.KEYCODE_BUTTON_START), 600f, 280f, 17f)
            disc(dn(KeyEvent.KEYCODE_BUTTON_MODE), 512f, 345f, 20f)
            // ombros
            bar(if (dn(KeyEvent.KEYCODE_BUTTON_L1)) 1f else 0f, 205f, 250f, 360f, 205f)
            bar(if (dn(KeyEvent.KEYCODE_BUTTON_R1)) 1f else 0f, 665f, 205f, 820f, 262f)
            bar(if (dn(KeyEvent.KEYCODE_BUTTON_L2)) 1f else st.lt, 215f, 222f, 355f, 178f)
            bar(if (dn(KeyEvent.KEYCODE_BUTTON_R2)) 1f else st.rt, 665f, 178f, 815f, 222f)
            // analógicos: apertar (L3/R3) e posição ao vivo
            ring(dn(KeyEvent.KEYCODE_BUTTON_THUMBL), 270f, 350f, 90f)
            ring(dn(KeyEvent.KEYCODE_BUTTON_THUMBR), 630f, 462f, 88f)
            if (hypot(st.lx, st.ly) > 0.06f) {
                drawCircle(color = accent, radius = 17f * k, center = p(270f + st.lx * 40f, 350f + st.ly * 40f))
            }
            if (hypot(st.rx, st.ry) > 0.06f) {
                drawCircle(color = accent, radius = 17f * k, center = p(630f + st.rx * 40f, 462f + st.ry * 40f))
            }
        }
        // legenda do botão apertado: no vão entre as duas empunhaduras
        Box(
            modifier = Modifier
                .offset(x = w * (512f - 190f) / 1024f, y = h * (690f - 152f) / 720f)
                .width(w * 380f / 1024f),
            contentAlignment = Alignment.Center
        ) {
            Text(
                caption, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 2
            )
        }
    }
}

@Composable
private fun StickTest(title: String, x: Float, y: Float, bins: FloatArray, rev: Int, restX: Float, restY: Float, accent: Color, modifier: Modifier, dial: androidx.compose.ui.unit.Dp = 104.dp) {
    val cov = coverage(bins)
    val round = roundness(bins)
    val drift = !restX.isNaN() && (abs(restX) > 0.08f || abs(restY) > 0.08f)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = Color(0xFF9AA3B5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Canvas(Modifier.size(dial)) {
            val r = size.minDimension / 2f * 0.92f
            val c = Offset(size.width / 2f, size.height / 2f)
            val unused = rev
            drawCircle(color = Color.White.copy(alpha = 0.35f), radius = r, center = c, style = Stroke(width = 2f))
            drawCircle(color = Color.White.copy(alpha = 0.15f), radius = r * 0.5f, center = c, style = Stroke(width = 1.5f))
            drawLine(color = Color.White.copy(alpha = 0.2f), start = Offset(c.x - r, c.y), end = Offset(c.x + r, c.y), strokeWidth = 1.5f)
            drawLine(color = Color.White.copy(alpha = 0.2f), start = Offset(c.x, c.y - r), end = Offset(c.x, c.y + r), strokeWidth = 1.5f)
            val path = Path()
            var started = false
            for (i in 0 until PT_BINS) {
                val a = -Math.PI + (i + 0.5) * 2.0 * Math.PI / PT_BINS
                val rr = bins[i].coerceAtMost(1.1f) * r
                if (bins[i] <= 0f) continue
                val pt = Offset(c.x + (cos(a) * rr).toFloat(), c.y + (sin(a) * rr).toFloat())
                if (!started) { path.moveTo(pt.x, pt.y); started = true } else path.lineTo(pt.x, pt.y)
            }
            if (started) {
                path.close()
                drawPath(path = path, color = accent.copy(alpha = 0.18f))
                drawPath(path = path, color = accent.copy(alpha = 0.9f), style = Stroke(width = 2.5f))
            }
            drawCircle(color = accent, radius = 6f, center = Offset(c.x + x.coerceIn(-1.2f, 1.2f) * r, c.y + y.coerceIn(-1.2f, 1.2f) * r))
        }
        Text("X ${f2(x)}  Y ${f2(y)}", color = Color.White, fontSize = 11.sp)
        Text(
            "Volta: ${cov * 100 / PT_BINS}%" + (if (round != null) " · redondo $round%" else ""),
            color = Color(0xFFCBD2E0), fontSize = 10.sp
        )
        Text(
            if (restX.isNaN()) "Repouso: —" else "Repouso: ${f2(restX)} ${f2(restY)} " + (if (drift) "(desvio)" else "(ok)"),
            color = if (drift) Color(0xFFFF6B81) else Color(0xFFCBD2E0), fontSize = 10.sp
        )
    }
}

@Composable
private fun TriggerBar(label: String, v: Float, vMax: Float, analog: Boolean, accent: Color, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = Color(0xFF9AA3B5), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${(v * 100).toInt()}%", color = Color.White, fontSize = 11.sp)
        }
        Box(Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF1A1E29))) {
            Box(Modifier.fillMaxWidth(v.coerceIn(0f, 1f)).height(9.dp).background(accent))
        }
        Text(
            if (vMax < 0.05f) "sem sinal" else "máx ${(vMax * 100).toInt()}% · " + (if (analog) "analógico" else "liga/desliga"),
            color = Color(0xFFCBD2E0), fontSize = 10.sp
        )
    }
}

// 4.9.7: o painel foi dividido em pedaços para a paisagem poder usar duas colunas sem rolagem
// (esquerda: desenho + resultados; direita: cabeçalho, analógicos e gatilhos).
@Composable
private fun PadHeader(st: PadTestState, accent: Color, ctx: android.content.Context, onClose: () -> Unit, startReq: FocusRequester) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Column(Modifier.weight(1f)) {
            Text("Testar controle", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(
                if (st.deviceName.isBlank()) (if (st.running) "Aperte qualquer botão" else "Parado") else st.deviceName,
                color = Color(0xFF9AA3B5), fontSize = 11.sp, maxLines = 1
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (st.running) Color(0xFF1A1E29) else accent.copy(alpha = 0.18f))
                .border(1.dp, accent, RoundedCornerShape(10.dp))
                .focusRequester(startReq)
                .shapedFocusRing(RoundedCornerShape(10.dp))
                .clickable {
                    if (st.running) { st.running = false; st.down.clear() }
                    else { st.reset(); st.running = true; st.anyInput++ }
                }
                .padding(horizontal = 11.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text(if (st.running) "Parar" else "Iniciar teste", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF1A1E29))
                .shapedFocusRing(RoundedCornerShape(10.dp))
                .clickable {
                    val ok = st.deviceId >= 0 && padVibrate(st.deviceId)
                    android.widget.Toast.makeText(
                        ctx,
                        if (ok) "Vibrando…" else if (st.deviceId < 0) "Aperte um botão do controle antes" else "Este controle não vibra",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                .padding(horizontal = 11.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text("Vibrar", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF1A1E29))
                .shapedFocusRing(RoundedCornerShape(10.dp))
                .clickable { st.reset() }
                .padding(horizontal = 11.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text("Zerar", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(accent.copy(alpha = 0.18f))
                .border(1.dp, accent, RoundedCornerShape(10.dp))
                .shapedFocusRing(RoundedCornerShape(10.dp))
                .clickable { onClose() }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) { Text("Fechar", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
    }
}

@Composable
private fun PadSticksAndTriggers(st: PadTestState, accent: Color, dial: androidx.compose.ui.unit.Dp, gap: androidx.compose.ui.unit.Dp) {
    val rev = st.rev
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(gap)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StickTest("ANALÓGICO ESQUERDO", st.lx, st.ly, st.lBins, rev, st.lRestX, st.lRestY, accent, Modifier.weight(1f), dial)
            StickTest("ANALÓGICO DIREITO", st.rx, st.ry, st.rBins, rev, st.rRestX, st.rRestY, accent, Modifier.weight(1f), dial)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TriggerBar("L2", maxOf(st.lt, if (st.down[KeyEvent.KEYCODE_BUTTON_L2] == true) 1f else 0f), st.ltMax, st.ltAnalog, accent, Modifier.weight(1f))
            TriggerBar("R2", maxOf(st.rt, if (st.down[KeyEvent.KEYCODE_BUTTON_R2] == true) 1f else 0f), st.rtMax, st.rtAnalog, accent, Modifier.weight(1f))
        }
    }
}

@Composable
private fun PadResults(st: PadTestState, accent: Color, compact: Boolean) {
    val btnsDone = PT_BUTTONS.count { st.tested[it] == true }
    val dpadDone = PT_DPAD.all { st.tested[it] == true }
    val lDone = coverage(st.lBins) >= PT_BINS - 3
    val rDone = coverage(st.rBins) >= PT_BINS - 3
    val trigDone = (st.ltMax > 0.9f || st.tested[KeyEvent.KEYCODE_BUTTON_L2] == true) &&
        (st.rtMax > 0.9f || st.tested[KeyEvent.KEYCODE_BUTTON_R2] == true)
    val all = btnsDone == PT_BUTTONS.size && dpadDone && lDone && rDone && trigDone
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF10131B)).border(1.dp, Color(0xFF232838), shape).padding(if (compact) 8.dp else 10.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 1.dp else 3.dp)
    ) {
        @Composable
        fun line(ok: Boolean, text: String) {
            Text((if (ok) "✓  " else "○  ") + text, color = if (ok) accent else Color(0xFF9AA3B5), fontSize = 12.sp)
        }
        line(btnsDone == PT_BUTTONS.size, "Botões ($btnsDone/${PT_BUTTONS.size})")
        line(dpadDone, "Direcional (4 direções)")
        line(lDone, "Analógico esquerdo (gire no limite)")
        line(rDone, "Analógico direito (gire no limite)")
        line(trigDone, "Gatilhos L2 e R2 (aperte até o fim)")
        Spacer(Modifier.height(if (compact) 2.dp else 4.dp))
        Text(
            if (all) "Resultado: tudo certo. O controle está funcionando bem." else "Resultado: teste os itens que faltam.",
            color = if (all) accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PadExitHint(st: PadTestState, accent: Color) {
    Text(
        if (st.running) "Testando: todos os botões do controle estão sendo capturados. Para encerrar o teste, segure SELECT + START por 1,5 s."
        else "Toque ou use o controle remoto em \"Iniciar teste\" e depois aperte os botões do controle.",
        color = if (st.running) accent else Color(0xFF9AA3B5), fontSize = 10.sp
    )
}

/** Painel em coluna única (retrato): cabeçalho, analógicos, gatilhos, resultados e dica. */
@Composable
private fun PadPanel(st: PadTestState, accent: Color, ctx: android.content.Context, onClose: () -> Unit, startReq: FocusRequester, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PadHeader(st, accent, ctx, onClose, startReq)
        PadSticksAndTriggers(st, accent, 104.dp, 10.dp)
        PadResults(st, accent, false)
        PadExitHint(st, accent)
    }
}

private fun FocusRequester.requestFocusSafe() {
    try { requestFocus() } catch (_: Exception) { }
}
