package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.AppFilterDialog(kind: Int) {
    val games = kind == 1
    val hidden = if (games) hiddenGameApps else hiddenEmuApps
    val accent = parseColor(accentHex)
    var q by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    val k = foldText(q.trim())
    val list = if (k.isEmpty()) allApps else allApps.filter {
        foldText(it.label).contains(k) || foldText(appShownName(it)).contains(k) || it.pkg.lowercase().contains(k)
    }
    NexusModal(if (games) "Apps de jogos" else "Apps emuladores", { appFilterKind = 0 }, tall = true) {
        val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Text(
            if (games) "Ligado = aparece ao adicionar um jogo Android. Use o lápis para dar o nome real do jogo."
            else "Ligado = aparece como opção de emulador.",
            color = C_MUTED, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Ligar todos", C_GRAY, Modifier.weight(1f)) {
                list.forEach { hidden.remove(it.pkg) }
                savePrefs()
            }
            CButton("Desligar todos", C_GRAY, Modifier.weight(1f)) {
                list.forEach { if (it.pkg !in hidden) hidden.add(it.pkg) }
                savePrefs()
            }
        }
        Spacer(Modifier.height(6.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(list, key = { it.pkg }) { a ->
                val on = a.pkg !in hidden
                Row(
                    modifier = Modifier.fillMaxWidth().cardRow(null),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppIcon(a.pkg)
                    if (editing == a.pkg) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            CField(editText, { editText = it }, "Nome do jogo", Modifier.fillMaxWidth(), wrap = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CButton("✔ Salvar", C_BLUE, Modifier.weight(1f)) {
                                    val t = editText.trim()
                                    if (t.isEmpty() || t == a.label) appAliases.remove(a.pkg) else appAliases[a.pkg] = t
                                    savePrefs()
                                    editing = null
                                }
                                CButton("✖ Cancelar", C_GRAY, Modifier.weight(1f)) { editing = null }
                            }
                        }
                    } else {
                        Column(Modifier.weight(1f)) {
                            MarqueeText(if (games) appShownName(a) else a.label, Color.White, 14, FontWeight.Normal)
                            if (games && appAliases[a.pkg] != null) {
                                Text(a.label, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (games) MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) {
                            editing = a.pkg
                            editText = appShownName(a)
                        }
                        Box(
                            modifier = Modifier.clip(RoundedCornerShape(14.dp)).focusGlow(RoundedCornerShape(14.dp)).clickable {
                                if (on) hidden.add(a.pkg) else hidden.remove(a.pkg)
                                savePrefs()
                            }
                        ) { SSwitch(on, accent) }
                    }
                }
            }
        }
        }
        if (landscape) {
            Panes(0.38f, {
                topUi()
                Spacer(Modifier.height(8.dp))
                CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appFilterKind = 0 }
            }, { listUi() })
        } else {
            topUi()
            listUi()
        Spacer(Modifier.height(8.dp))
        CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appFilterKind = 0 }
        }
    }
}

@Composable
internal fun MainActivity.AppPickerDialog() {
    var q by remember { mutableStateOf("") }
    val k = foldText(q.trim())
    val base = appsForPicker(appPickerMode)
    val filtered = if (k.isEmpty()) base else base.filter {
        foldText(it.label).contains(k) || it.pkg.lowercase().contains(k)
    }
    NexusModal("Escolher app", { appPickerOpen = false }, tall = true) {
        val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        LazyColumn(modifier = Modifier.weight(1f)) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .cardRow {
                            appPickerCb?.invoke(null)
                            appPickerOpen = false
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚙️  $appPickerNone", color = C_BLUE, fontSize = 14.sp)
                }
            }
            if (filtered.isEmpty()) {
                item {
                    Text(
                        if (appPickerMode == 0) "Nenhum app encontrado."
                        else "Nenhum app ligado. Ligue em Configurações > Biblioteca > Apps de " +
                            (if (appPickerMode == 1) "jogos." else "emuladores."),
                        color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp)
                    )
                }
            }
            items(filtered, key = { it.pkg }) { a ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .initialFocus(a.pkg == filtered.first().pkg)
                        .cardRow {
                            appPickerCb?.invoke(a)
                            appPickerOpen = false
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(a.pkg)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        MarqueeText(a.label, Color.White, 14, FontWeight.Normal)
                        Text(a.pkg, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        }
        val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
        Spacer(Modifier.height(8.dp))
        CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { appPickerOpen = false }
        }
        if (landscape) {
            Panes(0.36f, {
                topUi()
                botUi()
            }, { listUi() })
        } else {
            topUi()
            listUi()
            botUi()
        }
    }
}

// Lista de TODOS os apps do aparelho (o "Apps ocultos" do modo launcher): tocar abre o app.
@Composable
internal fun MainActivity.AppsDrawerDialog() {
    var q by remember { mutableStateOf("") }
    val apps = remember { loadApps().filter { it.pkg != packageName } }
    val k = foldText(q.trim())
    val list = if (k.isEmpty()) apps else apps.filter { foldText(it.label).contains(k) || it.pkg.lowercase().contains(k) }
    NexusModal("Apps ocultos", { appsDrawerOpen = false }, tall = true) {
        val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Text(
                "Todos os apps instalados. Toque para abrir. O botão ⓘ abre as informações do app no Android.",
                color = C_MUTED, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))
            CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text("${list.size} apps", color = C_MUTED, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow { launchApp(a.pkg) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppIcon(a.pkg)
                        Column(Modifier.weight(1f)) {
                            MarqueeText(a.label, Color.White, 14, FontWeight.Normal)
                        }
                        MiniIcon("ⓘ", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { openAppInfo(a.pkg) }
                    }
                }
            }
        }
        if (landscape) {
            Panes(0.38f, {
                topUi()
                Spacer(Modifier.height(8.dp))
                CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appsDrawerOpen = false }
            }, { listUi() })
        } else {
            topUi()
            listUi()
            Spacer(Modifier.height(8.dp))
            CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appsDrawerOpen = false }
        }
    }
}

@Composable
internal fun MainActivity.StoragePromptDialog() {
    NexusModal("Acesso ao armazenamento", { back() }) {
        Text(
            "Para ler suas pastas de ROMs e abrir os jogos nos emuladores, permita o acesso a todos os arquivos. " +
                "Isso também faz funcionar as pastas que vierem de um backup importado.",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        CButton("Permitir acesso", C_BLUE, Modifier.fillMaxWidth()) {
            overlay = Overlay.None
            askStorage()
            maybeWelcome()
        }
        Spacer(Modifier.height(8.dp))
        CButton("Agora não", C_GRAY, Modifier.fillMaxWidth()) {
            overlay = Overlay.None
            maybeWelcome()
        }
    }
}

// 4.7.0: trocar o vídeo do jogo colando um link do YouTube (ou buscar de novo / remover).
@Composable
internal fun MainActivity.VideoLinkDialog(g: Game) {
    var link by remember { mutableStateOf("") }
    val cur = games.firstOrNull { it.id == g.id } ?: g
    NexusModal("Vídeo gameplay", { videoLinkFor = null }) {
        Text(
            if (cur.videoId.isNotEmpty()) "Vídeo atual: " + cur.videoTitle.ifBlank { "youtu.be/" + cur.videoId } else "Nenhum vídeo salvo para este jogo.",
            color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(link, { link = it.trim() }, "Cole o link do vídeo do YouTube", Modifier.weight(1f), mic = false)
            CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                val t = clipboardText()
                if (t.isEmpty()) toast("Nada copiado para colar") else link = t
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Salvar link", C_BLUE, Modifier.weight(1f)) {
                val vid = YouTubeApi.parseId(link)
                if (vid == null) toast("Link do YouTube não reconhecido")
                else {
                    replaceGame(cur.copy(videoId = vid, videoTitle = "", videoTried = System.currentTimeMillis()))
                    toast("Vídeo salvo")
                    videoLinkFor = null
                }
            }
            CButton("Buscar de novo", C_GRAY, Modifier.weight(1f)) {
                if (ytKey.isBlank()) toast("Adicione sua chave do YouTube em Configurações > Sistema")
                else {
                    val cleared = cur.copy(videoId = "", videoTitle = "", videoTried = 0L)
                    replaceGame(cleared)
                    ensureVideo(cleared, force = true)
                    toast("Buscando vídeo…")
                    videoLinkFor = null
                }
            }
        }
        if (cur.videoId.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            CButton("Remover vídeo", C_RED, Modifier.fillMaxWidth()) {
                // videoTried > 0: não busca sozinho de novo; o botão nos detalhes permite buscar quando o usuário quiser.
                replaceGame(cur.copy(videoId = "", videoTitle = "", videoTried = System.currentTimeMillis()))
                videoLinkFor = null
            }
        }
    }
}

@Composable
internal fun MainActivity.ConfirmDeleteDialog(g: Game) {
    NexusModal("Apagar jogo?", { overlay = Overlay.Edit(g) }) {
        Text(
            "Apagar \"${g.title}\" da biblioteca? Essa ação não pode ser desfeita.",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Cancelar", C_GRAY, Modifier.weight(1f).initialFocus()) { overlay = Overlay.Edit(g) }
            CButton("Apagar", C_RED, Modifier.weight(1f)) { deleteGame(g) }
        }
    }
}

/**
 * 4.9.18: o atalho do jogo (ex.: GameHub) não existe mais para o Nexus (backup restaurado, dados limpos, reinstalação).
 * Explica, e "Recriar agora" mostra os passos (o assistente automático completo vem na 4.9.19).
 */
@Composable
internal fun MainActivity.ShortcutFixDialog(g: Game) {
    var step by remember { mutableStateOf(0) }
    val appName = allApps.firstOrNull { it.pkg == g.pkg }?.label ?: "app do jogo"
    val isHub = g.pkg == GAMEHUB_PKG
    val note = Color(0xFFCBD2E0)
    RefocusOnStep(step)
    NexusModal(
        if (step == 0) "Atalho precisa ser recriado" else "Recriar o atalho",
        { if (step == 1) step = 0 else shortcutFix = null }
    ) {
        if (step == 0) {
            Text(
                "O Nexus não consegue mais abrir o atalho de \"${g.title}\". Isso acontece depois de restaurar um backup, limpar os dados do Nexus ou reinstalar o app: o Android apaga os atalhos que o Nexus tinha fixado. É só criar o atalho de novo dentro do $appName.",
                color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            if (!TvMode.isTv) {
                CButton("Recriar agora", C_BLUE, Modifier.fillMaxWidth().initialFocus()) { step = 1 }
                Spacer(Modifier.height(8.dp))
                CButton("Só abrir o $appName", C_GRAY, Modifier.fillMaxWidth()) { shortcutFix = null; launchApp(g.pkg) }
            } else {
                CButton("Só abrir o $appName", C_GRAY, Modifier.fillMaxWidth().initialFocus()) { shortcutFix = null; launchApp(g.pkg) }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { shortcutFix = null }
        } else {
            Text("Faça nesta ordem:", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Text(
                if (isHome) "1. O Nexus já é o launcher padrão ✓" else "1. Deixe o Nexus como launcher padrão, só por alguns instantes (o Android só entrega o pedido de atalho ao launcher padrão).",
                color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            if (!isHome) {
                Spacer(Modifier.height(6.dp))
                CButton("Tornar o Nexus o launcher padrão", C_BLUE, Modifier.fillMaxWidth().initialFocus()) { askDefaultLauncher() }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (isHub) "2. Abra o GameHub, entre em \"${g.title}\" e use \"Atalho na Área\"." else "2. Abra o $appName e crie o atalho de \"${g.title}\" na área de trabalho.",
                color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            CButton("Abrir o $appName", if (isHome) C_BLUE else C_GRAY, Modifier.fillMaxWidth().initialFocus()) { launchApp(g.pkg) }
            Spacer(Modifier.height(12.dp))
            Text(
                "3. Quando aparecer \"Atalho adicionado ao Nexus\", volte ao Nexus: ele avisa que o atalho foi recriado. Depois, se quiser, devolva o launcher que você usava.",
                color = note, fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            CButton("Escolher o launcher anterior", C_GRAY, Modifier.fillMaxWidth()) { openHomeSettings() }
            Spacer(Modifier.height(12.dp))
            CButton("Voltar", C_GRAY, Modifier.fillMaxWidth()) { step = 0 }
        }
    }
}

@Composable
internal fun MainActivity.ResetGamesDialog() {
    // 0 = escolher, 1 = lista de plataformas, 2 = confirmar "todos", 3 = confirmar uma plataforma
    var step by remember { mutableStateOf(0) }
    var plat by remember { mutableStateOf("") }
    val title = when (step) {
        0 -> "Resetar Jogos"
        1 -> "Apagar por plataforma"
        else -> "Apagar jogos?"
    }
    RefocusOnStep(step)
    NexusModal(title, { if (step == 0) popOverlay() else step = 0 }) {
        val note = Color(0xFFCBD2E0)
        when (step) {
            0 -> {
                Text(
                    "Apaga só os jogos da tela inicial. Os vínculos (apps de jogos, apps emuladores, emuladores), os gêneros, as coleções e as chaves de API continuam como estão.",
                    color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                CButton("Apagar por plataforma", C_BLUE, Modifier.fillMaxWidth()) { step = 1 }
                Spacer(Modifier.height(8.dp))
                CButton("Apagar todos os jogos", C_RED, Modifier.fillMaxWidth()) { step = 2 }
                Spacer(Modifier.height(8.dp))
                CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { popOverlay() }
            }
            1 -> {
                // 4.7.9: conta pela plataforma original; os mascarados aparecem separados na própria linha.
                val names = (platformNames() + games.map { it.platform }.distinct()).distinct()
                val plats = names.filter { n -> games.any { it.platform == n } }
                if (plats.isEmpty()) {
                    Text("Nenhum jogo na biblioteca.", color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                } else {
                    for (name in plats) {
                        val inPlat = games.filter { it.platform == name }
                        val masked = inPlat.count { it.maskPlatform.isNotEmpty() }
                        val plain = inPlat.size - masked
                        // 4.8.0: até 3 linhas (o botão cresce): nome / jogos com a etiqueta da plataforma / jogos com máscara.
                        val lines = if (masked > 0) {
                            buildList {
                                add(name)
                                if (plain > 0) add("$plain " + (if (plain == 1) "jogo" else "jogos") + " com etiqueta $name")
                                add("$masked " + (if (masked == 1) "jogo" else "jogos") + " com Máscara de Etiqueta")
                            }
                        } else {
                            listOf("$name · $plain " + (if (plain == 1) "jogo" else "jogos"))
                        }
                        CButtonLines(lines, Modifier.fillMaxWidth()) {
                            plat = name
                            step = 3
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                CButton("Voltar", C_GRAY, Modifier.fillMaxWidth()) { step = 0 }
            }
            2 -> {
                Text(
                    "Isso apaga todos os ${games.size} jogos da tela inicial. Vínculos, gêneros, coleções e chaves de API não são apagados.",
                    color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Cancelar", C_GRAY, Modifier.weight(1f).initialFocus()) { step = 0 }
                    CButton("Apagar todos", C_RED, Modifier.weight(1f)) { deleteGamesWhere(true) }
                }
            }
            else -> {
                val inPlat = games.filter { it.platform == plat }
                val n = inPlat.size
                val masked = inPlat.count { it.maskPlatform.isNotEmpty() }
                val extra = if (masked > 0) " ($masked com máscara de etiqueta)" else ""
                Text(
                    "Isso apaga os $n " + (if (n == 1) "jogo" else "jogos") + " de $plat$extra. Vínculos, gêneros, coleções e chaves de API não são apagados.",
                    color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Cancelar", C_GRAY, Modifier.weight(1f).initialFocus()) { step = 1 }
                    CButton("Apagar", C_RED, Modifier.weight(1f)) { deleteGamesWhere(false, plat) }
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.ConfirmFactoryDialog() {
    NexusModal("Restaurar configurações de fábrica?", { popOverlay() }) {
        Text(
            "Isso apaga TUDO: todos os jogos, as configurações, os vínculos de apps e emuladores, os gêneros, as coleções e as chaves de API (SteamGridDB e YouTube). Seus arquivos de ROM não são apagados. O Nexus será reiniciado.",
            color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CButton("Cancelar", C_GRAY, Modifier.weight(1f).initialFocus()) { popOverlay() }
            CButton("Restaurar", C_RED, Modifier.weight(1f)) { factoryReset() }
        }
    }
}
