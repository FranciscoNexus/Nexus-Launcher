package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

// ---------- Componentes de formulário ----------
@Composable
internal fun MainActivity.CField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier, wrap: Boolean = false, paste: Boolean = false, mic: Boolean = true) {
    val shape = RoundedCornerShape(rBtn.dp)
    var focused by remember { mutableStateOf(false) }
    val tvEdit = rememberTvEdit()
    val hot = focused || tvEdit.selected
    BoxWithConstraints(
        modifier = modifier
            .then(if (wrap) Modifier.heightIn(min = 44.dp) else Modifier.height(44.dp))
            .clip(shape)
            .background(if (tvEdit.selected) FocusStyle.navColor.copy(alpha = 0.16f) else C_FIELD)
            .border(if (tvEdit.selected) 3.dp else if (focused) 2.dp else 1.dp, if (hot) FocusStyle.navColor else C_BORDER, shape)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        // Microfone (4.0.8): fica dentro do campo, na altura que ele já tem. Em campos muito
        // estreitos ele some para não espremer o texto.
        val showMic = mic && maxWidth >= 130.dp
        Row(if (wrap) Modifier.fillMaxWidth().padding(vertical = 8.dp) else Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).tvFieldBox(tvEdit), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Text(hint, color = C_MUTED, fontSize = 13.sp, maxLines = 1)
                BasicTextField(
                    value = value,
                    onValueChange = { onChange(if (wrap) it.replace("\n", "") else it) },
                    singleLine = !wrap, maxLines = if (wrap) 4 else 1,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().tvFieldInput(tvEdit).onFocusChanged { focused = it.isFocused }
                )
            }
            if (showMic && paste) {
                Spacer(Modifier.width(6.dp))
                val ps = RoundedCornerShape(rBtn.dp)
                Box(
                    modifier = Modifier.height(30.dp).clip(ps)
                        .background(parseColor(accentHex).copy(alpha = 0.16f))
                        .border(1.dp, parseColor(accentHex).copy(alpha = 0.5f), ps)
                        .focusGlow(ps)
                        .clickable {
                            val t = clipboardText().trim()
                            if (t.isEmpty()) toast("Nada copiado para colar") else onChange(t)
                        }
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Colar", color = parseColor(accentHex), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) }
            } else if (showMic) {
                Spacer(Modifier.width(6.dp))
                VoiceMic(value, onChange, parseColor(accentHex), size = 30.dp, onFallback = { tvEdit.editing = true })
            }
        }
    }
}

/**
 * 4.9.5: janela de opções (no lugar das listas suspensas do Compose, que não entendiam o controle):
 * setas navegam, A escolhe, B fecha, a alavanca direita rola listas longas.
 */
@Composable
internal fun MainActivity.OptionsWindow(
    title: String, onDismiss: () -> Unit,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val accent = parseColor(accentHex)
    val panel = RoundedCornerShape(rPanel.dp)
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog()
        Box(Modifier.fillMaxSize().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(if (landscape) 0.5f else 0.86f)
                    .heightIn(max = if (landscape) 320.dp else 520.dp)
                    .shadow(14.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(C_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                Text(
                    title.removeSuffix(":"), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp)
                )
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) { content() }
            }
        }
    }
}

@Composable
internal fun MainActivity.OptRow(text: String, sub: String = "", cur: Boolean = false, initial: Boolean = false,
                   color: Color = Color.White, onClick: () -> Unit) {
    val accent = parseColor(accentHex)
    val rowShape = RoundedCornerShape(rCard.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(rowShape)
            .background(if (cur) accent.copy(alpha = 0.14f) else Color.Transparent)
            .initialFocus(initial)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(text, color = color, fontSize = 14.sp)
            if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C_MUTED)
        }
        if (cur) Text("✓", color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }
}

@Composable
internal fun MainActivity.CSelect(
    label: String, value: String, options: List<String>,
    modifier: Modifier = Modifier, subtitle: ((String) -> String)? = null, onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(rBtn.dp)
    Box(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, C_BORDER, shape)
                .clickable { open = true }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text(
                value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text("▾", color = C_MUTED, fontSize = 12.sp)
        }
    }
    // 4.9.5: a lista de opções é uma janela própria: o foco já começa na opção em uso.
    if (open) {
        OptionsWindow(label, { open = false }) {
            options.forEachIndexed { idx, o ->
                OptRow(
                    o, subtitle?.invoke(o) ?: "", cur = o == value,
                    initial = o == value || (idx == 0 && options.none { it == value })
                ) {
                    onSelect(o)
                    open = false
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.CButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val accent = parseColor(accentHex)
    val shape = RoundedCornerShape(rBtn.dp)
    // Botões "azuis" (ação principal) seguem a cor de destaque escolhida.
    val bg = if (color == C_BLUE) accent else color
    val fg = if (color == C_BLUE) onAccent(accent) else Color.White
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .background(bg)
            .then(if (color == C_GRAY) Modifier.border(1.dp, Color(0x1FFFFFFF), shape) else Modifier)
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

/** 4.8.0: botão cinza com até 3 linhas centralizadas (a altura se ajusta). */
@Composable
internal fun MainActivity.CButtonLines(lines: List<String>, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(rBtn.dp)
    Column(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(C_GRAY)
            .border(1.dp, Color(0x1FFFFFFF), shape)
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = if (lines.size > 1) 8.dp else 0.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        lines.forEachIndexed { i, t ->
            Text(
                t, color = Color.White, fontSize = if (i == 0) 13.sp else 12.sp,
                fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Medium,
                textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun MainActivity.CToggle(text: String, checked: Boolean, modifier: Modifier = Modifier, star: Boolean = false, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(rBtn.dp)
    val accent = parseColor(accentHex)
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .background(C_FIELD)
            .border(1.dp, if (checked) accent else C_BORDER, shape)
            .focusGlow(shape)
            .clickable { onChange(!checked) }
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                (if (checked) "☑ " else "☐ ") + text,
                color = if (checked) accent else Color.White, fontSize = 13.sp, maxLines = 1
            )
            if (star) {
                Spacer(Modifier.width(6.dp))
                NxStar(accent, styleIdx, Modifier.size(20.dp))
            }
        }
    }
}

// ---------- Tela de edição de jogo (3.9.7) ----------
/** Texto de uma linha que rola sozinho (devagar) quando é maior que o espaço disponível. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun MainActivity.MarqueeText(
    text: String, color: Color, size: Int,
    weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight,
        maxLines = 1, softWrap = false,
        modifier = modifier.basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
    )
}

@Composable
internal fun MainActivity.ELabel(text: String, color: Color = S_MUTED) {
    Text(
        text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp, maxLines = 1
    )
}

@Composable
internal fun MainActivity.EPill(
    modifier: Modifier = Modifier, selected: Boolean = false, tint: Color? = null,
    vpad: Dp = 8.dp, onClick: (() -> Unit)? = null,
    content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit
) {
    val accent = tint ?: parseColor(accentHex)
    val shape = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(if (selected) accent.copy(alpha = 0.12f) else S_FIELD)
            .border(if (tint != null && selected) 2.dp else 1.dp, if (selected) accent.copy(alpha = if (tint != null) 1f else 0.55f) else S_LINE, shape)
            .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp, vertical = vpad),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** Seleção de vários itens (até [max]) em lista suspensa; o menu fica aberto para marcar mais de um. */
@Composable
internal fun MainActivity.MultiSelectMenu(
    open: Boolean, onDismiss: () -> Unit, selected: List<String>, options: List<String>,
    max: Int, onChange: (List<String>) -> Unit
) {
    if (!open) return
    OptionsWindow("Gêneros", onDismiss) {
        if (options.isEmpty()) {
            OptRow("Nenhum gênero cadastrado", color = C_MUTED, initial = true, onClick = onDismiss)
        }
        options.forEachIndexed { i, o ->
            val on = o in selected
            OptRow(o, cur = on, initial = i == 0, color = if (on) Color.White else Color(0xFFCBD2E0)) {
                if (on) onChange(selected - o)
                else if (selected.size >= max) toast("No máximo $max gêneros por jogo")
                else onChange(selected + o)
            }
        }
        OptRow("Limpar", color = C_MUTED) { onChange(emptyList()); onDismiss() }
    }
}

@Composable
internal fun MainActivity.MultiSelectPill(
    label: String, selected: List<String>, options: List<String>, max: Int,
    modifier: Modifier = Modifier, vpad: Dp = 8.dp, onChange: (List<String>) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        EPill(Modifier.fillMaxWidth(), vpad = vpad, onClick = { open = true }) {
            Column(Modifier.weight(1f)) {
                ELabel(label)
                Spacer(Modifier.height(3.dp))
                MarqueeText(if (selected.isEmpty()) "—" else selected.joinToString(", "), Color.White, 13)
            }
            Spacer(Modifier.width(6.dp))
            Text("▾", color = S_MUTED, fontSize = 13.sp)
        }
        MultiSelectMenu(open, { open = false }, selected, options, max, onChange)
    }
}

@Composable
internal fun MainActivity.MultiSelectField(
    label: String, selected: List<String>, options: List<String>, max: Int,
    modifier: Modifier = Modifier, onChange: (List<String>) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(rBtn.dp)
    Box(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, C_BORDER, shape)
                .clickable { open = true }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text(
                if (selected.isEmpty()) "—" else selected.joinToString(", "),
                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text("▾", color = C_MUTED, fontSize = 12.sp)
        }
        MultiSelectMenu(open, { open = false }, selected, options, max, onChange)
    }
}

@Composable
internal fun MainActivity.PillSelect(
    label: String, value: String, options: List<String>,
    modifier: Modifier = Modifier, vpad: Dp = 8.dp, subtitle: ((String) -> String)? = null,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        EPill(Modifier.fillMaxWidth(), vpad = vpad, onClick = { open = true }) {
            Column(Modifier.weight(1f)) {
                ELabel(label)
                Spacer(Modifier.height(3.dp))
                MarqueeText(value, Color.White, 13)
            }
            Spacer(Modifier.width(6.dp))
            Text("▾", color = S_MUTED, fontSize = 13.sp)
        }
        if (open) {
            OptionsWindow(label, { open = false }) {
                options.forEachIndexed { idx, o ->
                    OptRow(
                        o, subtitle?.invoke(o) ?: "", cur = o == value,
                        initial = o == value || (idx == 0 && options.none { it == value })
                    ) {
                        onSelect(o)
                        open = false
                    }
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.PillField(
    label: String?, value: String, onChange: (String) -> Unit, hint: String,
    modifier: Modifier = Modifier, size: Int = 13, weight: FontWeight = FontWeight.Bold,
    vpad: Dp = 8.dp, trailing: (@Composable () -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    val tvEdit = rememberTvEdit()
    val accent = parseColor(accentHex)
    val shape = RoundedCornerShape(rBtn.dp)
    val hot = focused || tvEdit.selected
    BoxWithConstraints(modifier) {
    // Microfone (4.0.8): no fim da linha, menor que a altura mínima do campo (não aumenta nada).
    val showMic = maxWidth >= 150.dp
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (tvEdit.selected) accent.copy(alpha = 0.16f) else S_FIELD)
            .border(if (tvEdit.selected) 3.dp else if (focused) 2.dp else 1.dp, if (hot) accent else S_LINE, shape)
            .padding(horizontal = 10.dp, vertical = vpad),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).tvFieldBox(tvEdit)) {
            if (label != null) {
                ELabel(label)
                Spacer(Modifier.height(3.dp))
            }
            Box(Modifier.fillMaxWidth()) {
                if (value.isEmpty()) Text(hint, color = S_MUTED, fontSize = size.sp, maxLines = 1)
                BasicTextField(
                    value = value, onValueChange = onChange, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = size.sp, fontWeight = weight),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFieldInput(tvEdit)
                        .alpha(if (focused || value.isEmpty()) 1f else 0f)
                        .onFocusChanged { focused = it.isFocused }
                )
                // Fora de edição, títulos/links longos rolam sozinhos para dar para ler tudo.
                if (!focused && value.isNotEmpty()) MarqueeText(value, Color.White, size, weight)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
        if (showMic) {
            Spacer(Modifier.width(8.dp))
            VoiceMic(value, onChange, accent, size = if (label == null) 22.dp else 26.dp)
        }
    }
    }
}

@Composable
internal fun MainActivity.EBtn(
    label: String, glyph: String?, bg: Color, border: Color, fg: Color, modifier: Modifier = Modifier,
    tall: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = modifier
            .heightIn(min = if (tall) 44.dp else 34.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .focusGlow(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph != null) {
            Text(glyph, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
        }
        Text(label, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}
