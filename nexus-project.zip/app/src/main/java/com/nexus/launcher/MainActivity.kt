package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class RomEntry(val name: String, val folder: String, val uri: String)

class RomListRequest(val platform: String, val onPick: (String, String) -> Unit)

class EmuPickerRequest(val platform: EmuPlatform, val onPick: (EmuPlayer) -> Unit)

/** Capas em lote: andamento da busca no SteamGridDB (roda em segundo plano). */
class CoverBatch(val scope: String, val total: Int) {
    var done by androidx.compose.runtime.mutableIntStateOf(0)
    var applied by androidx.compose.runtime.mutableIntStateOf(0)
    var running by androidx.compose.runtime.mutableStateOf(true)
    var error by androidx.compose.runtime.mutableStateOf("")
    val notFound = androidx.compose.runtime.mutableStateListOf<String>()
    @Volatile var cancelled = false
}

/** Seletor de plataforma (busca + lista completa + criar/editar/apagar personalizadas). */
class PlatPickerRequest(
    val title: String,
    val selected: String,
    val filter: (String) -> Boolean,
    /** Chamado quando uma plataforma personalizada é renomeada (new = novo nome) ou apagada (new = ""). */
    val onChanged: (old: String, new: String) -> Unit,
    val onPick: (String) -> Unit
)

class BuiltIntent(val intent: Intent, val kill: Boolean)

class ScanResult(val roms: List<RomEntry>, val failed: Int)

// ---------- Cadastro em lote ----------
class BatchItem(val key: String, val variants: List<ScanCandidate>, chosen: ScanCandidate) {
    var cand by mutableStateOf(chosen)
    var checked by mutableStateOf(true)
}

class BatchIgnored(val item: IgnoredItem) {
    var checked by mutableStateOf(false)
}

enum class BatchPhase { SCANNING, REGIONS, LIST }

class BatchSession(val platform: String, val profile: ScanProfile) {
    var phase by mutableStateOf(BatchPhase.SCANNING)
    var found by mutableStateOf(0)
    @Volatile var cancelled = false
    @Volatile var failedFolders = 0
    var all: List<ScanCandidate> = emptyList()
    var ignored: List<IgnoredItem> = emptyList()
    var alreadyCount by mutableStateOf(0)
    var dupGroups by mutableStateOf(0)
    val items = mutableStateListOf<BatchItem>()
    val ignoredItems = mutableStateListOf<BatchIgnored>()
    var query by mutableStateOf("")
    var showIgnored by mutableStateOf(false)
}

/** 4.9.5: rolagem da janela aberta (as janelas sem item focável rolam com as setas do controle). */
val LocalModalScroll = androidx.compose.runtime.compositionLocalOf<androidx.compose.foundation.ScrollState?> { null }

sealed class Overlay {
    object None : Overlay()
    class Edit(val game: Game?) : Overlay()
    object Filter : Overlay()
    object Settings : Overlay()
    object Genres : Overlay()
    object Platforms : Overlay()
    object CoverBatchSetup : Overlay()
    class LinkEdit(val link: PlatformLink?) : Overlay()
    object Search : Overlay()
    object ResetGames : Overlay()
    object ConfirmFactory : Overlay()
    class ConfirmDelete(val game: Game) : Overlay()
    class Info(val id: String) : Overlay()
    class PlatformImage(val name: String) : Overlay()
    object Collections : Overlay()
    class ConfirmDeleteCollection(val name: String) : Overlay()
    object StoragePrompt : Overlay()
    class AddChoice(val first: Boolean) : Overlay()
    object BatchSetup : Overlay()
    /** 4.6.1 (TV): escolha do modo de visualização das capas (botão do olho). */
    object ViewMode : Overlay()
    /** 4.9.3: botão START (cabeçalho ou controle): adicionar novo jogo ou editar o jogo em foco. */
    object StartMenu : Overlay()
    /** 4.9.3: tela que mostra ao vivo o que o controle manda (Configurações > Sistema). */
    object PadTest : Overlay()
    /** 4.9.4: botão "?" das Configurações: estatísticas, aparelho, diagnóstico, atualização e créditos. */
    object About : Overlay()
    /** 4.9.13: tutorial (só celular e tablet). */
    object Tutorial : Overlay()
    /** 4.9.13: boas-vindas da primeira abertura (celular e tablet). */
    object TutorialWelcome : Overlay()
}

internal const val SETTINGS_TABS = 4   // Visual, Biblioteca, Sistema, Extras
internal const val ADD_ID = "__add__"
internal const val H_ORIENT = 0
internal const val H_FLOAT = 1
internal const val H_SELECT = 2
internal const val H_START = 3
internal const val H_GEAR = 4
internal const val H_EYE = 5
/** Modos de visualização da TV (4.6.1). */
internal const val TV_VIEW_STD = 0
internal const val TV_VIEW_CAROUSEL = 1
internal const val TV_VIEW_GRID = 2
internal const val TV_VIEW_LIST = 3
/** Espaço acima da primeira linha da grade/lista; o brilho da capa não pode passar disso sem ser cortado. */
internal const val LIST_TOP_PAD_DP = 10f
internal const val LIST_ROW_H_DP = 96
internal const val LIST_ROW_MIN_DP = 72
internal const val LIST_ROW_MAX_DP = 170
internal const val NO_GENRE = "Sem gênero"
internal const val PLAT_PREFIX = "plat:"

/** 4.9.3: quanto rolar (px; positivo = avançar) para um item que começa em [start] e tem [size] ficar inteiro dentro de [0, end - margin]. */
internal fun fitDelta(start: Float, size: Float, end: Float, margin: Float): Float = when {
    start < 0f -> start
    start + size > end - margin -> start + size - end + margin
    else -> 0f
}

class SgdbPicker(
    val title: String, val term: String, val portrait: Boolean, val onPick: (String) -> Unit,
    /** 4.9.12: se não for nulo, o seletor mostra a aba "Animadas" e chama isto ao escolher uma capa animada. */
    val onPickAnim: ((String) -> Unit)? = null
) {
    /** 4.9.14: o botão Voltar do controle (B) chama isto antes de fechar: devolve true se já tratou (voltou o foco às capas). */
    var backStep: () -> Boolean = { false }
}

internal const val APP_VERSION = "4.9.15"

// Paleta do destaque (borda e LED). A ordem é a mesma da paleta antiga, para migrar quem já tinha uma cor salva.
internal val ACCENTS = listOf(
    "Azul" to "#0A84FF", "Verde" to "#30D158", "Laranja" to "#FF9F0A", "Vermelho" to "#FF453A",
    "Roxo" to "#BF5AF2", "Amarelo" to "#FFD60A", "Branco" to "#FFFFFF", "Ciano" to "#00E5FF",
    "Rosa" to "#FF4DA6", "Verde-limão" to "#AEEA00"
)
internal val OLD_COLORS = listOf(
    "#007AFF", "#4CD964", "#FF9500", "#FF3B30", "#AF52DE", "#FFCC00", "#FFFFFF",
    "#00E5FF", "#FF2D95", "#C6FF00"
)

internal val SORTS = listOf(
    "Padrão (Recentes > Favoritos > A-Z)",
    "Jogados recentemente (últimos 10)",
    "A-Z (crescente)",
    "Z-A (decrescente)"
)

internal val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

/** Tempo (ms) com o OK apertado para valer como toque longo. */
internal const val OK_LONG_MS = 500L

internal val PAD_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2
)

// Navegação com repetição: 1 toque = 1 item; segurando, repete após HOLD_DELAY_MS
// e acelera de RATE_MIN até RATE_MAX itens/segundo ao longo de RATE_RAMP_MS.
internal const val HOLD_DELAY_MS = 400L
internal const val RATE_MIN = 3f
internal const val RATE_MAX = 6f
internal const val RATE_RAMP_MS = 2000L
internal const val PAGE_ITEMS = 4
internal const val TRIGGER_PRESS = 0.10f   // zona morta de 10% dos gatilhos
internal const val TRIGGER_RELEASE = 0.05f
internal const val STICK_ON = 0.6f
internal const val STICK_OFF = 0.4f

internal val C_PANEL = Color(0xFF141720)
internal val C_FIELD = Color(0xFF11141C)
internal val C_BORDER = Color(0x24FFFFFF)
internal val C_MUTED = Color(0xFF9AA3B5)
internal val C_BLUE = Color(0xFF0A84FF)
internal val C_ORANGE = Color(0xFFF59E0B)
internal val C_RED = Color(0xFFE11D48)
internal val C_GRAY = Color(0xFF1E222B)
internal val C_YELLOW = Color(0xFFFBBF24)
internal val S_PANEL = Color(0xFF141720)
internal val HDR_BG = Color(0xE0181C25)
internal val HDR_LINE = Color(0x1AFFFFFF)
internal val S_CARD = Color(0xFF1A1E29)
internal val S_FIELD = Color(0xFF11141C)
internal val S_LINE = Color(0x1AFFFFFF)
internal val S_MUTED = Color(0xFF9AA3B5)
internal val S_PAD_A = Color(0xFF1DB87A)
internal val S_PAD_B = Color(0xFFE5484D)

class MainActivity : ComponentActivity() {

    // ---------- Estado ----------
    internal val prefs by lazy { getSharedPreferences("nexus_prefs", MODE_PRIVATE) }
    internal val libFile by lazy { File(filesDir, "library.json") }
    internal val sgdbFile by lazy { File(filesDir, "sgdb_cache.json") }
    internal val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    internal var sgdbKey by mutableStateOf("")
    internal var ytKey by mutableStateOf("") // 4.7.0: chave da API do YouTube (vídeo gameplay)
    internal var hideSgdbHint by mutableStateOf(false)
    internal val sgdbCache = mutableStateMapOf<String, SgdbInfo>()
    internal val sgdbErr = mutableStateMapOf<String, String>()
    internal var sgdbBusy by mutableStateOf(setOf<String>())
    // ---- 4.7.0: vídeo gameplay ----
    internal val ytCtrl = YtController().also { c -> c.onRevealed = { ytCtl = YT_PLAY } }
    internal var ytOpen by mutableStateOf(false)
    internal var ytNav by mutableStateOf(false)
    internal var ytFull by mutableStateOf(false)
    internal var ytCtl by mutableStateOf(YT_PLAY)
    internal var ytBusy by mutableStateOf(setOf<String>())
    internal val ytErr = mutableStateMapOf<String, String>()
    internal var ytRegion by mutableStateOf<androidx.compose.ui.geometry.Rect?>(null)
    internal var videoLinkFor by mutableStateOf<Game?>(null)
    internal var sgdbPicker by mutableStateOf<SgdbPicker?>(null)
    internal val games = mutableStateListOf<Game>()
    internal val genres = mutableStateListOf<String>()
    internal val links = mutableStateListOf<PlatformLink>()
    internal val platforms = mutableStateListOf<GamePlatform>()
    internal var allApps: List<AppItem> = emptyList()
    internal val iconCache = HashMap<String, ImageBitmap?>()
    internal val bigIconCache = HashMap<String, ImageBitmap?>()

    internal var selectedId by mutableStateOf<String?>(null)
    internal var coverRev by mutableStateOf(0)
    internal var storageOk by mutableStateOf(false)
    internal var overlayState by mutableStateOf<Overlay>(Overlay.None)

    /**
     * 4.9.5: pilha de telas. Ao ir para uma tela "filha" a atual é empilhada; ao pedir a tela que está no topo da pilha
     * (Voltar) ela é desempilhada. "Voltar" sempre volta UMA tela só, para a que abriu a atual.
     */
    internal val overlayStack = ArrayList<Overlay>()
    internal var overlay: Overlay
        get() = overlayState
        set(v) {
            val cur = overlayState
            if (v is Overlay.Settings && cur is Overlay.None) settingsTab = 0   // 4.9.5: Configurações sempre abre na aba Visual
            if (v is Overlay.None) {
                returnKey = ""
                overlayStack.clear()
            } else if (overlayStack.isNotEmpty() && overlayStack[overlayStack.size - 1] == v) {
                overlayStack.removeAt(overlayStack.size - 1)
            } else if (cur !is Overlay.None && cur != v) {
                // Info -> Editar -> (salvar) volta pra Info; Info nunca fica empilhada duas vezes.
                if (overlayStack.none { it == cur }) overlayStack.add(cur)
            }
            overlayState = v
        }
    /** 4.9.4: celular — true enquanto o usuário usa o controle (volta a false no primeiro toque na tela). */
    internal var padActive by mutableStateOf(false)
    /** 4.9.4: navegação por controle na tela inicial: sempre na TV; no celular só deitado e com o controle em uso. */
    internal val padNav: Boolean get() = TvMode.isTv || (landscape && padActive)
    /** 4.9.4: página aberta dentro da tela "?" (0 = menu). */
    internal var aboutPage by mutableStateOf(0)
    internal var landscape by mutableStateOf(false)
    internal var widthP by mutableStateOf(175)
    /** 4.9.4: o tamanho das capas na paisagem é individual por modo de visualização (padrão e carrossel não se afetam). */
    internal var widthLStd by mutableStateOf(170)
    internal var widthLCar by mutableStateOf(170)
    internal var widthL: Int
        get() = if (tvView == TV_VIEW_CAROUSEL) widthLCar else widthLStd
        set(v) { if (tvView == TV_VIEW_CAROUSEL) widthLCar = v else widthLStd = v }
    /** 4.9.3: grade — 0 = capas pequenas (mais por linha), 1 = médias, 2 = grandes (menos por linha). 4.9.4: um valor por orientação. */
    internal var gridSizeP by mutableStateOf(1)
    internal var gridSizeL by mutableStateOf(1)
    internal var gridSize: Int
        get() = if (landscape) gridSizeL else gridSizeP
        set(v) { if (landscape) gridSizeL = v else gridSizeP = v }
    /** 4.9.3: lista — altura da linha em dp (a capa acompanha a altura; a largura da linha nunca muda). */
    internal var listRowH by mutableStateOf(LIST_ROW_H_DP)
    internal var radius by mutableStateOf(14)
    internal var accentHex by mutableStateOf("#0A84FF")
    internal var settingsTab by mutableStateOf(0)
    internal var cutoutPad by mutableStateOf(false)
    internal var favOnly by mutableStateOf(false)
    internal var searchTerm by mutableStateOf("")
    internal var fPlatform by mutableStateOf("")
    internal var dashMode by mutableStateOf(0)
    internal var dashPlatform by mutableStateOf("")
    internal var fGenre by mutableStateOf("")
    internal var fCollection by mutableStateOf("")
    internal var sortMode by mutableStateOf(0)
    internal var power by mutableStateOf(PowerSnapshot())
    /** O Nexus é o launcher padrão do aparelho agora? (libera as opções do modo launcher) */
    internal var isHome by mutableStateOf(false)
    internal var appsDrawerOpen by mutableStateOf(false)
    internal var carouselOn by mutableStateOf(true)
    internal var introOn by mutableStateOf(true)
    /** 4.9.12: chave "Animar capas escolhidas" (ligada por padrão). */
    internal var animCovers by mutableStateOf(true)
    /** 4.9.13: tutorial: módulos concluídos, módulo aberto (null = lista) e passo atual. */
    internal var tutDone by mutableStateOf<Set<String>>(emptySet())
    internal var tutOpenId by mutableStateOf<String?>(null)
    internal var tutPage by mutableStateOf(0)
    internal var floatSmall by mutableStateOf(false)   // 4.5.4: painel flutuante compacto
    internal var appPickerOpen by mutableStateOf(false)
    /** 0 = todos os apps, 1 = só os marcados como jogo, 2 = só os marcados como emulador. */
    internal var appPickerMode by mutableStateOf(0)
    internal var appFilterKind by mutableStateOf(0)
    internal val hiddenGameApps = mutableStateListOf<String>()
    internal val hiddenEmuApps = mutableStateListOf<String>()
    internal val appAliases = androidx.compose.runtime.mutableStateMapOf<String, String>()
    internal var appPickerNone by mutableStateOf("Automático (padrão da plataforma)")
    internal var romList by mutableStateOf<RomListRequest?>(null)
    internal var batch by mutableStateOf<BatchSession?>(null)
    internal var emuPicker by mutableStateOf<EmuPickerRequest?>(null)
    internal var platPicker by mutableStateOf<PlatPickerRequest?>(null)
    internal var coverBatch by mutableStateOf<CoverBatch?>(null)

    internal var appPickerCb: ((AppItem?) -> Unit)? = null
    internal val collections = mutableStateListOf<String>()
    internal var collPickerOpen by mutableStateOf(false)
    internal val collPickerSel = mutableStateListOf<String>()
    internal var collPickerCb: ((List<String>) -> Unit)? = null
    internal var genrePickerOpen by mutableStateOf(false)
    internal val genrePickerSel = mutableStateListOf<String>()
    internal var genrePickerCb: ((List<String>) -> Unit)? = null
    internal var gridColumns = 2
    internal val padHandler = Handler(Looper.getMainLooper())
    internal val heldKeys = LinkedHashSet<Int>()
    internal var axisDx = 0
    internal var axisDy = 0
    internal var holdDx = 0
    internal var holdDy = 0
    internal var holdStartMs = 0L
    /** 4.9.3: tela de detalhes e player (dentro da janela principal): setas e alavanca viram um passo só, sem duplicar. */
    internal val infoPad = PadFilter { code ->
        val t = SystemClock.uptimeMillis()
        superDispatch(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        superDispatch(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
    internal val ytPad = PadFilter { code ->
        val t = SystemClock.uptimeMillis()
        ytHandleKey(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0), code)
    }
    internal fun superDispatch(ev: KeyEvent): Boolean = super.dispatchKeyEvent(ev)
    internal var ltDown = false
    internal var rtDown = false
    internal val repeatTick = object : Runnable {
        override fun run() {
            if ((holdDx == 0 && holdDy == 0) || modalOpen()) {
                stopHold()
                return
            }
            stepSelection(holdDx, holdDy)
            val held = SystemClock.uptimeMillis() - holdStartMs - HOLD_DELAY_MS
            val t = (held.toFloat() / RATE_RAMP_MS).coerceIn(0f, 1f)
            val rate = RATE_MIN + (RATE_MAX - RATE_MIN) * t
            padHandler.postDelayed(this, (1000f / rate).toLong())
        }
    }
    internal var pendingPlay: Game? = null
    internal var dialogRomCb: ((Uri) -> Unit)? = null
    internal var treeCb: ((String) -> Unit)? = null

    // ---------- Modo TV (4.6.0) ----------
    /** Zona de navegação da tela inicial na TV: 0 = capas, 1 = cabeçalho, 2 = rodapé (A / B / Y / X). */
    internal var navZone by mutableStateOf(0)
    internal var hdrIdx by mutableStateOf(0)
    /**
     * 4.9.3 (TV, modo Padrão): sublinhado fino embaixo da capa focada. Só aparece quando o foco chega na capa vindo do
     * cabeçalho/rodapé (navegação vertical); some assim que o D-pad anda para os lados.
     */
    internal var coverUnderline by mutableStateOf(false)
    internal var ftrIdx by mutableStateOf(0)
    /** Explorador de arquivos embutido (substitui o seletor do Android na TV). */
    internal var explorer by mutableStateOf<ExplorerState?>(null)
    /** Ajuda quando o Android da TV não tem a tela de permissão: "overlay" ou "storage". */
    internal var permHelp by mutableStateOf<String?>(null)
    /** Na tela de informações: o D-pad já foi usado, então A/OK clicam no item destacado em vez de "Jogar". */
    internal var infoNav = false
    /** 4.6.1: modo de visualização da tela inicial na TV: 0 padrão, 1 carrossel, 2 grade, 3 lista. */
    internal var tvView by mutableStateOf(TV_VIEW_STD)

    // ---------- Launchers ----------
    internal val pickRomForPlay = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val g = pendingPlay
        pendingPlay = null
        if (uri != null && g != null) {
            persist(uri)
            val updated = g.copy(romUri = uri.toString())
            replaceGame(updated)
            launchGame(updated)
        }
    }

    internal val pickRomForDialog = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            dialogRomCb?.invoke(uri)
        }
    }

    internal val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) writeBackup(uri) }

    internal val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) readBackup(uri) }

    internal val homeRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { isHome = LauncherMode.isDefault(this) }

    // Painel flutuante (4.5.0): 1) permissão "Exibir sobre outros apps"  2) permissão de notificação  3) liga o serviço.
    internal val overlayPermRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (FloatingPanelService.canDraw(this)) askNotifThenStartFloat() else toast("Sem a permissão, o painel não pode aparecer sobre outros apps") }

    internal val notifPermRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startFloat() }

    internal val treePicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            treeCb?.invoke(uri.toString())
        }
    }

    // 4.6.0: na TV a tela é vista de longe, então toda a interface fica maior (equivale a "tamanho de exibição").
    override fun attachBaseContext(newBase: Context) {
        var ctx = newBase
        try {
            TvMode.init(newBase)
            if (TvMode.isTv) {
                val cfg = Configuration(newBase.resources.configuration)
                val sc = TvMode.UI_SCALE
                cfg.densityDpi = (cfg.densityDpi * sc).toInt()
                cfg.screenWidthDp = (cfg.screenWidthDp / sc).toInt()
                cfg.screenHeightDp = (cfg.screenHeightDp / sc).toInt()
                cfg.smallestScreenWidthDp = (cfg.smallestScreenWidthDp / sc).toInt()
                ctx = newBase.createConfigurationContext(cfg)
            }
        } catch (_: Exception) {
        }
        super.attachBaseContext(ctx)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPrefs()
        // 4.5.4: o Nexus obedece ao Android — gira pelo sensor se o giro automático estiver ligado e fica
        // travado se o usuário bloqueou a rotação. Só o botão do cabeçalho passa por cima do bloqueio.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        applyFullscreen()
        allApps = loadApps()
        loadLibrary()
        importPendingShortcuts()
        syncPlatforms()
        ensureFixedCollections()
        loadFilters()
        validateFilters()
        isHome = LauncherMode.isDefault(this)
        sgdbCache.putAll(SgdbStore.load(sgdbFile))
        File(filesDir, "rawg_cache.json").delete() // restos da integração antiga
        Covers.init(this)
        storageOk = hasAllFiles()
        if (!storageOk && !prefs.getBoolean("storagePrompted", false)) {
            prefs.edit().putBoolean("storagePrompted", true).apply()
            overlay = Overlay.StoragePrompt
        } else {
            maybeWelcome()
        }
        prefetchCovers()
        selectedId = firstNavId()
        setContent {
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, 1f)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                        // 4.9.2: lê as cores/raios AQUI (na composição) para o anel de foco acompanhar a troca em tempo real.
                        val focusAccentNow = parseColor(accentHex)
                        val focusRadiusNow = rBtn.toFloat()
                        SideEffect {
                            FocusStyle.accent = focusAccentNow
                            FocusStyle.radiusDp = focusRadiusNow
                        }
                        var showIntro by remember { mutableStateOf(introOn && !NexusIntroState.shown && overlay is Overlay.None) }
                        Box(Modifier.fillMaxSize()) {
                            NexusScreen()
                            if (showIntro) {
                                NexusIntro(
                                    accent = parseColor(accentHex),
                                    onDone = { NexusIntroState.shown = true; showIntro = false }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 4.9.3: se a janela perde/ganha o foco (abriu ou fechou uma janela), nenhuma direção pode ficar "presa":
    // o soltar da tecla chegaria na outra janela e o D-pad pararia de responder.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen()
        stopHold()
        infoPad.reset()
        ytPad.reset()
    }

    // ---------- Preferências ----------
    internal fun loadPrefs() {
        widthP = prefs.getInt("widthP", 175)
        widthLStd = prefs.getInt("widthL", 170)
        widthLCar = prefs.getInt("widthLCar", widthLStd)
        gridSizeP = prefs.getInt("gridSizeP", prefs.getInt("gridSize", 1)).coerceIn(0, 2)
        gridSizeL = prefs.getInt("gridSizeL", prefs.getInt("gridSize", 1)).coerceIn(0, 2)
        listRowH = prefs.getInt("listRowH", LIST_ROW_H_DP).coerceIn(LIST_ROW_MIN_DP, LIST_ROW_MAX_DP)
        radius = canonicalRadius(prefs.getInt("radius", 14))
        accentHex = normalizeAccent(prefs.getString("color", "#0A84FF") ?: "#0A84FF")
        cutoutPad = prefs.getBoolean("cutoutPad", false)
        sgdbKey = prefs.getString("sgdbKey", "") ?: ""
        ytKey = prefs.getString("ytKey", "") ?: ""
        hideSgdbHint = prefs.getBoolean("hideSgdbHint", false)
        if (prefs.contains("rawgKey")) prefs.edit().remove("rawgKey").apply()
        dashMode = prefs.getInt("dashMode", 0)
        carouselOn = prefs.getBoolean("carouselOn", true)
        tvView = prefs.getInt("tvView", if (carouselOn) TV_VIEW_CAROUSEL else TV_VIEW_STD).coerceIn(0, 3)
        introOn = prefs.getBoolean("introOn", true)
        animCovers = prefs.getBoolean("animCovers", true)
        loadTutorial()
        floatSmall = prefs.getBoolean("floatSmall", false)
        // 4.5.2: os sons foram removidos; apaga o que ficou salvo.
        if (prefs.contains("soundsOn") || prefs.contains("soundStyle")) prefs.edit().remove("soundsOn").remove("soundStyle").apply()
        collections.clear()
        prefs.getString("collectionsList", null)?.let { s ->
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val n = a.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            } catch (_: Exception) {
            }
        }
        hiddenGameApps.clear()
        hiddenEmuApps.clear()
        appAliases.clear()
        try {
            prefs.getString("hiddenGameApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenGameApps.add(a.getString(i)) } }
            prefs.getString("hiddenEmuApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenEmuApps.add(a.getString(i)) } }
            prefs.getString("appAliases", null)?.let { j ->
                val o = org.json.JSONObject(j)
                for (k in o.keys()) appAliases[k] = o.getString(k)
            }
        } catch (_: Exception) {
        }
        genres.clear()
        val gs = prefs.getString("genres", null)
        if (gs != null) {
            try {
                val a = JSONArray(gs)
                for (i in 0 until a.length()) genres.add(a.getString(i))
            } catch (_: Exception) {
            }
        }
        if (genres.isEmpty()) genres.addAll(GENRES)
        platforms.clear()
        val ps = prefs.getString("platformsList", null)
        if (ps != null) {
            try {
                platforms.addAll(PlatformStore.parse(ps))
            } catch (_: Exception) {
            }
        }
        if (platforms.isEmpty()) platforms.addAll(defaultPlatforms())
        links.clear()
        val ls = prefs.getString("links", null)
        if (ls != null) {
            try {
                links.addAll(LinkStore.parse(ls))
            } catch (_: Exception) {
            }
        }
    }

    /** 4.7.8: true durante "Restaurar configurações de fábrica": nada pode ser regravado antes do reinício. */
    internal var wiping = false

    internal fun savePrefs() {
        if (wiping) return
        prefs.edit()
            .putInt("widthP", widthP)
            .putInt("widthL", widthLStd)
            .putInt("widthLCar", widthLCar)
            .putInt("gridSizeP", gridSizeP)
            .putInt("gridSizeL", gridSizeL)
            .putInt("listRowH", listRowH)
            .putInt("radius", radius)
            .putString("color", accentHex)
            .putBoolean("cutoutPad", cutoutPad)
            .putInt("dashMode", dashMode)
            .putString("collectionsList", JSONArray(collections.toList()).toString())
            .putString("genres", JSONArray(genres.toList()).toString())
            .putString("hiddenGameApps", JSONArray(hiddenGameApps.toList()).toString())
            .putString("hiddenEmuApps", JSONArray(hiddenEmuApps.toList()).toString())
            .putString("appAliases", org.json.JSONObject(appAliases.toMap()).toString())
            .putString("links", LinkStore.toJson(links.toList()))
            .putString("platformsList", PlatformStore.toJson(platforms.toList()))
            .apply()
    }

    /** Orientação que o botão do cabeçalho forçou (null = quem manda é o Android). */
    internal var forcedLandscape: Boolean? = null
    internal var orientListener: OrientationEventListener? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    internal val styleIdx: Int get() = styleOf(radius)
    internal val rPanel: Int get() = intArrayOf(6, 18, 28)[styleIdx]
    internal val rCard: Int get() = intArrayOf(4, 14, 22)[styleIdx]
    internal val rBtn: Int get() = intArrayOf(4, 11, 18)[styleIdx]

    /** Borda de foco na cor de destaque (navegação por controle). Deve vir ANTES do clickable. */
    @Composable
    internal fun Modifier.focusGlow(shape: Shape): Modifier {
        var focused by remember { mutableStateOf(false) }
        val accent = FocusStyle.navColor
        return this
            .ownRing()
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) FocusProbe.touch() }
            .then(
                if (focused) Modifier.border(3.dp, accent, shape).background(accent.copy(alpha = 0.18f), shape)
                else Modifier
            )
    }

    // 4.7.0: sempre os 3 últimos; com o filtro "Jogados recentemente" (Select) valem os 10 últimos.
    // 4.9.0: listas calculadas UMA vez e reaproveitadas (só recalculam quando jogos/filtros mudam).
    internal val recentIdsD = derivedStateOf { computeRecentIds() }
    internal val filteredGamesD = derivedStateOf { computeFilteredGames() }
    internal val visibleGamesD = derivedStateOf { computeVisibleGames() }
    internal val platformCardsD = derivedStateOf { computePlatformCards() }

    /** 4.6.1 (TV, horizontal): modo Grade — igual ao do celular em pé, adaptado para a tela deitada. */
    internal val tvGridOn: Boolean get() = landscape && tvView == TV_VIEW_GRID
    /** 4.6.1 (TV, horizontal): modo Lista — cartões com capa e informações, rolagem para cima e para baixo. */
    internal val tvListOn: Boolean get() = landscape && tvView == TV_VIEW_LIST
    /** Navegação numa fila só, para os lados (celular deitado e TV nos modos Padrão/Carrossel). */
    internal val rowNav: Boolean get() = landscape && !tvGridOn && !tvListOn

    internal var ytLast = YT_PLAY

    /** 4.9.5: item que abriu a tela filha; quando a filha fecha (Voltar), o foco volta para ele. */
    internal var returnKey by mutableStateOf("")

    @Composable
    internal fun Modifier.returnFocus(key: String): Modifier {
        val req = remember { FocusRequester() }
        val pad = padNav
        LaunchedEffect(returnKey, pad) {
            if (pad && returnKey == key) {
                delay(130)
                try {
                    req.requestFocus()
                } catch (_: Exception) {
                }
                returnKey = ""
            }
        }
        return this.focusRequester(req)
    }

    // ---------- 4.9.5: Voltar na tela inicial (Google TV e Fire OS) ----------
    internal var tvBackCount = 0
    internal var tvBackLastMs = 0L
    internal var tvBackDownMs = 0L
    internal var tvBackHoldToast = false

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (TvMode.isTv) {
            if (code == KeyEvent.KEYCODE_BACK) {
                if (tvHomeBack(ev)) return true
            } else if (ev.action == KeyEvent.ACTION_DOWN) tvBackCount = 0
        }
        // 4.9.4: celular — o controle só vale com o aparelho deitado; em pé o Nexus é usado só por toque.
        if (!TvMode.isTv && (ev.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK)) != 0) {
            if (!landscape) return super.dispatchKeyEvent(ev)
            if (!padActive) padActive = true
        }
        // TV: OK do controle remoto (DPAD_CENTER / ENTER) age como "clicar no item destacado".
        val isOk = TvMode.isTv && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
            code == KeyEvent.KEYCODE_NUMPAD_ENTER)
        // 4.9.0: depois de um OK segurado, o resto do toque (repetições e soltar) não pode vazar para a tela que abriu.
        if (okSwallow && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
                code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A)) {
            if (ev.action == KeyEvent.ACTION_UP) okSwallow = false
            return true
        }
        val ytMedia = ytOpen && (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY ||
            code == KeyEvent.KEYCODE_MEDIA_PAUSE || code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
        // 4.9.0: TV, tela principal: teclas de "página" do controle remoto (avançar/voltar, canal +/-) pulam vários jogos.
        val pageKey = TvMode.isTv && !ytOpen && (code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
            code == KeyEvent.KEYCODE_MEDIA_PREVIOUS || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
            code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN ||
            code == KeyEvent.KEYCODE_PAGE_UP || code == KeyEvent.KEYCODE_PAGE_DOWN)
        if (code !in PAD_KEYS && !isOk && !ytMedia && !pageKey) return super.dispatchKeyEvent(ev)
        val isDirKey = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

        if (modalOpen()) {
            stopHold()
            val inf = overlay
            if (ytOpen && inf is Overlay.Info) {
                // 4.9.3: as setas passam pelo filtro (um passo por toque; repete se segurar).
                if (isDirKey) {
                    if (ev.action == KeyEvent.ACTION_DOWN) {
                        if (ev.repeatCount == 0) ytPad.key(code, true)
                    } else ytPad.key(code, false)
                    return true
                }
                // Em TV/controle remoto também vale o "Voltar" (KEYCODE_BACK) quando o player está aberto.
                return ytHandleKey(ev, code)
            }
            if (inf is Overlay.Info && !collPickerOpen && !genrePickerOpen) {
                // 4.6.0: o D-pad / OK navegam pelos botões da tela de informações (controle remoto).
                if (isDirKey) {
                    infoNav = true
                    if (ev.action == KeyEvent.ACTION_DOWN) {
                        if (ev.repeatCount == 0) infoPad.key(code, true)
                    } else infoPad.key(code, false)
                    return true
                }
                if (isOk) {
                    infoNav = true
                    return super.dispatchKeyEvent(ev)
                }
                if (code == KeyEvent.KEYCODE_BUTTON_A && infoNav) {
                    return super.dispatchKeyEvent(
                        KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                    )
                }
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    when (code) {
                        KeyEvent.KEYCODE_BUTTON_A -> games.firstOrNull { it.id == inf.id }?.let { infoPlay(it) }
                        KeyEvent.KEYCODE_BUTTON_B -> back()
                        KeyEvent.KEYCODE_BUTTON_START -> games.firstOrNull { it.id == inf.id }?.let { overlay = Overlay.Edit(it) }
                    }
                }
                return true
            }
            if (overlay is Overlay.Settings && (code == KeyEvent.KEYCODE_BUTTON_L1 || code == KeyEvent.KEYCODE_BUTTON_R1)) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    settingsTab = if (code == KeyEvent.KEYCODE_BUTTON_R1) (settingsTab + 1) % SETTINGS_TABS else (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS
                }
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) back()
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_A) {
                return super.dispatchKeyEvent(
                    KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                )
            }
            return super.dispatchKeyEvent(ev)
        }

        if (pageKey) {
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                val fwd = code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
                    code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_DOWN
                pageStep(if (fwd) 1 else -1)
            }
            return true
        }

        // 4.9.0: na TV o OK (e o A do gamepad) na tela principal: toque = abrir; segurar (meio segundo) = toque longo.
        if (isOk || (padNav && code == KeyEvent.KEYCODE_BUTTON_A)) return okKey(ev)

        if (isDirKey) {
            // A repetição é feita por nós (com aceleração); ignora o auto-repeat do sistema.
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) {
                    heldKeys.remove(code)
                    heldKeys.add(code)
                    updateHold()
                }
            } else if (ev.action == KeyEvent.ACTION_UP) {
                heldKeys.remove(code)
                updateHold()
            }
            return true
        }

        if (ev.action == KeyEvent.ACTION_DOWN) {
            val first = ev.repeatCount == 0
            when (code) {
                KeyEvent.KEYCODE_BUTTON_R1 -> if (first) pageStep(1)
                KeyEvent.KEYCODE_BUTTON_L1 -> if (first) pageStep(-1)
                KeyEvent.KEYCODE_BUTTON_R2 -> if (first) jumpEdge(true)
                KeyEvent.KEYCODE_BUTTON_L2 -> if (first) jumpEdge(false)
                KeyEvent.KEYCODE_BUTTON_A -> if (first) { zoneActivate() }
                KeyEvent.KEYCODE_BUTTON_B -> if (first) back()
                KeyEvent.KEYCODE_BUTTON_X -> if (first) { randomPick() }
                KeyEvent.KEYCODE_BUTTON_Y -> if (first) { overlay = Overlay.Search }
                KeyEvent.KEYCODE_BUTTON_START -> if (first) { overlay = Overlay.StartMenu }
                KeyEvent.KEYCODE_BUTTON_SELECT -> if (first) { overlay = Overlay.Filter }
            }
        }
        return true
    }

    internal var okPending = false
    internal var okLong = false
    internal var okSwallow = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // 4.9.4: tocou na tela = volta ao modo toque (sem contorno de navegação do controle).
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && padActive) {
            padActive = false
            navZone = 0
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoy = PadInput.isJoystick(ev)
        if (isJoy && !TvMode.isTv) {
            if (!landscape) return super.dispatchGenericMotionEvent(ev)
            if (!padActive && ev.action == MotionEvent.ACTION_MOVE) padActive = true
        }
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE && ytOpen && overlay is Overlay.Info) {
            // 4.9.3: player aberto: D-pad por eixo e alavanca andam pelos botões como as setas do teclado (sem duplicar).
            ytPad.axis(PadInput.axisDir(ev, ytPad.axisDir))
            return true
        }
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE) {
            if (modalOpen()) {
                stopHold()
                if (overlay is Overlay.Info && !collPickerOpen && !genrePickerOpen) {
                    // Tela de detalhes: o eixo vira um passo só (o Android também cria setas a partir do eixo, o que duplicava).
                    infoNav = true
                    infoPad.axis(PadInput.axisDir(ev, infoPad.axisDir))
                    return true
                }
                return super.dispatchGenericMotionEvent(ev)
            }
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val sx = ev.getAxisValue(MotionEvent.AXIS_X)
            val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
            val ax = if (abs(hx) > 0.5f) hx else sx
            val ay = if (abs(hy) > 0.5f) hy else sy
            val limit = if (axisDx != 0 || axisDy != 0) STICK_OFF else STICK_ON
            var ndx = 0
            var ndy = 0
            if (abs(ax) > limit || abs(ay) > limit) {
                if (abs(ax) >= abs(ay)) ndx = if (ax > 0) 1 else -1
                else ndy = if (ay > 0) 1 else -1
            }
            axisDx = ndx
            axisDy = ndy
            updateHold()
            handleTriggers(ev)
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        ytCtrl.onHostResume()
        importPendingShortcuts()
        storageOk = hasAllFiles() // volta da tela de permissões do Android
        isHome = LauncherMode.isDefault(this) // volta da tela de escolha do launcher
        startOrientationWatch()
        FloatState.hostVisible = true
        FloatingPanelService.instance?.applyVisibility()
        // Se o painel estava ligado e o sistema encerrou o serviço, religa sozinho.
        if (!TvMode.isFireTv && prefs.getBoolean("floatOn", false) && !FloatState.on && FloatingPanelService.canDraw(this)) {
            FloatingPanelService.start(this)
        }
    }

    // Botão Home com o Nexus como launcher padrão: volta para a tela principal (fecha as janelas abertas).
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) goHome()
    }

    override fun onPause() {
        orientListener?.disable()
        FloatState.hostVisible = false
        FloatingPanelService.instance?.applyVisibility()
        stopHold()
        ytCtrl.onHostPause()
        super.onPause()
    }

    /** Divisão de tela (paisagem): controles à esquerda, lista à direita. */
    @Composable
    internal fun androidx.compose.foundation.layout.ColumnScope.Panes(
        leftW: Float = 0.4f,
        left: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
        right: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(leftW).fillMaxHeight().verticalScroll(rememberScrollState())) { left() }
            Column(Modifier.weight(1f - leftW).fillMaxHeight()) { right() }
        }
    }

    /** Linha de lista em cartão de vidro escuro (com foco do controle). Use no lugar do padding simples. */
    @Composable
    internal fun Modifier.cardRow(onClick: (() -> Unit)?): Modifier {
        val shape = RoundedCornerShape(rCard.dp)
        return this
            .padding(vertical = 3.dp)
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    }

    internal val PKG_LIKE = Regex("^[a-z0-9_]+(\\.[A-Za-z0-9_\\-]+)+$")

}
