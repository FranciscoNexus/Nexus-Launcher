package com.nexus.launcher

import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

data class AppItem(val label: String, val pkg: String)

sealed class Overlay {
    object None : Overlay()
    class Edit(val game: Game?) : Overlay()
    object Filter : Overlay()
    object Settings : Overlay()
    object Genres : Overlay()
    object Search : Overlay()
    object ConfirmReset : Overlay()
}

private const val ADD_ID = "__add__"

private val COLORS = listOf("#007AFF", "#4CD964", "#FF9500", "#FF3B30", "#AF52DE", "#FFCC00", "#FFFFFF")

private val SORTS = listOf(
    "Padrão (Recentes > Favoritos > A-Z)",
    "Histórico (todos os jogados)",
    "A-Z (crescente)",
    "Z-A (decrescente)"
)

private val RADII = listOf("Padrão" to 10, "Reto" to 0, "Médio" to 16, "Muito redondo" to 24)

private val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

private val PAD_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT
)

private val C_PANEL = Color(0xFF1B1B1D)
private val C_FIELD = Color(0xFF2A2A2D)
private val C_BORDER = Color(0xFF3A3A3C)
private val C_MUTED = Color(0xFF8E8E93)
private val C_BLUE = Color(0xFF007AFF)
private val C_ORANGE = Color(0xFFFF9500)
private val C_RED = Color(0xFFFF3B30)
private val C_GRAY = Color(0xFF3A3A3C)
private val C_YELLOW = Color(0xFFFFCC00)

class MainActivity : ComponentActivity() {

    // ---------- Estado ----------
    private val prefs by lazy { getSharedPreferences("nexus_prefs", MODE_PRIVATE) }
    private val libFile by lazy { File(filesDir, "library.json") }
    private val games = mutableStateListOf<Game>()
    private val genres = mutableStateListOf<String>()
    private var allApps: List<AppItem> = emptyList()
    private val iconCache = HashMap<String, ImageBitmap?>()

    private var selectedId by mutableStateOf<String?>(null)
    private var overlay by mutableStateOf<Overlay>(Overlay.None)
    private var landscape by mutableStateOf(false)
    private var widthP by mutableStateOf(175)
    private var widthL by mutableStateOf(170)
    private var radius by mutableStateOf(10)
    private var accentHex by mutableStateOf("#007AFF")
    private var cutoutPad by mutableStateOf(false)
    private var favOnly by mutableStateOf(false)
    private var fPlatform by mutableStateOf("")
    private var fGenre by mutableStateOf("")
    private var sortMode by mutableStateOf(0)
    private var battery by mutableStateOf(0)
    private var charging by mutableStateOf(false)
    private var appPickerOpen by mutableStateOf(false)

    private var appPickerCb: ((AppItem?) -> Unit)? = null
    private var gridColumns = 2
    private var lastMoveMs = 0L
    private var pendingPlay: Game? = null
    private var dialogRomCb: ((Uri) -> Unit)? = null

    // ---------- Launchers ----------
    private val pickRomForPlay = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val g = pendingPlay
        pendingPlay = null
        if (uri != null && g != null) {
            persist(uri)
            val updated = g.copy(romUri = uri.toString())
            replaceGame(updated)
            launchGame(updated)
        }
    }

    private val pickRomForDialog = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            dialogRomCb?.invoke(uri)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) writeBackup(uri) }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) readBackup(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPrefs()
        requestedOrientation = orientationFlag()
        applyFullscreen()
        allApps = loadApps()
        loadLibrary()
        selectedId = visibleGames().firstOrNull()?.id
        setContent {
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, 1f)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                        NexusScreen()
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen()
    }

    private fun applyFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Preferências ----------
    private fun loadPrefs() {
        landscape = prefs.getBoolean("landscape", false)
        widthP = prefs.getInt("widthP", 175)
        widthL = prefs.getInt("widthL", 170)
        radius = prefs.getInt("radius", 10)
        accentHex = prefs.getString("color", "#007AFF") ?: "#007AFF"
        cutoutPad = prefs.getBoolean("cutoutPad", false)
        genres.clear()
        val gs = prefs.getString("genres", null)
        if (gs != null) {
            try {
                val a = JSONArray(gs)
                for (i in 0 until a.length()) genres.add(a.getString(i))
            } catch (_: Exception) {
            }
        }
        if (genres.isEmpty()) genres.addAll(GENRES)
    }

    private fun savePrefs() {
        prefs.edit()
            .putBoolean("landscape", landscape)
            .putInt("widthP", widthP)
            .putInt("widthL", widthL)
            .putInt("radius", radius)
            .putString("color", accentHex)
            .putBoolean("cutoutPad", cutoutPad)
            .putString("genres", JSONArray(genres.toList()).toString())
            .apply()
    }

    private fun orientationFlag(): Int =
        if (landscape) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

    private fun toggleOrientation() {
        landscape = !landscape
        requestedOrientation = orientationFlag()
        savePrefs()
    }

    private fun parseColor(hex: String): Color = try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        Color(0xFF007AFF)
    }

    // ---------- Biblioteca ----------
    private fun defaultGames(): List<Game> =
        LibraryStore.parse(assets.open("default_library.json").bufferedReader().use { it.readText() })

    private fun loadLibrary() {
        val existed = libFile.exists()
        val list = try {
            if (existed) LibraryStore.parse(libFile.readText()) else defaultGames()
        } catch (e: Exception) {
            toast("Erro ao ler biblioteca: ${e.message}")
            emptyList()
        }
        games.addAll(list)
        if (!existed) saveLibrary()
    }

    private fun saveLibrary() {
        try {
            libFile.writeText(LibraryStore.toJson(games.toList()))
        } catch (e: Exception) {
            toast("Erro ao salvar: ${e.message}")
        }
    }

    private fun replaceGame(updated: Game) {
        val idx = games.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            games[idx] = updated
            saveLibrary()
        }
    }

    private fun markPlayed(g: Game) {
        val idx = games.indexOfFirst { it.id == g.id }
        if (idx >= 0) {
            games[idx] = games[idx].copy(lastPlayedTs = System.currentTimeMillis())
            saveLibrary()
        }
    }

    private fun recentIds(): Set<String> =
        games.filter { it.lastPlayedTs > 0 }
            .sortedByDescending { it.lastPlayedTs }
            .take(3).map { it.id }.toSet()

    private fun visibleGames(): List<Game> {
        var l: List<Game> = games.toList()
        if (favOnly) l = l.filter { it.isFavorite }
        if (fPlatform.isNotEmpty()) l = l.filter { it.platform == fPlatform }
        if (fGenre.isNotEmpty()) l = l.filter { it.genre == fGenre }
        return when (sortMode) {
            1 -> l.filter { it.lastPlayedTs > 0 }.sortedByDescending { it.lastPlayedTs }
            2 -> l.sortedBy { it.title.lowercase() }
            3 -> l.sortedByDescending { it.title.lowercase() }
            else -> {
                val rec = l.filter { it.lastPlayedTs > 0 }
                    .sortedByDescending { it.lastPlayedTs }.take(3)
                val ids = rec.map { it.id }.toSet()
                val rest = l.filter { it.id !in ids }
                rec +
                    rest.filter { it.isFavorite }.sortedBy { it.title.lowercase() } +
                    rest.filter { !it.isFavorite }.sortedBy { it.title.lowercase() }
            }
        }
    }

    private fun navIds(): List<String> = visibleGames().map { it.id } + ADD_ID

    private fun resetFilters() {
        favOnly = false
        fPlatform = ""
        fGenre = ""
        sortMode = 0
    }

    private fun selectGame(id: String) {
        if (visibleGames().none { it.id == id }) resetFilters()
        selectedId = id
    }

    private fun renameGenre(old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty() || (n != old && n in genres)) return
        val i = genres.indexOf(old)
        if (i >= 0) genres[i] = n
        for (k in games.indices) if (games[k].genre == old) games[k] = games[k].copy(genre = n)
        if (fGenre == old) fGenre = n
        saveLibrary()
        savePrefs()
    }

    private fun deleteGenre(g: String) {
        genres.remove(g)
        for (k in games.indices) if (games[k].genre == g) games[k] = games[k].copy(genre = "")
        if (fGenre == g) fGenre = ""
        saveLibrary()
        savePrefs()
    }

    // ---------- Ações ----------
    private fun moveSelection(dx: Int, dy: Int) {
        val now = SystemClock.uptimeMillis()
        if (now - lastMoveMs < 140L) return
        lastMoveMs = now
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val step = dx + (if (landscape) 0 else dy * gridColumns)
        if (step == 0) return
        val target = idx + step
        if (target !in ids.indices) {
            if (dy > 0 && !landscape) selectedId = ids.last()
            return
        }
        selectedId = ids[target]
    }

    private fun openSelected() {
        val id = selectedId ?: return
        if (id == ADD_ID) {
            overlay = Overlay.Edit(null)
            return
        }
        val g = games.firstOrNull { it.id == id } ?: return
        playGame(g)
    }

    private fun editSelected() {
        val id = selectedId
        if (id == null || id == ADD_ID) {
            overlay = Overlay.Edit(null)
            return
        }
        games.firstOrNull { it.id == id }?.let { overlay = Overlay.Edit(it) }
    }

    private fun randomPick() {
        val l = visibleGames()
        if (l.isNotEmpty()) selectedId = l.random().id
    }

    private fun back() {
        when {
            appPickerOpen -> appPickerOpen = false
            overlay is Overlay.Genres -> overlay = Overlay.Settings
            overlay !is Overlay.None -> overlay = Overlay.None
            else -> selectedId = null
        }
    }

    private fun playGame(g: Game) {
        if (g.execType == "ppsspp" && g.romUri.isEmpty() && resolvePkg(g) != null) {
            pendingPlay = g
            pickRomForPlay.launch(arrayOf("*/*"))
        } else {
            launchGame(g)
        }
    }

    // ---------- Controle (gamepad) ----------
    private fun modalOpen(): Boolean = overlay !is Overlay.None || appPickerOpen

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (code !in PAD_KEYS) return super.dispatchKeyEvent(ev)

        if (modalOpen()) {
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) back()
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_A) {
                return super.dispatchKeyEvent(
                    KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                )
            }
            return super.dispatchKeyEvent(ev)
        }

        if (ev.action == KeyEvent.ACTION_DOWN) {
            val first = ev.repeatCount == 0
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> moveSelection(-1, 0)
                KeyEvent.KEYCODE_DPAD_RIGHT -> moveSelection(1, 0)
                KeyEvent.KEYCODE_DPAD_UP -> moveSelection(0, -1)
                KeyEvent.KEYCODE_DPAD_DOWN -> moveSelection(0, 1)
                KeyEvent.KEYCODE_BUTTON_A -> if (first) openSelected()
                KeyEvent.KEYCODE_BUTTON_B -> if (first) back()
                KeyEvent.KEYCODE_BUTTON_X -> if (first) randomPick()
                KeyEvent.KEYCODE_BUTTON_Y -> if (first) overlay = Overlay.Search
                KeyEvent.KEYCODE_BUTTON_START -> if (first) editSelected()
                KeyEvent.KEYCODE_BUTTON_SELECT -> if (first) overlay = Overlay.Filter
            }
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoy = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE && !modalOpen()) {
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val sx = ev.getAxisValue(MotionEvent.AXIS_X)
            val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
            val ax = if (abs(hx) > 0.5f) hx else sx
            val ay = if (abs(hy) > 0.5f) hy else sy
            if (abs(ax) > 0.6f || abs(ay) > 0.6f) {
                if (abs(ax) >= abs(ay)) moveSelection(if (ax > 0) 1 else -1, 0)
                else moveSelection(0, if (ay > 0) 1 else -1)
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    // ---------- Apps / lançamento ----------
    private fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun iconFor(pkg: String): ImageBitmap? = iconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun resolvePkg(g: Game): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    private fun launchGame(g: Game) {
        if (g.execType == "browser") {
            if (g.webUrl.isBlank()) {
                toast("Este jogo não tem link configurado")
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val pkg = resolvePkg(g)
        if (pkg == null) {
            toast("Defina o app em Editar (segure a capa ou aperte START)")
            return
        }
        try {
            val intent: Intent? = if (g.execType == "ppsspp" && g.romUri.isNotEmpty()) {
                Intent(Intent.ACTION_VIEW).apply {
                    setClassName(pkg, "org.ppsspp.ppsspp.PpssppActivity")
                    data = Uri.parse(g.romUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                packageManager.getLaunchIntentForPackage(pkg)
            }
            if (intent == null) {
                toast("Não foi possível abrir $pkg")
                return
            }
            startActivity(intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun openSteamGrid(title: String) {
        if (title.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        val url = "https://www.steamgriddb.com/search/grids?term=" + URLEncoder.encode(title.trim(), "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    private fun cleanTitle(file: String, keepId: Boolean): String {
        var s = file.substringBeforeLast('.', file)
        s = s.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
        if (!keepId) s = s.replace(Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$"), "")
        return s.trim()
    }

    // ---------- Backup ----------
    private fun writeBackup(uri: Uri) {
        try {
            val o = JSONObject(LibraryStore.toJson(games.toList()))
            o.put("platforms", JSONArray(PLATFORMS.map { JSONObject().put("name", it).put("active", true) }))
            o.put("genresList", JSONArray(genres.toList()))
            o.put(
                "visualPrefs",
                JSONObject().put("widthP", widthP).put("widthL", widthL)
                    .put("radius", "${radius}px").put("color", accentHex)
            )
            o.put("currentOrientation", if (landscape) "landscape" else "portrait")
            contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray(Charsets.UTF_8)) }
            toast("Backup salvo")
        } catch (e: Exception) {
            toast("Erro ao exportar: ${e.message}")
        }
    }

    private fun readBackup(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: return
            val o = JSONObject(text)
            val list = LibraryStore.parse(text)
            games.clear()
            games.addAll(list)
            saveLibrary()
            o.optJSONArray("genresList")?.let { arr ->
                val g = (0 until arr.length()).map { arr.getString(it) }
                if (g.isNotEmpty()) {
                    genres.clear()
                    genres.addAll(g)
                }
            }
            o.optJSONObject("visualPrefs")?.let { v ->
                widthP = v.optInt("widthP", widthP)
                widthL = v.optInt("widthL", widthL)
                val r = v.optString("radius", "").filter { it.isDigit() }
                if (r.isNotEmpty()) radius = r.toInt()
                val c = v.optString("color", "")
                if (c.startsWith("#")) accentHex = c
            }
            savePrefs()
            resetFilters()
            selectedId = visibleGames().firstOrNull()?.id
            toast("Backup importado: ${list.size} jogos")
        } catch (e: Exception) {
            toast("Erro ao importar: ${e.message}")
        }
    }

    // ---------- Tela principal ----------
    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        battery = if (level < 0 || scale <= 0) 0 else level * 100 / scale
        charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
    }

    @Composable
    private fun NexusScreen() {
        val ctx = LocalContext.current
        val list = visibleGames()
        val accent = parseColor(accentHex)
        val recents = recentIds()
        val ids = list.map { it.id } + ADD_ID
        val gridState = rememberLazyGridState()
        val rowState = rememberLazyListState()

        DisposableEffect(Unit) {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    if (i != null) updateBattery(i)
                }
            }
            val sticky = ContextCompat.registerReceiver(
                ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            if (sticky != null) updateBattery(sticky)
            onDispose { ctx.unregisterReceiver(receiver) }
        }

        val cols by remember {
            derivedStateOf {
                val v = gridState.layoutInfo.visibleItemsInfo
                if (v.isEmpty()) 2 else max(1, v.count { it.offset.y == v.first().offset.y })
            }
        }
        SideEffect { gridColumns = cols }

        LaunchedEffect(selectedId, landscape) {
            val idx = ids.indexOf(selectedId)
            if (idx >= 0) {
                if (landscape) {
                    val info = rowState.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                    val ok = item != null && item.offset >= 0 && item.offset + item.size <= info.viewportEndOffset
                    if (!ok) rowState.animateScrollToItem(idx)
                } else {
                    val info = gridState.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                    val ok = item != null && item.offset.y >= 0 &&
                        item.offset.y + item.size.height <= info.viewportEndOffset
                    if (!ok) gridState.animateScrollToItem(idx)
                }
            }
        }

        val title = when (val s = selectedId) {
            null -> ""
            ADD_ID -> "Adicionar Novo Jogo"
            else -> games.firstOrNull { it.id == s }?.title ?: ""
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
        ) {
            Header(title)

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (landscape) {
                    LazyRow(
                        state = rowState,
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(list, key = { it.id }) { g ->
                            GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.width(widthL.dp))
                        }
                        item(key = ADD_ID) {
                            AddTile(selectedId == ADD_ID, accent, Modifier.width(widthL.dp))
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        state = gridState,
                        columns = GridCells.Adaptive(widthP.dp),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(list, key = { it.id }) { g ->
                            GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.fillMaxWidth())
                        }
                        item(key = ADD_ID) {
                            AddTile(selectedId == ADD_ID, accent, Modifier.fillMaxWidth())
                        }
                    }
                }
            }

            BottomBar()
        }

        when (val o = overlay) {
            Overlay.None -> {}
            is Overlay.Edit -> GameDialog(o.game)
            Overlay.Filter -> FilterDialog()
            Overlay.Settings -> SettingsDialog()
            Overlay.Genres -> GenresDialog()
            Overlay.Search -> SearchDialog()
            Overlay.ConfirmReset -> ConfirmResetDialog()
        }
        if (appPickerOpen) AppPickerDialog()
    }

    // ---------- Cabeçalho e rodapé ----------
    @Composable
    private fun Pill(text: String, onClick: () -> Unit) {
        val shape = RoundedCornerShape(8.dp)
        Box(
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(Color(0xFF1C1C1E))
                .border(1.dp, Color(0xFF3A3A3C), shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }

    @Composable
    private fun BatteryPill() {
        val shape = RoundedCornerShape(8.dp)
        Box(
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(Color(0xFF1C1C1E))
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "$battery%" + if (charging) " ⚡" else "",
                color = Color(0xFFCCCCCC), fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1
            )
        }
    }

    @Composable
    private fun OrientButton() {
        val shape = RoundedCornerShape(8.dp)
        Box(
            modifier = Modifier
                .height(26.dp)
                .width(34.dp)
                .clip(shape)
                .background(Color(0xFF1C1C1E))
                .border(1.dp, Color(0xFF3A3A3C), shape)
                .clickable { toggleOrientation() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(16.dp)) {
                val w = size.width
                val h = size.height
                val sw = 1.5.dp.toPx()
                drawRoundRect(
                    Color.White, Offset(w * 0.06f, h * 0.04f), Size(w * 0.5f, h * 0.92f),
                    CornerRadius(w * 0.1f), style = Stroke(width = sw)
                )
                drawCircle(Color.White, sw * 0.8f, Offset(w * 0.2f, h * 0.8f))
                val p = Path().apply {
                    moveTo(w * 0.68f, h * 0.25f)
                    lineTo(w * 0.82f, h * 0.25f)
                    quadraticBezierTo(w * 0.96f, h * 0.25f, w * 0.96f, h * 0.4f)
                    lineTo(w * 0.96f, h * 0.6f)
                    quadraticBezierTo(w * 0.96f, h * 0.75f, w * 0.82f, h * 0.75f)
                    lineTo(w * 0.68f, h * 0.75f)
                }
                drawPath(p, Color.White, style = Stroke(width = sw, cap = StrokeCap.Round))
            }
        }
    }

    @Composable
    private fun GearButton() {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Color(0xFF2C2C2E))
                .clickable { overlay = Overlay.Settings },
            contentAlignment = Alignment.Center
        ) {
            Text("\u2699\uFE0E", color = Color.White, fontSize = 16.sp)
        }
    }

    @Composable
    private fun TitleText(title: String, modifier: Modifier) {
        Text(
            title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = modifier
        )
    }

    @Composable
    private fun Header(title: String) {
        if (landscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OrientButton()
                Spacer(Modifier.width(12.dp))
                TitleText(title, Modifier.weight(1f).padding(end = 8.dp))
                BatteryPill()
                Spacer(Modifier.width(8.dp))
                Pill("SELECT") { overlay = Overlay.Filter }
                Spacer(Modifier.width(8.dp))
                Pill("START") { editSelected() }
                Spacer(Modifier.width(8.dp))
                GearButton()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 4.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OrientButton()
                    Spacer(Modifier.weight(1f))
                    BatteryPill()
                    Spacer(Modifier.width(8.dp))
                    GearButton()
                }
                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TitleText(title, Modifier.weight(1f).padding(end = 8.dp))
                    Pill("SELECT") { overlay = Overlay.Filter }
                    Spacer(Modifier.width(8.dp))
                    Pill("START") { editSelected() }
                }
            }
        }
    }

    @Composable
    private fun PadButton(letter: String, label: String, color: Color, onClick: () -> Unit) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(28.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF111111))
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp)
        ) {
            Box(
                modifier = Modifier.size(18.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    letter,
                    color = if (letter == "Y") Color.Black else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
            Spacer(Modifier.width(5.dp))
            Text(label, color = Color(0xFFAAAAAA), fontSize = 10.sp, maxLines = 1)
        }
    }

    @Composable
    private fun BottomBar() {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PadButton("A", "Abrir", Color(0xFF6BBE45)) { openSelected() }
            PadButton("B", "Voltar", Color(0xFFE8453C)) { back() }
            PadButton("Y", "Pesquisar", Color(0xFFFFB400)) { overlay = Overlay.Search }
            PadButton("X", "Aleatório", Color(0xFF2E86DE)) { randomPick() }
        }
    }

    // ---------- Capas ----------
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun GameCard(g: Game, selected: Boolean, recent: Boolean, accent: Color, modifier: Modifier) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.06f else 1f, label = "scale")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glow")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    if (glow > 0.01f) {
                        val r = radius.dp.toPx()
                        for (i in 12 downTo 1) {
                            val e = i * 2.4.dp.toPx()
                            drawRoundRect(
                                accent.copy(alpha = 0.05f * glow),
                                Offset(-e, -e),
                                Size(size.width + 2 * e, size.height + 2 * e),
                                CornerRadius(r + e)
                            )
                        }
                    }
                }
                .clip(shape)
                .background(Color(0xFF1C1C1E))
                .border(if (selected) 3.dp else 2.dp, if (selected) accent else Color(0xFF2C2C2E), shape)
                .combinedClickable(
                    onClick = { selectedId = g.id },
                    onLongClick = {
                        selectedId = g.id
                        overlay = Overlay.Edit(g)
                    }
                )
        ) {
            if (g.cover.isBlank()) {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(10.dp)
                )
            } else {
                AsyncImage(
                    model = g.cover, contentDescription = g.title,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
            if (recent) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xE6FFFFFF)),
                    contentAlignment = Alignment.Center
                ) { Text("🕒", fontSize = 9.sp) }
            }
            if (g.isFavorite) {
                Text(
                    "⭐", fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 6.dp, bottom = 5.dp)
                )
            }
            Text(
                g.platform.uppercase(),
                color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, softWrap = false,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            )
        }
    }

    @Composable
    private fun AddTile(selected: Boolean, accent: Color, modifier: Modifier) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.06f else 1f, label = "scaleAdd")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowAdd")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    if (glow > 0.01f) {
                        val r = radius.dp.toPx()
                        for (i in 12 downTo 1) {
                            val e = i * 2.4.dp.toPx()
                            drawRoundRect(
                                accent.copy(alpha = 0.05f * glow),
                                Offset(-e, -e),
                                Size(size.width + 2 * e, size.height + 2 * e),
                                CornerRadius(r + e)
                            )
                        }
                    }
                }
                .clip(shape)
                .background(Color(0xFF0D0D0D))
                .border(if (selected) 3.dp else 2.dp, if (selected) accent else Color(0xFF444444), shape)
                .clickable {
                    if (selectedId == ADD_ID) overlay = Overlay.Edit(null) else selectedId = ADD_ID
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("+", color = Color(0xFF888888), fontSize = 36.sp)
                Text("Adicionar", color = Color(0xFF888888), fontSize = 11.sp)
            }
        }
    }

    // ---------- Componentes de formulário ----------
    @Composable
    private fun CField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
        val shape = RoundedCornerShape(10.dp)
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, C_BORDER, shape)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (value.isEmpty()) Text(hint, color = C_MUTED, fontSize = 13.sp, maxLines = 1)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    @Composable
    private fun CSelect(
        label: String, value: String, options: List<String>,
        modifier: Modifier = Modifier, onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(10.dp)
        Box(modifier) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(shape)
                    .background(C_FIELD)
                    .border(1.dp, C_BORDER, shape)
                    .clickable { open = true }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(
                    value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text("▾", color = C_MUTED, fontSize = 12.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { o ->
                    DropdownMenuItem(text = { Text(o, fontSize = 14.sp) }, onClick = {
                        onSelect(o)
                        open = false
                    })
                }
            }
        }
    }

    @Composable
    private fun CButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }

    @Composable
    private fun CToggle(text: String, checked: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
        val shape = RoundedCornerShape(10.dp)
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, if (checked) C_YELLOW else C_BORDER, shape)
                .clickable { onChange(!checked) }
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                (if (checked) "☑ " else "☐ ") + text,
                color = if (checked) C_YELLOW else Color.White, fontSize = 13.sp, maxLines = 1
            )
        }
    }

    @Composable
    private fun HideBarsInDialog() {
        val view = LocalView.current
        SideEffect {
            val win = (view.parent as? DialogWindowProvider)?.window
            if (win != null) {
                WindowCompat.setDecorFitsSystemWindows(win, false)
                val c = WindowInsetsControllerCompat(win, view)
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    @Composable
    private fun NexusModal(
        title: String, onDismiss: () -> Unit, tall: Boolean = false,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier.fillMaxSize().imePadding(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (landscape) 0.86f else 0.94f)
                        .then(if (tall) Modifier.fillMaxHeight(if (landscape) 0.94f else 0.9f) else Modifier)
                        .clip(RoundedCornerShape(20.dp))
                        .background(C_PANEL)
                        .border(1.dp, C_BORDER, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    content()
                }
            }
        }
    }

    // ---------- Diálogos ----------
    @Composable
    private fun AppIcon(pkg: String) {
        val bmp = remember(pkg) { iconFor(pkg) }
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(36.dp))
        } else {
            Spacer(Modifier.size(36.dp))
        }
    }

    @Composable
    private fun AppPickerDialog() {
        var q by remember { mutableStateOf("") }
        val k = q.trim().lowercase()
        val filtered = if (k.isEmpty()) allApps else allApps.filter {
            it.label.lowercase().contains(k) || it.pkg.lowercase().contains(k)
        }
        NexusModal("Escolher app", { appPickerOpen = false }, tall = true) {
            CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                appPickerCb?.invoke(null)
                                appPickerOpen = false
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚙️  Automático (padrão da plataforma)", color = C_BLUE, fontSize = 14.sp)
                    }
                }
                items(filtered, key = { it.pkg }) { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                appPickerCb?.invoke(a)
                                appPickerOpen = false
                            }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(a.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.label, color = Color.White, fontSize = 14.sp, maxLines = 1)
                            Text(a.pkg, color = C_MUTED, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { appPickerOpen = false }
        }
    }

    @Composable
    private fun GameDialog(initial: Game?) {
        var title by remember { mutableStateOf(initial?.title ?: "") }
        var platform by remember { mutableStateOf(initial?.platform ?: PLATFORMS[0]) }
        var genre by remember { mutableStateOf(initial?.genre ?: (genres.firstOrNull() ?: "")) }
        var cover by remember { mutableStateOf(initial?.cover ?: "") }
        var webUrl by remember { mutableStateOf(initial?.webUrl ?: "") }
        var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
        var romUri by remember { mutableStateOf(initial?.romUri ?: "") }
        var romName by remember {
            mutableStateOf(if (initial != null && initial.romUri.isNotEmpty()) displayName(Uri.parse(initial.romUri)) else "")
        }
        var fav by remember { mutableStateOf(initial?.isFavorite ?: false) }
        val isWeb = platform == WEB_PLATFORM

        val save: () -> Unit = {
            if (title.isNotBlank()) {
                val now = System.currentTimeMillis()
                val exec = if (initial == null || initial.platform != platform) {
                    DEFAULT_EXEC[platform] ?: "native"
                } else initial.execType
                val base = initial ?: Game(
                    id = UUID.randomUUID().toString(), title = "", platform = platform, genre = genre
                )
                val favTs = if (fav && initial?.isFavorite != true) now else (initial?.favoriteTs ?: 0L)
                val saved = base.copy(
                    title = title.trim(), platform = platform, genre = genre,
                    cover = cover.trim(), webUrl = webUrl.trim(), execType = exec,
                    pkg = pkg, romUri = romUri, isFavorite = fav, favoriteTs = favTs
                )
                if (initial == null) {
                    games.add(saved)
                    saveLibrary()
                } else replaceGame(saved)
                selectGame(saved.id)
                overlay = Overlay.None
            } else toast("Digite o título")
        }

        val fPlat: @Composable () -> Unit = {
            CSelect("Plataforma:", platform, PLATFORMS, Modifier.fillMaxWidth()) { platform = it }
        }
        val fRom: @Composable () -> Unit = {
            if (isWeb) {
                CField(webUrl, { webUrl = it }, "Link Web do Jogo (URL)", Modifier.fillMaxWidth())
            } else {
                CButton(
                    if (romUri.isEmpty()) "📁 Escolher ROM" else "📁 $romName",
                    C_BLUE, Modifier.fillMaxWidth()
                ) {
                    dialogRomCb = { uri ->
                        romUri = uri.toString()
                        romName = displayName(uri)
                        if (title.isBlank()) title = cleanTitle(romName, platform == "PS Vita")
                    }
                    pickRomForDialog.launch(arrayOf("*/*"))
                }
            }
        }
        val fTitle: @Composable () -> Unit = {
            CField(title, { title = it }, "Título do jogo", Modifier.fillMaxWidth())
        }
        val fHint: @Composable () -> Unit = {
            if (platform == "PS Vita") {
                Text(
                    "⚠ Vita3K+: o título precisa conter o ID do jogo (ex.: PCSA00029)",
                    color = C_ORANGE, fontSize = 10.sp, maxLines = 2
                )
            }
        }
        val fGenre: @Composable (Modifier) -> Unit = { m ->
            CSelect("Gênero:", genre.ifEmpty { "—" }, genres.toList(), m) { genre = it }
        }
        val fFav: @Composable (Modifier) -> Unit = { m ->
            CToggle("Favorito ⭐", fav, m) { fav = it }
        }
        val fCover: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(cover, { cover = it }, "URL da capa", Modifier.weight(1f))
                CButton("📋 Colar", C_ORANGE, Modifier.width(88.dp)) {
                    val t = clipboardText()
                    if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                }
            }
        }
        val fSteam: @Composable () -> Unit = {
            CButton("🔍 Procurar no SteamGridDB", C_GRAY, Modifier.fillMaxWidth()) { openSteamGrid(title) }
        }
        val fApp: @Composable () -> Unit = {
            if (!isWeb) {
                val label = allApps.firstOrNull { it.pkg == pkg }?.label
                CButton(
                    if (pkg.isEmpty()) "App/emulador: automático" else "App: ${label ?: pkg}",
                    C_GRAY, Modifier.fillMaxWidth()
                ) {
                    appPickerCb = { a -> pkg = a?.pkg ?: "" }
                    appPickerOpen = true
                }
            }
        }
        val buttons: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar (B)", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                if (initial != null) {
                    CButton("Apagar", C_RED, Modifier.weight(1f)) {
                        games.removeAll { it.id == initial.id }
                        saveLibrary()
                        selectedId = visibleGames().firstOrNull()?.id
                        overlay = Overlay.None
                    }
                }
                CButton("Salvar", C_BLUE, Modifier.weight(1f)) { save() }
            }
        }

        NexusModal(if (initial == null) "Adicionar Novo Jogo" else "Configurar: ${initial.title}", { overlay = Overlay.None }) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fPlat()
                        fRom()
                        fTitle()
                        fHint()
                        fGenre(Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fCover()
                        fSteam()
                        fApp()
                        fFav(Modifier.fillMaxWidth())
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fPlat()
                    fRom()
                    fTitle()
                    fHint()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        fGenre(Modifier.weight(1f))
                        fFav(Modifier.width(128.dp))
                    }
                    fCover()
                    fSteam()
                    fApp()
                }
            }
            Spacer(Modifier.height(12.dp))
            buttons()
        }
    }

    @Composable
    private fun FilterDialog() {
        val present = PLATFORMS.filter { p -> games.any { it.platform == p } }
        val fFavOnly: @Composable () -> Unit = {
            CToggle("Apenas Favoritos ⭐", favOnly, Modifier.fillMaxWidth()) { favOnly = it }
        }
        val fPlat: @Composable () -> Unit = {
            CSelect(
                "Plataforma:", if (fPlatform.isEmpty()) "Todas" else fPlatform,
                listOf("Todas") + present, Modifier.fillMaxWidth()
            ) { fPlatform = if (it == "Todas") "" else it }
        }
        val fGen: @Composable () -> Unit = {
            CSelect(
                "Gênero:", if (fGenre.isEmpty()) "Todos" else fGenre,
                listOf("Todos") + genres.toList(), Modifier.fillMaxWidth()
            ) { fGenre = if (it == "Todos") "" else it }
        }
        val fSort: @Composable () -> Unit = {
            CSelect("Ordem:", SORTS[sortMode], SORTS, Modifier.fillMaxWidth()) { sortMode = SORTS.indexOf(it) }
        }
        NexusModal("Filtrar Biblioteca", { overlay = Overlay.None }) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fFavOnly()
                        fPlat()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fGen()
                        fSort()
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fFavOnly()
                    fPlat()
                    fGen()
                    fSort()
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Remover Filtros", C_ORANGE, Modifier.weight(1f)) { resetFilters() }
                CButton("Fechar", C_BLUE, Modifier.weight(1f)) {
                    selectedId = visibleGames().firstOrNull()?.id
                    overlay = Overlay.None
                }
            }
        }
    }

    @Composable
    private fun SearchDialog() {
        var q by remember { mutableStateOf("") }
        val focus = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            try {
                focus.requestFocus()
            } catch (_: Exception) {
            }
        }
        val k = q.trim().lowercase()
        val all = games.toList()
        val results = if (k.isEmpty()) emptyList() else {
            all.filter { it.title.lowercase().startsWith(k) }.sortedBy { it.title.lowercase() } +
                all.filter { !it.title.lowercase().startsWith(k) && it.title.lowercase().contains(k) }
                    .sortedBy { it.title.lowercase() }
        }
        NexusModal("Pesquisar", { overlay = Overlay.None }) {
            CField(q, { q = it }, "Digite o título", Modifier.fillMaxWidth().focusRequester(focus))
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.heightIn(max = if (landscape) 110.dp else 300.dp)) {
                items(results, key = { it.id }) { g ->
                    Text(
                        "${g.title}  ·  ${g.platform}", color = Color.White, fontSize = 14.sp, maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectGame(g.id)
                                overlay = Overlay.None
                            }
                            .padding(vertical = 10.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
        }
    }

    @Composable
    private fun SettingsDialog() {
        var newGenre by remember { mutableStateOf("") }
        val accent = parseColor(accentHex)

        val fSlider: @Composable () -> Unit = {
            Column {
                Text(
                    if (landscape) "Paisagem (W): ${widthL}px" else "Retrato (W): ${widthP}px",
                    color = Color.White, fontSize = 12.sp
                )
                Slider(
                    value = (if (landscape) widthL else widthP).toFloat(),
                    onValueChange = { v -> if (landscape) widthL = v.toInt() else widthP = v.toInt() },
                    onValueChangeFinished = { savePrefs() },
                    valueRange = 110f..260f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent),
                    modifier = Modifier.height(30.dp)
                )
            }
        }
        val fCorners: @Composable () -> Unit = {
            CSelect(
                "Cantos:", RADII.firstOrNull { it.second == radius }?.first ?: "Personalizado",
                RADII.map { it.first }, Modifier.fillMaxWidth()
            ) { n ->
                radius = RADII.first { it.first == n }.second
                savePrefs()
            }
        }
        val fColors: @Composable () -> Unit = {
            Column {
                Text("Cor da borda", color = Color.White, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    COLORS.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(parseColor(hex))
                                .border(if (accentHex.equals(hex, true)) 3.dp else 0.dp, Color.White, CircleShape)
                                .clickable {
                                    accentHex = hex
                                    savePrefs()
                                }
                        )
                    }
                }
            }
        }
        val fCutout: @Composable () -> Unit = {
            CToggle("Recuar área da câmera", cutoutPad, Modifier.fillMaxWidth()) {
                cutoutPad = it
                savePrefs()
            }
        }
        val fNewGenre: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newGenre, { newGenre = it }, "Novo gênero", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val g = newGenre.trim()
                    if (g.isNotEmpty() && g !in genres) {
                        genres.add(g)
                        savePrefs()
                    }
                    newGenre = ""
                }
            }
        }
        val fManage: @Composable () -> Unit = {
            CButton("✏ Editar / apagar gêneros (${genres.size})", C_GRAY, Modifier.fillMaxWidth()) {
                overlay = Overlay.Genres
            }
        }
        val fBackup: @Composable () -> Unit = {
            Column {
                Text("Backup e Dados", color = Color.White, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CButton("Exportar", C_BLUE, Modifier.weight(1f)) {
                        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        exportLauncher.launch("nexus_backup_$d.json")
                    }
                    CButton("Importar", C_ORANGE, Modifier.weight(1f)) { importLauncher.launch(arrayOf("*/*")) }
                    CButton("Resetar", C_RED, Modifier.weight(1f)) { overlay = Overlay.ConfirmReset }
                }
            }
        }

        NexusModal("Configurações do Nexus", { overlay = Overlay.None }) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fSlider()
                        fCorners()
                        fColors()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fCutout()
                        fNewGenre()
                        fManage()
                        fBackup()
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    fSlider()
                    fCorners()
                    fColors()
                    fCutout()
                    fNewGenre()
                    fManage()
                    fBackup()
                }
            }
            Spacer(Modifier.height(12.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
        }
    }

    @Composable
    private fun GenresDialog() {
        var newGenre by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        NexusModal("Gêneros", { overlay = Overlay.Settings }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newGenre, { newGenre = it }, "Novo gênero", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val g = newGenre.trim()
                    if (g.isNotEmpty() && g !in genres) {
                        genres.add(g)
                        savePrefs()
                    }
                    newGenre = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(genres.toList(), key = { it }) { g ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == g) {
                            CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                renameGenre(g, editText)
                                editing = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else {
                            val used = games.count { it.genre == g }
                            Text(
                                "$g  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                editing = g
                                editText = g
                            }
                            CButton("🗑", C_RED, Modifier.width(48.dp)) { deleteGenre(g) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Ao apagar, os jogos desse gênero ficam sem gênero.",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun ConfirmResetDialog() {
        NexusModal("Resetar biblioteca?", { overlay = Overlay.None }) {
            Text(
                "Isso apaga suas alterações e restaura a lista original de jogos.",
                color = Color(0xFFCCCCCC), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar (B)", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                CButton("Resetar", C_RED, Modifier.weight(1f)) {
                    games.clear()
                    games.addAll(defaultGames())
                    saveLibrary()
                    resetFilters()
                    selectedId = visibleGames().firstOrNull()?.id
                    overlay = Overlay.None
                }
            }
        }
    }
}
