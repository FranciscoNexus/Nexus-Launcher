package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

data class AppItem(val label: String, val pkg: String)

class RomEntry(val name: String, val folder: String, val uri: String)

class RomListRequest(val platform: String, val onPick: (String, String) -> Unit)

class EmuPickerRequest(val platform: EmuPlatform, val onPick: (EmuPlayer) -> Unit)

class BuiltIntent(val intent: Intent, val kill: Boolean)

class ScanResult(val roms: List<RomEntry>, val failed: Int)

sealed class Overlay {
    object None : Overlay()
    class Edit(val game: Game?) : Overlay()
    object Filter : Overlay()
    object Settings : Overlay()
    object Genres : Overlay()
    object Platforms : Overlay()
    class LinkEdit(val link: PlatformLink?) : Overlay()
    object Search : Overlay()
    object ConfirmReset : Overlay()
    class ConfirmDelete(val game: Game) : Overlay()
    class Info(val id: String) : Overlay()
    class PlatformImage(val name: String) : Overlay()
    object Collections : Overlay()
    class ConfirmDeleteCollection(val name: String) : Overlay()
    object PlatformList : Overlay()
    object StoragePrompt : Overlay()
    class PlatformEdit(val platform: GamePlatform?) : Overlay()
    class ConfirmDeletePlatform(val platform: GamePlatform) : Overlay()
}

private const val ADD_ID = "__add__"
private const val PLAT_PREFIX = "plat:"

class SgdbPicker(val title: String, val term: String, val portrait: Boolean, val onPick: (String) -> Unit)

private const val APP_VERSION = "4.0.5"

// Paleta do destaque (borda e LED). A ordem é a mesma da paleta antiga, para migrar quem já tinha uma cor salva.
private val ACCENTS = listOf(
    "Azul" to "#0A84FF", "Verde" to "#30D158", "Laranja" to "#FF9F0A", "Vermelho" to "#FF453A",
    "Roxo" to "#BF5AF2", "Amarelo" to "#FFD60A", "Branco" to "#FFFFFF", "Ciano" to "#00E5FF",
    "Rosa" to "#FF375F", "Verde-limão" to "#AEEA00"
)
private val OLD_COLORS = listOf(
    "#007AFF", "#4CD964", "#FF9500", "#FF3B30", "#AF52DE", "#FFCC00", "#FFFFFF",
    "#00E5FF", "#FF2D95", "#C6FF00"
)

private val SORTS = listOf(
    "Padrão (Recentes > Favoritos > A-Z)",
    "Histórico (todos os jogados)",
    "A-Z (crescente)",
    "Z-A (decrescente)"
)

private val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

private val PAD_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2
)

// Navegação com repetição: 1 toque = 1 item; segurando, repete após HOLD_DELAY_MS
// e acelera de RATE_MIN até RATE_MAX itens/segundo ao longo de RATE_RAMP_MS.
private const val HOLD_DELAY_MS = 400L
private const val RATE_MIN = 3f
private const val RATE_MAX = 6f
private const val RATE_RAMP_MS = 2000L
private const val PAGE_ITEMS = 4
private const val TRIGGER_PRESS = 0.10f   // zona morta de 10% dos gatilhos
private const val TRIGGER_RELEASE = 0.05f
private const val STICK_ON = 0.6f
private const val STICK_OFF = 0.4f

private val C_PANEL = Color(0xFF141720)
private val C_FIELD = Color(0xFF11141C)
private val C_BORDER = Color(0x24FFFFFF)
private val C_MUTED = Color(0xFF9AA3B5)
private val C_BLUE = Color(0xFF0A84FF)
private val C_ORANGE = Color(0xFFF59E0B)
private val C_RED = Color(0xFFE11D48)
private val C_GRAY = Color(0xFF1E222B)
private val C_YELLOW = Color(0xFFFBBF24)
private val S_PANEL = Color(0xFF141720)
private val HDR_BG = Color(0xE0181C25)
private val HDR_LINE = Color(0x1AFFFFFF)
private val S_CARD = Color(0xFF1A1E29)
private val S_FIELD = Color(0xFF11141C)
private val S_LINE = Color(0x1AFFFFFF)
private val S_MUTED = Color(0xFF9AA3B5)
private val S_PAD_A = Color(0xFF1DB87A)
private val S_PAD_B = Color(0xFFE5484D)

class MainActivity : ComponentActivity() {

    // ---------- Estado ----------
    private val prefs by lazy { getSharedPreferences("nexus_prefs", MODE_PRIVATE) }
    private val libFile by lazy { File(filesDir, "library.json") }
    private val sgdbFile by lazy { File(filesDir, "sgdb_cache.json") }
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sgdbKey by mutableStateOf("")
    private var hideSgdbHint by mutableStateOf(false)
    private val sgdbCache = mutableStateMapOf<String, SgdbInfo>()
    private val sgdbErr = mutableStateMapOf<String, String>()
    private var sgdbBusy by mutableStateOf(setOf<String>())
    private var sgdbPicker by mutableStateOf<SgdbPicker?>(null)
    private val games = mutableStateListOf<Game>()
    private val genres = mutableStateListOf<String>()
    private val links = mutableStateListOf<PlatformLink>()
    private val platforms = mutableStateListOf<GamePlatform>()
    private var allApps: List<AppItem> = emptyList()
    private val iconCache = HashMap<String, ImageBitmap?>()
    private val bigIconCache = HashMap<String, ImageBitmap?>()

    private var selectedId by mutableStateOf<String?>(null)
    private var coverRev by mutableStateOf(0)
    private var storageOk by mutableStateOf(false)
    private var overlay by mutableStateOf<Overlay>(Overlay.None)
    private var landscape by mutableStateOf(false)
    private var widthP by mutableStateOf(175)
    private var widthL by mutableStateOf(170)
    private var radius by mutableStateOf(14)
    private var accentHex by mutableStateOf("#0A84FF")
    private var settingsTab by mutableStateOf(0)
    private var cutoutPad by mutableStateOf(false)
    private var favOnly by mutableStateOf(false)
    private var searchTerm by mutableStateOf("")
    private var fPlatform by mutableStateOf("")
    private var dashMode by mutableStateOf(0)
    private var dashPlatform by mutableStateOf("")
    private var fGenre by mutableStateOf("")
    private var fCollection by mutableStateOf("")
    private var sortMode by mutableStateOf(0)
    private var battery by mutableStateOf(0)
    private var charging by mutableStateOf(false)
    private var appPickerOpen by mutableStateOf(false)
    private var appPickerNone by mutableStateOf("Automático (padrão da plataforma)")
    private var romList by mutableStateOf<RomListRequest?>(null)
    private var emuPicker by mutableStateOf<EmuPickerRequest?>(null)

    private var appPickerCb: ((AppItem?) -> Unit)? = null
    private val collections = mutableStateListOf<String>()
    private var collPickerOpen by mutableStateOf(false)
    private val collPickerSel = mutableStateListOf<String>()
    private var collPickerCb: ((List<String>) -> Unit)? = null
    private var gridColumns = 2
    private val padHandler = Handler(Looper.getMainLooper())
    private val heldKeys = LinkedHashSet<Int>()
    private var axisDx = 0
    private var axisDy = 0
    private var holdDx = 0
    private var holdDy = 0
    private var holdStartMs = 0L
    private var ltDown = false
    private var rtDown = false
    private val repeatTick = object : Runnable {
        override fun run() {
            if ((holdDx == 0 && holdDy == 0) || modalOpen()) {
                stopHold()
                return
            }
            stepSelection(holdDx, holdDy)
            val held = SystemClock.uptimeMillis() - holdStartMs - HOLD_DELAY_MS
            val t = (held.toFloat() / RATE_RAMP_MS).coerceIn(0f, 1f)
            val rate = RATE_MIN + (RATE_MAX - RATE_MIN) * t
            padHandler.postDelayed(this, (1000f / rate).toLong())
        }
    }
    private var pendingPlay: Game? = null
    private var dialogRomCb: ((Uri) -> Unit)? = null
    private var treeCb: ((String) -> Unit)? = null

    // ---------- Launchers ----------
    private val pickRomForPlay = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val g = pendingPlay
        pendingPlay = null
        if (uri != null && g != null) {
            persist(uri)
            val updated = g.copy(romUri = uri.toString())
            replaceGame(updated)
            launchGame(updated)
        }
    }

    private val pickRomForDialog = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            dialogRomCb?.invoke(uri)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) writeBackup(uri) }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) readBackup(uri) }

    private val treePicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            treeCb?.invoke(uri.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPrefs()
        requestedOrientation = orientationFlag()
        applyFullscreen()
        allApps = loadApps()
        loadLibrary()
        syncPlatforms()
        sgdbCache.putAll(SgdbStore.load(sgdbFile))
        File(filesDir, "rawg_cache.json").delete() // restos da integração antiga
        Covers.init(this)
        storageOk = hasAllFiles()
        if (!storageOk && !prefs.getBoolean("storagePrompted", false)) {
            prefs.edit().putBoolean("storagePrompted", true).apply()
            overlay = Overlay.StoragePrompt
        }
        prefetchCovers()
        selectedId = firstNavId()
        setContent {
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, 1f)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                        NexusScreen()
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen() else stopHold()
    }

    private fun applyFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Preferências ----------
    private fun loadPrefs() {
        landscape = prefs.getBoolean("landscape", false)
        widthP = prefs.getInt("widthP", 175)
        widthL = prefs.getInt("widthL", 170)
        radius = canonicalRadius(prefs.getInt("radius", 14))
        accentHex = normalizeAccent(prefs.getString("color", "#0A84FF") ?: "#0A84FF")
        cutoutPad = prefs.getBoolean("cutoutPad", false)
        sgdbKey = prefs.getString("sgdbKey", "") ?: ""
        hideSgdbHint = prefs.getBoolean("hideSgdbHint", false)
        if (prefs.contains("rawgKey")) prefs.edit().remove("rawgKey").apply()
        dashMode = prefs.getInt("dashMode", 0)
        collections.clear()
        prefs.getString("collectionsList", null)?.let { s ->
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val n = a.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            } catch (_: Exception) {
            }
        }
        genres.clear()
        val gs = prefs.getString("genres", null)
        if (gs != null) {
            try {
                val a = JSONArray(gs)
                for (i in 0 until a.length()) genres.add(a.getString(i))
            } catch (_: Exception) {
            }
        }
        if (genres.isEmpty()) genres.addAll(GENRES)
        platforms.clear()
        val ps = prefs.getString("platformsList", null)
        if (ps != null) {
            try {
                platforms.addAll(PlatformStore.parse(ps))
            } catch (_: Exception) {
            }
        }
        if (platforms.isEmpty()) platforms.addAll(defaultPlatforms())
        links.clear()
        val ls = prefs.getString("links", null)
        if (ls != null) {
            try {
                links.addAll(LinkStore.parse(ls))
            } catch (_: Exception) {
            }
        }
    }

    private fun savePrefs() {
        prefs.edit()
            .putBoolean("landscape", landscape)
            .putInt("widthP", widthP)
            .putInt("widthL", widthL)
            .putInt("radius", radius)
            .putString("color", accentHex)
            .putBoolean("cutoutPad", cutoutPad)
            .putInt("dashMode", dashMode)
            .putString("collectionsList", JSONArray(collections.toList()).toString())
            .putString("genres", JSONArray(genres.toList()).toString())
            .putString("links", LinkStore.toJson(links.toList()))
            .putString("platformsList", PlatformStore.toJson(platforms.toList()))
            .apply()
    }

    private fun orientationFlag(): Int =
        if (landscape) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

    private fun toggleOrientation() {
        landscape = !landscape
        requestedOrientation = orientationFlag()
        savePrefs()
    }

    // ---------- Tema ao vivo (3.9.5) ----------
    // 0 = Reto, 1 = Padrão, 2 = Suave. Tudo (painéis, cards, botões, campos) lê estes valores.
    private fun styleOf(r: Int): Int = when {
        r <= 6 -> 0
        r <= 17 -> 1
        else -> 2
    }
    private fun canonicalRadius(r: Int): Int = intArrayOf(4, 14, 22)[styleOf(r)]
    private fun normalizeAccent(hex: String): String {
        ACCENTS.firstOrNull { it.second.equals(hex, true) }?.let { return it.second }
        val i = OLD_COLORS.indexOfFirst { it.equals(hex, true) }
        return if (i >= 0) ACCENTS[i].second else hex
    }
    private val styleIdx: Int get() = styleOf(radius)
    private val rPanel: Int get() = intArrayOf(6, 18, 28)[styleIdx]
    private val rCard: Int get() = intArrayOf(4, 14, 22)[styleIdx]
    private val rBtn: Int get() = intArrayOf(4, 11, 18)[styleIdx]
    private fun onAccent(c: Color): Color = if (c.luminance() > 0.55f) Color(0xFF07090D) else Color.White

    /** Borda de foco na cor de destaque (navegação por controle). Deve vir ANTES do clickable. */
    @Composable
    private fun Modifier.focusGlow(shape: Shape): Modifier {
        var focused by remember { mutableStateOf(false) }
        val accent = parseColor(accentHex)
        return this
            .onFocusChanged { focused = it.isFocused }
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
    }

    private fun parseColor(hex: String): Color = try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        Color(0xFF0A84FF)
    }

    // ---------- Biblioteca ----------
    private fun defaultGames(): List<Game> =
        LibraryStore.parse(assets.open("default_library.json").bufferedReader().use { it.readText() })

    private fun loadLibrary() {
        val existed = libFile.exists()
        val list = try {
            if (existed) LibraryStore.parse(libFile.readText()) else defaultGames()
        } catch (e: Exception) {
            toast("Erro ao ler biblioteca: ${e.message}")
            emptyList()
        }
        games.addAll(list)
        if (!existed) saveLibrary()
    }

    private fun saveLibrary() {
        try {
            libFile.writeText(LibraryStore.toJson(games.toList()))
        } catch (e: Exception) {
            toast("Erro ao salvar: ${e.message}")
        }
    }

    private fun replaceGame(updated: Game) {
        val idx = games.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            games[idx] = updated
            saveLibrary()
        }
    }

    private fun markPlayed(g: Game) {
        val idx = games.indexOfFirst { it.id == g.id }
        if (idx >= 0) {
            games[idx] = games[idx].copy(
                lastPlayedTs = System.currentTimeMillis(),
                openCount = games[idx].openCount + 1
            )
            saveLibrary()
        }
    }

    private fun recentIds(): Set<String> =
        games.filter { it.lastPlayedTs > 0 }
            .sortedByDescending { it.lastPlayedTs }
            .take(3).map { it.id }.toSet()

    // Filtros do botão Select (favoritos, plataforma, gênero e coleção), sem o recorte do dashboard.
    private fun filteredGames(): List<Game> {
        var l: List<Game> = games.toList()
        if (favOnly) l = l.filter { it.isFavorite }
        if (fPlatform.isNotEmpty()) l = l.filter { it.platform == fPlatform }
        if (fGenre.isNotEmpty()) l = l.filter { it.genre == fGenre }
        if (fCollection.isNotEmpty()) l = l.filter { fCollection in it.collections }
        val k = searchTerm.trim().lowercase()
        if (k.isNotEmpty()) {
            l = l.filter { g ->
                g.title.lowercase().contains(k) || g.platform.lowercase().contains(k) ||
                    g.genre.lowercase().contains(k) || g.collections.any { it.lowercase().contains(k) }
            }
        }
        return l
    }

    private fun visibleGames(): List<Game> {
        var l: List<Game> = filteredGames()
        if (dashMode == 1 && dashPlatform.isNotEmpty()) l = l.filter { it.platform == dashPlatform }
        return when (sortMode) {
            1 -> l.filter { it.lastPlayedTs > 0 }.sortedByDescending { it.lastPlayedTs }
            2 -> l.sortedAlpha { it.title }
            3 -> l.sortedAlpha { it.title }.reversed()
            else -> {
                val rec = l.filter { it.lastPlayedTs > 0 }
                    .sortedByDescending { it.lastPlayedTs }.take(3)
                val ids = rec.map { it.id }.toSet()
                val rest = l.filter { it.id !in ids }
                rec +
                    rest.filter { it.isFavorite }.sortedAlpha { it.title } +
                    rest.filter { !it.isFavorite }.sortedAlpha { it.title }
            }
        }
    }

    // ---------- Dashboard por plataformas ----------
    private fun platformCards(): List<GamePlatform> =
        filteredGames().let { fg ->
            platforms.filter { p -> fg.any { it.platform == p.name } }
                .sortedAlpha { it.name }
        }

    // Tela de plataformas ativa (modo Plataformas, fora de qualquer plataforma e com ao menos um jogo).
    private fun inPlatformList(): Boolean =
        dashMode == 1 && dashPlatform.isEmpty() && platformCards().isNotEmpty()

    private fun navIds(): List<String> =
        if (inPlatformList()) platformCards().map { PLAT_PREFIX + it.name }
        else visibleGames().map { it.id } + ADD_ID

    private fun firstNavId(): String? =
        if (inPlatformList()) navIds().firstOrNull() else visibleGames().firstOrNull()?.id

    private fun enterPlatform(name: String) {
        dashPlatform = name
        selectedId = visibleGames().firstOrNull()?.id
    }

    private fun exitPlatform() {
        val left = dashPlatform
        dashPlatform = ""
        selectedId = if (platformCards().any { it.name == left }) PLAT_PREFIX + left else firstNavId()
    }

    private fun savePlatformImage(name: String, url: String) {
        val i = platforms.indexOfFirst { it.name == name }
        if (i < 0) return
        val old = platforms[i].image
        val u = url.trim()
        platforms[i] = platforms[i].copy(image = u)
        savePrefs()
        if (old.isNotBlank() && old != u) {
            Covers.purgeIfUnused(old, games.map { it.cover } + platforms.map { it.image })
        }
        prefetchCovers()
    }

    private fun resetFilters() {
        favOnly = false
        fPlatform = ""
        fGenre = ""
        fCollection = ""
        searchTerm = ""
        sortMode = 0
    }

    private fun selectGame(id: String) {
        if (dashMode == 1) {
            games.firstOrNull { it.id == id }?.let { if (dashPlatform != it.platform) dashPlatform = it.platform }
        }
        if (visibleGames().none { it.id == id }) resetFilters()
        selectedId = id
    }

    // ---------- Coleções (franquias e grupos) ----------
    private fun addCollection(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        if (collections.any { it.equals(n, ignoreCase = true) }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        collections.add(n)
        savePrefs()
    }

    private fun renameCollection(old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty() || n == old) return
        if (collections.any { it.equals(n, ignoreCase = true) && it != old }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        val i = collections.indexOf(old)
        if (i >= 0) collections[i] = n
        if (fCollection == old) fCollection = n
        for (k in games.indices) {
            if (old in games[k].collections) {
                games[k] = games[k].copy(collections = games[k].collections.map { if (it == old) n else it })
            }
        }
        saveLibrary()
        savePrefs()
    }

    private fun deleteCollection(c: String) {
        collections.remove(c)
        if (fCollection == c) fCollection = ""
        for (k in games.indices) {
            if (c in games[k].collections) games[k] = games[k].copy(collections = games[k].collections - c)
        }
        saveLibrary()
        savePrefs()
    }

    private fun renameGenre(old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty() || (n != old && n in genres)) return
        val i = genres.indexOf(old)
        if (i >= 0) genres[i] = n
        for (k in games.indices) if (games[k].genre == old) games[k] = games[k].copy(genre = n)
        if (fGenre == old) fGenre = n
        saveLibrary()
        savePrefs()
    }

    private fun deleteGenre(g: String) {
        genres.remove(g)
        for (k in games.indices) if (games[k].genre == g) games[k] = games[k].copy(genre = "")
        if (fGenre == g) fGenre = ""
        saveLibrary()
        savePrefs()
    }

    // ---------- Ações ----------
    // Um passo na direção (dx, dy). Na paisagem só importa dx; no retrato dy anda uma linha.
    private fun stepSelection(dx: Int, dy: Int) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val step = dx + (if (landscape) 0 else dy * max(1, gridColumns))
        if (step == 0) return
        val target = idx + step
        if (target in ids.indices) {
            selectedId = ids[target]
        } else if (dy > 0 && !landscape) {
            selectedId = ids.last()
        }
    }

    // RB (+1) / LB (-1): PAGE_ITEMS jogos. Paisagem = para o lado; retrato = linhas para baixo/cima na mesma coluna.
    private fun pageStep(sign: Int) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val unit = if (landscape) 1 else max(1, gridColumns)
        selectedId = ids[(idx + sign * PAGE_ITEMS * unit).coerceIn(0, ids.lastIndex)]
    }

    // RT (toEnd = true) / LT (false): último/primeiro jogo da fila.
    // Paisagem = fim/começo da lista; retrato = fim/topo da coluna em que está.
    private fun jumpEdge(toEnd: Boolean) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val lastGame = if (ids.lastOrNull() == ADD_ID) ids.size - 2 else ids.size - 1 // "Adicionar" não conta
        if (lastGame < 0) return
        if (landscape) {
            selectedId = ids[if (toEnd) lastGame else 0]
            return
        }
        val cols = max(1, gridColumns)
        val col = idx % cols
        val target = if (toEnd) {
            if (lastGame >= col) lastGame - ((lastGame - col) % cols) else lastGame
        } else {
            if (col <= lastGame) col else 0
        }
        selectedId = ids[target]
    }

    private fun currentDir(): Pair<Int, Int> {
        when (heldKeys.lastOrNull()) {
            KeyEvent.KEYCODE_DPAD_LEFT -> return Pair(-1, 0)
            KeyEvent.KEYCODE_DPAD_RIGHT -> return Pair(1, 0)
            KeyEvent.KEYCODE_DPAD_UP -> return Pair(0, -1)
            KeyEvent.KEYCODE_DPAD_DOWN -> return Pair(0, 1)
        }
        return Pair(axisDx, axisDy)
    }

    // Chamado sempre que botão/alavanca muda: nova direção = um passo imediato + início da contagem de "segurar".
    private fun updateHold() {
        val (dx, dy) = currentDir()
        if (dx == holdDx && dy == holdDy) return
        holdDx = dx
        holdDy = dy
        padHandler.removeCallbacks(repeatTick)
        if (dx == 0 && dy == 0) return
        stepSelection(dx, dy)
        holdStartMs = SystemClock.uptimeMillis()
        padHandler.postDelayed(repeatTick, HOLD_DELAY_MS)
    }

    private fun stopHold() {
        padHandler.removeCallbacks(repeatTick)
        heldKeys.clear()
        axisDx = 0
        axisDy = 0
        holdDx = 0
        holdDy = 0
        ltDown = false
        rtDown = false
    }

    private fun handleTriggers(ev: MotionEvent) {
        val l = max(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val r = max(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        if (!ltDown && l >= TRIGGER_PRESS) {
            ltDown = true
            jumpEdge(false)
        } else if (ltDown && l < TRIGGER_RELEASE) {
            ltDown = false
        }
        if (!rtDown && r >= TRIGGER_PRESS) {
            rtDown = true
            jumpEdge(true)
        } else if (rtDown && r < TRIGGER_RELEASE) {
            rtDown = false
        }
    }

    // ---------- Plataformas cadastradas ----------
    private fun platformNames(): List<String> = sortPlatforms(platforms.toList()).map { it.name }

    // Android não usa emulador, então não entra no vínculo de plataformas e emuladores.
    private fun linkablePlatforms(): List<String> = platformNames().filter { it != ANDROID_PLATFORM }

    // Chave para tabelas embutidas (extensões de ROM, emulador padrão), mesmo se a plataforma foi renomeada.
    private fun execKey(platform: String): String {
        val b = platforms.firstOrNull { it.name == platform }?.base ?: ""
        return if (b.isEmpty()) platform else b
    }

    // Garante que "Web / Navegador" exista e que toda plataforma usada por algum jogo esteja cadastrada.
    private fun syncPlatforms() {
        var changed = false
        for (fixed in listOf(WEB_PLATFORM, ANDROID_PLATFORM)) {
            if (platforms.none { it.name == fixed }) {
                platforms.add(GamePlatform(fixed, DEFAULT_MANUFACTURER[fixed] ?: "", fixed))
                changed = true
            }
        }
        for (g in games) {
            if (g.platform.isNotBlank() && platforms.none { it.name == g.platform }) {
                platforms.add(
                    GamePlatform(g.platform, DEFAULT_MANUFACTURER[g.platform] ?: "", if (g.platform in PLATFORMS) g.platform else "")
                )
                changed = true
            }
        }
        if (changed) savePrefs()
    }

    private fun savePlatform(old: GamePlatform?, name: String, manufacturer: String): Boolean {
        val n = name.trim()
        if (n.isEmpty()) {
            toast("Digite o nome da plataforma")
            return false
        }
        if (platforms.any { it.name.equals(n, ignoreCase = true) && it.name != old?.name }) {
            toast("Já existe uma plataforma com esse nome")
            return false
        }
        val m0 = manufacturer.trim()
        val m = platforms.map { it.manufacturer }.firstOrNull { it.isNotBlank() && it.equals(m0, ignoreCase = true) } ?: m0
        if (old == null) {
            platforms.add(GamePlatform(n, m, ""))
        } else {
            val i = platforms.indexOfFirst { it.name == old.name }
            if (i >= 0) platforms[i] = old.copy(name = n, manufacturer = m)
            if (n != old.name) {
                for (k in games.indices) if (games[k].platform == old.name) games[k] = games[k].copy(platform = n)
                for (k in links.indices) if (links[k].platform == old.name) links[k] = links[k].copy(platform = n)
                if (fPlatform == old.name) fPlatform = n
                if (dashPlatform == old.name) dashPlatform = n
                saveLibrary()
            }
        }
        savePrefs()
        return true
    }

    private fun deletePlatform(p: GamePlatform) {
        platforms.removeAll { it.name == p.name }
        links.removeAll { it.platform == p.name }
        if (fPlatform == p.name) fPlatform = ""
        savePrefs()
        overlay = Overlay.PlatformList
    }

    // ---------- SteamGridDB ----------
    private fun saveSgdb() = SgdbStore.save(sgdbFile, sgdbCache.toMap())

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    private fun fmtReleased(secs: Long): String {
        if (secs <= 0L) return ""
        val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(secs * 1000L))
    }

    // Busca nome oficial e data de lançamento no SteamGridDB e guarda no aparelho. Só repete se force = true.
    private fun fetchSgdb(g: Game, force: Boolean = false) {
        val key = sgdbKey.trim()
        if (key.isEmpty() || g.id in sgdbBusy) return
        if (!force && sgdbCache[g.id] != null) return
        sgdbBusy = sgdbBusy + g.id
        sgdbErr.remove(g.id)
        mainScope.launch {
            val res = withContext(Dispatchers.IO) { SgdbApi.lookup(key, g.title) }
            sgdbBusy = sgdbBusy - g.id
            when (res) {
                is SgdbResult.Ok -> {
                    sgdbCache[g.id] = res.info
                    saveSgdb()
                }
                is SgdbResult.Failure -> {
                    sgdbErr[g.id] = res.message
                }
            }
        }
    }

    // Abre o seletor de imagens do SteamGridDB (capas de jogos em pé; imagens de plataformas em qualquer formato).
    private fun openSgdbPicker(title: String, term: String, portrait: Boolean, onPick: (String) -> Unit) {
        if (sgdbKey.isBlank()) {
            toast("Adicione sua chave do SteamGridDB em Configurações")
            return
        }
        if (term.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        sgdbPicker = SgdbPicker(title, term, portrait, onPick)
    }

    private fun testSgdbKey() {
        val key = sgdbKey.trim()
        if (key.isEmpty()) {
            toast("Cole sua chave primeiro")
            return
        }
        toast("Testando chave…")
        mainScope.launch {
            val err = withContext(Dispatchers.IO) { SgdbApi.ping(key) }
            toast(err ?: "Chave válida ✓")
        }
    }

    private fun prefetchCovers() = Covers.prefetch(this, games.map { it.cover } + platforms.map { it.image })

    private fun refreshCover(url: String) {
        val u = url.trim()
        if (u.isEmpty()) {
            toast("Sem URL de capa")
            return
        }
        toast("Atualizando capa…")
        Covers.refresh(this, u) { ok ->
            if (ok) coverRev++
            toast(if (ok) "Capa atualizada" else "Não foi possível atualizar. Mantive a capa salva.")
        }
    }

    private fun deleteGame(g: Game) {
        games.removeAll { it.id == g.id }
        saveLibrary()
        Covers.purgeIfUnused(g.cover, games.map { it.cover })
        if (sgdbCache.remove(g.id) != null) saveSgdb()
        selectedId = visibleGames().firstOrNull()?.id
        overlay = Overlay.None
    }

    private fun openSelected() {
        val id = selectedId ?: return
        if (id.startsWith(PLAT_PREFIX)) {
            enterPlatform(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == ADD_ID) {
            overlay = Overlay.Edit(null)
            return
        }
        if (games.none { it.id == id }) return
        overlay = Overlay.Info(id)
    }

    private fun infoPlay(g: Game) {
        overlay = Overlay.None
        playGame(g)
    }

    private fun editSelected() {
        val id = selectedId
        if (id != null && id.startsWith(PLAT_PREFIX)) {
            overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == null || id == ADD_ID) {
            overlay = Overlay.Edit(null)
            return
        }
        games.firstOrNull { it.id == id }?.let { overlay = Overlay.Edit(it) }
    }

    private fun randomPick() {
        if (inPlatformList()) {
            selectedId = navIds().random()
            return
        }
        val l = visibleGames()
        if (l.isNotEmpty()) selectedId = l.random().id
    }

    private fun back() {
        when {
            romList != null -> romList = null
            emuPicker != null -> emuPicker = null
            appPickerOpen -> appPickerOpen = false
            sgdbPicker != null -> sgdbPicker = null
            collPickerOpen -> collPickerOpen = false
            overlay is Overlay.Genres || overlay is Overlay.Platforms || overlay is Overlay.PlatformList || overlay is Overlay.Collections -> overlay = Overlay.Settings
            overlay is Overlay.ConfirmDeleteCollection -> overlay = Overlay.Collections
            overlay is Overlay.LinkEdit -> overlay = Overlay.Platforms
            overlay is Overlay.ConfirmDelete -> overlay = Overlay.Edit((overlay as Overlay.ConfirmDelete).game)
            overlay is Overlay.PlatformEdit -> overlay = Overlay.PlatformList
            overlay is Overlay.ConfirmDeletePlatform -> overlay = Overlay.PlatformEdit((overlay as Overlay.ConfirmDeletePlatform).platform)
            overlay !is Overlay.None -> overlay = Overlay.None
            dashMode == 1 && dashPlatform.isNotEmpty() -> exitPlatform()
            else -> selectedId = null
        }
    }

    private fun playGame(g: Game) {
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        val tpl = if (g.customCmd.isNotBlank()) g.customCmd
        else if (pkg != null) templateFor(pkg, link) else null
        if (tpl != null && tpl.contains("{file.") && g.romUri.isEmpty()) {
            if (link != null && link.folders.isNotEmpty()) {
                romList = RomListRequest(g.platform) { uri, _ ->
                    val u = g.copy(romUri = uri)
                    replaceGame(u)
                    launchGame(u)
                }
            } else {
                pendingPlay = g
                pickRomForPlay.launch(arrayOf("*/*"))
            }
        } else {
            launchGame(g)
        }
    }

    // ---------- Controle (gamepad) ----------
    private fun modalOpen(): Boolean = overlay !is Overlay.None || appPickerOpen || emuPicker != null || collPickerOpen || sgdbPicker != null || romList != null

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (code !in PAD_KEYS) return super.dispatchKeyEvent(ev)

        if (modalOpen()) {
            stopHold()
            val inf = overlay
            if (inf is Overlay.Info && !collPickerOpen) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    when (code) {
                        KeyEvent.KEYCODE_BUTTON_A -> games.firstOrNull { it.id == inf.id }?.let { infoPlay(it) }
                        KeyEvent.KEYCODE_BUTTON_B -> back()
                        KeyEvent.KEYCODE_BUTTON_START -> games.firstOrNull { it.id == inf.id }?.let { overlay = Overlay.Edit(it) }
                    }
                }
                return true
            }
            if (overlay is Overlay.Settings && (code == KeyEvent.KEYCODE_BUTTON_L1 || code == KeyEvent.KEYCODE_BUTTON_R1)) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    settingsTab = if (code == KeyEvent.KEYCODE_BUTTON_R1) (settingsTab + 1) % 3 else (settingsTab + 2) % 3
                }
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) back()
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_A) {
                return super.dispatchKeyEvent(
                    KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                )
            }
            return super.dispatchKeyEvent(ev)
        }

        val isDpad = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT
        if (isDpad) {
            // A repetição é feita por nós (com aceleração); ignora o auto-repeat do sistema.
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) {
                    heldKeys.remove(code)
                    heldKeys.add(code)
                    updateHold()
                }
            } else if (ev.action == KeyEvent.ACTION_UP) {
                heldKeys.remove(code)
                updateHold()
            }
            return true
        }

        if (ev.action == KeyEvent.ACTION_DOWN) {
            val first = ev.repeatCount == 0
            when (code) {
                KeyEvent.KEYCODE_BUTTON_R1 -> if (first) pageStep(1)
                KeyEvent.KEYCODE_BUTTON_L1 -> if (first) pageStep(-1)
                KeyEvent.KEYCODE_BUTTON_R2 -> if (first) jumpEdge(true)
                KeyEvent.KEYCODE_BUTTON_L2 -> if (first) jumpEdge(false)
                KeyEvent.KEYCODE_BUTTON_A -> if (first) openSelected()
                KeyEvent.KEYCODE_BUTTON_B -> if (first) back()
                KeyEvent.KEYCODE_BUTTON_X -> if (first) randomPick()
                KeyEvent.KEYCODE_BUTTON_Y -> if (first) overlay = Overlay.Search
                KeyEvent.KEYCODE_BUTTON_START -> if (first) editSelected()
                KeyEvent.KEYCODE_BUTTON_SELECT -> if (first) overlay = Overlay.Filter
            }
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoy = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE) {
            if (modalOpen()) {
                stopHold()
                return super.dispatchGenericMotionEvent(ev)
            }
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val sx = ev.getAxisValue(MotionEvent.AXIS_X)
            val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
            val ax = if (abs(hx) > 0.5f) hx else sx
            val ay = if (abs(hy) > 0.5f) hy else sy
            val limit = if (axisDx != 0 || axisDy != 0) STICK_OFF else STICK_ON
            var ndx = 0
            var ndy = 0
            if (abs(ax) > limit || abs(ay) > limit) {
                if (abs(ax) >= abs(ay)) ndx = if (ax > 0) 1 else -1
                else ndy = if (ay > 0) 1 else -1
            }
            axisDx = ndx
            axisDy = ndy
            updateHold()
            handleTriggers(ev)
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        storageOk = hasAllFiles() // volta da tela de permissões do Android
    }

    override fun onPause() {
        stopHold()
        super.onPause()
    }

    // ---------- Apps / lançamento ----------
    private fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedAlpha { it.label }
    }

    private fun iconFor(pkg: String): ImageBitmap? = iconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    // Ícone em alta resolução (usado como capa dos jogos da plataforma Android).
    private fun bigIconFor(pkg: String): ImageBitmap? = bigIconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun resolvePkg(g: Game): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    private fun launchGame(g: Game) {
        if (g.execType == "browser") {
            if (g.webUrl.isBlank()) {
                toast("Este jogo não tem link configurado")
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val custom = g.customCmd.trim()
        if (custom.isNotEmpty()) {
            val b = buildIntent(custom, g) ?: return
            try {
                startActivity(b.intent)
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        if (pkg == null) {
            if (link != null && link.pkg.isNotEmpty()) {
                toast("O emulador ${link.playerName.ifEmpty { link.pkg }} não está instalado")
            } else {
                toast("Defina o app em Editar (segure a capa ou aperte START)")
            }
            return
        }
        val tpl = templateFor(pkg, link)
        try {
            if (tpl != null && !(tpl.contains("{file.") && g.romUri.isEmpty())) {
                val b = buildIntent(tpl, g) ?: return
                if (b.kill) {
                    try {
                        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                    } catch (_: Exception) {
                    }
                }
                startActivity(b.intent)
                markPlayed(g)
                return
            }
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                toast("Não foi possível abrir $pkg")
                return
            }
            startActivity(intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    private fun effectivePkg(g: Game, link: PlatformLink?): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        if (link != null && link.pkg.isNotEmpty() && isInstalled(link.pkg)) return link.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun templateFor(pkg: String, link: PlatformLink?): String? {
        if (link != null && link.pkg == pkg && link.template.isNotBlank()) return link.template
        return TEMPLATES[pkg]
    }

    // ---------- Acesso a todos os arquivos (para pastas de ROMs vindas de backup) ----------
    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: Exception) {
                    toast("Abra Configurações > Apps > Nexus e libere o acesso a todos os arquivos")
                }
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77)
        }
    }

    private fun fileUri(f: File): String =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", f).toString()

    private fun safReadable(uri: String): Boolean = try {
        val pfd = contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) {
            false
        } else {
            pfd.close()
            true
        }
    } catch (_: Exception) {
        false
    }

    // Se o Nexus não tem mais a permissão da pasta (ex.: backup importado), usa o arquivo direto pelo acesso a todos os arquivos.
    private fun effectiveRomUri(uri: String): String {
        if (uri.isEmpty() || !hasAllFiles()) return uri
        val u = Uri.parse(uri)
        if (u.authority != "com.android.externalstorage.documents") return uri
        if (safReadable(uri)) return uri
        val f = File(pathOf(uri))
        if (!f.isFile) return uri
        return try {
            fileUri(f)
        } catch (_: Exception) {
            uri
        }
    }

    private fun treePath(tree: String): String {
        val id = try {
            DocumentsContract.getTreeDocumentId(Uri.parse(tree))
        } catch (_: Exception) {
            ""
        }
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    private fun walkFiles(dir: File, path: String, exts: Set<String>?, out: MutableList<RomEntry>, depth: Int) {
        if (depth > 12 || out.size > 20000) return
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (k.isDirectory) {
                walkFiles(k, "$path${k.name}/", exts, out, depth + 1)
            } else {
                val ext = k.name.substringAfterLast('.', "").lowercase()
                if (exts == null || ext in exts) out.add(RomEntry(k.name, path, fileUri(k)))
            }
        }
    }

    private fun pathOf(uri: String): String {
        if (!uri.startsWith("content://")) return Uri.parse(uri).path ?: uri
        val pu = Uri.parse(uri)
        if (pu.authority == "$packageName.fileprovider") return "/" + (pu.path ?: "").removePrefix("/root/")
        val id = docIdOf(uri)
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    // Converte o comando em um Intent.
    private fun buildIntent(tpl: String, g: Game): BuiltIntent? {
        val uriStr = effectiveRomUri(g.romUri)
        val fileName = if (uriStr.isEmpty()) "" else fileNameOf(uriStr)
        val unsupported = Regex("\\{tags\\.([A-Za-z0-9_]+)\\}").findAll(tpl)
            .map { it.groupValues[1] }.firstOrNull { it != "vita_game_id" }
        if (unsupported != null) {
            toast("Este emulador usa {tags.$unsupported}, que o Nexus ainda não preenche. Use um comando personalizado no jogo.")
            return null
        }
        val idRe = Regex("[A-Z]{4}\\d{5}")
        val vitaId = idRe.find(g.title)?.value ?: idRe.find(fileName)?.value ?: ""
        if (tpl.contains("{tags.vita_game_id}") && vitaId.isEmpty()) {
            toast("Vita3K+ precisa do ID do jogo no título (ex.: PCSA00029)")
            return null
        }
        fun sub(x: String): String = x
            .replace("{file.uri}", uriStr)
            .replace("{file.path}", if (uriStr.isEmpty()) "" else pathOf(uriStr))
            .replace("{file.name}", fileName)
            .replace("{file.mime}", if (uriStr.isEmpty()) "" else mimeOf(fileName))
            .replace("{tags.vita_game_id}", vitaId)

        val t = tpl.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var comp: ComponentName? = null
        var action: String? = null
        var data: String? = null
        var type: String? = null
        val cats = ArrayList<String>()
        val extras = LinkedHashMap<String, String>()
        val arrays = LinkedHashMap<String, List<String>>()
        val typed = ArrayList<Triple<String, Char, String>>()
        var flags = Intent.FLAG_ACTIVITY_NEW_TASK
        var kill = false
        try {
            var i = 0
            while (i < t.size) {
                when (t[i]) {
                    "-n" -> {
                        i++
                        val p = sub(t[i]).split("/")
                        if (p.size == 2) {
                            val cls = if (p[1].startsWith(".")) p[0] + p[1] else p[1]
                            comp = ComponentName(p[0], cls)
                        }
                    }
                    "-a" -> { i++; action = sub(t[i]) }
                    "-c" -> { i++; cats.add(sub(t[i])) }
                    "-d" -> { i++; data = sub(t[i]) }
                    "-t" -> { i++; type = sub(t[i]) }
                    "-e", "--es" -> {
                        i++
                        val k = t[i]
                        i++
                        extras[k] = sub(t[i])
                    }
                    "--esa" -> {
                        i++
                        val k = t[i]
                        i++
                        arrays[k] = sub(t[i]).split(",")
                    }
                    "--ez", "--ei", "--el" -> {
                        val kind = t[i].last()
                        i++
                        val k = t[i]
                        i++
                        typed.add(Triple(k, kind, sub(t[i])))
                    }
                    "-f" -> {
                        i++
                        flags = flags or java.lang.Long.decode(t[i]).toInt()
                    }
                    "--activity-clear-task" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    "--activity-clear-top" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    "--activity-no-history" -> flags = flags or Intent.FLAG_ACTIVITY_NO_HISTORY
                    "--nexus-kill" -> kill = true
                }
                i++
            }
        } catch (_: Exception) {
            toast("Comando de abertura inválido")
            return null
        }
        val intent = Intent()
        val a = action
        if (a != null) intent.action = a
        val c = comp
        if (c != null) intent.component = c
        for (cat in cats) intent.addCategory(cat)
        val d = data
        val ty = type
        if (d != null && ty != null) intent.setDataAndType(Uri.parse(d), ty)
        else if (d != null) intent.data = Uri.parse(d)
        else if (ty != null) intent.type = ty
        for ((k, v) in extras) intent.putExtra(k, v)
        for ((k, v) in arrays) intent.putExtra(k, v.toTypedArray())
        for ((k, kind, v) in typed) {
            when (kind) {
                'z' -> intent.putExtra(k, v.equals("true", ignoreCase = true))
                'i' -> intent.putExtra(k, v.toIntOrNull() ?: 0)
                else -> intent.putExtra(k, v.toLongOrNull() ?: 0L)
            }
        }
        intent.addFlags(flags)
        if (uriStr.startsWith("content://")) {
            intent.clipData = ClipData.newRawUri("rom", Uri.parse(uriStr))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return BuiltIntent(intent, kill)
    }

    private fun mimeOf(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun linkFor(platform: String): PlatformLink? = links.firstOrNull { it.platform == platform }

    private fun addPlatforms(current: String?): List<String> {
        val all = platformNames()
        val base = if (links.isEmpty()) all
        else all.filter { p -> p == ANDROID_PLATFORM || p == WEB_PLATFORM || links.any { it.platform == p } }
        return if (current != null && current !in base) base + current else base
    }

    private fun docIdOf(uri: String): String = try {
        DocumentsContract.getDocumentId(Uri.parse(uri))
    } catch (_: Exception) {
        Uri.parse(uri).lastPathSegment ?: ""
    }

    private fun fileNameOf(uri: String): String =
        docIdOf(uri).substringAfterLast('/').substringAfterLast(':')

    private fun scanRoms(platform: String): ScanResult {
        val link = linkFor(platform) ?: return ScanResult(emptyList(), 0)
        val exts = link.exts.takeIf { it.isNotEmpty() }?.toSet() ?: ROM_EXT[execKey(platform)]
        val out = ArrayList<RomEntry>()
        var failed = 0
        val granted = contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }.map { it.uri.toString() }
        for (f in link.folders) {
            if (f in granted) {
                try {
                    val tree = Uri.parse(f)
                    walkTree(tree, DocumentsContract.getTreeDocumentId(tree), "", exts, out, 0)
                } catch (_: Exception) {
                    failed++
                }
            } else if (hasAllFiles()) {
                // Sem permissão da pasta (ex.: veio de backup): lê direto pelo acesso a todos os arquivos.
                try {
                    val dir = File(treePath(f))
                    if (dir.isDirectory) walkFiles(dir, "", exts, out, 0) else failed++
                } catch (_: Exception) {
                    failed++
                }
            } else {
                failed++
            }
        }
        return ScanResult(out.distinctBy { it.uri }.sortedAlpha { it.name }, failed)
    }

    private fun walkTree(
        tree: Uri, docId: String, path: String, exts: Set<String>?,
        out: MutableList<RomEntry>, depth: Int
    ) {
        if (depth > 12 || out.size > 20000) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(kids, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walkTree(tree, id, "$path$name/", exts, out, depth + 1)
                } else {
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (exts == null || ext in exts) {
                        out.add(RomEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()))
                    }
                }
            }
        }
    }

    private fun folderLabel(s: String): String = try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(s))
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        (if (vol.equals("primary", true)) "Interno" else vol) + "/" + rel
    } catch (_: Exception) {
        s
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun openSteamGrid(title: String) {
        if (title.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        val url = "https://www.steamgriddb.com/search/grids?term=" + URLEncoder.encode(title.trim(), "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    private fun cleanTitle(file: String, keepId: Boolean): String {
        var s = file.substringBeforeLast('.', file)
        s = s.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
        if (!keepId) s = s.replace(Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$"), "")
        return s.trim()
    }

    // ---------- Backup ----------
    private fun writeBackup(uri: Uri) {
        try {
            val o = JSONObject(LibraryStore.toJson(games.toList()))
            o.put("platforms", PlatformStore.toJsonArray(platforms.toList()))
            o.put("genresList", JSONArray(genres.toList()))
            o.put("platformLinks", LinkStore.toJsonArray(links.toList()))
            o.put(
                "visualPrefs",
                JSONObject().put("widthP", widthP).put("widthL", widthL)
                    .put("radius", "${radius}px").put("color", accentHex)
            )
            o.put("currentOrientation", if (landscape) "landscape" else "portrait")
            o.put("cutoutPad", cutoutPad)
            o.put("dashboardMode", dashMode)
            o.put("collectionsList", JSONArray(collections.toList()))
            o.put("backupFormat", 2)
            contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray(Charsets.UTF_8)) }
            toast("Backup salvo")
        } catch (e: Exception) {
            toast("Erro ao exportar: ${e.message}")
        }
    }

    private fun readBackup(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            if (raw.isNullOrBlank()) {
                toast("Arquivo de backup vazio")
                return
            }
            val text = raw.removePrefix("\uFEFF")
            val o = JSONObject(text)
            if (!o.has("games")) {
                toast("Este arquivo não parece um backup do Nexus")
                return
            }
            // Lê tudo ANTES de mexer no estado: se algo falhar, nada é alterado.
            val list = LibraryStore.parse(text)
            val newGenres = o.optJSONArray("genresList")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
            } ?: emptyList()
            val newLinks = o.optJSONArray("platformLinks")?.let { LinkStore.parse(it.toString()) }
            val newPlatforms = o.optJSONArray("platforms")?.let { PlatformStore.parse(it.toString()) }

            games.clear()
            games.addAll(list)
            saveLibrary()

            if (newGenres.isNotEmpty()) {
                genres.clear()
                genres.addAll(newGenres)
            }
            o.optJSONObject("visualPrefs")?.let { v ->
                widthP = v.optInt("widthP", widthP)
                widthL = v.optInt("widthL", widthL)
                val r = v.optString("radius", "").filter { it.isDigit() }
                if (r.isNotEmpty()) radius = canonicalRadius(r.toInt())
                val c = v.optString("color", "")
                if (c.startsWith("#")) {
                    try {
                        android.graphics.Color.parseColor(c)
                        accentHex = normalizeAccent(c)
                    } catch (_: Exception) {
                    }
                }
            }
            when (o.optString("currentOrientation", "")) {
                "landscape" -> landscape = true
                "portrait" -> landscape = false
            }
            requestedOrientation = orientationFlag()
            if (o.has("cutoutPad")) cutoutPad = o.optBoolean("cutoutPad", cutoutPad)
            if (o.has("dashboardMode")) dashMode = if (o.optInt("dashboardMode", 0) == 1) 1 else 0
            dashPlatform = ""
            collections.clear()
            o.optJSONArray("collectionsList")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val n = arr.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            }
            for (g in list) for (c in g.collections) if (c !in collections) collections.add(c)
            if (newLinks != null) {
                links.clear()
                links.addAll(newLinks)
            }
            if (!newPlatforms.isNullOrEmpty()) {
                platforms.clear()
                platforms.addAll(newPlatforms)
            }
            syncPlatforms()
            savePrefs()
            resetFilters()
            prefetchCovers()
            selectedId = firstNavId()
            if (!storageOk && links.any { it.folders.isNotEmpty() }) overlay = Overlay.StoragePrompt
            toast("Backup importado: ${list.size} jogos")
        } catch (e: Exception) {
            toast("Erro ao importar: ${e.message}")
        }
    }

    // ---------- Tela principal ----------
    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        battery = if (level < 0 || scale <= 0) 0 else level * 100 / scale
        charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
    }

    @Composable
    private fun NexusScreen() {
        val ctx = LocalContext.current
        val list = visibleGames()
        val accent = parseColor(accentHex)
        val recents = recentIds()
        val inPlat = inPlatformList()
        val platCards = if (inPlat) platformCards() else emptyList()
        val ids = if (inPlat) platCards.map { PLAT_PREFIX + it.name } else list.map { it.id } + ADD_ID
        BackHandler(enabled = dashMode == 1 && dashPlatform.isNotEmpty() && overlay is Overlay.None) { exitPlatform() }
        val gridState = rememberLazyGridState()
        val rowState = rememberLazyListState()

        DisposableEffect(Unit) {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    if (i != null) updateBattery(i)
                }
            }
            val sticky = ContextCompat.registerReceiver(
                ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            if (sticky != null) updateBattery(sticky)
            onDispose { ctx.unregisterReceiver(receiver) }
        }

        val cols by remember {
            derivedStateOf {
                val v = gridState.layoutInfo.visibleItemsInfo
                if (v.isEmpty()) 2 else max(1, v.count { it.offset.y == v.first().offset.y })
            }
        }
        SideEffect { gridColumns = cols }

        LaunchedEffect(selectedId, landscape) {
            val idx = ids.indexOf(selectedId)
            if (idx >= 0) {
                if (landscape) {
                    val info = rowState.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                    val ok = item != null && item.offset >= 0 && item.offset + item.size <= info.viewportEndOffset
                    if (!ok) rowState.animateScrollToItem(idx)
                } else {
                    val info = gridState.layoutInfo
                    val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                    val ok = item != null && item.offset.y >= 0 &&
                        item.offset.y + item.size.height <= info.viewportEndOffset
                    if (!ok) gridState.animateScrollToItem(idx)
                }
            }
        }

        val blurR by animateDpAsState(if (overlay is Overlay.Info) 14.dp else 0.dp, label = "infoBlur")
        val title = when (val s = selectedId) {
            null -> ""
            ADD_ID -> "Adicionar Novo Jogo"
            else -> if (s.startsWith(PLAT_PREFIX)) s.removePrefix(PLAT_PREFIX) else (games.firstOrNull { it.id == s }?.title ?: "")
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0C10))
                .drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.12f), Color.Transparent),
                            center = Offset(size.width * 0.32f, size.height * 0.52f),
                            radius = size.width * 0.52f
                        )
                    )
                }
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                .then(if (blurR > 0.dp) Modifier.blur(blurR) else Modifier)
        ) {
            Header(title)

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (landscape) {
                    LazyRow(
                        state = rowState,
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (inPlat) {
                            items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                                PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent, Modifier.width(widthL.dp))
                            }
                        } else {
                            items(list, key = { it.id }) { g ->
                                GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.width(widthL.dp))
                            }
                            item(key = ADD_ID) {
                                AddTile(selectedId == ADD_ID, accent, Modifier.width(widthL.dp))
                            }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        state = gridState,
                        // Jogos: 3 por linha. Plataformas: 2 por linha.
                        columns = if (inPlat) GridCells.Fixed(2) else GridCells.Fixed(3),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (inPlat) {
                            items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                                PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent, Modifier.fillMaxWidth())
                            }
                        } else {
                            items(list, key = { it.id }) { g ->
                                GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.fillMaxWidth())
                            }
                            item(key = ADD_ID) {
                                AddTile(selectedId == ADD_ID, accent, Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }

            BottomBar(inPlat)
        }

        when (val o = overlay) {
            Overlay.None -> {}
            is Overlay.Edit -> GameDialog(o.game)
            Overlay.Filter -> FilterDialog()
            Overlay.Settings -> SettingsDialog()
            Overlay.Genres -> GenresDialog()
            Overlay.Platforms -> PlatformsDialog()
            is Overlay.LinkEdit -> LinkEditDialog(o.link)
            Overlay.Search -> SearchDialog()
            Overlay.ConfirmReset -> ConfirmResetDialog()
            is Overlay.ConfirmDelete -> ConfirmDeleteDialog(o.game)
            is Overlay.Info -> InfoOverlay(o.id)
            is Overlay.PlatformImage -> PlatformImageDialog(o.name)
            Overlay.Collections -> CollectionsDialog()
            is Overlay.ConfirmDeleteCollection -> ConfirmDeleteCollectionDialog(o.name)
            Overlay.PlatformList -> PlatformListDialog()
            Overlay.StoragePrompt -> StoragePromptDialog()
            is Overlay.PlatformEdit -> PlatformEditDialog(o.platform)
            is Overlay.ConfirmDeletePlatform -> ConfirmDeletePlatformDialog(o.platform)
        }
        if (appPickerOpen) AppPickerDialog()
        emuPicker?.let { EmuPickerDialog(it) }
        if (collPickerOpen) CollectionPickerDialog()
        sgdbPicker?.let { SgdbPickerDialog(it) }
        val rl = romList
        if (rl != null) RomListDialog(rl)
    }

    // ---------- Tela de informações do jogo ----------
    @Composable
    private fun InfoOverlay(id: String) {
        val g = games.firstOrNull { it.id == id }
        if (g == null) {
            SideEffect { overlay = Overlay.None }
            return
        }
        LaunchedEffect(id, sgdbKey) { fetchSgdb(g) }
        val info = sgdbCache[id]
        val err = sgdbErr[id]
        val status = when {
            sgdbKey.isBlank() && info == null -> SgdbStatus.NoKey
            id in sgdbBusy -> SgdbStatus.Loading
            info != null && info.found -> SgdbStatus.Found
            info != null -> SgdbStatus.NotFound
            err != null -> SgdbStatus.Failed
            else -> SgdbStatus.Loading
        }
        val extra = if (info != null && info.found) GameInfoData(released = fmtReleased(info.released)) else GameInfoData()
        val url = if (info != null && info.gameId > 0) "https://www.steamgriddb.com/game/${info.gameId}" else "https://www.steamgriddb.com"
        GameInfoScreen(
            game = g,
            extra = extra,
            landscape = landscape,
            accent = parseColor(accentHex),
            cornerDp = rCard,
            panelDp = rPanel,
            btnDp = rBtn,
            source = SgdbView(status, err ?: "", url),
            hintHidden = hideSgdbHint,
            cover = { m -> InfoCover(g, m) },
            onLink = { openUrl(it) },
            onRefresh = { fetchSgdb(g, force = true) },
            onPlay = { infoPlay(g) },
            onOptions = { overlay = Overlay.Edit(g) },
            onBack = { overlay = Overlay.None },
            onToggleFav = {
                val nowFav = !g.isFavorite
                replaceGame(g.copy(isFavorite = nowFav, favoriteTs = if (nowFav) System.currentTimeMillis() else g.favoriteTs))
            },
            onCollections = {
                collPickerSel.clear()
                collPickerSel.addAll(g.collections)
                collPickerCb = { sel -> replaceGame(g.copy(collections = sel)) }
                collPickerOpen = true
            },
            onHideHint = {
                hideSgdbHint = true
                prefs.edit().putBoolean("hideSgdbHint", true).apply()
            }
        )
    }

    @Composable
    private fun InfoCover(g: Game, modifier: Modifier) {
        Box(modifier.background(Color(0xFF1A1E29))) {
            val appIcon = if (g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()) {
                remember(g.pkg) { bigIconFor(g.pkg) }
            } else null
            if (appIcon != null) {
                Image(
                    bitmap = appIcon, contentDescription = g.title,
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
                )
            } else {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(12.dp)
                )
            }
            if (g.cover.isNotBlank()) {
                val req = remember(g.cover) { Covers.request(this@MainActivity, g.cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = g.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    // ---------- Cabeçalho e rodapé ----------
    @Composable
    private fun Pill(text: String, onClick: () -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .height(28.dp)
                .clip(shape)
                .background(HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text, color = Color(0xFFE2E8F0), fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.6.sp, maxLines = 1, softWrap = false
            )
        }
    }

    @Composable
    private fun BatteryPill() {
        val shape = RoundedCornerShape(rBtn.dp)
        val low = battery <= 15 && !charging
        Row(
            modifier = Modifier
                .height(28.dp)
                .clip(shape)
                .background(HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "$battery%", color = if (low) Color(0xFFFB7185) else Color(0xFF34D399),
                fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false
            )
            if (charging) Text(" ⚡", fontSize = 10.sp, maxLines = 1, softWrap = false)
        }
    }

    @Composable
    private fun OrientButton() {
        val shape = RoundedCornerShape(rBtn.dp)
        val ic = Color(0xFFE2E8F0)
        Box(
            modifier = Modifier
                .height(28.dp)
                .width(34.dp)
                .clip(shape)
                .background(HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .clickable { toggleOrientation() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(16.dp)) {
                val w = size.width
                val h = size.height
                val sw = 1.5.dp.toPx()
                drawRoundRect(
                    ic, Offset(w * 0.06f, h * 0.04f), Size(w * 0.5f, h * 0.92f),
                    CornerRadius(w * 0.1f), style = Stroke(width = sw)
                )
                drawCircle(ic, sw * 0.8f, Offset(w * 0.2f, h * 0.8f))
                val p = Path().apply {
                    moveTo(w * 0.68f, h * 0.25f)
                    lineTo(w * 0.82f, h * 0.25f)
                    quadraticBezierTo(w * 0.96f, h * 0.25f, w * 0.96f, h * 0.4f)
                    lineTo(w * 0.96f, h * 0.6f)
                    quadraticBezierTo(w * 0.96f, h * 0.75f, w * 0.82f, h * 0.75f)
                    lineTo(w * 0.68f, h * 0.75f)
                }
                drawPath(p, ic, style = Stroke(width = sw, cap = StrokeCap.Round))
            }
        }
    }

    @Composable
    private fun GearButton() {
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(shape)
                .background(HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .clickable { overlay = Overlay.Settings },
            contentAlignment = Alignment.Center
        ) {
            Text("\u2699\uFE0E", color = Color(0xFFE2E8F0), fontSize = 15.sp)
        }
    }

    @Composable
    private fun TitleText(title: String, modifier: Modifier) {
        // Títulos grandes rolam sozinhos, devagar, em vez de ficarem cortados.
        MarqueeText(title, Color.White, if (landscape) 16 else 14, FontWeight.ExtraBold, modifier)
    }

    @Composable
    private fun Header(title: String) {
        if (landscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OrientButton()
                Spacer(Modifier.width(12.dp))
                TitleText(title, Modifier.weight(1f).padding(end = 8.dp))
                BatteryPill()
                Spacer(Modifier.width(8.dp))
                Pill("SELECT") { overlay = Overlay.Filter }
                Spacer(Modifier.width(8.dp))
                Pill("START") { editSelected() }
                Spacer(Modifier.width(8.dp))
                GearButton()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 4.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OrientButton()
                    Spacer(Modifier.width(8.dp))
                    Pill("SELECT") { overlay = Overlay.Filter }
                    Spacer(Modifier.width(8.dp))
                    Pill("START") { editSelected() }
                    Spacer(Modifier.weight(1f))
                    BatteryPill()
                    Spacer(Modifier.width(8.dp))
                    GearButton()
                }
                Spacer(Modifier.height(10.dp))
                TitleText(title, Modifier.fillMaxWidth())
            }
        }
    }

    @Composable
    @OptIn(ExperimentalTextApi::class)
    private fun PadButton(letter: String, label: String, color: Color, onClick: () -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        val fg = when (letter) {
            "Y" -> Color(0xFF1A1202)
            "A" -> Color(0xFF05140B)
            else -> Color.White
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(Color(0xEB161A23))
                .border(1.dp, Color(0x17FFFFFF), shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp)
        ) {
            Box(
                modifier = Modifier.size(16.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    letter, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 9.5.sp,
                    lineHeight = 9.5.sp, style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                label, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, softWrap = false,
                lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
    }

    @Composable
    private fun BottomBar(platformMode: Boolean = false) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x0FFFFFFF)))
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PadButton("A", if (platformMode) "Abrir" else "Detalhes", Color(0xFF10B981)) { openSelected() }
                PadButton("B", "Voltar", Color(0xFFF43F5E)) { back() }
                PadButton("Y", if (searchTerm.isNotBlank()) "Pesquisar •" else "Pesquisar", Color(0xFFFBBF24)) { overlay = Overlay.Search }
                PadButton("X", "Aleatório", Color(0xFF0EA5E9)) { randomPick() }
            }
        }
    }

    // ---------- Cartão de plataforma (ocupa o espaço de 2 capas) ----------
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun PlatformCard(p: GamePlatform, selected: Boolean, accent: Color, modifier: Modifier) {
        val shape = RoundedCornerShape(radius.dp)
        val sid = PLAT_PREFIX + p.name
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scalePlat")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowPlat")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    if (glow > 0.01f) {
                        val r = radius.dp.toPx()
                        for (i in 12 downTo 1) {
                            val e = i * 2.4.dp.toPx()
                            drawRoundRect(
                                accent.copy(alpha = 0.05f * glow),
                                Offset(-e, -e),
                                Size(size.width + 2 * e, size.height + 2 * e),
                                CornerRadius(r + e)
                            )
                        }
                    }
                }
                .clip(shape)
                .background(Color(0xFF13161E))
                .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
                .combinedClickable(
                    onClick = { selectedId = sid },
                    onLongClick = {
                        selectedId = sid
                        overlay = Overlay.PlatformImage(p.name)
                    }
                )
        ) {
            Text(
                p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center).padding(14.dp)
            )
            if (p.image.isNotBlank()) {
                val req = remember(p.image) { Covers.request(this@MainActivity, p.image) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = p.name,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    @Composable
    private fun PlatformImageDialog(name: String) {
        var url by remember { mutableStateOf(platforms.firstOrNull { it.name == name }?.image ?: "") }
        val accent = parseColor(accentHex)
        val panel = RoundedCornerShape(rPanel.dp)
        val danger = Color(0xFFFF6B81)
        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .widthIn(max = 620.dp)
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                        Spacer(Modifier.width(6.dp))
                        ELabel("IMAGEM DA PLATAFORMA")
                    }
                    Spacer(Modifier.height(2.dp))
                    MarqueeText(name, Color.White, 18, FontWeight.ExtraBold)
                    Spacer(Modifier.height(10.dp))
                    SCard(pad = 10.dp) {
                        Row {
                            CoverThumb(url, name, name, "", Modifier.width(52.dp).height(82.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                PillField("LINK DA IMAGEM", url, { url = it }, "Cole a URL da imagem...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, 6.dp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), Modifier.weight(1f)) {
                                        val t = clipboardText().trim()
                                        if (t.isNotEmpty()) url = t else toast("Área de transferência vazia")
                                    }
                                    EBtn("Limpar", "✕", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { url = "" }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { openSteamGrid(name) }
                            EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), Modifier.weight(1f)) {
                                openSgdbPicker("Imagem: $name", name, true) { u -> url = u }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Sem imagem, o cartão da plataforma mostra só o nome.",
                        color = S_MUTED, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 2.dp, vertical = 4.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { overlay = Overlay.None }
                        EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                            savePlatformImage(name, url)
                            overlay = Overlay.None
                        }
                    }
                }
            }
        }
    }

    // ---------- Capas ----------
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun GameCard(g: Game, selected: Boolean, recent: Boolean, accent: Color, modifier: Modifier) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scale")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glow")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    if (glow > 0.01f) {
                        val r = radius.dp.toPx()
                        for (i in 12 downTo 1) {
                            val e = i * 2.4.dp.toPx()
                            drawRoundRect(
                                accent.copy(alpha = 0.05f * glow),
                                Offset(-e, -e),
                                Size(size.width + 2 * e, size.height + 2 * e),
                                CornerRadius(r + e)
                            )
                        }
                    }
                }
                .clip(shape)
                .background(Color(0xFF13161E))
                .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
                .combinedClickable(
                    onClick = { selectedId = g.id },
                    onLongClick = {
                        selectedId = g.id
                        overlay = Overlay.Info(g.id)
                    }
                )
        ) {
            val appIcon = if (g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()) {
                remember(g.pkg) { bigIconFor(g.pkg) }
            } else null
            if (appIcon != null) {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        bitmap = appIcon, contentDescription = g.title,
                        modifier = Modifier.fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(10.dp)
                )
            }
            if (g.cover.isNotBlank()) {
                val req = remember(g.cover) { Covers.request(this@MainActivity, g.cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = g.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
            if (recent) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color(0xE6FFFFFF)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_hourglass),
                        contentDescription = "Jogado recentemente",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size(width = 10.dp, height = 13.dp)
                    )
                }
            }
            if (g.isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .size(18.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xBF000000))
                        .border(1.dp, Color(0x80FBBF24), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("★", color = Color(0xFFFBBF24), fontSize = 11.sp, lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)) }
            }
            Text(
                g.platform.uppercase(),
                color = Color(0xFFF1F5F9), fontSize = 8.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp, maxLines = 1, softWrap = false,
                lineHeight = 8.sp, style = TextStyle(lineHeightStyle = CenteredLine),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xD9000000))
                    .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                    .height(18.dp)
                    .wrapContentHeight(Alignment.CenterVertically)
                    .padding(horizontal = 6.dp)
            )
        }
    }

    @Composable
    private fun AddTile(selected: Boolean, accent: Color, modifier: Modifier) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scaleAdd")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowAdd")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    if (glow > 0.01f) {
                        val r = radius.dp.toPx()
                        for (i in 12 downTo 1) {
                            val e = i * 2.4.dp.toPx()
                            drawRoundRect(
                                accent.copy(alpha = 0.05f * glow),
                                Offset(-e, -e),
                                Size(size.width + 2 * e, size.height + 2 * e),
                                CornerRadius(r + e)
                            )
                        }
                    }
                }
                .clip(shape)
                .background(Color(0xCC14171F))
                .then(
                    if (selected) Modifier.border(2.2.dp, accent, shape)
                    else Modifier.drawBehind {
                        val sw = 1.5.dp.toPx()
                        drawRoundRect(
                            Color(0x3DFFFFFF),
                            topLeft = Offset(sw / 2, sw / 2),
                            size = Size(size.width - sw, size.height - sw),
                            cornerRadius = CornerRadius(radius.dp.toPx()),
                            style = Stroke(
                                width = sw,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 7.dp.toPx()))
                            )
                        )
                    }
                )
                .clickable {
                    if (selectedId == ADD_ID) overlay = Overlay.Edit(null) else selectedId = ADD_ID
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, Color(0x26FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", color = Color(0xFFE2E8F0), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Adicionar", color = if (selected) Color.White else Color(0xFF94A3B8),
                    fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
                )
            }
        }
    }

    // ---------- Componentes de formulário ----------
    @Composable
    private fun CField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
        val shape = RoundedCornerShape(rBtn.dp)
        var focused by remember { mutableStateOf(false) }
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(if (focused) 2.dp else 1.dp, if (focused) parseColor(accentHex) else C_BORDER, shape)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (value.isEmpty()) Text(hint, color = C_MUTED, fontSize = 13.sp, maxLines = 1)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
            )
        }
    }

    @Composable
    private fun CSelect(
        label: String, value: String, options: List<String>,
        modifier: Modifier = Modifier, subtitle: ((String) -> String)? = null, onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(rBtn.dp)
        Box(modifier) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(shape)
                    .background(C_FIELD)
                    .border(1.dp, C_BORDER, shape)
                    .clickable { open = true }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(
                    value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text("▾", color = C_MUTED, fontSize = 12.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(S_CARD)) {
                options.forEachIndexed { idx, o ->
                    val sub = subtitle?.invoke(o) ?: ""
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(o, color = Color.White, fontSize = 14.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C_MUTED)
                            }
                        },
                        onClick = {
                            onSelect(o)
                            open = false
                        }
                    )
                    if (subtitle != null && idx < options.lastIndex) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .height(1.dp)
                                .background(C_BORDER)
                        )
                    }
                }
            }
        }
    }

    @Composable
    private fun CButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        // Botões "azuis" (ação principal) seguem a cor de destaque escolhida.
        val bg = if (color == C_BLUE) accent else color
        val fg = if (color == C_BLUE) onAccent(accent) else Color.White
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(bg)
                .then(if (color == C_GRAY) Modifier.border(1.dp, Color(0x1FFFFFFF), shape) else Modifier)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }

    @Composable
    private fun CToggle(text: String, checked: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        val accent = parseColor(accentHex)
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, if (checked) accent else C_BORDER, shape)
                .focusGlow(shape)
                .clickable { onChange(!checked) }
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                (if (checked) "☑ " else "☐ ") + text,
                color = if (checked) accent else Color.White, fontSize = 13.sp, maxLines = 1
            )
        }
    }

    @Composable
    private fun HideBarsInDialog() {
        val view = LocalView.current
        SideEffect {
            val win = (view.parent as? DialogWindowProvider)?.window
            if (win != null) {
                WindowCompat.setDecorFitsSystemWindows(win, false)
                // Teclado só aparece quando o usuário toca na caixa de texto.
                win.setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or
                        android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                )
                val c = WindowInsetsControllerCompat(win, view)
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    @Composable
    private fun NexusModal(
        title: String, onDismiss: () -> Unit, tall: Boolean = false,
        footer: (@Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                val accent = parseColor(accentHex)
                val panelShape = RoundedCornerShape(rPanel.dp)
                val closeShape = RoundedCornerShape(rBtn.dp)
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (landscape) 0.86f else 0.94f)
                        .then(if (tall) Modifier.fillMaxHeight(if (landscape) 0.94f else 0.9f) else Modifier)
                        .shadow(14.dp, panelShape, ambientColor = accent, spotColor = accent)
                        .clip(panelShape)
                        .background(C_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) { MarqueeText(title, Color.White, 17, FontWeight.ExtraBold) }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(closeShape)
                                .background(Color(0x0FFFFFFF))
                                .border(1.dp, S_LINE, closeShape)
                                .focusGlow(closeShape)
                                .clickable(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    if (tall) {
                        Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) { content() }
                    } else {
                        // Janelas sem altura fixa rolam quando o conteúdo passa do tamanho da tela.
                        Column(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) { content() }
                    }
                    if (footer != null) {
                        Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) { footer() }
                    }
                }
            }
        }
    }

    /** Linha de lista em cartão de vidro escuro (com foco do controle). Use no lugar do padding simples. */
    @Composable
    private fun Modifier.cardRow(onClick: (() -> Unit)?): Modifier {
        val shape = RoundedCornerShape(rCard.dp)
        return this
            .padding(vertical = 3.dp)
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    }

    // ---------- Diálogos ----------
    @Composable
    private fun AppIcon(pkg: String) {
        val bmp = remember(pkg) { iconFor(pkg) }
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(36.dp))
        } else {
            Spacer(Modifier.size(36.dp))
        }
    }

    @Composable
    private fun AppPickerDialog() {
        var q by remember { mutableStateOf("") }
        val k = q.trim().lowercase()
        val filtered = if (k.isEmpty()) allApps else allApps.filter {
            it.label.lowercase().contains(k) || it.pkg.lowercase().contains(k)
        }
        NexusModal("Escolher app", { appPickerOpen = false }, tall = true) {
            CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                appPickerCb?.invoke(null)
                                appPickerOpen = false
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚙️  $appPickerNone", color = C_BLUE, fontSize = 14.sp)
                    }
                }
                items(filtered, key = { it.pkg }) { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                appPickerCb?.invoke(a)
                                appPickerOpen = false
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(a.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.label, color = Color.White, fontSize = 14.sp, maxLines = 1)
                            Text(a.pkg, color = C_MUTED, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { appPickerOpen = false }
        }
    }

    // ---------- Tela de edição de jogo (3.9.7) ----------
    /** Texto de uma linha que rola sozinho (devagar) quando é maior que o espaço disponível. */
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun MarqueeText(
        text: String, color: Color, size: Int,
        weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
    ) {
        Text(
            text, color = color, fontSize = size.sp, fontWeight = weight,
            maxLines = 1, softWrap = false,
            modifier = modifier.basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
        )
    }

    @Composable
    private fun ELabel(text: String, color: Color = S_MUTED) {
        Text(
            text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp, maxLines = 1
        )
    }

    @Composable
    private fun EPill(
        modifier: Modifier = Modifier, selected: Boolean = false, tint: Color? = null,
        vpad: Dp = 8.dp, onClick: (() -> Unit)? = null,
        content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit
    ) {
        val accent = tint ?: parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .clip(shape)
                .background(if (selected) accent.copy(alpha = 0.12f) else S_FIELD)
                .border(1.dp, if (selected) accent.copy(alpha = 0.55f) else S_LINE, shape)
                .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 10.dp, vertical = vpad),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }

    @Composable
    private fun PillSelect(
        label: String, value: String, options: List<String>,
        modifier: Modifier = Modifier, vpad: Dp = 8.dp, subtitle: ((String) -> String)? = null,
        onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        Box(modifier) {
            EPill(Modifier.fillMaxWidth(), vpad = vpad, onClick = { open = true }) {
                Column(Modifier.weight(1f)) {
                    ELabel(label)
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(value, Color.White, 13)
                }
                Spacer(Modifier.width(6.dp))
                Text("▾", color = S_MUTED, fontSize = 13.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(S_CARD)) {
                options.forEach { o ->
                    val sub = subtitle?.invoke(o) ?: ""
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text(o, color = Color.White, fontSize = 14.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C_MUTED)
                            }
                        },
                        onClick = {
                            onSelect(o)
                            open = false
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun PillField(
        label: String?, value: String, onChange: (String) -> Unit, hint: String,
        modifier: Modifier = Modifier, size: Int = 13, weight: FontWeight = FontWeight.Bold,
        vpad: Dp = 8.dp, trailing: (@Composable () -> Unit)? = null
    ) {
        var focused by remember { mutableStateOf(false) }
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .clip(shape)
                .background(S_FIELD)
                .border(if (focused) 2.dp else 1.dp, if (focused) accent else S_LINE, shape)
                .padding(horizontal = 10.dp, vertical = vpad),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                if (label != null) {
                    ELabel(label)
                    Spacer(Modifier.height(3.dp))
                }
                Box(Modifier.fillMaxWidth()) {
                    if (value.isEmpty()) Text(hint, color = S_MUTED, fontSize = size.sp, maxLines = 1)
                    BasicTextField(
                        value = value, onValueChange = onChange, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = size.sp, fontWeight = weight),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .alpha(if (focused || value.isEmpty()) 1f else 0f)
                            .onFocusChanged { focused = it.isFocused }
                    )
                    // Fora de edição, títulos/links longos rolam sozinhos para dar para ler tudo.
                    if (!focused && value.isNotEmpty()) MarqueeText(value, Color.White, size, weight)
                }
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }
    }

    @Composable
    private fun EBtn(
        label: String, glyph: String?, bg: Color, border: Color, fg: Color, modifier: Modifier = Modifier,
        tall: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .heightIn(min = if (tall) 44.dp else 34.dp)
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (glyph != null) {
                Text(glyph, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
            }
            Text(label, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
    }

    @Composable
    private fun CoverThumb(cover: String, title: String, platform: String, pkg: String, modifier: Modifier) {
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = modifier
                .clip(shape)
                .background(Color(0xFF0F2744))
                .border(1.dp, accent.copy(alpha = 0.4f), shape),
            contentAlignment = Alignment.Center
        ) {
            val appIcon = if (platform == ANDROID_PLATFORM && pkg.isNotEmpty()) {
                remember(pkg) { bigIconFor(pkg) }
            } else null
            if (appIcon != null) {
                Image(bitmap = appIcon, contentDescription = title, modifier = Modifier.fillMaxWidth(0.7f).aspectRatio(1f))
            } else if (cover.isBlank()) {
                Text("▣", color = S_MUTED, fontSize = 18.sp)
            }
            if (cover.isNotBlank()) {
                val req = remember(cover) { Covers.request(this@MainActivity, cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    @Composable
    private fun GameDialog(initial: Game?) {
        var title by remember { mutableStateOf(initial?.title ?: "") }
        var platform by remember {
            mutableStateOf(
                initial?.platform
                    ?: (if (dashMode == 1 && dashPlatform.isNotEmpty() && dashPlatform in addPlatforms(null)) dashPlatform
                    else addPlatforms(null).first())
            )
        }
        var genre by remember { mutableStateOf(initial?.genre ?: (genres.firstOrNull() ?: "")) }
        var gameCols by remember { mutableStateOf(initial?.collections ?: emptyList<String>()) }
        var cover by remember { mutableStateOf(initial?.cover ?: "") }
        var webUrl by remember { mutableStateOf(initial?.webUrl ?: "") }
        var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
        var romUri by remember { mutableStateOf(initial?.romUri ?: "") }
        var romName by remember {
            mutableStateOf(if (initial != null && initial.romUri.isNotEmpty()) fileNameOf(initial.romUri) else "")
        }
        var fav by remember { mutableStateOf(initial?.isFavorite ?: false) }
        var custom by remember { mutableStateOf(initial?.customCmd ?: "") }
        val isWeb = platform == WEB_PLATFORM
        val isAndroid = platform == ANDROID_PLATFORM

        val save: () -> Unit = {
            if (isAndroid && pkg.isEmpty()) {
                toast("Escolha o app do jogo")
            } else if (title.isNotBlank()) {
                val now = System.currentTimeMillis()
                val exec = if (initial == null || initial.platform != platform) {
                    DEFAULT_EXEC[execKey(platform)] ?: "native"
                } else initial.execType
                val base = initial ?: Game(
                    id = UUID.randomUUID().toString(), title = "", platform = platform, genre = genre
                )
                val favTs = if (fav && initial?.isFavorite != true) now else (initial?.favoriteTs ?: 0L)
                val saved = base.copy(
                    title = title.trim(), platform = platform, genre = genre,
                    cover = cover.trim(), webUrl = webUrl.trim(), execType = exec,
                    pkg = pkg, romUri = romUri, isFavorite = fav, favoriteTs = favTs,
                    customCmd = custom.trim(), collections = gameCols
                )
                if (initial == null) {
                    games.add(saved)
                    saveLibrary()
                } else replaceGame(saved)
                if (initial != null && initial.cover.isNotBlank() && initial.cover != saved.cover) {
                    Covers.purgeIfUnused(initial.cover, games.map { it.cover })
                }
                if (initial != null && (initial.title != saved.title || initial.platform != saved.platform)) {
                    if (sgdbCache.remove(saved.id) != null) saveSgdb()
                }
                prefetchCovers()
                selectGame(saved.id)
                overlay = Overlay.None
            } else toast("Digite o título")
        }

        val onPlatformSel: (String) -> Unit = { sel ->
            val wasAndroid = platform == ANDROID_PLATFORM
            platform = sel
            if ((sel == ANDROID_PLATFORM) != wasAndroid) {
                pkg = ""
                romUri = ""
                romName = ""
            }
        }
        val fPlat: @Composable () -> Unit = {
            CSelect("Plataforma:", platform, addPlatforms(initial?.platform), Modifier.fillMaxWidth()) { onPlatformSel(it) }
        }
        val pickGameApp: () -> Unit = {
            appPickerNone = "Nenhum (voltar)"
            appPickerCb = { a ->
                if (a != null) {
                    pkg = a.pkg
                    if (title.isBlank()) title = a.label
                }
            }
            appPickerOpen = true
        }
        val pickRom: () -> Unit = {
            val link = linkFor(platform)
            val onRom: (String, String) -> Unit = { uriStr, name ->
                romUri = uriStr
                romName = name
                if (title.isBlank()) title = cleanTitle(name, platform == "PS Vita")
            }
            if (link != null && link.folders.isNotEmpty()) {
                romList = RomListRequest(platform, onRom)
            } else {
                dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
                pickRomForDialog.launch(arrayOf("*/*"))
            }
        }
        val fRom: @Composable () -> Unit = {
            if (isWeb) {
                CField(webUrl, { webUrl = it }, "Link Web do Jogo (URL)", Modifier.fillMaxWidth())
            } else if (isAndroid) {
                val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
                CButton(
                    if (pkg.isEmpty()) "📱 Escolher app instalado" else "📱 ${appLabel ?: pkg}",
                    C_BLUE, Modifier.fillMaxWidth()
                ) { pickGameApp() }
            } else {
                CButton(
                    if (romUri.isEmpty()) "📁 Escolher ROM" else "📁 $romName",
                    C_BLUE, Modifier.fillMaxWidth()
                ) { pickRom() }
            }
        }
        val fTitle: @Composable () -> Unit = {
            CField(title, { title = it }, "Título do jogo", Modifier.fillMaxWidth())
        }
        val fHint: @Composable () -> Unit = {
            if (platform == "PS Vita") {
                Text(
                    "⚠ Vita3K+: o título precisa conter o ID do jogo (ex.: PCSA00029)",
                    color = C_ORANGE, fontSize = 10.sp, maxLines = 2
                )
            }
            if (isAndroid) {
                Text(
                    "Sem URL de capa, o ícone do app é usado como capa.",
                    color = C_MUTED, fontSize = 10.sp, maxLines = 2
                )
            }
        }
        val fGenre: @Composable (Modifier) -> Unit = { m ->
            CSelect("Gênero:", genre.ifEmpty { "—" }, genres.sortedAlpha { it }, m) { genre = it }
        }
        val fCols: @Composable () -> Unit = {
            CButton(
                "📚 Coleções: " + (if (gameCols.isEmpty()) "nenhuma" else gameCols.joinToString(", ")),
                C_GRAY, Modifier.fillMaxWidth()
            ) {
                collPickerSel.clear()
                collPickerSel.addAll(gameCols)
                collPickerCb = { sel -> gameCols = sel }
                collPickerOpen = true
            }
        }
        val fFav: @Composable (Modifier) -> Unit = { m ->
            CToggle("Favorito ⭐", fav, m) { fav = it }
        }
        val fCover: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(cover, { cover = it }, "URL da capa", Modifier.weight(1f))
                CButton("📋 Colar", C_ORANGE, Modifier.width(88.dp)) {
                    val t = clipboardText()
                    if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                }
                CButton("🔄", C_GRAY, Modifier.width(48.dp)) { refreshCover(cover) }
            }
        }
        val fSgdbCover: @Composable () -> Unit = {
            CButton("🎮 Escolher capa no SteamGridDB", C_BLUE, Modifier.fillMaxWidth()) {
                openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
            }
        }
        val fSteam: @Composable () -> Unit = {
            CButton("🌐 Abrir site do SteamGridDB", C_GRAY, Modifier.fillMaxWidth()) { openSteamGrid(title) }
        }
        val fApp: @Composable () -> Unit = {
            if (!isWeb && !isAndroid) {
                val label = allApps.firstOrNull { it.pkg == pkg }?.label
                val lp = linkFor(platform)?.pkg ?: ""
                val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
                CButton(
                    if (pkg.isEmpty()) "App/emulador: automático" + (if (linkLabel != null) " ($linkLabel)" else "")
                    else "App: ${label ?: pkg}",
                    C_GRAY, Modifier.fillMaxWidth()
                ) {
                    appPickerNone = "Automático (padrão da plataforma)"
                    appPickerCb = { a -> pkg = a?.pkg ?: "" }
                    appPickerOpen = true
                }
            }
        }
        val fCustom: @Composable () -> Unit = {
            val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
            if (!isWeb && !isAndroid && (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null))) {
                CField(custom, { custom = it }, "Comando personalizado (opcional)", Modifier.fillMaxWidth())
            }
        }
        val buttons: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                if (initial != null) {
                    CButton("Apagar", C_RED, Modifier.weight(1f)) {
                        overlay = Overlay.ConfirmDelete(initial)
                    }
                }
                CButton("Salvar", C_BLUE, Modifier.weight(1f)) { save() }
            }
        }

        // ----- Peças compartilhadas entre retrato e paisagem -----
        val accent = parseColor(accentHex)
        val amber = Color(0xFFFFC53D)
        val danger = Color(0xFFFF6B81)
        val green = Color(0xFF30D158)
        val vp = if (landscape) 4.dp else 6.dp
        val showEmu = !isWeb && !isAndroid
        val coverOk = cover.isNotBlank()

        val favPill: @Composable () -> Unit = {
            EPill(
                selected = fav, tint = amber, vpad = vp,
                modifier = Modifier,
                onClick = { fav = !fav }
            ) {
                Text(if (fav) "★" else "☆", color = if (fav) amber else Color(0xFFD5DAE5), fontSize = 14.sp,
                    maxLines = 1, softWrap = false, lineHeight = 14.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                Spacer(Modifier.width(6.dp))
                Text("Favorito", color = if (fav) amber else Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, softWrap = false, lineHeight = 14.sp, style = TextStyle(lineHeightStyle = CenteredLine))
            }
        }
        val headerTitle = if (initial == null) "Adicionar Novo Jogo" else "Configurar: " + title.ifBlank { initial.title }
        val tagText = if (initial == null) "NOVO JOGO" else "EDITAR JOGO"

        val romPill: @Composable (Modifier) -> Unit = { m ->
            if (isWeb) {
                PillField("LINK WEB DO JOGO", webUrl, { webUrl = it }, "https://…", m, 12, vpad = vp)
            } else if (isAndroid) {
                val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
                EPill(m, selected = pkg.isNotEmpty(), vpad = vp, onClick = pickGameApp) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                        contentAlignment = Alignment.Center
                    ) { Text("📱", fontSize = 13.sp) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("APP DO JOGO", accent)
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (pkg.isEmpty()) "Escolher app instalado" else (appLabel ?: pkg), Color.White, 12)
                    }
                }
            } else {
                EPill(m, selected = true, vpad = vp, onClick = pickRom) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                        contentAlignment = Alignment.Center
                    ) { Text("📁", fontSize = 13.sp) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("ARQUIVO ROM", accent)
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (romUri.isEmpty()) "Escolher ROM" else romName, Color.White, 12)
                    }
                }
            }
        }

        val titlePill: @Composable () -> Unit = {
            PillField(
                "TÍTULO DO JOGO", title, { title = it }, "Título do jogo", Modifier.fillMaxWidth(), vpad = vp,
                trailing = {
                    if (title.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0x14FFFFFF))
                                .focusGlow(CircleShape)
                                .clickable { title = "" },
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            )
        }

        val vitaRow: @Composable () -> Unit = {
            if (platform == "PS Vita") {
                val idRe = Regex("[A-Z]{4}\\d{5}")
                val idInTitle = idRe.find(title)?.value
                val idInRom = idRe.find(romName)?.value
                EPill(Modifier.fillMaxWidth(), selected = true, tint = if (idInTitle != null) green else amber, vpad = if (landscape) 4.dp else 8.dp) {
                    Text(if (idInTitle != null) "✓" else "⚠", color = if (idInTitle != null) green else amber, fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (idInTitle != null) "Vita3K+: ID encontrado ($idInTitle)" else "Vita3K+: inclua o ID no título",
                        color = if (idInTitle != null) Color(0xFFB7F5C8) else Color(0xFFFDE6A8),
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                    if (idInTitle == null && idInRom != null) {
                        Spacer(Modifier.width(8.dp))
                        EBtn("+ $idInRom", null, Color(0x33FFC53D), Color(0x80FFC53D), Color(0xFFFFD36B)) {
                            title = (title.trim() + " " + idInRom).trim()
                        }
                    }
                }
            }
        }

        val genreCols: @Composable () -> Unit = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillSelect("GÊNERO", genre.ifEmpty { "—" }, genres.sortedAlpha { it }, Modifier.weight(1f), vp) { genre = it }
                EPill(
                    Modifier.weight(1f), vpad = vp,
                    onClick = {
                        collPickerSel.clear()
                        collPickerSel.addAll(gameCols)
                        collPickerCb = { sel -> gameCols = sel }
                        collPickerOpen = true
                    }
                ) {
                    Column(Modifier.weight(1f)) {
                        ELabel("COLEÇÕES")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (gameCols.isEmpty()) "Nenhuma" else gameCols.joinToString(", "), Color.White, 13)
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, S_LINE, RoundedCornerShape(rBtn.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("▣", color = Color(0xFFD5DAE5), fontSize = 12.sp) }
                }
            }
        }

        val coverHeader: @Composable () -> Unit = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("CAPA DO JOGO (STEAMGRIDDB)", modifier = Modifier.weight(1f), compact = true)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (coverOk) green else S_MUTED))
                Spacer(Modifier.width(4.dp))
                Text(
                    if (coverOk) "Capa ativa" else if (isAndroid) "Ícone do app" else "Sem capa",
                    color = if (coverOk) green else S_MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }

        val coverMain: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth()) {
                CoverThumb(cover, title, platform, pkg, Modifier.width(52.dp).height(if (landscape) 74.dp else 82.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PillField(null, cover, { cover = it }, "Cole a URL da capa...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, vp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), Modifier.weight(1f)) {
                            val t = clipboardText()
                            if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                        }
                        EBtn("Atualizar", "⟳", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { refreshCover(cover) }
                    }
                }
            }
        }

        val coverButtons: @Composable () -> Unit = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { openSteamGrid(title) }
                EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), Modifier.weight(1f)) {
                    openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
                }
            }
        }

        val emuBlock: @Composable () -> Unit = {
            val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
            val lp = linkFor(platform)?.pkg ?: ""
            val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
            val emu = if (pkg.isEmpty()) "Automático" + (if (linkLabel != null) " ($linkLabel)" else "") else (appLabel ?: pkg)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(accent.copy(alpha = 0.15f))
                            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(rBtn.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("⇄", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("APP / EMULADOR")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(emu, Color.White, 13)
                    }
                    Spacer(Modifier.width(8.dp))
                    EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                        appPickerNone = "Automático (padrão da plataforma)"
                        appPickerCb = { a -> pkg = a?.pkg ?: "" }
                        appPickerOpen = true
                    }
                }
                val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
                if (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null)) {
                    PillField("COMANDO PERSONALIZADO (OPCIONAL)", custom, { custom = it }, "Comando", Modifier.fillMaxWidth(), 12, vpad = vp)
                }
            }
        }

        val panel = RoundedCornerShape(rPanel.dp)

        if (landscape) {
            // Paisagem: janela cheia, cabeçalho numa linha, duas colunas e rodapé com dicas do controle.
            val view = LocalView.current
            Dialog(
                onDismissRequest = { overlay = Overlay.None },
                properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
            ) {
                HideBarsInDialog()
                SideEffect {
                    val w = (view.parent as? DialogWindowProvider)?.window
                    if (w != null) {
                        val lp = w.attributes
                        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        w.attributes = lp
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                        .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                            .clip(panel)
                            .background(S_PANEL)
                            .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(rBtn.dp))
                                    .background(accent.copy(alpha = 0.15f))
                                    .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(rBtn.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                                Spacer(Modifier.width(6.dp))
                                ELabel(tagText, accent)
                            }
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) { MarqueeText(headerTitle, Color.White, 16, FontWeight.ExtraBold) }
                            Spacer(Modifier.width(10.dp))
                            favPill()
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        PillSelect("PLATAFORMA", platform, addPlatforms(initial?.platform), Modifier.weight(5f), vp) { onPlatformSel(it) }
                                        romPill(Modifier.weight(7f))
                                    }
                                    titlePill()
                                    vitaRow()
                                    genreCols()
                                }
                            }
                            SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                    coverHeader()
                                    coverMain()
                                    coverButtons()
                                    if (showEmu) emuBlock()
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PadHint("A", "Confirmar", S_PAD_A, compact = true, onClick = null)
                                Spacer(Modifier.width(8.dp))
                                PadHint("B", "Cancelar", S_PAD_B, compact = true, onClick = null)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.widthIn(min = 110.dp)) { overlay = Overlay.None }
                                if (initial != null) {
                                    EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.widthIn(min = 100.dp)) {
                                        overlay = Overlay.ConfirmDelete(initial)
                                    }
                                }
                                EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.widthIn(min = 110.dp)) { save() }
                            }
                        }
                    }
                }
            }
        } else {
            // Retrato: tudo numa tela só, sem rolagem. Textos longos rolam sozinhos (marquee).
            Dialog(
                onDismissRequest = { overlay = Overlay.None },
                properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
            ) {
                HideBarsInDialog()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                        .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.96f)
                            .fillMaxHeight(0.97f)
                            .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                            .clip(panel)
                            .background(S_PANEL)
                            .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                                    Spacer(Modifier.width(6.dp))
                                    ELabel(tagText)
                                }
                                Spacer(Modifier.height(2.dp))
                                MarqueeText(headerTitle, Color.White, 18, FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.width(10.dp))
                            favPill()
                        }
                        Spacer(Modifier.height(6.dp))

                        // Sem rolagem: os blocos dividem o espaço disponível.
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                SCard(pad = 10.dp) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            PillSelect("PLATAFORMA", platform, addPlatforms(initial?.platform), Modifier.weight(5f), vp) { onPlatformSel(it) }
                                            romPill(Modifier.weight(7f))
                                        }
                                        titlePill()
                                        vitaRow()
                                    }
                                }
                                SCard(pad = 10.dp) { genreCols() }
                                SCard(pad = 10.dp) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        coverHeader()
                                        coverMain()
                                        coverButtons()
                                    }
                                }
                                if (showEmu) SCard(pad = 10.dp) { emuBlock() }
                            }
                        }

                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { overlay = Overlay.None }
                            if (initial != null) {
                                EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.weight(1f), tall = true) {
                                    overlay = Overlay.ConfirmDelete(initial)
                                }
                            }
                            EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) { save() }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun FilterDialog() {
        val present = platformNames().filter { p -> games.any { it.platform == p } }
        val fFavOnly: @Composable () -> Unit = {
            CToggle("Apenas Favoritos ⭐", favOnly, Modifier.fillMaxWidth()) { favOnly = it }
        }
        val fPlat: @Composable () -> Unit = {
            CSelect(
                "Plataforma:", if (fPlatform.isEmpty()) "Todas" else fPlatform,
                listOf("Todas") + present, Modifier.fillMaxWidth()
            ) { fPlatform = if (it == "Todas") "" else it }
        }
        val fGen: @Composable () -> Unit = {
            CSelect(
                "Gênero:", if (fGenre.isEmpty()) "Todos" else fGenre,
                listOf("Todos") + genres.sortedAlpha { it }, Modifier.fillMaxWidth()
            ) { fGenre = if (it == "Todos") "" else it }
        }
        val fColl: @Composable () -> Unit = {
            CSelect(
                "Coleção:", if (fCollection.isEmpty()) "Todas" else fCollection,
                listOf("Todas") + collections.sortedAlpha { it }, Modifier.fillMaxWidth()
            ) { fCollection = if (it == "Todas") "" else it }
        }
        val fSort: @Composable () -> Unit = {
            CSelect("Ordem:", SORTS[sortMode], SORTS, Modifier.fillMaxWidth()) { sortMode = SORTS.indexOf(it) }
        }
        NexusModal(
            "Filtrar Biblioteca", { overlay = Overlay.None },
            footer = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Remover Filtros", C_ORANGE, Modifier.weight(1f)) { resetFilters() }
                    CButton("Fechar", C_BLUE, Modifier.weight(1f)) {
                        selectedId = firstNavId()
                        overlay = Overlay.None
                    }
                }
            }
        ) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fFavOnly()
                        fPlat()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fGen()
                        fColl()
                        fSort()
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fFavOnly()
                    fPlat()
                    fGen()
                    fColl()
                    fSort()
                }
            }
        }
    }

    @Composable
    private fun SearchGlyph(color: Color, dim: Dp) {
        Canvas(Modifier.size(dim)) {
            val w = this.size.minDimension
            val sw = w * 0.11f
            drawCircle(color, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(width = sw))
            drawLine(color, Offset(w * 0.66f, w * 0.66f), Offset(w * 0.9f, w * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }

    // Pesquisa em tempo real (3.9.9): o grid de trás filtra enquanto você digita.
    // "Ver Resultados" mantém o filtro; fechar (B) descarta e volta ao que estava antes.
    @Composable
    private fun SearchDialog() {
        val accent = parseColor(accentHex)
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        val prev = remember { searchTerm }
        var committed by remember { mutableStateOf(false) }
        DisposableEffect(Unit) {
            onDispose { if (!committed) searchTerm = prev }
        }
        val focus = remember { FocusRequester() }
        var fieldFocused by remember { mutableStateOf(false) }
        val q = searchTerm
        val active = q.isNotBlank()
        val count = filteredGames().size
        val countText = when {
            !active -> if (count == 1) "1 jogo disponível" else "$count jogos disponíveis"
            count == 0 -> "0 jogos encontrados"
            count == 1 -> "1 jogo encontrado"
            else -> "$count jogos encontrados"
        }
        // Atalhos rápidos: coleções e plataformas que existem na sua biblioteca.
        val chips = (collections.toList() +
            games.groupBy { it.platform }.entries.sortedByDescending { it.value.size }.map { it.key })
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
            .take(8)

        val applySearch: () -> Unit = {
            if (active && count == 0) {
                toast("Nenhum jogo encontrado")
            } else {
                committed = true
                selectedId = firstNavId()
                overlay = Overlay.None
            }
        }
        val clearSearch: () -> Unit = {
            searchTerm = ""
        }

        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .onPreviewKeyEvent { ev ->
                        val n = ev.nativeKeyEvent
                        if (n.action != KeyEvent.ACTION_DOWN) {
                            false
                        } else when (n.keyCode) {
                            KeyEvent.KEYCODE_BUTTON_Y -> {
                                clearSearch()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_CENTER -> if (fieldFocused) {
                                applySearch()
                                true
                            } else false
                            else -> false
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (landscape) 0.6f else 0.92f)
                        .widthIn(max = 440.dp)
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(16.dp)
                ) {
                    // Cabeçalho: ícone, título com contagem e termo ativo
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                            contentAlignment = Alignment.Center
                        ) { SearchGlyph(accent, 17.dp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Pesquisar", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Text(countText, color = S_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                        }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .widthIn(max = 120.dp)
                                .clip(CircleShape)
                                .background(S_FIELD)
                                .border(1.dp, if (active) accent else Color(0x26FFFFFF), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            MarqueeText(
                                if (active) "\"${q.trim()}\"" else "Todos",
                                if (active) accent else Color(0xFFCBD2E0), 12
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))

                    // Campo de busca
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(btn)
                            .background(S_FIELD)
                            .border(if (fieldFocused) 2.dp else 1.dp, if (fieldFocused) accent else S_LINE, btn)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SearchGlyph(S_MUTED, 16.dp)
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f)) {
                            if (q.isEmpty()) Text("Digite o título...", color = S_MUTED, fontSize = 14.sp, maxLines = 1)
                            BasicTextField(
                                value = q, onValueChange = { searchTerm = it }, singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium),
                                cursorBrush = SolidColor(Color.White),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { applySearch() }),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(focus)
                                    .onFocusChanged { fieldFocused = it.isFocused }
                            )
                        }
                        if (q.isNotEmpty()) {
                            Spacer(Modifier.width(8.dp))
                            EBtn("Limpar", null, Color(0xFF222734), Color(0x26FFFFFF), Color(0xFFE2E6EF)) { clearSearch() }
                        }
                    }

                    // Atalhos rápidos
                    if (chips.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "RÁPIDO:", color = S_MUTED, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp, maxLines = 1, softWrap = false
                            )
                            chips.forEach { c ->
                                val on = active && q.trim().equals(c, true)
                                Box(
                                    modifier = Modifier
                                        .clip(btn)
                                        .background(if (on) accent.copy(alpha = 0.12f) else S_FIELD)
                                        .border(1.dp, if (on) accent else S_LINE, btn)
                                        .focusGlow(btn)
                                        .clickable { searchTerm = if (on) "" else c }
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        c, color = if (on) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    // Botões menores, sem quebra de linha
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(btn)
                                .background(Color(0xFF1E222B))
                                .border(1.dp, S_LINE, btn)
                                .focusGlow(btn)
                                .clickable { overlay = Overlay.None }
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(18.dp).clip(CircleShape).background(S_PAD_B), contentAlignment = Alignment.Center) {
                                Text("B", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                                    lineHeight = 10.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Fechar (B)", color = Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, softWrap = false
                            )
                        }
                        EBtn("Ver Resultados", null, accent, accent, onAccent(accent), Modifier.weight(1f).height(38.dp)) { applySearch() }
                    }
                }

                // Legenda do controle, no rodapé da tela
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF20A0C10))) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PadHint("A", "Confirmar", S_PAD_A, compact = true) { applySearch() }
                        Spacer(Modifier.width(14.dp))
                        PadHint("B", "Voltar", S_PAD_B, compact = true) { overlay = Overlay.None }
                        Spacer(Modifier.width(14.dp))
                        PadHint("Y", "Limpar", Color(0xFFF6CE48), compact = true) { clearSearch() }
                    }
                }
            }
        }
    }

    // ---------- Configurações (redesign 3.9.6: retrato sem rolagem + paisagem dedicada) ----------
    @Composable
    private fun SLabel(text: String, color: Color = S_MUTED, modifier: Modifier = Modifier, compact: Boolean = false) {
        Text(
            text, color = color, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp, modifier = modifier
        )
    }

    @Composable
    private fun SCard(
        modifier: Modifier = Modifier, pad: Dp = 14.dp,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .padding(pad),
            content = content
        )
    }

    @Composable
    private fun SChip(text: String, accent: Color) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.14f))
                .border(1.dp, accent.copy(alpha = 0.45f), CircleShape)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(text, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun SSwitch(on: Boolean, accent: Color) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .clip(CircleShape)
                .background(if (on) accent else Color(0xFF2A2F3D))
                .border(2.dp, if (on) accent else Color(0xFF4B5267), CircleShape)
                .padding(horizontal = 4.dp),
            contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .size(if (on) 18.dp else 16.dp)
                    .clip(CircleShape)
                    .background(if (on) Color(0xFF080A0F) else S_MUTED)
            )
        }
    }

    @Composable
    private fun Swatch(hex: String, size: Dp = 44.dp) {
        val sel = accentHex.equals(hex, true)
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .focusGlow(CircleShape)
                .clickable {
                    accentHex = hex
                    savePrefs()
                },
            contentAlignment = Alignment.Center
        ) {
            if (sel) Box(Modifier.size(size - 2.dp).border(2.dp, Color.White, CircleShape))
            Box(Modifier.size(if (sel) size - 10.dp else size - 6.dp).clip(CircleShape).background(parseColor(hex)))
        }
    }

    @Composable
    private fun CatalogTile(
        glyph: String, title: String, sub: String, count: Int, modifier: Modifier,
        compact: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        if (compact) {
            Row(
                modifier = modifier
                    .clip(shape)
                    .background(S_CARD)
                    .border(1.dp, S_LINE, shape)
                    .focusGlow(shape)
                    .clickable(onClick = onClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(30.dp).clip(CircleShape).background(S_FIELD),
                    contentAlignment = Alignment.Center
                ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, softWrap = false, lineHeight = 16.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                    Text(sub, color = S_MUTED, fontSize = 10.sp,
                        maxLines = 1, softWrap = false, lineHeight = 13.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                }
                Spacer(Modifier.width(6.dp))
                Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 8.dp, vertical = 3.dp)) {
                    Text("$count", color = S_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
            return
        }
        Column(
            modifier = modifier
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(14.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(if (compact) 32.dp else 40.dp).clip(CircleShape).background(S_FIELD),
                    contentAlignment = Alignment.Center
                ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = if (compact) 15.sp else 18.sp) }
                Spacer(Modifier.weight(1f))
                Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text("$count", color = S_MUTED, fontSize = if (compact) 12.sp else 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (!compact) Spacer(Modifier.height(10.dp))
            Column {
                Text(title, color = Color.White, fontSize = if (compact) 13.sp else 16.sp, fontWeight = FontWeight.Bold)
                Text(sub, color = S_MUTED, fontSize = if (compact) 10.sp else 12.sp)
            }
        }
    }

    @Composable
    private fun ActionRow(
        glyph: String, title: String, sub: String,
        bg: Color, border: Color, iconBg: Color, iconFg: Color,
        titleColor: Color = Color.White, chevron: Boolean = true,
        modifier: Modifier = Modifier, compact: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        val ib = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = if (compact) 12.dp else 14.dp, vertical = if (compact) 4.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 34.dp else 44.dp).clip(ib).background(iconBg),
                contentAlignment = Alignment.Center
            ) { Text(glyph, color = iconFg, fontSize = if (compact) 17.sp else 20.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = titleColor, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.Bold,
                    lineHeight = if (compact) 16.sp else 19.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                Text(sub, color = S_MUTED, fontSize = if (compact) 10.sp else 12.sp,
                    lineHeight = if (compact) 13.sp else 15.sp, style = TextStyle(lineHeightStyle = CenteredLine))
            }
            if (chevron) {
                Spacer(Modifier.width(8.dp))
                Text("›", color = parseColor(accentHex), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    private fun PadHint(letter: String, label: String, color: Color, compact: Boolean = false, onClick: (() -> Unit)?) {
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = Modifier
                .clip(shape)
                .then(if (onClick != null) Modifier.background(Color(0x0DFFFFFF)) else Modifier)
                .focusGlow(shape)
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = if (compact) 10.dp else 12.dp, vertical = if (compact) 4.dp else 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(if (compact) 20.dp else 28.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                val fs = if (compact) 11.sp else 14.sp
                Text(letter, color = if (letter == "Y") Color.Black else Color.White, fontSize = fs, fontWeight = FontWeight.ExtraBold,
                    lineHeight = fs, style = TextStyle(lineHeightStyle = CenteredLine))
            }
            Spacer(Modifier.width(if (compact) 6.dp else 8.dp))
            Text(label, color = Color(0xFFE2E6EF), fontSize = if (compact) 11.sp else 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }

    @Composable
    private fun KeyCap(label: String, onClick: () -> Unit) {
        val shape = RoundedCornerShape(5.dp)
        Box(
            modifier = Modifier
                .clip(shape)
                .background(Color(0x1AFFFFFF))
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) { Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) }
    }

    @Composable
    private fun LRHint() {
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = Modifier
                .clip(shape)
                .background(Color(0x0AFFFFFF))
                .border(1.dp, S_LINE, shape)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KeyCap("L1") { settingsTab = (settingsTab + 2) % 3 }
            Spacer(Modifier.width(4.dp))
            KeyCap("R1") { settingsTab = (settingsTab + 1) % 3 }
            Spacer(Modifier.width(6.dp))
            Text("Abas", color = Color(0xFFCBD2E0), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }

    @Composable
    private fun SettingsTabs(accent: Color, compact: Boolean) {
        val outer = RoundedCornerShape((if (compact) rBtn else rCard).dp)
        val inner = RoundedCornerShape(rBtn.dp)
        val tabs = listOf("◐" to "Visual", "▦" to "Biblioteca", "▤" to "Sistema")
        Row(
            modifier = (if (compact) Modifier else Modifier.fillMaxWidth())
                .clip(outer)
                .background(S_FIELD)
                .border(1.dp, S_LINE, outer)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEachIndexed { i, t ->
                val sel = settingsTab == i
                val fg = if (sel) onAccent(accent) else S_MUTED
                Row(
                    modifier = (if (compact) Modifier.height(30.dp) else Modifier.weight(1f).height(40.dp))
                        .clip(inner)
                        .background(if (sel) accent else Color.Transparent)
                        .focusGlow(inner)
                        .clickable { settingsTab = i }
                        .padding(horizontal = if (compact) 12.dp else 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(t.first, color = fg, fontSize = if (compact) 12.sp else 13.sp)
                    Spacer(Modifier.width(5.dp))
                    Text(t.second, color = fg, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.SemiBold, softWrap = false)
                }
            }
        }
    }

    @Composable
    private fun CornerOptions(compact: Boolean) {
        val style = styleIdx
        val accent = parseColor(accentHex)
        val btn = RoundedCornerShape(rBtn.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Reto", "Padrão", "Suave").forEachIndexed { i, name ->
                val sel = style == i
                val mod = Modifier
                    .weight(1f)
                    .clip(btn)
                    .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
                    .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
                    .focusGlow(btn)
                    .clickable {
                        radius = intArrayOf(4, 14, 22)[i]
                        savePrefs()
                    }
                val icon: @Composable () -> Unit = {
                    Box(
                        Modifier
                            .width(if (compact) 14.dp else 24.dp)
                            .height(if (compact) 10.dp else 16.dp)
                            .border(2.dp, if (sel) Color.White else S_MUTED, RoundedCornerShape(intArrayOf(2, 6, 8)[i].dp))
                    )
                }
                val txtColor = if (sel) Color.White else Color(0xFFCBD2E0)
                if (compact) {
                    Row(
                        modifier = mod.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        icon()
                        Spacer(Modifier.width(6.dp))
                        Text(name, color = txtColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            lineHeight = 13.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                    }
                } else {
                    Column(modifier = mod.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        icon()
                        Spacer(Modifier.height(6.dp))
                        Text(name, color = txtColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            lineHeight = 16.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                    }
                }
            }
        }
    }

    @Composable
    private fun ColorsCard(accent: Color, land: Boolean, modifier: Modifier = Modifier) {
        SCard(modifier, if (land) 12.dp else 14.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SLabel(if (land) "COR DA BORDA" else "COR DA BORDA & LED", compact = land)
                    if (!land) {
                        Spacer(Modifier.height(2.dp))
                        Text("Destaque dinâmico da interface", color = S_MUTED, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.width(8.dp))
                SChip(ACCENTS.firstOrNull { it.second.equals(accentHex, true) }?.first ?: "Personalizada", accent)
            }
            if (land) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    // Tamanho limitado pela altura disponível: as bolinhas nunca viram "pílulas".
                    val sw = minOf(34.dp, (maxHeight - 6.dp) / 2, maxWidth / 5)
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                        ACCENTS.chunked(5).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                rowItems.forEach { Swatch(it.second, sw) }
                            }
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(10.dp))
                ACCENTS.chunked(5).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        rowItems.forEach { Swatch(it.second) }
                    }
                }
            }
        }
    }

    @Composable
    private fun CameraCard(sub: String, compact: Boolean, modifier: Modifier = Modifier) {
        val accent = parseColor(accentHex)
        val card = RoundedCornerShape(rCard.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clip(card)
                .background(S_CARD)
                .border(1.dp, S_LINE, card)
                .focusGlow(card)
                .clickable {
                    cutoutPad = !cutoutPad
                    savePrefs()
                }
                .padding(if (compact) 10.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 34.dp else 44.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                contentAlignment = Alignment.Center
            ) { Text("▣", color = accent, fontSize = if (compact) 16.sp else 20.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Recuar área da câmera", color = Color.White, fontSize = if (compact) 12.sp else 14.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, softWrap = false)
                Text(sub, color = S_MUTED, fontSize = if (compact) 10.sp else 12.sp, maxLines = 1, softWrap = false)
            }
            Spacer(Modifier.width(12.dp))
            SSwitch(cutoutPad, accent)
        }
    }

    @Composable
    private fun DashOption(label: String, mode: Int, glyph: String?, accent: Color, modifier: Modifier) {
        val btn = RoundedCornerShape(rBtn.dp)
        val sel = dashMode == mode
        Row(
            modifier = modifier
                .heightIn(min = 44.dp)
                .clip(btn)
                .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
                .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
                .focusGlow(btn)
                .clickable {
                    if (dashMode != mode) {
                        dashMode = mode
                        dashPlatform = ""
                        selectedId = firstNavId()
                        savePrefs()
                    }
                }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (glyph != null) {
                Text(glyph, color = if (sel) accent else S_MUTED, fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
            }
            Text(
                label, color = if (sel) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                modifier = Modifier.weight(1f)
            )
            if (sel) {
                Spacer(Modifier.width(4.dp))
                Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            }
        }
    }

    @Composable
    private fun SgdbCard(accent: Color, modifier: Modifier = Modifier, compact: Boolean = false) {
        SCard(modifier, if (compact) 10.dp else 14.dp) {
            if (compact) {
                SLabel("STEAMGRIDDB (CAPAS E DADOS)", compact = true)
                Spacer(Modifier.height(6.dp))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(sgdbKey, { v ->
                    sgdbKey = v.trim()
                    prefs.edit().putString("sgdbKey", sgdbKey).apply()
                }, "Cole sua chave aqui", Modifier.weight(1f))
                CButton("Testar", C_BLUE, Modifier.width(76.dp)) { testSgdbKey() }
            }
            Text(
                "Criar chave grátis (steamgriddb.com)", color = accent, fontSize = 12.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier
                    .clickable { openUrl("https://www.steamgriddb.com/profile/preferences/api") }
                    .padding(top = 6.dp)
            )
        }
    }

    // ----- Retrato: tudo cabe na tela, sem rolagem e sem texto cortado -----
    @Composable
    private fun TabVisual(accent: Color) {
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("ESTILO DOS CANTOS", modifier = Modifier.weight(1f))
                Text(listOf("Reto", "Padrão", "Suave")[styleIdx], color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            CornerOptions(false)
        }
        ColorsCard(accent, false)
        CameraCard("Evita corte pelo furo frontal", false)
    }

    @Composable
    private fun TabLibrary(accent: Color) {
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("TELA INICIAL (DASHBOARD)", modifier = Modifier.weight(1f))
                Text(if (dashMode == 1) "Plataformas" else "Todos os Jogos", color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashOption("Plataformas", 1, null, accent, Modifier.weight(1f))
                DashOption("Todos os Jogos", 0, null, accent, Modifier.weight(1f))
            }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            SLabel("GERENCIAR CATÁLOGO", modifier = Modifier.weight(1f))
            Text("Toque para editar", color = S_MUTED, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f)) { overlay = Overlay.Genres }
            CatalogTile("▣", "Coleções", "${collections.size} criadas", collections.size, Modifier.weight(1f)) { overlay = Overlay.Collections }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("▭", "Plataformas", "${platforms.size} cadastradas", platforms.size, Modifier.weight(1f)) { overlay = Overlay.PlatformList }
            CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f)) { overlay = Overlay.Platforms }
        }
    }

    @Composable
    private fun TabSystem(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        val danger = Color(0xFFFF5A72)
        SLabel("BACKUP & RESTAURAÇÃO", modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
            bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent)) { doExport() }
        ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { doImport() }
        SLabel("ARMAZENAMENTO", modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("▤", "Acesso ao armazenamento", if (storageOk) "Concedido ✓" else "Toque para permitir",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent, chevron = !storageOk) { doStorage() }
        SLabel("STEAMGRIDDB (CAPAS E DADOS DOS JOGOS)", modifier = Modifier.padding(horizontal = 2.dp))
        SgdbCard(accent)
        SLabel("ZONA DE PERIGO", color = danger, modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("🗑", "Resetar biblioteca", "Apaga os jogos e restaura o padrão de fábrica",
            bg = Color(0x1AFF375F), border = Color(0x66FF375F), iconBg = Color(0x33FF375F), iconFg = danger,
            titleColor = danger, chevron = false) { overlay = Overlay.ConfirmReset }
    }

    private fun doExport() {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        exportLauncher.launch("nexus_backup_$d.json")
    }

    private fun doImport() {
        importLauncher.launch(arrayOf("*/*"))
    }

    private fun doStorage() {
        if (storageOk) toast("O acesso ao armazenamento já está concedido") else askStorage()
    }

    // ----- Paisagem: layout em duas colunas, igual ao protótipo, sem rolagem -----
    @Composable
    private fun TabVisualL(accent: Color) {
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SCard(Modifier.weight(1f), 12.dp) {
                    Spacer(Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SLabel("PAISAGEM (W)", Color(0xFFCBD2E0), compact = true)
                            Text("Largura dos cards na tela horizontal", color = S_MUTED, fontSize = 10.sp)
                        }
                        Spacer(Modifier.width(8.dp))
                        SChip("${widthL}px", accent)
                    }
                    Slider(
                        value = widthL.toFloat(),
                        onValueChange = { v -> widthL = v.toInt() },
                        onValueChangeFinished = { savePrefs() },
                        valueRange = 110f..260f,
                        colors = SliderDefaults.colors(
                            thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = Color(0xFF2C3140)
                        ),
                        modifier = Modifier.height(30.dp)
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("110px", color = S_MUTED, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                        Text("185px", color = S_MUTED, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                        Text("260px", color = S_MUTED, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.weight(1f))
                }
                SCard(Modifier.weight(1f), 12.dp) {
                    Spacer(Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SLabel("ESTILO DOS CANTOS", Color(0xFFCBD2E0), Modifier.weight(1f), compact = true)
                        Text(listOf("Reto", "Padrão", "Suave")[styleIdx], color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(8.dp))
                    CornerOptions(true)
                    Spacer(Modifier.weight(1f))
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ColorsCard(accent, true, Modifier.weight(1f))
                CameraCard("Afasta a borda esquerda do furo frontal", true)
            }
        }
    }

    @Composable
    private fun TabLibraryL(accent: Color) {
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SCard(Modifier.weight(5f).fillMaxHeight(), 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SLabel("TELA INICIAL", Color(0xFFCBD2E0), Modifier.weight(1f), compact = true)
                    Text(if (dashMode == 1) "Plataformas" else "Todos os Jogos", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
                Text("Escolha a visualização exibida ao abrir o Nexus.", color = S_MUTED, fontSize = 10.sp)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DashOption("Plataformas", 1, "▭", accent, Modifier.fillMaxWidth())
                    DashOption("Todos os Jogos", 0, "≡", accent, Modifier.fillMaxWidth())
                }
            }
            Column(Modifier.weight(7f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Genres }
                    CatalogTile("▣", "Coleções", "${collections.size} criadas", collections.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Collections }
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CatalogTile("▭", "Plataformas", "${platforms.size} cadastradas", platforms.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.PlatformList }
                    CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Platforms }
                }
            }
        }
    }

    @Composable
    private fun TabSystemL(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        val danger = Color(0xFFFF5A72)
        val shape = RoundedCornerShape(rCard.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(7f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
                    bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent),
                    modifier = Modifier.weight(1f), compact = true) { doExport() }
                ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.weight(1f), compact = true) { doImport() }
                ActionRow("▤", "Acesso ao armazenamento", if (storageOk) "Concedido ✓" else "Toque para permitir",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent, chevron = !storageOk,
                    modifier = Modifier.weight(1f), compact = true) { doStorage() }
            }
            Column(Modifier.weight(5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Color(0x1AFF375F))
                        .border(1.dp, Color(0x66FF375F), shape)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("\u26A0\uFE0E", color = danger, fontSize = 13.sp)
                            Spacer(Modifier.width(6.dp))
                            SLabel("ZONA DE PERIGO", danger, compact = true)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Resetar biblioteca", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Apaga os jogos da biblioteca e restaura o padrão. Seus arquivos de ROM não são apagados.",
                            color = Color(0xB3FFC9D1), fontSize = 10.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(btn)
                            .background(Color(0xE6E11D48))
                            .focusGlow(btn)
                            .clickable { overlay = Overlay.ConfirmReset },
                        contentAlignment = Alignment.Center
                    ) { Text("Resetar Agora", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
                SgdbCard(accent, compact = true)
            }
        }
    }

    @Composable
    private fun SettingsLandscape(accent: Color) {
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                // Cabeçalho compacto: título à esquerda, abas e fechar à direita
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(btn)
                            .background(accent.copy(alpha = 0.14f))
                            .border(1.dp, accent.copy(alpha = 0.45f), btn),
                        contentAlignment = Alignment.Center
                    ) { Text("\u2699\uFE0E", color = accent, fontSize = 16.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Configurações do Nexus", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Modo Paisagem • v$APP_VERSION", color = S_MUTED, fontSize = 10.sp)
                    }
                    SettingsTabs(accent, true)
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(btn)
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, S_LINE, btn)
                            .focusGlow(btn)
                            .clickable { overlay = Overlay.None },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))

                Box(modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp)) {
                    when (settingsTab) {
                        0 -> TabVisualL(accent)
                        1 -> TabLibraryL(accent)
                        else -> TabSystemL(accent)
                    }
                }

                // Rodapé central: L1/R1 Abas, A Selecionar, B Voltar
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xF20E1017))
                        .padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LRHint()
                    Spacer(Modifier.width(14.dp))
                    PadHint("A", "Selecionar", S_PAD_A, compact = true, onClick = null)
                    Spacer(Modifier.width(14.dp))
                    PadHint("B", "Voltar", S_PAD_B, compact = true) { overlay = Overlay.None }
                }
            }
        }
    }

    @Composable
    private fun SettingsPortrait(accent: Color) {
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.95f)
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(btn)
                                .background(accent.copy(alpha = 0.14f))
                                .border(1.dp, accent.copy(alpha = 0.45f), btn),
                            contentAlignment = Alignment.Center
                        ) { Text("\u2699\uFE0E", color = accent, fontSize = 20.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Configurações do Nexus", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Frontend & Launcher • v$APP_VERSION", color = S_MUTED, fontSize = 12.sp)
                        }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(btn)
                                .background(Color(0x0FFFFFFF))
                                .border(1.dp, S_LINE, btn)
                                .focusGlow(btn)
                                .clickable { overlay = Overlay.None },
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 16.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingsTabs(accent, false)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))

                // Cabe inteiro na tela. A rolagem só existiria como rede de segurança em telas muito baixas.
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(if (settingsTab == 2) 8.dp else 12.dp)
                ) {
                    when (settingsTab) {
                        0 -> TabVisual(accent)
                        1 -> TabLibrary(accent)
                        else -> TabSystem(accent)
                    }
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PadHint("A", "Selecionar", S_PAD_A, onClick = null)
                    Spacer(Modifier.width(20.dp))
                    PadHint("B", "Voltar", S_PAD_B) { overlay = Overlay.None }
                }
            }
        }
    }

    @Composable
    private fun SettingsDialog() {
        val accent = parseColor(accentHex)
        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            if (landscape) {
                // Na paisagem a janela ocupa a tela toda, inclusive sob o furo da câmera,
                // e o "Recuar área da câmera" afasta a borda esquerda na hora.
                val view = LocalView.current
                SideEffect {
                    val w = (view.parent as? DialogWindowProvider)?.window
                    if (w != null) {
                        val lp = w.attributes
                        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        w.attributes = lp
                    }
                }
                SettingsLandscape(accent)
            } else {
                SettingsPortrait(accent)
            }
        }
    }

    @Composable
    private fun CollectionsDialog() {
        var newName by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        NexusModal("Coleções", { overlay = Overlay.Settings }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newName, { newName = it }, "Nova coleção (franquia ou grupo)", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    addCollection(newName)
                    newName = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (collections.isEmpty()) {
                    item {
                        Text("Nenhuma coleção ainda.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                items(collections.sortedAlpha { it }, key = { it }) { c ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == c) {
                            CField(editText, { editText = it }, "Nome da coleção", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                renameCollection(c, editText)
                                editing = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else {
                            val used = games.count { c in it.collections }
                            Text(
                                "$c  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                editing = c
                                editText = c
                            }
                            CButton("🗑", C_RED, Modifier.width(48.dp)) { overlay = Overlay.ConfirmDeleteCollection(c) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Um jogo pode estar em várias coleções. Escolha as coleções ao editar o jogo.",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun ConfirmDeleteCollectionDialog(name: String) {
        NexusModal("Apagar coleção?", { overlay = Overlay.Collections }) {
            Text(
                "Apagar a coleção \"$name\"? Os jogos continuam na biblioteca, só saem dessa coleção.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.Collections }
                CButton("Apagar", C_RED, Modifier.weight(1f)) {
                    deleteCollection(name)
                    overlay = Overlay.Collections
                }
            }
        }
    }

    // Escolha de coleções de um jogo (seleção múltipla). Também permite criar uma coleção na hora.
    // Escolha de imagem no SteamGridDB: busca o jogo (ou a plataforma) e mostra miniaturas para tocar.
    @Composable
    private fun SgdbPickerDialog(p: SgdbPicker) {
        var term by remember { mutableStateOf(p.term) }
        var tick by remember { mutableStateOf(0) }
        var loading by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf("") }
        var gameName by remember { mutableStateOf("") }
        var grids by remember { mutableStateOf(emptyList<SgdbGrid>()) }
        LaunchedEffect(tick) {
            loading = true
            error = ""
            val key = sgdbKey.trim()
            val res = withContext(Dispatchers.IO) { SgdbApi.findGrids(key, term, p.portrait) }
            when (res) {
                is SgdbGridsResult.Ok -> {
                    gameName = res.game?.name ?: ""
                    grids = res.grids
                }
                is SgdbGridsResult.Failure -> {
                    error = res.message
                    grids = emptyList()
                }
            }
            loading = false
        }
        NexusModal(p.title, { sgdbPicker = null }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(term, { term = it }, "Nome para buscar", Modifier.weight(1f))
                CButton("🔍", C_BLUE, Modifier.width(52.dp)) { tick++ }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                when {
                    loading -> "Buscando…"
                    error.isNotEmpty() -> error
                    gameName.isEmpty() -> "Nada encontrado. Tente outro nome."
                    else -> "Resultado para: $gameName. Toque em uma imagem."
                },
                color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (p.portrait) 3 else 2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(grids, key = { it.url }) { g ->
                    AsyncImage(
                        model = g.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(if (p.portrait) 0.67f else 1.43f)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(Color(0xFF1A1E29))
                            .clickable {
                                p.onPick(g.url)
                                sgdbPicker = null
                            }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { sgdbPicker = null }
        }
    }

    @Composable
    private fun CollectionPickerDialog() {
        var newName by remember { mutableStateOf("") }
        NexusModal("Coleções do jogo", { collPickerOpen = false }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newName, { newName = it }, "Nova coleção (ex.: Zelda)", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        if (collections.none { it.equals(n, ignoreCase = true) }) {
                            collections.add(n)
                            savePrefs()
                        }
                        val canon = collections.first { it.equals(n, ignoreCase = true) }
                        if (canon !in collPickerSel) collPickerSel.add(canon)
                    }
                    newName = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (collections.isEmpty()) {
                    item {
                        Text("Nenhuma coleção ainda. Crie uma acima.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                items(collections.sortedAlpha { it }, key = { it }) { c ->
                    val on = c in collPickerSel
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow { if (on) collPickerSel.remove(c) else collPickerSel.add(c) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (on) "☑" else "☐", color = if (on) C_BLUE else C_MUTED, fontSize = 20.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(c, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) {
                collPickerCb?.invoke(collections.filter { it in collPickerSel })
                collPickerOpen = false
            }
            Spacer(Modifier.height(6.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { collPickerOpen = false }
        }
    }

    @Composable
    private fun GenresDialog() {
        var newGenre by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        NexusModal("Gêneros", { overlay = Overlay.Settings }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newGenre, { newGenre = it }, "Novo gênero", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val g = newGenre.trim()
                    if (g.isNotEmpty() && g !in genres) {
                        genres.add(g)
                        savePrefs()
                    }
                    newGenre = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(genres.sortedAlpha { it }, key = { it }) { g ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == g) {
                            CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                renameGenre(g, editText)
                                editing = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else {
                            val used = games.count { it.genre == g }
                            Text(
                                "$g  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                editing = g
                                editText = g
                            }
                            CButton("🗑", C_RED, Modifier.width(48.dp)) { deleteGenre(g) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Ao apagar, os jogos desse gênero ficam sem gênero.",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun RomListDialog(req: RomListRequest) {
        var entries by remember(req) { mutableStateOf<ScanResult?>(null) }
        var q by remember(req) { mutableStateOf("") }
        LaunchedEffect(req) { entries = withContext(Dispatchers.IO) { scanRoms(req.platform) } }
        val k = q.trim().lowercase()
        val all = entries?.roms
        val failed = entries?.failed ?: 0
        val shown = if (all == null) emptyList() else if (k.isEmpty()) all else all.filter { it.name.lowercase().contains(k) }
        NexusModal("ROMs · ${req.platform}", { romList = null }, tall = true) {
            CField(q, { q = it }, "🔍 Buscar ROM", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text(
                if (all == null) "Lendo pastas…" else "${shown.size} de ${all.size} arquivo(s)",
                color = C_MUTED, fontSize = 11.sp
            )
            if (failed > 0) {
                Text(
                    "⚠ $failed pasta(s) sem acesso. Vincule de novo em Configurações.",
                    color = C_ORANGE, fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(4.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(shown, key = { it.uri }) { e ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                romList = null
                                req.onPick(e.uri, e.name)
                            }
                    ) {
                        Text(e.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (e.folder.isNotEmpty()) Text(e.folder, color = C_MUTED, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Escolher manualmente", C_GRAY, Modifier.weight(1f)) {
                    romList = null
                    dialogRomCb = { uri -> req.onPick(uri.toString(), displayName(uri)) }
                    pickRomForDialog.launch(arrayOf("*/*"))
                }
                CButton("Fechar (B)", C_BLUE, Modifier.weight(1f)) { romList = null }
            }
        }
    }

    @Composable
    private fun PlatformsDialog() {
        NexusModal("Plataformas e emuladores", { overlay = Overlay.Settings }, tall = true) {
            if (links.isEmpty()) {
                Text(
                    "Nenhuma plataforma vinculada ainda. Vincule uma plataforma a um emulador e às pastas das ROMs.",
                    color = C_MUTED, fontSize = 12.sp, modifier = Modifier.fillMaxWidth()
                )
            }
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(links.sortedAlpha { it.platform }, key = { it.platform }) { l ->
                    val emu = if (l.pkg.isEmpty()) "sem emulador (app nativo)"
                    else if (l.playerName.isNotEmpty()) l.playerName
                    else (allApps.firstOrNull { it.pkg == l.pkg }?.label ?: l.pkg)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow { overlay = Overlay.LinkEdit(l) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(l.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(l.platform, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("$emu · ${l.folders.size} pasta(s)", color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                        }
                        Text("›", color = C_MUTED, fontSize = 20.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("+ Vincular plataforma", C_BLUE, Modifier.fillMaxWidth()) { overlay = Overlay.LinkEdit(null) }
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun LinkEditDialog(initial: PlatformLink?) {
        // Plataformas já cadastradas + todas as plataformas do catálogo ainda não cadastradas.
        val emuAll = remember { EmuCatalog.all(this@MainActivity) }
        val registered = linkablePlatforms()
        val extra = emuAll.map { it.name }
            .filter { n -> registered.none { it.equals(n, ignoreCase = true) } }
            .sortedAlpha { it }
        // Marca (fabricante) de cada plataforma: cadastrada primeiro, senão a do catálogo.
        val brandOf: (String) -> String = { n ->
            (platforms.firstOrNull { it.name == n }?.manufacturer
                ?: emuAll.firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
                ?: "").ifBlank { "Outros" }
        }
        // Ordem alfabética pela marca (Outros por último) e depois pelo nome da plataforma.
        val options = (registered + extra)
            .filter { p -> p == initial?.platform || links.none { it.platform == p } }
            .sortedWith(
                compareBy<String> { brandOf(it) == "Outros" }
                    .thenBy(ALPHA) { brandOf(it) }
                    .thenBy(ALPHA) { it }
            )

        var platform by remember { mutableStateOf(initial?.platform ?: (options.firstOrNull() ?: WEB_PLATFORM)) }
        var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
        var tpl by remember {
            mutableStateOf(initial?.template?.takeIf { it.isNotBlank() } ?: (TEMPLATES[initial?.pkg ?: ""] ?: ""))
        }
        var playerName by remember { mutableStateOf(initial?.playerName ?: "") }
        var exts by remember { mutableStateOf(initial?.exts ?: emptyList<String>()) }
        val folders = remember {
            mutableStateListOf<String>().apply { if (initial != null) addAll(initial.folders) }
        }
        val emuPlat = remember(platform) { EmuCatalog.forPlatform(this@MainActivity, execKey(platform)) }

        val accent = parseColor(accentHex)
        val fPlat: @Composable () -> Unit = {
            PillSelect("PLATAFORMA", platform, options, Modifier.fillMaxWidth(), subtitle = brandOf) {
                if (it != platform && playerName.isNotEmpty()) {
                    pkg = ""
                    tpl = ""
                    playerName = ""
                    exts = emptyList()
                }
                platform = it
            }
        }
        val fEmu: @Composable () -> Unit = {
            val label = allApps.firstOrNull { it.pkg == pkg }?.label ?: pkg
            val shown = if (playerName.isNotEmpty()) playerName else label
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val dp = emuPlat
                if (dp != null && dp.players.isNotEmpty()) {
                    ActionRow("📚", "Catálogo de emuladores", "${dp.players.size} disponíveis para esta plataforma",
                        bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f),
                        iconBg = accent, iconFg = onAccent(accent), compact = true) {
                        emuPicker = EmuPickerRequest(dp) { pl ->
                            pkg = pl.pkg
                            tpl = pl.template
                            playerName = pl.name
                            exts = pl.exts
                        }
                    }
                } else {
                    Text(
                        "Esta plataforma não tem emuladores no catálogo. Escolha um app instalado.",
                        color = C_MUTED, fontSize = 11.sp
                    )
                }
                EPill(Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        ELabel("EMULADOR")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (pkg.isEmpty()) "Nenhum (app nativo)" else shown, Color.White, 13)
                    }
                    Spacer(Modifier.width(8.dp))
                    EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                        appPickerNone = "Nenhum (app nativo / escolho por jogo)"
                        appPickerCb = { a ->
                            val np = a?.pkg ?: ""
                            pkg = np
                            // Se o catálogo tem um único emulador com esse pacote para a plataforma, usa o comando dele.
                            val only = emuPlat?.players?.filter { it.pkg == np }?.singleOrNull()
                            tpl = TEMPLATES[np] ?: only?.template ?: ""
                            playerName = only?.name ?: ""
                            exts = only?.exts ?: emptyList()
                        }
                        appPickerOpen = true
                    }
                }
            }
        }
        val fFolders: @Composable () -> Unit = {
            Column {
                ELabel("PASTAS DE ROMS (${folders.size})")
                Spacer(Modifier.height(6.dp))
                LazyColumn(modifier = Modifier.heightIn(max = if (landscape) 96.dp else 130.dp)) {
                    items(folders.sortedAlpha { folderLabel(it) }, key = { it }) { f ->
                        Row(
                            modifier = Modifier.fillMaxWidth().cardRow(null),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.weight(1f)) { MarqueeText(folderLabel(f), Color(0xFFCBD2E0), 11, FontWeight.Medium) }
                            Spacer(Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x26E11D48))
                                    .focusGlow(CircleShape)
                                    .clickable { folders.remove(f) },
                                contentAlignment = Alignment.Center
                            ) { Text("✕", color = Color(0xFFFF6B81), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                EBtn("Adicionar pasta", "+", accent.copy(alpha = 0.14f), accent.copy(alpha = 0.5f), accent, Modifier.fillMaxWidth()) {
                    treeCb = { u -> if (u !in folders) folders.add(u) }
                    treePicker.launch(null)
                }
            }
        }
        val fTpl: @Composable () -> Unit = {
            Column {
                ELabel("COMANDO DE ABERTURA (AVANÇADO)")
                Spacer(Modifier.height(6.dp))
                PillField(null, tpl, { tpl = it }, "-n pacote/.Activity -d {file.uri}", Modifier.fillMaxWidth(), 12, FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                // Toque em um item para inserir no comando.
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("{file.uri}", "{file.path}", "{file.mime}", "{tags.vita_game_id}").forEach { tk ->
                        val chip = RoundedCornerShape(rBtn.dp)
                        Box(
                            modifier = Modifier
                                .clip(chip)
                                .background(S_FIELD)
                                .border(1.dp, S_LINE, chip)
                                .focusGlow(chip)
                                .clickable { tpl = if (tpl.isEmpty() || tpl.endsWith(" ")) tpl + tk else tpl + " " + tk }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) { Text(tk, color = C_MUTED, fontSize = 10.sp, maxLines = 1, softWrap = false) }
                    }
                }
            }
        }

        NexusModal(
            if (initial == null) "Vincular plataforma" else "Editar: ${initial.platform}",
            { overlay = Overlay.Platforms },
            footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) { overlay = Overlay.Platforms }
                if (initial != null) {
                    EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), Color(0xFFFF6B81), Modifier.weight(1f), tall = true) {
                        links.removeAll { it.platform == initial.platform }
                        savePrefs()
                        overlay = Overlay.Platforms
                    }
                }
                EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                    val clean = if (tpl.trim() == (TEMPLATES[pkg] ?: "")) "" else tpl.trim()
                    val nl = PlatformLink(platform, pkg, clean, folders.toList(), playerName, exts)
                    // Plataforma do catálogo ainda não cadastrada: cadastra ao vincular,
                    // assim ela passa a aparecer ao adicionar jogos.
                    if (platforms.none { it.name == platform }) {
                        val dp = EmuCatalog.forPlatform(this@MainActivity, platform)
                        platforms.add(GamePlatform(platform, dp?.manufacturer ?: "", platform))
                    }
                    val idx = if (initial == null) -1 else links.indexOfFirst { it.platform == initial.platform }
                    if (idx >= 0) links[idx] = nl else links.add(nl)
                    savePrefs()
                    overlay = Overlay.Platforms
                }
            }
            }
        ) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fPlat()
                        fEmu()
                        fTpl()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) { fFolders() }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fPlat()
                    fEmu()
                    fFolders()
                    fTpl()
                }
            }
        }
    }

    @Composable
    private fun EmuPickerDialog(req: EmuPickerRequest) {
        var q by remember { mutableStateOf("") }
        val k = q.trim().lowercase()
        val rows = remember(req) {
            req.platform.players.map { it to isInstalled(it.pkg) }
                .sortedAlpha { it.first.name }
                .sortedByDescending { it.second }
        }
        val filtered = if (k.isEmpty()) rows else rows.filter {
            it.first.name.lowercase().contains(k) || it.first.pkg.lowercase().contains(k)
        }
        NexusModal("Emuladores: ${req.platform.name}", { emuPicker = null }, tall = true) {
            CField(q, { q = it }, "🔍 Buscar emulador", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filtered) { row ->
                    val pl = row.first
                    val inst = row.second
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                req.onPick(pl)
                                emuPicker = null
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(if (inst) pl.pkg else "")
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(pl.name, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(pl.pkg, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            if (inst) "instalado" else "não instalado",
                            color = if (inst) Color(0xFF34D399) else C_MUTED, fontSize = 10.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { emuPicker = null }
        }
    }

    @Composable
    private fun StoragePromptDialog() {
        NexusModal("Acesso ao armazenamento", { overlay = Overlay.None }) {
            Text(
                "Para ler suas pastas de ROMs e abrir os jogos nos emuladores, permita o acesso a todos os arquivos. " +
                    "Isso também faz funcionar as pastas que vierem de um backup importado.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            CButton("Permitir acesso", C_BLUE, Modifier.fillMaxWidth()) {
                overlay = Overlay.None
                askStorage()
            }
            Spacer(Modifier.height(8.dp))
            CButton("Agora não", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
        }
    }

    @Composable
    private fun PlatformListDialog() {
        NexusModal("Cadastro de plataformas", { overlay = Overlay.Settings }, tall = true) {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(sortPlatforms(platforms.toList()), key = { it.name }) { p ->
                    val locked = p.name == WEB_PLATFORM || p.name == ANDROID_PLATFORM
                    val used = games.count { it.platform == p.name }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow(if (locked) null else ({ overlay = Overlay.PlatformEdit(p) })),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            val man = if (p.manufacturer.isBlank()) "Sem fabricante" else p.manufacturer
                            Text(
                                if (locked) "Fixa do sistema · $used jogo(s)" else "$man · $used jogo(s)",
                                color = C_MUTED, fontSize = 11.sp, maxLines = 1
                            )
                        }
                        if (!locked) Text("›", color = C_MUTED, fontSize = 20.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Ordem: fabricante (A-Z) e depois nome (A-Z).",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("+ Nova plataforma", C_BLUE, Modifier.fillMaxWidth()) { overlay = Overlay.PlatformEdit(null) }
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun PlatformEditDialog(initial: GamePlatform?) {
        var name by remember { mutableStateOf(initial?.name ?: "") }
        var man by remember { mutableStateOf(initial?.manufacturer ?: "") }
        val used = if (initial == null) 0 else games.count { it.platform == initial.name }
        val accent = parseColor(accentHex)
        NexusModal(
            if (initial == null) "Nova plataforma" else "Editar plataforma",
            { overlay = Overlay.PlatformList },
            footer = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) { overlay = Overlay.PlatformList }
                    if (initial != null) {
                        EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), Color(0xFFFF6B81), Modifier.weight(1f), tall = true) {
                            if (used > 0) toast("$used jogo(s) usam esta plataforma. Mude ou apague esses jogos antes.")
                            else overlay = Overlay.ConfirmDeletePlatform(initial)
                        }
                    }
                    EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                        if (savePlatform(initial, name, man)) overlay = Overlay.PlatformList
                    }
                }
            }
        ) {
            PillField("NOME DA PLATAFORMA", name, { name = it }, "Ex.: Game Boy Advance", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            PillField("FABRICANTE", man, { man = it }, "Ex.: Nintendo", Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            SCard(pad = 10.dp) {
                Row(verticalAlignment = Alignment.Top) {
                    Text("ⓘ", color = accent, fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (initial == null) "Depois, vincule a plataforma a um emulador em Plataformas e emuladores."
                        else "$used jogo(s) usam esta plataforma. Ao renomear, eles acompanham o novo nome.",
                        color = Color(0xFFCBD2E0), fontSize = 11.sp
                    )
                }
            }
        }
    }

    @Composable
    private fun ConfirmDeletePlatformDialog(p: GamePlatform) {
        NexusModal("Apagar plataforma?", { overlay = Overlay.PlatformEdit(p) }) {
            Text(
                "Apagar \"${p.name}\"? A vinculação dela com emulador e pastas também será removida.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.PlatformEdit(p) }
                CButton("Apagar", C_RED, Modifier.weight(1f)) { deletePlatform(p) }
            }
        }
    }

    @Composable
    private fun ConfirmDeleteDialog(g: Game) {
        NexusModal("Apagar jogo?", { overlay = Overlay.Edit(g) }) {
            Text(
                "Apagar \"${g.title}\" da biblioteca? Essa ação não pode ser desfeita.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.Edit(g) }
                CButton("Apagar", C_RED, Modifier.weight(1f)) { deleteGame(g) }
            }
        }
    }

    @Composable
    private fun ConfirmResetDialog() {
        NexusModal("Resetar biblioteca?", { overlay = Overlay.None }) {
            Text(
                "Isso apaga todos os jogos da biblioteca.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                CButton("Resetar", C_RED, Modifier.weight(1f)) {
                    games.clear()
                    games.addAll(defaultGames())
                    saveLibrary()
                    Covers.clearAll()
                    resetFilters()
                    dashPlatform = ""
                    selectedId = firstNavId()
                    overlay = Overlay.None
                }
            }
        }
    }
}
