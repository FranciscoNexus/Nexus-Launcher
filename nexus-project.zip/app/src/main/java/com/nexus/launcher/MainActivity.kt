package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class RomEntry(val name: String, val folder: String, val uri: String)

class RomListRequest(val platform: String, val onPick: (String, String) -> Unit)

class EmuPickerRequest(val platform: EmuPlatform, val onPick: (EmuPlayer) -> Unit)

/** Capas em lote: andamento da busca no SteamGridDB (roda em segundo plano). */
class CoverBatch(val scope: String, val total: Int) {
    var done by androidx.compose.runtime.mutableIntStateOf(0)
    var applied by androidx.compose.runtime.mutableIntStateOf(0)
    var running by androidx.compose.runtime.mutableStateOf(true)
    var error by androidx.compose.runtime.mutableStateOf("")
    val notFound = androidx.compose.runtime.mutableStateListOf<String>()
    @Volatile var cancelled = false
}

/** Seletor de plataforma (busca + lista completa + criar/editar/apagar personalizadas). */
class PlatPickerRequest(
    val title: String,
    val selected: String,
    val filter: (String) -> Boolean,
    /** Chamado quando uma plataforma personalizada é renomeada (new = novo nome) ou apagada (new = ""). */
    val onChanged: (old: String, new: String) -> Unit,
    val onPick: (String) -> Unit
)

class BuiltIntent(val intent: Intent, val kill: Boolean)

class ScanResult(val roms: List<RomEntry>, val failed: Int)

// ---------- Cadastro em lote ----------
class BatchItem(val key: String, val variants: List<ScanCandidate>, chosen: ScanCandidate) {
    var cand by mutableStateOf(chosen)
    var checked by mutableStateOf(true)
}

class BatchIgnored(val item: IgnoredItem) {
    var checked by mutableStateOf(false)
}

enum class BatchPhase { SCANNING, REGIONS, LIST }

class BatchSession(val platform: String, val profile: ScanProfile) {
    var phase by mutableStateOf(BatchPhase.SCANNING)
    var found by mutableStateOf(0)
    @Volatile var cancelled = false
    @Volatile var failedFolders = 0
    var all: List<ScanCandidate> = emptyList()
    var ignored: List<IgnoredItem> = emptyList()
    var alreadyCount by mutableStateOf(0)
    var dupGroups by mutableStateOf(0)
    val items = mutableStateListOf<BatchItem>()
    val ignoredItems = mutableStateListOf<BatchIgnored>()
    var query by mutableStateOf("")
    var showIgnored by mutableStateOf(false)
}

sealed class Overlay {
    object None : Overlay()
    class Edit(val game: Game?) : Overlay()
    object Filter : Overlay()
    object Settings : Overlay()
    object Genres : Overlay()
    object Platforms : Overlay()
    object CoverBatchSetup : Overlay()
    class LinkEdit(val link: PlatformLink?) : Overlay()
    object Search : Overlay()
    object ResetGames : Overlay()
    object ConfirmFactory : Overlay()
    class ConfirmDelete(val game: Game) : Overlay()
    class Info(val id: String) : Overlay()
    class PlatformImage(val name: String) : Overlay()
    object Collections : Overlay()
    class ConfirmDeleteCollection(val name: String) : Overlay()
    object StoragePrompt : Overlay()
    class AddChoice(val first: Boolean) : Overlay()
    object BatchSetup : Overlay()
    /** 4.6.1 (TV): escolha do modo de visualização das capas (botão do olho). */
    object ViewMode : Overlay()
}

private const val SETTINGS_TABS = 4   // Visual, Biblioteca, Sistema, Extras
private const val ADD_ID = "__add__"
private const val H_ORIENT = 0
private const val H_FLOAT = 1
private const val H_SELECT = 2
private const val H_START = 3
private const val H_GEAR = 4
private const val H_EYE = 5
/** Modos de visualização da TV (4.6.1). */
private const val TV_VIEW_STD = 0
private const val TV_VIEW_CAROUSEL = 1
private const val TV_VIEW_GRID = 2
private const val TV_VIEW_LIST = 3
/** Espaço acima da primeira linha da grade/lista; o brilho da capa não pode passar disso sem ser cortado. */
private const val LIST_TOP_PAD_DP = 10f
private const val LIST_ROW_H_DP = 96
private const val NO_GENRE = "Sem gênero"
private const val PLAT_PREFIX = "plat:"

class SgdbPicker(val title: String, val term: String, val portrait: Boolean, val onPick: (String) -> Unit)

private const val APP_VERSION = "4.9.0"

// Paleta do destaque (borda e LED). A ordem é a mesma da paleta antiga, para migrar quem já tinha uma cor salva.
private val ACCENTS = listOf(
    "Azul" to "#0A84FF", "Verde" to "#30D158", "Laranja" to "#FF9F0A", "Vermelho" to "#FF453A",
    "Roxo" to "#BF5AF2", "Amarelo" to "#FFD60A", "Branco" to "#FFFFFF", "Ciano" to "#00E5FF",
    "Rosa" to "#FF4DA6", "Verde-limão" to "#AEEA00"
)
private val OLD_COLORS = listOf(
    "#007AFF", "#4CD964", "#FF9500", "#FF3B30", "#AF52DE", "#FFCC00", "#FFFFFF",
    "#00E5FF", "#FF2D95", "#C6FF00"
)

private val SORTS = listOf(
    "Padrão (Recentes > Favoritos > A-Z)",
    "Jogados recentemente (últimos 10)",
    "A-Z (crescente)",
    "Z-A (decrescente)"
)

private val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

/** Tempo (ms) com o OK apertado para valer como toque longo. */
private const val OK_LONG_MS = 500L

private val PAD_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2
)

// Navegação com repetição: 1 toque = 1 item; segurando, repete após HOLD_DELAY_MS
// e acelera de RATE_MIN até RATE_MAX itens/segundo ao longo de RATE_RAMP_MS.
private const val HOLD_DELAY_MS = 400L
private const val RATE_MIN = 3f
private const val RATE_MAX = 6f
private const val RATE_RAMP_MS = 2000L
private const val PAGE_ITEMS = 4
private const val TRIGGER_PRESS = 0.10f   // zona morta de 10% dos gatilhos
private const val TRIGGER_RELEASE = 0.05f
private const val STICK_ON = 0.6f
private const val STICK_OFF = 0.4f

private val C_PANEL = Color(0xFF141720)
private val C_FIELD = Color(0xFF11141C)
private val C_BORDER = Color(0x24FFFFFF)
private val C_MUTED = Color(0xFF9AA3B5)
private val C_BLUE = Color(0xFF0A84FF)
private val C_ORANGE = Color(0xFFF59E0B)
private val C_RED = Color(0xFFE11D48)
private val C_GRAY = Color(0xFF1E222B)
private val C_YELLOW = Color(0xFFFBBF24)
private val S_PANEL = Color(0xFF141720)
private val HDR_BG = Color(0xE0181C25)
private val HDR_LINE = Color(0x1AFFFFFF)
private val S_CARD = Color(0xFF1A1E29)
private val S_FIELD = Color(0xFF11141C)
private val S_LINE = Color(0x1AFFFFFF)
private val S_MUTED = Color(0xFF9AA3B5)
private val S_PAD_A = Color(0xFF1DB87A)
private val S_PAD_B = Color(0xFFE5484D)

class MainActivity : ComponentActivity() {

    // ---------- Estado ----------
    private val prefs by lazy { getSharedPreferences("nexus_prefs", MODE_PRIVATE) }
    private val libFile by lazy { File(filesDir, "library.json") }
    private val sgdbFile by lazy { File(filesDir, "sgdb_cache.json") }
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sgdbKey by mutableStateOf("")
    private var ytKey by mutableStateOf("") // 4.7.0: chave da API do YouTube (vídeo gameplay)
    private var hideSgdbHint by mutableStateOf(false)
    private val sgdbCache = mutableStateMapOf<String, SgdbInfo>()
    private val sgdbErr = mutableStateMapOf<String, String>()
    private var sgdbBusy by mutableStateOf(setOf<String>())
    // ---- 4.7.0: vídeo gameplay ----
    private val ytCtrl = YtController().also { c -> c.onRevealed = { ytCtl = YT_PLAY } }
    private var ytOpen by mutableStateOf(false)
    private var ytNav by mutableStateOf(false)
    private var ytFull by mutableStateOf(false)
    private var ytCtl by mutableStateOf(YT_PLAY)
    private var ytBusy by mutableStateOf(setOf<String>())
    private val ytErr = mutableStateMapOf<String, String>()
    private var ytRegion by mutableStateOf<androidx.compose.ui.geometry.Rect?>(null)
    private var videoLinkFor by mutableStateOf<Game?>(null)
    private var sgdbPicker by mutableStateOf<SgdbPicker?>(null)
    private val games = mutableStateListOf<Game>()
    private val genres = mutableStateListOf<String>()
    private val links = mutableStateListOf<PlatformLink>()
    private val platforms = mutableStateListOf<GamePlatform>()
    private var allApps: List<AppItem> = emptyList()
    private val iconCache = HashMap<String, ImageBitmap?>()
    private val bigIconCache = HashMap<String, ImageBitmap?>()

    private var selectedId by mutableStateOf<String?>(null)
    private var coverRev by mutableStateOf(0)
    private var storageOk by mutableStateOf(false)
    private var overlay by mutableStateOf<Overlay>(Overlay.None)
    private var landscape by mutableStateOf(false)
    private var widthP by mutableStateOf(175)
    private var widthL by mutableStateOf(170)
    private var radius by mutableStateOf(14)
    private var accentHex by mutableStateOf("#0A84FF")
    private var settingsTab by mutableStateOf(0)
    private var cutoutPad by mutableStateOf(false)
    private var favOnly by mutableStateOf(false)
    private var searchTerm by mutableStateOf("")
    private var fPlatform by mutableStateOf("")
    private var dashMode by mutableStateOf(0)
    private var dashPlatform by mutableStateOf("")
    private var fGenre by mutableStateOf("")
    private var fCollection by mutableStateOf("")
    private var sortMode by mutableStateOf(0)
    private var power by mutableStateOf(PowerSnapshot())
    /** O Nexus é o launcher padrão do aparelho agora? (libera as opções do modo launcher) */
    private var isHome by mutableStateOf(false)
    private var appsDrawerOpen by mutableStateOf(false)
    private var carouselOn by mutableStateOf(true)
    private var introOn by mutableStateOf(true)
    private var floatSmall by mutableStateOf(false)   // 4.5.4: painel flutuante compacto
    private var appPickerOpen by mutableStateOf(false)
    /** 0 = todos os apps, 1 = só os marcados como jogo, 2 = só os marcados como emulador. */
    private var appPickerMode by mutableStateOf(0)
    private var appFilterKind by mutableStateOf(0)
    private val hiddenGameApps = mutableStateListOf<String>()
    private val hiddenEmuApps = mutableStateListOf<String>()
    private val appAliases = androidx.compose.runtime.mutableStateMapOf<String, String>()
    private var appPickerNone by mutableStateOf("Automático (padrão da plataforma)")
    private var romList by mutableStateOf<RomListRequest?>(null)
    private var batch by mutableStateOf<BatchSession?>(null)
    private var emuPicker by mutableStateOf<EmuPickerRequest?>(null)
    private var platPicker by mutableStateOf<PlatPickerRequest?>(null)
    private var coverBatch by mutableStateOf<CoverBatch?>(null)

    private var appPickerCb: ((AppItem?) -> Unit)? = null
    private val collections = mutableStateListOf<String>()
    private var collPickerOpen by mutableStateOf(false)
    private val collPickerSel = mutableStateListOf<String>()
    private var collPickerCb: ((List<String>) -> Unit)? = null
    private var genrePickerOpen by mutableStateOf(false)
    private val genrePickerSel = mutableStateListOf<String>()
    private var genrePickerCb: ((List<String>) -> Unit)? = null
    private var gridColumns = 2
    private val padHandler = Handler(Looper.getMainLooper())
    private val heldKeys = LinkedHashSet<Int>()
    private var axisDx = 0
    private var axisDy = 0
    private var holdDx = 0
    private var holdDy = 0
    private var holdStartMs = 0L
    private var ltDown = false
    private var rtDown = false
    private val repeatTick = object : Runnable {
        override fun run() {
            if ((holdDx == 0 && holdDy == 0) || modalOpen()) {
                stopHold()
                return
            }
            stepSelection(holdDx, holdDy)
            val held = SystemClock.uptimeMillis() - holdStartMs - HOLD_DELAY_MS
            val t = (held.toFloat() / RATE_RAMP_MS).coerceIn(0f, 1f)
            val rate = RATE_MIN + (RATE_MAX - RATE_MIN) * t
            padHandler.postDelayed(this, (1000f / rate).toLong())
        }
    }
    private var pendingPlay: Game? = null
    private var dialogRomCb: ((Uri) -> Unit)? = null
    private var treeCb: ((String) -> Unit)? = null

    // ---------- Modo TV (4.6.0) ----------
    /** Zona de navegação da tela inicial na TV: 0 = capas, 1 = cabeçalho, 2 = rodapé (A / B / Y / X). */
    private var navZone by mutableStateOf(0)
    private var hdrIdx by mutableStateOf(0)
    private var ftrIdx by mutableStateOf(0)
    /** Explorador de arquivos embutido (substitui o seletor do Android na TV). */
    private var explorer by mutableStateOf<ExplorerState?>(null)
    /** Ajuda quando o Android da TV não tem a tela de permissão: "overlay" ou "storage". */
    private var permHelp by mutableStateOf<String?>(null)
    /** Na tela de informações: o D-pad já foi usado, então A/OK clicam no item destacado em vez de "Jogar". */
    private var infoNav = false
    /** 4.6.1: modo de visualização da tela inicial na TV: 0 padrão, 1 carrossel, 2 grade, 3 lista. */
    private var tvView by mutableStateOf(TV_VIEW_STD)

    // ---------- Launchers ----------
    private val pickRomForPlay = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val g = pendingPlay
        pendingPlay = null
        if (uri != null && g != null) {
            persist(uri)
            val updated = g.copy(romUri = uri.toString())
            replaceGame(updated)
            launchGame(updated)
        }
    }

    private val pickRomForDialog = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            dialogRomCb?.invoke(uri)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) writeBackup(uri) }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) readBackup(uri) }

    private val homeRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { isHome = LauncherMode.isDefault(this) }

    // Painel flutuante (4.5.0): 1) permissão "Exibir sobre outros apps"  2) permissão de notificação  3) liga o serviço.
    private val overlayPermRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (FloatingPanelService.canDraw(this)) askNotifThenStartFloat() else toast("Sem a permissão, o painel não pode aparecer sobre outros apps") }

    private val notifPermRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startFloat() }

    private val treePicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            treeCb?.invoke(uri.toString())
        }
    }

    // 4.6.0: na TV a tela é vista de longe, então toda a interface fica maior (equivale a "tamanho de exibição").
    override fun attachBaseContext(newBase: Context) {
        var ctx = newBase
        try {
            TvMode.init(newBase)
            if (TvMode.isTv) {
                val cfg = Configuration(newBase.resources.configuration)
                val sc = TvMode.UI_SCALE
                cfg.densityDpi = (cfg.densityDpi * sc).toInt()
                cfg.screenWidthDp = (cfg.screenWidthDp / sc).toInt()
                cfg.screenHeightDp = (cfg.screenHeightDp / sc).toInt()
                cfg.smallestScreenWidthDp = (cfg.smallestScreenWidthDp / sc).toInt()
                ctx = newBase.createConfigurationContext(cfg)
            }
        } catch (_: Exception) {
        }
        super.attachBaseContext(ctx)
    }

    // ---------- Seletores de arquivo/pasta (4.6.0): na TV usam o explorador embutido ----------
    private fun openExplorerFile(forPlay: Boolean) {
        explorer = ExplorerState(false, "Escolher o arquivo do jogo", null, null) { f ->
            val uri = Uri.parse(fileUri(f))
            if (forPlay) {
                val g = pendingPlay
                pendingPlay = null
                if (g != null) {
                    val updated = g.copy(romUri = uri.toString())
                    replaceGame(updated)
                    launchGame(updated)
                }
            } else {
                dialogRomCb?.invoke(uri)
            }
        }
    }

    private fun pickRomFile(forPlay: Boolean) {
        if (TvMode.isTv) {
            openExplorerFile(forPlay)
            return
        }
        try {
            if (forPlay) pickRomForPlay.launch(arrayOf("*/*")) else pickRomForDialog.launch(arrayOf("*/*"))
        } catch (_: Exception) {
            openExplorerFile(forPlay)
        }
    }

    private fun openExplorerFolder() {
        explorer = ExplorerState(true, "Escolher a pasta", null, null) { f ->
            treeCb?.invoke(ExplorerFs.treeUriFor(f.path))
        }
    }

    private fun pickFolder() {
        if (TvMode.isTv) {
            openExplorerFolder()
            return
        }
        try {
            treePicker.launch(null)
        } catch (_: Exception) {
            openExplorerFolder()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPrefs()
        // 4.5.4: o Nexus obedece ao Android — gira pelo sensor se o giro automático estiver ligado e fica
        // travado se o usuário bloqueou a rotação. Só o botão do cabeçalho passa por cima do bloqueio.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        applyFullscreen()
        allApps = loadApps()
        loadLibrary()
        importPendingShortcuts()
        syncPlatforms()
        ensureFixedCollections()
        isHome = LauncherMode.isDefault(this)
        sgdbCache.putAll(SgdbStore.load(sgdbFile))
        File(filesDir, "rawg_cache.json").delete() // restos da integração antiga
        Covers.init(this)
        storageOk = hasAllFiles()
        if (!storageOk && !prefs.getBoolean("storagePrompted", false)) {
            prefs.edit().putBoolean("storagePrompted", true).apply()
            overlay = Overlay.StoragePrompt
        } else {
            maybeWelcome()
        }
        prefetchCovers()
        selectedId = firstNavId()
        setContent {
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, 1f)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                        SideEffect {
                            FocusStyle.accent = parseColor(accentHex)
                            FocusStyle.radiusDp = rBtn.toFloat()
                        }
                        var showIntro by remember { mutableStateOf(introOn && !NexusIntroState.shown && overlay is Overlay.None) }
                        Box(Modifier.fillMaxSize()) {
                            NexusScreen()
                            if (showIntro) {
                                NexusIntro(
                                    accent = parseColor(accentHex),
                                    onDone = { NexusIntroState.shown = true; showIntro = false }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen() else stopHold()
    }

    private fun applyFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Preferências ----------
    private fun loadPrefs() {
        widthP = prefs.getInt("widthP", 175)
        widthL = prefs.getInt("widthL", 170)
        radius = canonicalRadius(prefs.getInt("radius", 14))
        accentHex = normalizeAccent(prefs.getString("color", "#0A84FF") ?: "#0A84FF")
        cutoutPad = prefs.getBoolean("cutoutPad", false)
        sgdbKey = prefs.getString("sgdbKey", "") ?: ""
        ytKey = prefs.getString("ytKey", "") ?: ""
        hideSgdbHint = prefs.getBoolean("hideSgdbHint", false)
        if (prefs.contains("rawgKey")) prefs.edit().remove("rawgKey").apply()
        dashMode = prefs.getInt("dashMode", 0)
        carouselOn = prefs.getBoolean("carouselOn", true)
        tvView = prefs.getInt("tvView", if (carouselOn) TV_VIEW_CAROUSEL else TV_VIEW_STD).coerceIn(0, 3)
        introOn = prefs.getBoolean("introOn", true)
        floatSmall = prefs.getBoolean("floatSmall", false)
        // 4.5.2: os sons foram removidos; apaga o que ficou salvo.
        if (prefs.contains("soundsOn") || prefs.contains("soundStyle")) prefs.edit().remove("soundsOn").remove("soundStyle").apply()
        collections.clear()
        prefs.getString("collectionsList", null)?.let { s ->
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val n = a.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            } catch (_: Exception) {
            }
        }
        hiddenGameApps.clear()
        hiddenEmuApps.clear()
        appAliases.clear()
        try {
            prefs.getString("hiddenGameApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenGameApps.add(a.getString(i)) } }
            prefs.getString("hiddenEmuApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenEmuApps.add(a.getString(i)) } }
            prefs.getString("appAliases", null)?.let { j ->
                val o = org.json.JSONObject(j)
                for (k in o.keys()) appAliases[k] = o.getString(k)
            }
        } catch (_: Exception) {
        }
        genres.clear()
        val gs = prefs.getString("genres", null)
        if (gs != null) {
            try {
                val a = JSONArray(gs)
                for (i in 0 until a.length()) genres.add(a.getString(i))
            } catch (_: Exception) {
            }
        }
        if (genres.isEmpty()) genres.addAll(GENRES)
        platforms.clear()
        val ps = prefs.getString("platformsList", null)
        if (ps != null) {
            try {
                platforms.addAll(PlatformStore.parse(ps))
            } catch (_: Exception) {
            }
        }
        if (platforms.isEmpty()) platforms.addAll(defaultPlatforms())
        links.clear()
        val ls = prefs.getString("links", null)
        if (ls != null) {
            try {
                links.addAll(LinkStore.parse(ls))
            } catch (_: Exception) {
            }
        }
    }

    /** 4.7.8: true durante "Restaurar configurações de fábrica": nada pode ser regravado antes do reinício. */
    private var wiping = false

    private fun savePrefs() {
        if (wiping) return
        prefs.edit()
            .putInt("widthP", widthP)
            .putInt("widthL", widthL)
            .putInt("radius", radius)
            .putString("color", accentHex)
            .putBoolean("cutoutPad", cutoutPad)
            .putInt("dashMode", dashMode)
            .putString("collectionsList", JSONArray(collections.toList()).toString())
            .putString("genres", JSONArray(genres.toList()).toString())
            .putString("hiddenGameApps", JSONArray(hiddenGameApps.toList()).toString())
            .putString("hiddenEmuApps", JSONArray(hiddenEmuApps.toList()).toString())
            .putString("appAliases", org.json.JSONObject(appAliases.toMap()).toString())
            .putString("links", LinkStore.toJson(links.toList()))
            .putString("platformsList", PlatformStore.toJson(platforms.toList()))
            .apply()
    }

    /** Orientação que o botão do cabeçalho forçou (null = quem manda é o Android). */
    private var forcedLandscape: Boolean? = null
    private var orientListener: OrientationEventListener? = null

    /** O giro automático do Android está ligado? (false = o usuário bloqueou a rotação) */
    private fun autoRotateOn(): Boolean = try {
        android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.ACCELEROMETER_ROTATION, 0) == 1
    } catch (e: Exception) { true }

    /**
     * O botão gira a tela na hora, mesmo com o giro automático bloqueado. Com o giro automático LIGADO, quando
     * o aparelho for girado de verdade para a mesma posição o Android volta a mandar. Com o giro BLOQUEADO, o
     * Nexus fica na orientação escolhida até o botão ser tocado de novo.
     */
    private fun toggleOrientation() {
        val target = !landscape
        forcedLandscape = target
        landscape = target
        requestedOrientation =
            if (target) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    private fun startOrientationWatch() {
        if (orientListener == null) {
            orientListener = object : OrientationEventListener(this) {
                override fun onOrientationChanged(deg: Int) {
                    val forced = forcedLandscape ?: return
                    if (deg == OrientationEventListener.ORIENTATION_UNKNOWN) return
                    if (!autoRotateOn()) return
                    val physLand = deg in 60..120 || deg in 240..300
                    val physPort = deg <= 30 || deg >= 330 || deg in 150..210
                    if ((forced && physLand) || (!forced && physPort)) {
                        forcedLandscape = null
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                    }
                }
            }
        }
        orientListener?.let { if (it.canDetectOrientation()) it.enable() }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    // ---------- Tema ao vivo (3.9.5) ----------
    // 0 = Reto, 1 = Padrão, 2 = Suave. Tudo (painéis, cards, botões, campos) lê estes valores.
    private fun styleOf(r: Int): Int = when {
        r <= 6 -> 0
        r <= 17 -> 1
        else -> 2
    }
    private fun canonicalRadius(r: Int): Int = intArrayOf(4, 14, 22)[styleOf(r)]
    private fun normalizeAccent(hex: String): String {
        if (hex.equals("#FF375F", true)) return ACCENTS[8].second // rosa antigo (parecido com o vermelho)
        ACCENTS.firstOrNull { it.second.equals(hex, true) }?.let { return it.second }
        val i = OLD_COLORS.indexOfFirst { it.equals(hex, true) }
        return if (i >= 0) ACCENTS[i].second else hex
    }
    private val styleIdx: Int get() = styleOf(radius)
    private val rPanel: Int get() = intArrayOf(6, 18, 28)[styleIdx]
    private val rCard: Int get() = intArrayOf(4, 14, 22)[styleIdx]
    private val rBtn: Int get() = intArrayOf(4, 11, 18)[styleIdx]
    private fun onAccent(c: Color): Color = if (c.luminance() > 0.55f) Color(0xFF07090D) else Color.White

    /** Borda de foco na cor de destaque (navegação por controle). Deve vir ANTES do clickable. */
    @Composable
    private fun Modifier.focusGlow(shape: Shape): Modifier {
        var focused by remember { mutableStateOf(false) }
        val accent = parseColor(accentHex)
        return this
            .ownRing()
            .onFocusChanged { focused = it.isFocused }
            .then(
                if (focused) Modifier.border(3.dp, accent, shape).background(accent.copy(alpha = 0.18f), shape)
                else Modifier
            )
    }

    private fun parseColor(hex: String): Color = try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        Color(0xFF0A84FF)
    }

    // ---------- Biblioteca ----------
    private fun defaultGames(): List<Game> =
        LibraryStore.parse(assets.open("default_library.json").bufferedReader().use { it.readText() })

    private fun loadLibrary() {
        val existed = libFile.exists()
        val list = try {
            if (existed) LibraryStore.parse(libFile.readText()) else defaultGames()
        } catch (e: Exception) {
            toast("Erro ao ler biblioteca: ${e.message}")
            emptyList()
        }
        games.addAll(list)
        if (!existed) saveLibrary()
    }

    private fun saveLibrary() {
        if (wiping) return
        try {
            libFile.writeText(LibraryStore.toJson(games.toList()))
        } catch (e: Exception) {
            toast("Erro ao salvar: ${e.message}")
        }
    }

    private fun replaceGame(updated: Game) {
        val idx = games.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            games[idx] = updated
            saveLibrary()
        }
    }

    private fun markPlayed(g: Game) {
        val idx = games.indexOfFirst { it.id == g.id }
        if (idx >= 0) {
            games[idx] = games[idx].copy(
                lastPlayedTs = System.currentTimeMillis(),
                openCount = games[idx].openCount + 1
            )
            saveLibrary()
        }
    }

    // 4.7.0: sempre os 3 últimos; com o filtro "Jogados recentemente" (Select) valem os 10 últimos.
    // 4.9.0: listas calculadas UMA vez e reaproveitadas (só recalculam quando jogos/filtros mudam).
    private val recentIdsD = derivedStateOf { computeRecentIds() }
    private val filteredGamesD = derivedStateOf { computeFilteredGames() }
    private val visibleGamesD = derivedStateOf { computeVisibleGames() }
    private val platformCardsD = derivedStateOf { computePlatformCards() }
    private fun recentIds(): Set<String> = recentIdsD.value
    private fun filteredGames(): List<Game> = filteredGamesD.value
    private fun visibleGames(): List<Game> = visibleGamesD.value
    private fun platformCards(): List<GamePlatform> = platformCardsD.value

    private fun computeRecentIds(): Set<String> =
        games.filter { it.lastPlayedTs > 0 }
            .sortedByDescending { it.lastPlayedTs }
            .take(if (sortMode == 1) 10 else 3).map { it.id }.toSet()

    // Filtros do botão Select (favoritos, plataforma, gênero e coleção), sem o recorte do dashboard.
    private fun computeFilteredGames(): List<Game> {
        var l: List<Game> = games.toList()
        if (favOnly) l = l.filter { it.isFavorite }
        if (fPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == fPlatform }
        if (fGenre.isNotEmpty()) l = l.filter { if (fGenre == NO_GENRE) it.genres.isEmpty() else fGenre in it.genres }
        if (fCollection.isNotEmpty()) l = l.filter { fCollection in it.collections }
        val k = searchTerm.trim().lowercase()
        if (k.isNotEmpty()) {
            l = l.filter { g ->
                g.title.lowercase().contains(k) || g.shownPlatform.lowercase().contains(k) ||
                    g.genres.any { it.lowercase().contains(k) } || (k.length >= 3 && g.genres.isEmpty() && foldText(NO_GENRE).contains(foldText(k))) || g.collections.any { it.lowercase().contains(k) }
            }
        }
        return l
    }

    private fun computeVisibleGames(): List<Game> {
        var l: List<Game> = filteredGames()
        if (dashMode == 1 && dashPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == dashPlatform }
        return when (sortMode) {
            1 -> l.filter { it.lastPlayedTs > 0 }.sortedByDescending { it.lastPlayedTs }.take(10)
            2 -> l.sortedAlpha { it.title }
            3 -> l.sortedAlpha { it.title }.reversed()
            else -> {
                val rec = l.filter { it.lastPlayedTs > 0 }
                    .sortedByDescending { it.lastPlayedTs }.take(3)
                val ids = rec.map { it.id }.toSet()
                val rest = l.filter { it.id !in ids }
                rec +
                    rest.filter { it.isFavorite }.sortedAlpha { it.title } +
                    rest.filter { !it.isFavorite }.sortedAlpha { it.title }
            }
        }
    }

    // ---------- Dashboard por plataformas ----------
    private fun computePlatformCards(): List<GamePlatform> =
        filteredGames().let { fg ->
            platforms.filter { p -> fg.any { it.shownPlatform == p.name } }
                .sortedAlpha { it.name }
        }

    // Tela de plataformas ativa (modo Plataformas, fora de qualquer plataforma e com ao menos um jogo).
    private fun inPlatformList(): Boolean =
        dashMode == 1 && dashPlatform.isEmpty() && platformCards().isNotEmpty()

    private fun navIds(): List<String> =
        if (inPlatformList()) platformCards().map { PLAT_PREFIX + it.name }
        else visibleGames().map { it.id } + ADD_ID

    private fun firstNavId(): String? =
        if (inPlatformList()) navIds().firstOrNull() else visibleGames().firstOrNull()?.id

    private fun enterPlatform(name: String) {
        dashPlatform = name
        selectedId = visibleGames().firstOrNull()?.id
    }

    private fun exitPlatform() {
        val left = dashPlatform
        dashPlatform = ""
        selectedId = if (platformCards().any { it.name == left }) PLAT_PREFIX + left else firstNavId()
    }

    private fun savePlatformImage(name: String, url: String) {
        val i = platforms.indexOfFirst { it.name == name }
        if (i < 0) return
        val old = platforms[i].image
        val u = url.trim()
        platforms[i] = platforms[i].copy(image = u)
        savePrefs()
        if (old.isNotBlank() && old != u) {
            Covers.purgeIfUnused(old, games.map { it.cover } + platforms.map { it.image })
        }
        prefetchCovers()
    }

    private fun resetFilters() {
        favOnly = false
        fPlatform = ""
        fGenre = ""
        fCollection = ""
        searchTerm = ""
        sortMode = 0
    }

    private fun selectGame(id: String) {
        if (dashMode == 1) {
            games.firstOrNull { it.id == id }?.let { if (dashPlatform != it.shownPlatform) dashPlatform = it.shownPlatform }
        }
        if (visibleGames().none { it.id == id }) resetFilters()
        selectedId = id
    }

    // ---------- Coleções (franquias e grupos) ----------
    /**
     * Garante as coleções fixas (Já zerei, Jogando agora, Quero jogar, Clássicos, Abandonados).
     * Uma coleção sua com o mesmo nome (mesmo com maiúsculas diferentes) é unida à fixa, sem perder os jogos.
     */
    private fun ensureFixedCollections() {
        val rename = HashMap<String, String>()
        for (c in collections.toList()) {
            val f = FIXED_COLLECTIONS.firstOrNull { it.equals(c, ignoreCase = true) }
            if (f != null && f != c) rename[c] = f
        }
        var changedGames = false
        if (rename.isNotEmpty()) {
            for (old in rename.keys) collections.remove(old)
            for (k in games.indices) {
                val cs = games[k].collections
                if (cs.any { it in rename }) {
                    games[k] = games[k].copy(collections = cs.map { rename[it] ?: it }.distinct())
                    changedGames = true
                }
            }
            if (fCollection in rename) fCollection = rename[fCollection] ?: ""
        }
        var changed = rename.isNotEmpty()
        for (f in FIXED_COLLECTIONS) {
            if (f !in collections) {
                collections.add(f)
                changed = true
            }
        }
        if (changedGames) saveLibrary()
        if (changed) savePrefs()
    }

    /** Fixas primeiro (na ordem definida), depois as suas em ordem alfabética. */
    private fun orderedCollections(): List<String> =
        FIXED_COLLECTIONS.filter { it in collections } + collections.filter { !isFixedCollection(it) }.sortedAlpha { it }

    private fun userCollectionCount(): Int = collections.count { !isFixedCollection(it) }

    private fun addCollection(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        if (collections.any { it.equals(n, ignoreCase = true) }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        collections.add(n)
        savePrefs()
    }

    private fun renameCollection(old: String, new: String) {
        if (isFixedCollection(old)) {
            toast("Esta coleção é fixa e não pode ser renomeada")
            return
        }
        val n = new.trim()
        if (n.isEmpty() || n == old) return
        if (collections.any { it.equals(n, ignoreCase = true) && it != old }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        val i = collections.indexOf(old)
        if (i >= 0) collections[i] = n
        if (fCollection == old) fCollection = n
        for (k in games.indices) {
            if (old in games[k].collections) {
                games[k] = games[k].copy(collections = games[k].collections.map { if (it == old) n else it })
            }
        }
        saveLibrary()
        savePrefs()
    }

    private fun deleteCollection(c: String) {
        if (isFixedCollection(c)) {
            toast("Esta coleção é fixa e não pode ser apagada")
            return
        }
        collections.remove(c)
        if (fCollection == c) fCollection = ""
        for (k in games.indices) {
            if (c in games[k].collections) games[k] = games[k].copy(collections = games[k].collections - c)
        }
        saveLibrary()
        savePrefs()
    }

    private fun renameGenre(old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty() || (n != old && n in genres)) return
        val i = genres.indexOf(old)
        if (i >= 0) genres[i] = n
        for (k in games.indices) if (old in games[k].genres) games[k] = games[k].copy(genres = games[k].genres.map { if (it == old) n else it }.distinct())
        if (fGenre == old) fGenre = n
        saveLibrary()
        savePrefs()
    }

    private fun deleteGenre(g: String) {
        genres.remove(g)
        for (k in games.indices) if (g in games[k].genres) games[k] = games[k].copy(genres = games[k].genres - g)
        if (fGenre == g) fGenre = ""
        saveLibrary()
        savePrefs()
    }

    // ---------- Ações ----------
    // Um passo na direção (dx, dy). Na paisagem só importa dx; no retrato dy anda uma linha.
    private fun stepSelection(dx: Int, dy: Int) {
        if (TvMode.isTv) {
            // TV: o D-pad também chega ao cabeçalho (cima) e ao rodapé (baixo) da tela inicial.
            if (navZone != 0) {
                zoneStep(dx, dy)
                return
            }
            // Modo Lista: só cima/baixo andam pelos cartões.
            if (tvListOn && dx != 0) return
            if (zoneEnter(dx, dy)) return
        }
        stepSelectionRaw(dx, dy)
    }

    /** 4.6.1 (TV, horizontal): modo Grade — igual ao do celular em pé, adaptado para a tela deitada. */
    private val tvGridOn: Boolean get() = landscape && tvView == TV_VIEW_GRID
    /** 4.6.1 (TV, horizontal): modo Lista — cartões com capa e informações, rolagem para cima e para baixo. */
    private val tvListOn: Boolean get() = landscape && tvView == TV_VIEW_LIST
    /** Navegação numa fila só, para os lados (celular deitado e TV nos modos Padrão/Carrossel). */
    private val rowNav: Boolean get() = landscape && !tvGridOn && !tvListOn
    /** Colunas usadas pelo D-pad: 1 na lista; as da grade nos outros modos de grade. */
    private fun navCols(): Int = if (tvListOn) 1 else max(1, gridColumns)

    /** Itens do cabeçalho na ordem em que aparecem (a TV não tem o botão de girar a tela). */
    private fun headerOrder(): List<Int> {
        val l = if (landscape) listOf(H_ORIENT, H_FLOAT, H_SELECT, H_START, H_GEAR)
        else listOf(H_ORIENT, H_SELECT, H_START, H_FLOAT, H_GEAR)
        // 4.7.7: no celular deitado o olho vem logo depois do botão de girar a tela.
        if (!TvMode.isTv) return if (landscape) listOf(H_ORIENT, H_EYE) + l.drop(1) else l
        // TV deitada: o olho (modos de visualização) ocupa o lugar do botão de girar a tela.
        val tvl = l.filter { it != H_ORIENT }
        return if (landscape) listOf(H_EYE) + tvl else tvl
    }

    private fun zoneCount(): Int = when (navZone) {
        1 -> headerOrder().size
        2 -> 4
        else -> 0
    }

    private fun zoneStep(dx: Int, dy: Int) {
        if (dx != 0) {
            val n = max(1, zoneCount())
            if (navZone == 1) hdrIdx = (hdrIdx + dx).coerceIn(0, n - 1)
            else ftrIdx = (ftrIdx + dx).coerceIn(0, n - 1)
            return
        }
        if ((navZone == 1 && dy > 0) || (navZone == 2 && dy < 0)) navZone = 0
    }

    private fun zoneEnter(dx: Int, dy: Int): Boolean {
        if (dy == 0 || dx != 0) return false
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        val cols = navCols()
        val firstRow = rowNav || idx < cols
        val lastRow = rowNav || idx < 0 || idx >= ((ids.size - 1) / cols) * cols
        if (dy < 0 && firstRow) {
            hdrIdx = hdrIdx.coerceIn(0, max(0, headerOrder().size - 1))
            navZone = 1
            return true
        }
        if (dy > 0 && lastRow) {
            ftrIdx = ftrIdx.coerceIn(0, 3)
            navZone = 2
            return true
        }
        return false
    }

    /** OK do controle remoto / botão A: age sobre o que está destacado (capa, botão do cabeçalho ou do rodapé). */
    private fun zoneActivate() {
        when (navZone) {
            1 -> when (headerOrder().getOrNull(hdrIdx)) {
                H_ORIENT -> toggleOrientation()
                H_EYE -> overlay = Overlay.ViewMode
                H_FLOAT -> toggleFloat()
                H_SELECT -> overlay = Overlay.Filter
                H_START -> editSelected()
                H_GEAR -> overlay = Overlay.Settings
            }
            2 -> when (ftrIdx) {
                0 -> openSelected()
                1 -> {
                    navZone = 0
                    back()
                }
                2 -> overlay = Overlay.Search
                3 -> randomPick()
            }
            else -> openSelected()
        }
    }

    private fun stepSelectionRaw(dx: Int, dy: Int) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val step = if (rowNav) dx else if (tvListOn) dy else dx + dy * navCols()
        if (step == 0) return
        val target = idx + step
        if (target in ids.indices) {
            selectedId = ids[target]
        } else if (dy > 0 && !rowNav) {
            selectedId = ids.last()
        }
    }

    // RB (+1) / LB (-1): PAGE_ITEMS jogos. Paisagem = para o lado; retrato = linhas para baixo/cima na mesma coluna.
    private fun pageStep(sign: Int) {
        val before = selectedId
        pageStepRaw(sign)
    }

    private fun pageStepRaw(sign: Int) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val unit = if (rowNav) 1 else navCols()
        selectedId = ids[(idx + sign * PAGE_ITEMS * unit).coerceIn(0, ids.lastIndex)]
    }

    // RT (toEnd = true) / LT (false): último/primeiro jogo da fila.
    // Paisagem = fim/começo da lista; retrato = fim/topo da coluna em que está.
    private fun jumpEdge(toEnd: Boolean) {
        val before = selectedId
        jumpEdgeRaw(toEnd)
    }

    private fun jumpEdgeRaw(toEnd: Boolean) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val lastGame = if (ids.lastOrNull() == ADD_ID) ids.size - 2 else ids.size - 1 // "Adicionar" não conta
        if (lastGame < 0) return
        if (rowNav) {
            selectedId = ids[if (toEnd) lastGame else 0]
            return
        }
        val cols = navCols()
        val col = idx % cols
        val target = if (toEnd) {
            if (lastGame >= col) lastGame - ((lastGame - col) % cols) else lastGame
        } else {
            if (col <= lastGame) col else 0
        }
        selectedId = ids[target]
    }

    private fun currentDir(): Pair<Int, Int> {
        when (heldKeys.lastOrNull()) {
            KeyEvent.KEYCODE_DPAD_LEFT -> return Pair(-1, 0)
            KeyEvent.KEYCODE_DPAD_RIGHT -> return Pair(1, 0)
            KeyEvent.KEYCODE_DPAD_UP -> return Pair(0, -1)
            KeyEvent.KEYCODE_DPAD_DOWN -> return Pair(0, 1)
        }
        return Pair(axisDx, axisDy)
    }

    // Chamado sempre que botão/alavanca muda: nova direção = um passo imediato + início da contagem de "segurar".
    private fun updateHold() {
        val (dx, dy) = currentDir()
        if (dx == holdDx && dy == holdDy) return
        holdDx = dx
        holdDy = dy
        padHandler.removeCallbacks(repeatTick)
        if (dx == 0 && dy == 0) return
        stepSelection(dx, dy)
        holdStartMs = SystemClock.uptimeMillis()
        padHandler.postDelayed(repeatTick, HOLD_DELAY_MS)
    }

    private fun stopHold() {
        padHandler.removeCallbacks(repeatTick)
        heldKeys.clear()
        axisDx = 0
        axisDy = 0
        holdDx = 0
        holdDy = 0
        ltDown = false
        rtDown = false
    }

    private fun handleTriggers(ev: MotionEvent) {
        val l = max(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val r = max(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        if (!ltDown && l >= TRIGGER_PRESS) {
            ltDown = true
            jumpEdge(false)
        } else if (ltDown && l < TRIGGER_RELEASE) {
            ltDown = false
        }
        if (!rtDown && r >= TRIGGER_PRESS) {
            rtDown = true
            jumpEdge(true)
        } else if (rtDown && r < TRIGGER_RELEASE) {
            rtDown = false
        }
    }

    // ---------- Plataformas cadastradas ----------
    private fun platformNames(): List<String> = sortPlatforms(platforms.toList()).map { it.name }

    // Android não usa emulador, então não entra no vínculo de plataformas e emuladores.
    private fun linkablePlatforms(): List<String> = platformNames().filter { it != ANDROID_PLATFORM }

    // Chave para tabelas embutidas (extensões de ROM, emulador padrão), mesmo se a plataforma foi renomeada.
    private fun execKey(platform: String): String {
        val b = platforms.firstOrNull { it.name == platform }?.base ?: ""
        return if (b.isEmpty()) platform else b
    }

    // Garante que "Web / Navegador" exista e que toda plataforma usada por algum jogo esteja cadastrada.
    private fun syncPlatforms() {
        var changed = false
        for (fixed in listOf(WEB_PLATFORM, ANDROID_PLATFORM)) {
            if (platforms.none { it.name == fixed }) {
                platforms.add(GamePlatform(fixed, DEFAULT_MANUFACTURER[fixed] ?: "", fixed))
                changed = true
            }
        }
        for (g in games) {
            if (g.platform.isNotBlank() && platforms.none { it.name == g.platform }) {
                platforms.add(
                    GamePlatform(g.platform, DEFAULT_MANUFACTURER[g.platform] ?: "", if (g.platform in PLATFORMS || EmuCatalog.all(this).any { it.name == g.platform }) g.platform else "")
                )
                changed = true
            }
        }
        if (changed) savePrefs()
    }

    private fun savePlatform(old: GamePlatform?, name: String, manufacturer: String): Boolean {
        val n = name.trim()
        if (n.isEmpty()) {
            toast("Digite o nome da plataforma")
            return false
        }
        if (platforms.any { it.name.equals(n, ignoreCase = true) && it.name != old?.name }) {
            toast("Já existe uma plataforma com esse nome")
            return false
        }
        val m0 = manufacturer.trim()
        val m = platforms.map { it.manufacturer }.firstOrNull { it.isNotBlank() && it.equals(m0, ignoreCase = true) } ?: m0
        if (old == null) {
            platforms.add(GamePlatform(n, m, ""))
        } else {
            val i = platforms.indexOfFirst { it.name == old.name }
            if (i >= 0) platforms[i] = old.copy(name = n, manufacturer = m)
            if (n != old.name) {
                for (k in games.indices) {
                    if (games[k].platform == old.name) games[k] = games[k].copy(platform = n)
                    if (games[k].maskPlatform == old.name) games[k] = games[k].copy(maskPlatform = n)
                }
                for (k in links.indices) if (links[k].platform == old.name) links[k] = links[k].copy(platform = n)
                if (fPlatform == old.name) fPlatform = n
                if (dashPlatform == old.name) dashPlatform = n
                saveLibrary()
            }
        }
        savePrefs()
        return true
    }

    private fun deletePlatform(p: GamePlatform) {
        platforms.removeAll { it.name == p.name }
        links.removeAll { it.platform == p.name }
        if (fPlatform == p.name) fPlatform = ""
        savePrefs()
    }

    // ---------- Capas em lote ----------
    private fun isMobileGame(g: Game): Boolean = g.platform == ANDROID_PLATFORM || g.platform == WEB_PLATFORM

    /** Sem capa própria (o ícone do app não conta como capa). Android/Web só entram se [includeMobile]. */
    private fun coverEligible(g: Game, scope: String, includeMobile: Boolean = true): Boolean =
        g.cover.isBlank() && (includeMobile || !isMobileGame(g)) &&
            (scope.isEmpty() || g.shownPlatform == scope)

    private fun coverMissingCount(): Int = games.count { coverEligible(it, "") }

    private fun startCoverBatch(scope: String, includeMobile: Boolean) {
        val key = sgdbKey.trim()
        if (key.isEmpty()) {
            toast("Informe a chave do SteamGridDB em Sistema")
            return
        }
        val targets = games.filter { coverEligible(it, scope, includeMobile) }.sortedWith(compareBy(ALPHA) { it.platform })
        if (targets.isEmpty()) {
            toast("Nenhum jogo sem capa")
            return
        }
        val job = CoverBatch(scope, targets.size)
        coverBatch = job
        ScanService.start(this)
        mainScope.launch {
            withContext(Dispatchers.IO) {
                for (g in targets) {
                    if (job.cancelled) break
                    val r = SgdbApi.findGrids(key, g.title, true)
                    if (r is SgdbGridsResult.Failure) {
                        job.error = r.message
                        break
                    }
                    val url = (r as SgdbGridsResult.Ok).grids.firstOrNull()?.url
                    if (url == null) {
                        job.notFound.add(g.title)
                    } else {
                        withContext(Dispatchers.Main) {
                            val i = games.indexOfFirst { it.id == g.id }
                            // Nunca sobrescreve uma capa que já exista.
                            if (i >= 0 && games[i].cover.isBlank()) {
                                games[i] = games[i].copy(cover = url)
                                job.applied++
                            }
                        }
                    }
                    job.done++
                    ScanNotify.progressText(this@MainActivity, "Capas em lote", "${job.done} de ${job.total} jogos")
                    kotlinx.coroutines.delay(120)
                }
            }
            job.running = false
            saveLibrary()
            prefetchCovers()
            ScanService.stop(this@MainActivity)
            ScanNotify.doneTitled(
                this@MainActivity, "Capas em lote concluído",
                "${job.applied} capa(s) aplicada(s), ${job.notFound.size} não encontrada(s)"
            )
        }
    }

    // ---------- SteamGridDB ----------
    private fun saveSgdb() { if (!wiping) SgdbStore.save(sgdbFile, sgdbCache.toMap()) }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    private fun fmtReleased(secs: Long): String {
        if (secs <= 0L) return ""
        val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(secs * 1000L))
    }

    // Busca nome oficial e data de lançamento no SteamGridDB e guarda no aparelho. Só repete se force = true.
    private fun fetchSgdb(g: Game, force: Boolean = false) {
        val key = sgdbKey.trim()
        if (key.isEmpty() || g.id in sgdbBusy) return
        if (!force && sgdbCache[g.id] != null) return
        sgdbBusy = sgdbBusy + g.id
        sgdbErr.remove(g.id)
        mainScope.launch {
            val res = withContext(Dispatchers.IO) { SgdbApi.lookup(key, g.title) }
            sgdbBusy = sgdbBusy - g.id
            when (res) {
                is SgdbResult.Ok -> {
                    sgdbCache[g.id] = res.info
                    saveSgdb()
                }
                is SgdbResult.Failure -> {
                    sgdbErr[g.id] = res.message
                }
            }
        }
    }

    // Abre o seletor de imagens do SteamGridDB (capas de jogos em pé; imagens de plataformas em qualquer formato).
    private fun openSgdbPicker(title: String, term: String, portrait: Boolean, onPick: (String) -> Unit) {
        if (sgdbKey.isBlank()) {
            toast("Adicione sua chave do SteamGridDB em Configurações")
            return
        }
        if (term.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        sgdbPicker = SgdbPicker(title, term, portrait, onPick)
    }

    // ---------- Vídeo gameplay (4.7.0) ----------
    /**
     * Procura o vídeo do jogo no YouTube. Só roda na 1ª vez que a tela de detalhes abre (ou quando o usuário
     * toca no botão depois de uma busca sem resultado). O vídeo achado fica salvo e a busca nunca se repete.
     */
    private fun ensureVideo(g: Game, force: Boolean = false) {
        val key = ytKey.trim()
        if (key.isEmpty() || g.id in ytBusy || g.videoId.isNotEmpty()) return
        if (!force && g.videoTried > 0) return
        ytBusy = ytBusy + g.id
        ytErr.remove(g.id)
        val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        mainScope.launch {
            val res = withContext(Dispatchers.IO) { YouTubeApi.search(key, g.title, plat) }
            ytBusy = ytBusy - g.id
            val cur = games.firstOrNull { it.id == g.id } ?: return@launch
            when (res) {
                is YtResult.Ok -> replaceGame(cur.copy(videoId = res.video.id, videoTitle = res.video.title, videoTried = System.currentTimeMillis()))
                YtResult.NotFound -> {
                    replaceGame(cur.copy(videoTried = System.currentTimeMillis()))
                    if (force) toast("Nenhum vídeo encontrado. Use Opções para colar um link.")
                }
                is YtResult.Failure -> {
                    ytErr[g.id] = res.message
                    if (force) toast(res.message)
                }
            }
        }
    }

    private fun onVideoClick(g: Game) {
        when {
            g.videoId.isNotEmpty() -> {
                ytCtl = YT_PLAY
                ytFull = false
                ytNav = infoNav
                ytCtrl.reset()
                ytOpen = true
            }
            ytKey.isBlank() -> {
                // 4.7.6: sem chave de API o player abre só com o aviso e o botão YouTube (busca no app/navegador).
                ytCtl = YT_EXT
                ytFull = false
                ytNav = infoNav
                ytCtrl.reset()
                ytOpen = true
            }
            g.id in ytBusy -> toast("Buscando vídeo…")
            else -> {
                toast("Buscando vídeo…")
                ensureVideo(g, force = true)
            }
        }
    }

    /** Abre o vídeo no app do YouTube (ou no navegador, se o app não existir). */
    private fun openInYouTube(videoId: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")))
        } catch (e: Exception) {
            openUrl("https://www.youtube.com/watch?v=$videoId")
        }
    }

    /** Sem vídeo salvo (e sem chave de API): abre a busca do jogo no app do YouTube ou, se não houver, no navegador. */
    private fun openYouTubeSearch(g: Game) {
        val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        openUrl(YouTubeApi.searchUrl(g.title, plat))
    }

    /**
     * 4.9.0 (TV): abre o app do YouTube já na busca "título plataforma gameplay", no último usuário usado.
     * Tenta o app do Google TV, o do Fire TV e, por último, o navegador. (O app não consegue escolher o perfil.)
     */
    private fun openYouTubeSearchTv(g: Game) {
        val plat = if (g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        val url = YouTubeApi.searchUrl(g.title, plat, simple = true)
        val q = listOf(g.title, plat, "gameplay").filter { it.isNotBlank() }.joinToString(" ")
        val pkgs = listOf("com.google.android.youtube.tv", "com.amazon.firetv.youtube", "com.google.android.youtube")
        for (pkg in pkgs) {
            if (!isInstalled(pkg)) continue
            val tries = listOf(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg),
                Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(android.app.SearchManager.QUERY, q)
            )
            for (intent in tries) {
                if (intent.resolveActivity(packageManager) == null) continue
                try {
                    startActivity(intent)
                    return
                } catch (_: Exception) { }
            }
        }
        openUrl(url)
    }

    private fun closeVideo() {
        ytOpen = false
        ytFull = false
        ytCtl = YT_PLAY
    }

    private fun infoGame(): Game? = (overlay as? Overlay.Info)?.let { o -> games.firstOrNull { it.id == o.id } }

    /** Ação de um botão do player (toque, OK do controle remoto ou A do gamepad). */
    private fun ytAct(i: Int) {
        ytCtl = i
        when (i) {
            YT_CLOSE -> closeVideo()
            YT_BACK -> ytCtrl.seekBy(-10)
            YT_FWD -> ytCtrl.seekBy(10)
            YT_PLAY -> if (ytCtrl.error != 0) {
                infoGame()?.let { openInYouTube(it.videoId) }
            } else ytCtrl.toggle()
            YT_FULL -> if (landscape) ytFull = !ytFull
            YT_EXT -> infoGame()?.let {
                if (TvMode.isTv) openYouTubeSearchTv(it)
                else if (it.videoId.isNotEmpty()) openInYouTube(it.videoId) else openYouTubeSearch(it)
            }
        }
    }

    /** Teclas com o player aberto: o D-pad anda pelos botões do player e nada vaza para a tela de trás. */
    private fun ytHandleKey(ev: KeyEvent, code: Int): Boolean {
        if (ev.action != KeyEvent.ACTION_DOWN) return true
        // Paisagem com os controles escondidos: qualquer tecla só os traz de volta (foco no play/pause);
        // só B / Voltar agem.
        val isBack = code == KeyEvent.KEYCODE_BUTTON_B || code == KeyEvent.KEYCODE_BACK
        if (landscape && !ytCtrl.uiVisible && !isBack) {
            ytCtl = YT_PLAY
            ytNav = true
            infoNav = true
            ytCtrl.wake()
            return true
        }
        ytCtrl.wake()
        val canFull = landscape
        infoNav = true
        ytNav = true
        val noVideo = infoGame()?.videoId.isNullOrEmpty()
        val transport = !noVideo && ytCtrl.error == 0
        // Ordem na tela, da esquerda para a direita: YouTube, −10s, play/pause, +10s, tela cheia.
        val order = when {
            !transport -> listOf(YT_EXT)
            canFull -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD, YT_FULL)
            else -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD)
        }
        val home = if (YT_PLAY in order) YT_PLAY else YT_EXT
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (ytCtl != YT_CLOSE) {
                val i = order.indexOf(if (ytCtl in order) ytCtl else home)
                ytCtl = order[(i - 1).coerceAtLeast(0)]
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (ytCtl != YT_CLOSE) {
                val i = order.indexOf(if (ytCtl in order) ytCtl else home)
                ytCtl = order[(i + 1).coerceAtMost(order.lastIndex)]
            }
            KeyEvent.KEYCODE_DPAD_UP -> if (ytCtl != YT_CLOSE) { ytLast = ytCtl; ytCtl = YT_CLOSE }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (ytCtl == YT_CLOSE) ytCtl = if (ytLast in order) ytLast else home
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A -> if (ev.repeatCount == 0) ytAct(if (ytCtl in order || ytCtl == YT_CLOSE) ytCtl else home)
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> if (ev.repeatCount == 0) back()
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> if (transport && ev.repeatCount == 0) ytCtrl.toggle()
            KeyEvent.KEYCODE_MEDIA_PLAY -> if (transport) ytCtrl.play()
            KeyEvent.KEYCODE_MEDIA_PAUSE -> if (transport) ytCtrl.pause()
            KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_MEDIA_REWIND -> if (transport) ytCtrl.seekBy(-10)
            KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> if (transport) ytCtrl.seekBy(10)
            KeyEvent.KEYCODE_BUTTON_Y -> if (landscape && transport && ev.repeatCount == 0) ytFull = !ytFull
        }
        return true
    }
    private var ytLast = YT_PLAY

    private fun testSgdbKey() {
        val key = sgdbKey.trim()
        if (key.isEmpty()) {
            toast("Cole sua chave primeiro")
            return
        }
        toast("Testando chave…")
        mainScope.launch {
            val err = withContext(Dispatchers.IO) { SgdbApi.ping(key) }
            toast(err ?: "Chave válida ✓")
        }
    }

    private fun testYtKey() {
        val key = ytKey.trim()
        if (key.isEmpty()) {
            toast("Cole sua chave do YouTube primeiro")
            return
        }
        toast("Testando chave…")
        mainScope.launch {
            val err = withContext(Dispatchers.IO) { YouTubeApi.ping(key) }
            toast(err ?: "Chave válida ✓")
        }
    }

    private fun prefetchCovers() = Covers.prefetch(this, games.map { it.cover } + platforms.map { it.image })

    private fun refreshCover(url: String) {
        val u = url.trim()
        if (u.isEmpty()) {
            toast("Sem URL de capa")
            return
        }
        toast("Atualizando capa…")
        Covers.refresh(this, u) { ok ->
            if (ok) coverRev++
            toast(if (ok) "Capa atualizada" else "Não foi possível atualizar. Mantive a capa salva.")
        }
    }

    private fun deleteGame(g: Game) {
        games.removeAll { it.id == g.id }
        saveLibrary()
        Covers.purgeIfUnused(g.cover, games.map { it.cover })
        if (sgdbCache.remove(g.id) != null) saveSgdb()
        selectedId = visibleGames().firstOrNull()?.id
        overlay = Overlay.None
    }

    /** Primeiro uso: pergunta como o usuário quer cadastrar o primeiro jogo (uma vez só). */
    private fun maybeWelcome() {
        if (prefs.getBoolean("welcomeDone", false)) return
        prefs.edit().putBoolean("welcomeDone", true).apply()
        if (games.isEmpty() && overlay is Overlay.None) overlay = Overlay.AddChoice(true)
    }

    private fun openAdd() {
        overlay = Overlay.AddChoice(false)
    }

    private fun openSelected() {
        val id = selectedId ?: return
        if (id.startsWith(PLAT_PREFIX)) {
            enterPlatform(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == ADD_ID) {
            openAdd()
            return
        }
        if (games.none { it.id == id }) return
        overlay = Overlay.Info(id)
    }

    private fun infoPlay(g: Game) {
        overlay = Overlay.None
        playGame(g)
    }

    private fun editSelected() {
        val id = selectedId
        if (id != null && id.startsWith(PLAT_PREFIX)) {
            overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == null || id == ADD_ID) {
            openAdd()
            return
        }
        games.firstOrNull { it.id == id }?.let { overlay = Overlay.Edit(it) }
    }

    private fun randomPick() {
        if (inPlatformList()) {
            selectedId = navIds().random()
            return
        }
        val l = visibleGames()
        if (l.isNotEmpty()) selectedId = l.random().id
    }

    private fun back() {
        when {
            ytOpen -> if (ytFull) ytFull = false else closeVideo()
            videoLinkFor != null -> videoLinkFor = null
            permHelp != null -> permHelp = null
            explorer != null -> explorer?.let { if (!it.up()) explorer = null }
            !modalOpen() && navZone != 0 -> navZone = 0
            appsDrawerOpen -> appsDrawerOpen = false
            romList != null -> romList = null
            batch != null -> {
                val b = batch
                if (b != null && b.phase == BatchPhase.SCANNING) toast("Varredura em andamento. Use Cancelar ou Minimizar.")
                else closeBatch()
            }
            platPicker != null -> platPicker = null
            emuPicker != null -> emuPicker = null
            appFilterKind != 0 -> appFilterKind = 0
            appPickerOpen -> appPickerOpen = false
            sgdbPicker != null -> sgdbPicker = null
            genrePickerOpen -> genrePickerOpen = false
            collPickerOpen -> collPickerOpen = false
            overlay is Overlay.Genres || overlay is Overlay.Platforms || overlay is Overlay.Collections -> overlay = Overlay.Settings
            overlay is Overlay.ConfirmDeleteCollection -> overlay = Overlay.Collections
            overlay is Overlay.LinkEdit -> overlay = Overlay.Platforms
            overlay is Overlay.ConfirmDelete -> overlay = Overlay.Edit((overlay as Overlay.ConfirmDelete).game)
            overlay !is Overlay.None -> overlay = Overlay.None
            dashMode == 1 && dashPlatform.isNotEmpty() -> exitPlatform()
            else -> selectedId = null
        }
    }

    private fun playGame(g: Game) {
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        val tpl = if (g.customCmd.isNotBlank()) g.customCmd
        else if (pkg != null) templateFor(pkg, link) else null
        if (tpl != null && tpl.contains("{file.") && g.romUri.isEmpty()) {
            if (link != null && link.folders.isNotEmpty()) {
                romList = RomListRequest(g.platform) { uri, _ ->
                    val u = g.copy(romUri = uri)
                    replaceGame(u)
                    launchGame(u)
                }
            } else {
                pendingPlay = g
                pickRomFile(true)
            }
        } else {
            launchGame(g)
        }
    }

    // ---------- Controle (gamepad) ----------
    private fun modalOpen(): Boolean = overlay !is Overlay.None || appsDrawerOpen || appPickerOpen || appFilterKind != 0 || emuPicker != null || platPicker != null || genrePickerOpen || collPickerOpen || sgdbPicker != null || videoLinkFor != null || romList != null || batch != null || explorer != null || permHelp != null

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        // TV: OK do controle remoto (DPAD_CENTER / ENTER) age como "clicar no item destacado".
        val isOk = TvMode.isTv && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
            code == KeyEvent.KEYCODE_NUMPAD_ENTER)
        // 4.9.0: depois de um OK segurado, o resto do toque (repetições e soltar) não pode vazar para a tela que abriu.
        if (okSwallow && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
                code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A)) {
            if (ev.action == KeyEvent.ACTION_UP) okSwallow = false
            return true
        }
        val ytMedia = ytOpen && (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY ||
            code == KeyEvent.KEYCODE_MEDIA_PAUSE || code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
        // 4.9.0: TV, tela principal: teclas de "página" do controle remoto (avançar/voltar, canal +/-) pulam vários jogos.
        val pageKey = TvMode.isTv && !ytOpen && (code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
            code == KeyEvent.KEYCODE_MEDIA_PREVIOUS || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
            code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN ||
            code == KeyEvent.KEYCODE_PAGE_UP || code == KeyEvent.KEYCODE_PAGE_DOWN)
        if (code !in PAD_KEYS && !isOk && !ytMedia && !pageKey) return super.dispatchKeyEvent(ev)
        val isDirKey = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

        if (modalOpen()) {
            stopHold()
            val inf = overlay
            if (ytOpen && inf is Overlay.Info) {
                // Em TV/controle remoto também vale o "Voltar" (KEYCODE_BACK) quando o player está aberto.
                return ytHandleKey(ev, code)
            }
            if (inf is Overlay.Info && !collPickerOpen) {
                // 4.6.0: o D-pad / OK navegam pelos botões da tela de informações (controle remoto).
                if (isDirKey || isOk) {
                    infoNav = true
                    return super.dispatchKeyEvent(ev)
                }
                if (code == KeyEvent.KEYCODE_BUTTON_A && infoNav) {
                    return super.dispatchKeyEvent(
                        KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                    )
                }
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    when (code) {
                        KeyEvent.KEYCODE_BUTTON_A -> games.firstOrNull { it.id == inf.id }?.let { infoPlay(it) }
                        KeyEvent.KEYCODE_BUTTON_B -> back()
                        KeyEvent.KEYCODE_BUTTON_START -> games.firstOrNull { it.id == inf.id }?.let { overlay = Overlay.Edit(it) }
                    }
                }
                return true
            }
            if (overlay is Overlay.Settings && (code == KeyEvent.KEYCODE_BUTTON_L1 || code == KeyEvent.KEYCODE_BUTTON_R1)) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    settingsTab = if (code == KeyEvent.KEYCODE_BUTTON_R1) (settingsTab + 1) % SETTINGS_TABS else (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS
                }
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) back()
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_A) {
                return super.dispatchKeyEvent(
                    KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                )
            }
            return super.dispatchKeyEvent(ev)
        }

        if (pageKey) {
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                val fwd = code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
                    code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_DOWN
                pageStep(if (fwd) 1 else -1)
            }
            return true
        }

        // 4.9.0: na TV o OK (e o A do gamepad) na tela principal: toque = abrir; segurar (meio segundo) = toque longo.
        if (isOk || (TvMode.isTv && code == KeyEvent.KEYCODE_BUTTON_A)) return okKey(ev)

        if (isDirKey) {
            // A repetição é feita por nós (com aceleração); ignora o auto-repeat do sistema.
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) {
                    heldKeys.remove(code)
                    heldKeys.add(code)
                    updateHold()
                }
            } else if (ev.action == KeyEvent.ACTION_UP) {
                heldKeys.remove(code)
                updateHold()
            }
            return true
        }

        if (ev.action == KeyEvent.ACTION_DOWN) {
            val first = ev.repeatCount == 0
            when (code) {
                KeyEvent.KEYCODE_BUTTON_R1 -> if (first) pageStep(1)
                KeyEvent.KEYCODE_BUTTON_L1 -> if (first) pageStep(-1)
                KeyEvent.KEYCODE_BUTTON_R2 -> if (first) jumpEdge(true)
                KeyEvent.KEYCODE_BUTTON_L2 -> if (first) jumpEdge(false)
                KeyEvent.KEYCODE_BUTTON_A -> if (first) { zoneActivate() }
                KeyEvent.KEYCODE_BUTTON_B -> if (first) back()
                KeyEvent.KEYCODE_BUTTON_X -> if (first) { randomPick() }
                KeyEvent.KEYCODE_BUTTON_Y -> if (first) { overlay = Overlay.Search }
                KeyEvent.KEYCODE_BUTTON_START -> if (first) { editSelected() }
                KeyEvent.KEYCODE_BUTTON_SELECT -> if (first) { overlay = Overlay.Filter }
            }
        }
        return true
    }

    private var okPending = false
    private var okLong = false
    private var okSwallow = false

    /** Toque longo (OK segurado) no item selecionado: jogo = detalhes; plataforma = trocar a imagem dela. */
    private fun longPressSelected() {
        val id = selectedId ?: return
        when {
            id.startsWith(PLAT_PREFIX) -> overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
            id == ADD_ID -> return
            games.any { it.id == id } -> overlay = Overlay.Info(id)
        }
    }

    private fun okKey(ev: KeyEvent): Boolean {
        if (navZone != 0) {
            // Cabeçalho e rodapé: age na hora, como antes.
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) zoneActivate()
            return true
        }
        when (ev.action) {
            KeyEvent.ACTION_DOWN -> {
                if (ev.repeatCount == 0) {
                    okPending = true
                    okLong = false
                } else if (okPending && !okLong && (ev.isLongPress || ev.eventTime - ev.downTime >= OK_LONG_MS)) {
                    okLong = true
                    okSwallow = true
                    longPressSelected()
                }
            }
            KeyEvent.ACTION_UP -> {
                if (okPending && !okLong) {
                    // Alguns controles não repetem a tecla: se ficou apertado o tempo do toque longo, vale como longo.
                    if (ev.eventTime - ev.downTime >= OK_LONG_MS) longPressSelected() else zoneActivate()
                }
                okPending = false
                okLong = false
            }
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoy = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE && ytOpen && overlay is Overlay.Info) {
            // Player aberto: mexer no analógico/D-pad traz os controles de volta (foco no play/pause) ou reinicia os 3 s.
            val strong = abs(ev.getAxisValue(MotionEvent.AXIS_X)) > 0.5f || abs(ev.getAxisValue(MotionEvent.AXIS_Y)) > 0.5f ||
                abs(ev.getAxisValue(MotionEvent.AXIS_HAT_X)) > 0.5f || abs(ev.getAxisValue(MotionEvent.AXIS_HAT_Y)) > 0.5f
            if (strong) {
                if (landscape && !ytCtrl.uiVisible) {
                    ytCtl = YT_PLAY
                    ytNav = true
                }
                ytCtrl.wake()
            }
            return true
        }
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE) {
            if (modalOpen()) {
                stopHold()
                return super.dispatchGenericMotionEvent(ev)
            }
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val sx = ev.getAxisValue(MotionEvent.AXIS_X)
            val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
            val ax = if (abs(hx) > 0.5f) hx else sx
            val ay = if (abs(hy) > 0.5f) hy else sy
            val limit = if (axisDx != 0 || axisDy != 0) STICK_OFF else STICK_ON
            var ndx = 0
            var ndy = 0
            if (abs(ax) > limit || abs(ay) > limit) {
                if (abs(ax) >= abs(ay)) ndx = if (ax > 0) 1 else -1
                else ndy = if (ay > 0) 1 else -1
            }
            axisDx = ndx
            axisDy = ndy
            updateHold()
            handleTriggers(ev)
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        ytCtrl.onHostResume()
        importPendingShortcuts()
        storageOk = hasAllFiles() // volta da tela de permissões do Android
        isHome = LauncherMode.isDefault(this) // volta da tela de escolha do launcher
        startOrientationWatch()
        FloatState.hostVisible = true
        FloatingPanelService.instance?.applyVisibility()
        // Se o painel estava ligado e o sistema encerrou o serviço, religa sozinho.
        if (prefs.getBoolean("floatOn", false) && !FloatState.on && FloatingPanelService.canDraw(this)) {
            FloatingPanelService.start(this)
        }
    }

    // Botão Home com o Nexus como launcher padrão: volta para a tela principal (fecha as janelas abertas).
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) goHome()
    }

    private fun goHome() {
        stopHold()
        overlay = Overlay.None
        appsDrawerOpen = false
        appPickerOpen = false
        appFilterKind = 0
        emuPicker = null
        platPicker = null
        genrePickerOpen = false
        collPickerOpen = false
        sgdbPicker = null
        videoLinkFor = null
        closeVideo()
        romList = null
    }

    // ---------- Modo launcher (4.3.0) ----------
    /** Liga/desliga o painel flutuante de temperatura e bateria (toque no cabeçalho ou em Extras). */
    private fun toggleFloat() {
        if (FloatState.on) {
            FloatingPanelService.stop(this)
            toast("Painel flutuante desligado")
            return
        }
        if (!FloatingPanelService.canDraw(this)) {
            if (!TvMode.isTv) toast("Permita \"Exibir sobre outros apps\" para o Nexus e volte")
            try {
                overlayPermRequest.launch(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
                // Muitas TVs não têm essa tela: mostra como liberar pelo computador (ADB).
                if (TvMode.isTv) permHelp = "overlay" else toast("Não foi possível abrir a permissão de sobreposição")
            }
            return
        }
        askNotifThenStartFloat()
    }

    private fun askNotifThenStartFloat() {
        if (!FloatingPanelService.notificationsAllowed(this) && Build.VERSION.SDK_INT >= 33) {
            try {
                notifPermRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            } catch (_: Exception) {
            }
        }
        startFloat()
    }

    private fun startFloat() {
        prefs.edit().putBoolean("floatOn", true).apply()
        FloatingPanelService.start(this)
        FloatState.on = true
        toast(if (TvMode.isTv) "Painel ligado: a temperatura aparece sobre os outros apps." else "Painel ligado: aparece sobre os outros apps. Arraste para onde quiser.")
    }

    private fun askDefaultLauncher() {
        try {
            homeRequest.launch(LauncherMode.requestIntent(this))
        } catch (_: Exception) {
            openHomeSettings()
        }
    }

    private fun openHomeSettings() {
        try {
            startActivity(LauncherMode.homeSettingsIntent())
        } catch (_: Exception) {
            toast("Não foi possível abrir as configurações de launcher")
        }
    }

    private fun openSystemSettings() {
        try {
            startActivity(LauncherMode.systemSettingsIntent())
        } catch (_: Exception) {
            toast("Não foi possível abrir as configurações do Android")
        }
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(LauncherMode.appInfoIntent(pkg))
        } catch (_: Exception) {
            toast("Não foi possível abrir as informações do app")
        }
    }

    /** Intent de abertura do app. Na TV, apps feitos para Android TV só têm a entrada "leanback". */
    private fun launchIntentFor(pkg: String): Intent? {
        val pm = packageManager
        return if (TvMode.isTv) (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))
        else (pm.getLaunchIntentForPackage(pkg) ?: pm.getLeanbackLaunchIntentForPackage(pkg))
    }

    private fun launchApp(pkg: String) {
        val i = launchIntentFor(pkg)
        if (i == null) {
            toast("Este app não pode ser aberto")
            return
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    private fun applyCarouselOn(v: Boolean) {
        carouselOn = v
        prefs.edit().putBoolean("carouselOn", v).apply()
        // "Padrão" e "Carrossel" são os dois estados desta opção; Grade e Lista não mudam.
        if (tvView <= TV_VIEW_CAROUSEL) {
            tvView = if (v) TV_VIEW_CAROUSEL else TV_VIEW_STD
            prefs.edit().putInt("tvView", tvView).apply()
        }
    }

    /** Escolhe o modo de visualização da TV (olho do cabeçalho). */
    private fun applyTvView(v: Int) {
        tvView = v.coerceIn(0, 3)
        prefs.edit().putInt("tvView", tvView).apply()
        if (tvView == TV_VIEW_STD) applyCarouselOn(false)
        else if (tvView == TV_VIEW_CAROUSEL) applyCarouselOn(true)
    }

    private fun applyFloatSmall(v: Boolean) {
        floatSmall = v
        prefs.edit().putBoolean("floatSmall", v).apply()
        FloatingPanelService.instance?.applySize()
    }

    private fun applyIntroOn(v: Boolean) {
        introOn = v
        prefs.edit().putBoolean("introOn", v).apply()
    }

    override fun onPause() {
        orientListener?.disable()
        FloatState.hostVisible = false
        FloatingPanelService.instance?.applyVisibility()
        stopHold()
        ytCtrl.onHostPause()
        super.onPause()
    }

    // ---------- Apps / lançamento ----------
    private fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = ArrayList<android.content.pm.ResolveInfo>(packageManager.queryIntentActivities(intent, 0))
        if (TvMode.isTv) {
            // Apps de Android TV (emuladores, jogos) podem ter só a entrada "leanback".
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            found.addAll(packageManager.queryIntentActivities(tvIntent, 0))
        }
        return found
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedAlpha { it.label }
    }

    private fun iconFor(pkg: String): ImageBitmap? = iconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    // Ícone em alta resolução (usado como capa dos jogos da plataforma Android).
    /** 4.9.0: só consulta o cache (rápido, pode ser chamado na tela). */
    private fun cachedBigIcon(pkg: String): ImageBitmap? = synchronized(bigIconCache) { bigIconCache[pkg] }

    /** Pode ser chamado em segundo plano (a primeira vez decodifica o ícone do app). */
    private fun bigIconFor(pkg: String): ImageBitmap? {
        synchronized(bigIconCache) { if (bigIconCache.containsKey(pkg)) return bigIconCache[pkg] }
        val v = try {
            packageManager.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (_: Exception) {
            null
        }
        synchronized(bigIconCache) { bigIconCache[pkg] = v }
        return v
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun resolvePkg(g: Game): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    /** 4.7.4: transforma em jogos os atalhos recebidos de outros apps (ver PinShortcut.kt). */
    private fun importPendingShortcuts() {
        val pend = PinShortcuts.take(this)
        if (pend.isEmpty()) return
        var added = 0
        var lastId: String? = null
        for (p in pend) {
            if (games.any { it.pkg == p.pkg && it.shortcutId == p.shortcutId }) continue
            val g = Game(
                id = UUID.randomUUID().toString(), title = p.label, platform = ANDROID_PLATFORM,
                cover = p.iconPath, pkg = p.pkg, shortcutId = p.shortcutId,
                execType = DEFAULT_EXEC[execKey(ANDROID_PLATFORM)] ?: "native"
            )
            games.add(g)
            lastId = g.id
            added++
        }
        if (added > 0) {
            saveLibrary()
            lastId?.let { selectGame(it) }
            toast(if (added == 1) "Atalho adicionado como jogo" else "$added atalhos adicionados como jogos")
        }
    }

    private fun launchShortcutGame(g: Game) {
        val err = PinShortcuts.start(this, g.pkg, g.shortcutId)
        if (err == null) {
            markPlayed(g)
            return
        }
        // Plano B: abre o próprio app do atalho.
        val intent = launchIntentFor(g.pkg)
        if (intent != null) {
            try {
                startActivity(intent)
                markPlayed(g)
                toast("Não deu para abrir o atalho direto (deixe o Nexus como launcher padrão). Abrindo o app.")
                return
            } catch (_: Exception) {
            }
        }
        toast("Não foi possível abrir o atalho: $err")
    }

    private fun launchGame(g: Game) {
        if (g.shortcutId.isNotEmpty()) {
            launchShortcutGame(g)
            return
        }
        if (g.execType == "browser") {
            if (g.webUrl.isBlank()) {
                toast("Este jogo não tem link configurado")
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val custom = g.customCmd.trim()
        if (custom.isNotEmpty()) {
            val b = buildIntent(custom, g) ?: return
            try {
                startActivity(b.intent)
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        if (pkg == null) {
            if (link != null && link.pkg.isNotEmpty()) {
                toast("O emulador ${link.playerName.ifEmpty { link.pkg }} não está instalado")
            } else {
                toast("Defina o app em Editar (segure a capa ou aperte START)")
            }
            return
        }
        val tpl = templateFor(pkg, link)
        try {
            if (tpl != null && !(tpl.contains("{file.") && g.romUri.isEmpty())) {
                val b = buildIntent(tpl, g) ?: return
                if (b.kill) {
                    try {
                        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                    } catch (_: Exception) {
                    }
                }
                startActivity(b.intent)
                markPlayed(g)
                return
            }
            val intent = launchIntentFor(pkg)
            if (intent == null) {
                toast("Não foi possível abrir $pkg")
                return
            }
            startActivity(intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    private fun effectivePkg(g: Game, link: PlatformLink?): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        if (link != null && link.pkg.isNotEmpty() && isInstalled(link.pkg)) return link.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun templateFor(pkg: String, link: PlatformLink?): String? {
        if (link != null && link.pkg == pkg && link.template.isNotBlank()) return link.template
        return TEMPLATES[pkg]
    }

    // ---------- Acesso a todos os arquivos (para pastas de ROMs vindas de backup) ----------
    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: Exception) {
                    if (TvMode.isTv) permHelp = "storage"
                    else toast("Abra Configurações > Apps > Nexus e libere o acesso a todos os arquivos")
                }
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77)
        }
    }

    private fun fileUri(f: File): String =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", f).toString()

    private fun safReadable(uri: String): Boolean = try {
        val pfd = contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) {
            false
        } else {
            pfd.close()
            true
        }
    } catch (_: Exception) {
        false
    }

    // Se o Nexus não tem mais a permissão da pasta (ex.: backup importado), usa o arquivo direto pelo acesso a todos os arquivos.
    private fun effectiveRomUri(uri: String): String {
        if (uri.isEmpty() || !hasAllFiles()) return uri
        val u = Uri.parse(uri)
        if (u.authority != "com.android.externalstorage.documents") return uri
        if (safReadable(uri)) return uri
        val f = File(pathOf(uri))
        if (!f.isFile) return uri
        return try {
            fileUri(f)
        } catch (_: Exception) {
            uri
        }
    }

    private fun treePath(tree: String): String {
        val id = try {
            DocumentsContract.getTreeDocumentId(Uri.parse(tree))
        } catch (_: Exception) {
            ""
        }
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    private fun walkFiles(dir: File, path: String, exts: Set<String>?, out: MutableList<RomEntry>, depth: Int) {
        if (depth > 12 || out.size > 20000) return
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (k.isDirectory) {
                walkFiles(k, "$path${k.name}/", exts, out, depth + 1)
            } else {
                val ext = k.name.substringAfterLast('.', "").lowercase()
                if (exts == null || ext in exts) out.add(RomEntry(k.name, path, fileUri(k)))
            }
        }
    }

    private fun pathOf(uri: String): String {
        if (!uri.startsWith("content://")) return Uri.parse(uri).path ?: uri
        val pu = Uri.parse(uri)
        if (pu.authority == "$packageName.fileprovider") return "/" + (pu.path ?: "").removePrefix("/root/")
        val id = docIdOf(uri)
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    // Converte o comando em um Intent.
    private fun buildIntent(tpl: String, g: Game): BuiltIntent? {
        val uriStr = effectiveRomUri(g.romUri)
        val fileName = if (uriStr.isEmpty()) "" else fileNameOf(uriStr)
        val unsupported = Regex("\\{tags\\.([A-Za-z0-9_]+)\\}").findAll(tpl)
            .map { it.groupValues[1] }.firstOrNull { it != "vita_game_id" }
        if (unsupported != null) {
            toast("Este emulador usa {tags.$unsupported}, que o Nexus ainda não preenche. Use um comando personalizado no jogo.")
            return null
        }
        val idRe = Regex("[A-Z]{4}\\d{5}")
        val vitaId = idRe.find(g.title)?.value ?: idRe.find(fileName)?.value ?: ""
        if (tpl.contains("{tags.vita_game_id}") && vitaId.isEmpty()) {
            toast("Vita3K+ precisa do ID do jogo no título (ex.: PCSA00029)")
            return null
        }
        fun sub(x: String): String = x
            .replace("{file.uri}", uriStr)
            .replace("{file.path}", if (uriStr.isEmpty()) "" else pathOf(uriStr))
            .replace("{file.name}", fileName)
            .replace("{file.mime}", if (uriStr.isEmpty()) "" else mimeOf(fileName))
            .replace("{tags.vita_game_id}", vitaId)

        val t = tpl.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var comp: ComponentName? = null
        var action: String? = null
        var data: String? = null
        var type: String? = null
        val cats = ArrayList<String>()
        val extras = LinkedHashMap<String, String>()
        val arrays = LinkedHashMap<String, List<String>>()
        val typed = ArrayList<Triple<String, Char, String>>()
        var flags = Intent.FLAG_ACTIVITY_NEW_TASK
        var kill = false
        try {
            var i = 0
            while (i < t.size) {
                when (t[i]) {
                    "-n" -> {
                        i++
                        val p = sub(t[i]).split("/")
                        if (p.size == 2) {
                            val cls = if (p[1].startsWith(".")) p[0] + p[1] else p[1]
                            comp = ComponentName(p[0], cls)
                        }
                    }
                    "-a" -> { i++; action = sub(t[i]) }
                    "-c" -> { i++; cats.add(sub(t[i])) }
                    "-d" -> { i++; data = sub(t[i]) }
                    "-t" -> { i++; type = sub(t[i]) }
                    "-e", "--es" -> {
                        i++
                        val k = t[i]
                        i++
                        extras[k] = sub(t[i])
                    }
                    "--esa" -> {
                        i++
                        val k = t[i]
                        i++
                        arrays[k] = sub(t[i]).split(",")
                    }
                    "--ez", "--ei", "--el" -> {
                        val kind = t[i].last()
                        i++
                        val k = t[i]
                        i++
                        typed.add(Triple(k, kind, sub(t[i])))
                    }
                    "-f" -> {
                        i++
                        flags = flags or java.lang.Long.decode(t[i]).toInt()
                    }
                    "--activity-clear-task" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    "--activity-clear-top" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    "--activity-no-history" -> flags = flags or Intent.FLAG_ACTIVITY_NO_HISTORY
                    "--nexus-kill" -> kill = true
                }
                i++
            }
        } catch (_: Exception) {
            toast("Comando de abertura inválido")
            return null
        }
        val intent = Intent()
        val a = action
        if (a != null) intent.action = a
        val c = comp
        if (c != null) intent.component = c
        for (cat in cats) intent.addCategory(cat)
        val d = data
        val ty = type
        if (d != null && ty != null) intent.setDataAndType(Uri.parse(d), ty)
        else if (d != null) intent.data = Uri.parse(d)
        else if (ty != null) intent.type = ty
        for ((k, v) in extras) intent.putExtra(k, v)
        for ((k, v) in arrays) intent.putExtra(k, v.toTypedArray())
        for ((k, kind, v) in typed) {
            when (kind) {
                'z' -> intent.putExtra(k, v.equals("true", ignoreCase = true))
                'i' -> intent.putExtra(k, v.toIntOrNull() ?: 0)
                else -> intent.putExtra(k, v.toLongOrNull() ?: 0L)
            }
        }
        intent.addFlags(flags)
        if (uriStr.startsWith("content://")) {
            intent.clipData = ClipData.newRawUri("rom", Uri.parse(uriStr))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return BuiltIntent(intent, kill)
    }

    private fun mimeOf(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun linkFor(platform: String): PlatformLink? = links.firstOrNull { it.platform == platform }

    /** Lista completa (cadastradas + catálogo) que o seletor mostra, em ordem alfabética. */
    private fun platformPickList(filter: (String) -> Boolean): List<String> {
        val reg = platformNames()
        val extra = EmuCatalog.all(this).map { it.name }.filter { n -> reg.none { it.equals(n, ignoreCase = true) } }
        return (reg + extra).filter(filter).distinctBy { it.lowercase() }.sortedAlpha { it }
    }

    private fun addPlatforms(current: String?): List<String> {
        val base = platformPickList { true }
        return if (current != null && current !in base) base + current else base
    }

    /** Jogos de emulador entram em lote; o que sobra no cadastro manual quase sempre é Android. */
    private fun defaultAddPlatform(): String = ANDROID_PLATFORM

    /** Só as plataformas criadas pelo usuário podem ser editadas ou apagadas. */
    private fun isCustomPlatform(name: String): Boolean =
        name != WEB_PLATFORM && name != ANDROID_PLATFORM &&
            platforms.firstOrNull { it.name == name }?.base?.isEmpty() == true

    private fun brandOfPlatform(n: String): String =
        (platforms.firstOrNull { it.name == n }?.manufacturer
            ?: EmuCatalog.all(this).firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
            ?: "").ifBlank { "Outros" }

    /** Cadastra a plataforma (do catálogo) quando um jogo ou emulador passa a usá-la. */
    private fun registerPlatformIfNeeded(name: String) {
        if (name.isBlank() || platforms.any { it.name == name }) return
        val dp = EmuCatalog.forPlatform(this, name)
        platforms.add(GamePlatform(name, dp?.manufacturer ?: DEFAULT_MANUFACTURER[name] ?: "", name))
        savePrefs()
    }

    private fun foldText(s: String): String =
        java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun docIdOf(uri: String): String = try {
        DocumentsContract.getDocumentId(Uri.parse(uri))
    } catch (_: Exception) {
        Uri.parse(uri).lastPathSegment ?: ""
    }

    private fun fileNameOf(uri: String): String =
        docIdOf(uri).substringAfterLast('/').substringAfterLast(':')

    private fun scanRoms(platform: String): ScanResult {
        val link = linkFor(platform) ?: return ScanResult(emptyList(), 0)
        val exts = link.exts.takeIf { it.isNotEmpty() }?.toSet() ?: ROM_EXT[execKey(platform)]
        val out = ArrayList<RomEntry>()
        var failed = 0
        val granted = contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }.map { it.uri.toString() }
        for (f in link.folders) {
            if (f in granted) {
                try {
                    val tree = Uri.parse(f)
                    walkTree(tree, DocumentsContract.getTreeDocumentId(tree), "", exts, out, 0)
                } catch (_: Exception) {
                    failed++
                }
            } else if (hasAllFiles()) {
                // Sem permissão da pasta (ex.: veio de backup): lê direto pelo acesso a todos os arquivos.
                try {
                    val dir = File(treePath(f))
                    if (dir.isDirectory) walkFiles(dir, "", exts, out, 0) else failed++
                } catch (_: Exception) {
                    failed++
                }
            } else {
                failed++
            }
        }
        return ScanResult(out.distinctBy { it.uri }.sortedAlpha { it.name }, failed)
    }

    private fun walkTree(
        tree: Uri, docId: String, path: String, exts: Set<String>?,
        out: MutableList<RomEntry>, depth: Int
    ) {
        if (depth > 12 || out.size > 20000) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(kids, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walkTree(tree, id, "$path$name/", exts, out, depth + 1)
                } else {
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (exts == null || ext in exts) {
                        out.add(RomEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()))
                    }
                }
            }
        }
    }

    private fun folderLabel(s: String): String = try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(s))
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        (if (vol.equals("primary", true)) "Interno" else vol) + "/" + rel
    } catch (_: Exception) {
        s
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    private fun openSteamGrid(title: String) {
        if (title.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        val url = "https://www.steamgriddb.com/search/grids?term=" + URLEncoder.encode(title.trim(), "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    private fun cleanTitle(file: String, keepId: Boolean): String {
        var s = file.substringBeforeLast('.', file)
        s = s.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
        if (!keepId) s = s.replace(Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$"), "")
        return s.trim()
    }

    // ---------- Cadastro em lote (varredura automática) ----------
    private fun execBase(platform: String): String = platforms.firstOrNull { it.name == platform }?.base ?: ""

    /** Extensões do emulador escolhido; sem elas, a tabela embutida da plataforma. */
    private fun batchExts(platform: String, linkExts: List<String>): List<String> =
        if (linkExts.isNotEmpty()) linkExts
        else (ROM_EXT[execKey(platform)]?.toList()
            ?: if (isCustomPlatform(platform)) ScanEngine.GENERIC_EXTS.toList() else emptyList())

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("notifAsked", false)
        ) {
            prefs.edit().putBoolean("notifAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 78)
        }
    }

    private fun closeBatch() {
        batch?.cancelled = true
        batch = null
        ScanService.stop(this)
    }

    private fun regionLabel(r: String): String = when (r) {
        "Brazil" -> "Brasil"
        "PT-BR" -> "PT-BR (tradução)"
        "World" -> "Mundo"
        "Japan" -> "Japão"
        "Europe" -> "Europa"
        else -> r
    }

    private fun regionText(c: ScanCandidate): String =
        if (c.regions.isEmpty()) "Sem região" else c.regions.joinToString(" + ") { regionLabel(it) }

    private fun startBatchScan(platform: String) {
        val link = linkFor(platform) ?: return
        val profile = ScanEngine.profileFor(platform, execBase(platform), batchExts(platform, link.exts))
        if (profile == null) {
            toast("Escolha um emulador para $platform")
            return
        }
        val s = BatchSession(platform, profile)
        batch = s
        askNotifications()
        ScanService.start(this)
        mainScope.launch {
            val raw = withContext(Dispatchers.IO) { collectRaw(link, s) }
            if (batch !== s || s.cancelled) return@launch
            val outcome = withContext(Dispatchers.Default) { ScanEngine.process(raw, profile) }
            if (batch !== s || s.cancelled) return@launch
            finishScan(s, raw, outcome)
        }
    }

    private fun collectRaw(link: PlatformLink, s: BatchSession): List<RawEntry> {
        val out = ArrayList<RawEntry>()
        var failed = 0
        val granted = contentResolver.persistedUriPermissions.filter { it.isReadPermission }.map { it.uri.toString() }
        val cancelled = { s.cancelled }
        val onFound: (Int) -> Unit = { n ->
            s.found = n
            ScanNotify.progress(this, s.platform, n)
        }
        for (f in link.folders) {
            if (s.cancelled) break
            val inSaf = f in granted
            if (hasAllFiles()) {
                // Caminho rápido: lê direto pelo sistema de arquivos. Os endereços seguem o mesmo formato do cadastro manual.
                try {
                    val root = File(treePath(f))
                    if (root.isDirectory) {
                        ScanEngine.walkFiles(
                            root, s.profile, out,
                            uriOf = { file -> if (inSaf) safUri(f, file) else fileUri(file) },
                            cancelled = cancelled, onFound = onFound
                        )
                    } else failed++
                } catch (_: Exception) {
                    failed++
                }
            } else if (inSaf) {
                try {
                    val tree = Uri.parse(f)
                    walkTreeRaw(tree, DocumentsContract.getTreeDocumentId(tree), "", s.profile, out, 0, cancelled, onFound)
                } catch (_: Exception) {
                    failed++
                }
            } else {
                failed++
            }
        }
        s.failedFolders = failed
        return out.distinctBy { it.uri }
    }

    /** Endereço SAF (o mesmo que a lista de ROMs gera) de um arquivo dentro de uma pasta já autorizada. */
    private fun safUri(tree: String, file: File): String {
        val tu = Uri.parse(tree)
        val treeId = DocumentsContract.getTreeDocumentId(tu)
        val rel = file.path.removePrefix(treePath(tree)).trim('/')
        val docId = when {
            rel.isEmpty() -> treeId
            treeId.endsWith(":") || treeId.endsWith("/") -> treeId + rel
            else -> "$treeId/$rel"
        }
        return DocumentsContract.buildDocumentUriUsingTree(tu, docId).toString()
    }

    private fun walkTreeRaw(
        tree: Uri, docId: String, path: String, p: ScanProfile, out: MutableList<RawEntry>,
        depth: Int, cancelled: () -> Boolean, onFound: (Int) -> Unit
    ) {
        if (depth > 12 || out.size > 60000 || cancelled()) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(kids, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (cancelled()) return
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val isDir = (c.getString(2) ?: "") == DocumentsContract.Document.MIME_TYPE_DIR
                if (ScanEngine.wanted(p, name, isDir)) {
                    out.add(RawEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString(), isDir))
                    onFound(out.size)
                } else if (isDir && ScanEngine.shouldDescend(p, name, depth)) {
                    walkTreeRaw(tree, id, "$path$name/", p, out, depth + 1, cancelled, onFound)
                }
            }
        }
    }

    private fun finishScan(s: BatchSession, raw: List<RawEntry>, outcome: ScanOutcome) {
        val platform = s.platform
        // Jogos que já estão no catálogo (mesmo arquivo): não entram de novo.
        val existing = games.filter { it.platform == platform && it.romUri.isNotEmpty() }.map { pathOf(it.romUri) }.toSet()
        val fresh = outcome.candidates.filter { pathOf(it.uri) !in existing }
        s.alreadyCount = outcome.candidates.size - fresh.size
        s.all = fresh
        s.ignored = outcome.ignored.filter { pathOf(it.candidate.uri) !in existing }

        // Arquivos ausentes: jogos em lote cujo arquivo não foi achado ficam marcados (nunca são removidos).
        if (s.failedFolders == 0) {
            val scanned = raw.map { pathOf(it.uri) }.toSet()
            var changed = false
            for (i in games.indices) {
                val g = games[i]
                if (g.platform == platform && g.isAuto && g.romUri.isNotEmpty()) {
                    val miss = pathOf(g.romUri) !in scanned
                    if (miss != g.missing) {
                        games[i] = g.copy(missing = miss)
                        changed = true
                    }
                }
            }
            if (changed) saveLibrary()
        }

        val text = "${fresh.size} jogo(s) encontrado(s) em $platform"
        val inBackground = !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
        ScanService.stop(this)
        if (inBackground) ScanNotify.done(this, text)

        if (fresh.isEmpty() && s.ignored.isEmpty()) {
            batch = null
            toast(
                if (s.failedFolders > 0) "Não consegui ler as pastas. Vincule-as de novo e libere o acesso."
                else if (s.alreadyCount > 0) "Nenhum jogo novo: os ${s.alreadyCount} jogo(s) encontrados já estão no catálogo."
                else "Nenhum jogo encontrado nessas pastas para ${platform}."
            )
            return
        }
        val groups = ScanEngine.dupGroups(fresh)
        s.dupGroups = groups.size
        if (groups.isNotEmpty()) {
            s.phase = BatchPhase.REGIONS
        } else {
            buildBatchItems(s, ScanEngine.regionPriority("USA"))
        }
    }

    private fun buildBatchItems(s: BatchSession, priority: List<String>) {
        val chosen = ScanEngine.resolveRegions(s.all, priority)
        val byKey = s.all.groupBy { it.key }
        s.items.clear()
        s.items.addAll(chosen.map { BatchItem(it.key, byKey[it.key] ?: listOf(it), it) }.sortedAlpha { it.cand.title })
        s.ignoredItems.clear()
        s.ignoredItems.addAll(s.ignored.sortedAlpha { it.name }.map { BatchIgnored(it) })
        s.phase = BatchPhase.LIST
    }

    private fun confirmBatch(s: BatchSession) {
        val platform = s.platform
        val exec = DEFAULT_EXEC[execKey(platform)] ?: "native"
        val chosen = ArrayList<ScanCandidate>()
        for (bi in s.items) if (bi.checked) chosen.add(bi.cand)
        for (ig in s.ignoredItems) if (ig.checked) chosen.add(ig.item.candidate)
        val added = chosen.distinctBy { it.uri }.map { c ->
            Game(
                id = UUID.randomUUID().toString(), title = c.title, platform = platform,
                execType = exec, romUri = c.uri, source = SOURCE_AUTO,
                romFileName = c.fileName, region = c.region
            )
        }
        batch = null
        if (added.isEmpty()) return
        games.addAll(added)
        saveLibrary()
        prefetchCovers()
        toast("${added.size} jogo(s) adicionados em $platform")
    }

    /** Tela de informações: troca o arquivo em que um jogo em lote se baseia. */
    private fun changeRomFile(g: Game) {
        val onRom: (String, String) -> Unit = { uriStr, name ->
            games.firstOrNull { it.id == g.id }?.let { cur ->
                replaceGame(cur.copy(romUri = uriStr, romFileName = name, missing = false))
                toast("Arquivo trocado: $name")
            }
        }
        val link = linkFor(g.platform)
        if (link != null && link.folders.isNotEmpty()) {
            romList = RomListRequest(g.platform, onRom)
        } else {
            dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
            pickRomFile(false)
        }
    }

    @Composable
    private fun AddChoiceDialog(first: Boolean) {
        val accent = parseColor(accentHex)
        NexusModal(if (first) "Bem-vindo ao Nexus" else "Adicionar jogos", { overlay = Overlay.None }) {
            Text(
                if (first) "Vamos cadastrar seu primeiro jogo no catálogo. Como você quer adicionar?"
                else "Como você quer adicionar?",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            ActionRow(
                "✍", "Manualmente", "Um jogo por vez. Entra no catálogo só o que você escolher.",
                bg = S_CARD, border = S_LINE, iconBg = S_FIELD, iconFg = Color.White
            ) { overlay = Overlay.Edit(null) }
            Spacer(Modifier.height(8.dp))
            ActionRow(
                "📦", "Em lote", "Escolha a plataforma e as pastas; o Nexus encontra os jogos de uma vez.",
                bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f), iconBg = accent, iconFg = onAccent(accent)
            ) { overlay = Overlay.BatchSetup }
            if (first) {
                Spacer(Modifier.height(10.dp))
                CButton("Pular por agora", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
            }
        }
    }

    @Composable
    private fun BatchHost(s: BatchSession) {
        when (s.phase) {
            BatchPhase.SCANNING -> BatchProgressDialog(s)
            BatchPhase.REGIONS -> BatchRegionDialog(s)
            BatchPhase.LIST -> BatchListDialog(s)
        }
    }

    @Composable
    private fun BatchProgressDialog(s: BatchSession) {
        NexusModal("Varrendo pastas", { moveTaskToBack(true) }) {
            Text(s.platform, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("${s.found} arquivo(s) encontrado(s)", color = C_MUTED, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(), color = parseColor(accentHex)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Pode minimizar o Nexus. Avisamos por notificação quando terminar.",
                color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) {
                    closeBatch()
                    toast("Varredura cancelada")
                }
                CButton("Minimizar", C_BLUE, Modifier.weight(1f)) { moveTaskToBack(true) }
            }
        }
    }

    @Composable
    private fun BatchRegionDialog(s: BatchSession) {
        NexusModal("Jogos em mais de uma região", { closeBatch() }) {
            Text(
                "Encontramos ${s.dupGroups} jogo(s) com versões de regiões diferentes. " +
                    "Qual região você prefere? Se um jogo não tiver essa região, o Nexus usa a mais próxima. " +
                    "Na lista seguinte você pode trocar a versão de cada jogo.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            ScanEngine.REGION_CHOICES.forEach { r ->
                CButton(
                    if (r == "Brazil") "Brasil (traduções PT-BR primeiro)" else regionLabel(r),
                    if (r == "Brazil") C_BLUE else C_GRAY, Modifier.fillMaxWidth()
                ) { buildBatchItems(s, ScanEngine.regionPriority(r)) }
                Spacer(Modifier.height(6.dp))
            }
            Spacer(Modifier.height(4.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { closeBatch() }
        }
    }

    @Composable
    private fun BatchListDialog(s: BatchSession) {
        val accent = parseColor(accentHex)
        val k = s.query.trim().lowercase()
        val shown = if (k.isEmpty()) s.items.toList()
        else s.items.filter { it.cand.title.lowercase().contains(k) || it.cand.fileName.lowercase().contains(k) }
        val ign = if (k.isEmpty()) s.ignoredItems.toList()
        else s.ignoredItems.filter { it.item.name.lowercase().contains(k) }
        val marked = s.items.count { it.checked }
        val total = marked + s.ignoredItems.count { it.checked }
        val addLabel = if (total == 0) "Nada marcado" else "Adicionar $total"
        val onAdd = { if (total > 0) confirmBatch(s) else toast("Marque ao menos um jogo") }
        val counter = "$marked de ${s.items.size} marcados" + (if (s.alreadyCount > 0) " · ${s.alreadyCount} já no catálogo" else "")
        val controls: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            CField(s.query, { s.query = it }, "🔍 Buscar", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            if (landscape) {
                Text(counter, color = C_MUTED, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EBtn("Todos", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f)) { shown.forEach { it.checked = true } }
                    EBtn("Nenhum", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f)) { shown.forEach { it.checked = false } }
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(counter, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    EBtn("Todos", null, S_FIELD, S_LINE, Color(0xFFE2E8F0)) { shown.forEach { it.checked = true } }
                    Spacer(Modifier.width(6.dp))
                    EBtn("Nenhum", null, S_FIELD, S_LINE, Color(0xFFE2E8F0)) { shown.forEach { it.checked = false } }
                }
            }
            if (s.failedFolders > 0) {
                Text("⚠ ${s.failedFolders} pasta(s) sem acesso.", color = C_ORANGE, fontSize = 10.sp)
            }
        }
        val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Spacer(Modifier.height(4.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(shown, key = { "g" + it.key }) { bi -> BatchRow(bi, accent) }
                if (ign.isNotEmpty()) {
                    item(key = "ign-header") {
                        Row(
                            modifier = Modifier.fillMaxWidth().cardRow { s.showIgnored = !s.showIgnored },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Ignorados (${ign.size}): BIOS, updates, DLC, Beta e outros",
                                color = C_MUTED, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(if (s.showIgnored) "▴" else "▾", color = C_MUTED, fontSize = 14.sp)
                        }
                    }
                    if (s.showIgnored) {
                        items(ign, key = { "i" + it.item.candidate.uri }) { ig -> BatchIgnoredRow(ig, accent) }
                    }
                }
            }
        }
        if (landscape) {
            NexusModal(
                "Adicionar: ${s.platform}", { closeBatch() }, tall = true,
                leftPane = {
                    controls()
                    Spacer(Modifier.height(14.dp))
                    EBtn(addLabel, "✓", accent, accent, onAccent(accent), Modifier.fillMaxWidth(), tall = true) { onAdd() }
                    Spacer(Modifier.height(8.dp))
                    EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.fillMaxWidth(), tall = true) { closeBatch() }
                }
            ) { listUi() }
        } else {
            NexusModal(
                "Adicionar: ${s.platform}", { closeBatch() }, tall = true,
                footer = {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) { closeBatch() }
                        EBtn(addLabel, "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) { onAdd() }
                    }
                }
            ) {
                controls()
                listUi()
            }
        }
    }

    @Composable
    private fun BatchRow(bi: BatchItem, accent: Color) {
        Row(
            modifier = Modifier.fillMaxWidth().cardRow { bi.checked = !bi.checked },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(if (bi.checked) "☑" else "☐", color = if (bi.checked) accent else C_MUTED, fontSize = 18.sp)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(bi.cand.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(bi.cand.fileName, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (bi.variants.size > 1) {
                Spacer(Modifier.width(6.dp))
                VariantPicker(bi)
            }
        }
    }

    @Composable
    private fun VariantPicker(bi: BatchItem) {
        var open by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(rBtn.dp)
        Box {
            Box(
                modifier = Modifier
                    .clip(shape)
                    .background(S_FIELD)
                    .border(1.dp, S_LINE, shape)
                    .clickable { open = true }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(regionText(bi.cand) + " ▾", color = Color.White, fontSize = 11.sp, maxLines = 1)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(S_CARD)) {
                bi.variants.forEach { v ->
                    DropdownMenuItem(modifier = Modifier.focusRing(), 
                        text = {
                            Column {
                                Text(regionText(v), color = Color.White, fontSize = 14.sp)
                                Text(v.fileName, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        },
                        onClick = {
                            bi.cand = v
                            open = false
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun BatchIgnoredRow(ig: BatchIgnored, accent: Color) {
        Row(
            modifier = Modifier.fillMaxWidth().cardRow { ig.checked = !ig.checked },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(if (ig.checked) "☑" else "☐", color = if (ig.checked) accent else C_MUTED, fontSize = 18.sp)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(ig.item.name, color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(ig.item.reason, color = C_ORANGE, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }

    // ---------- Backup ----------
    private fun writeBackup(uri: Uri) {
        try {
            val o = JSONObject(LibraryStore.toJson(games.toList()))
            o.put("platforms", PlatformStore.toJsonArray(platforms.toList()))
            o.put("genresList", JSONArray(genres.toList()))
            o.put("platformLinks", LinkStore.toJsonArray(links.toList()))
            o.put(
                "visualPrefs",
                JSONObject().put("widthP", widthP).put("widthL", widthL)
                    .put("radius", "${radius}px").put("color", accentHex)
            )
            o.put("cutoutPad", cutoutPad)
            o.put("dashboardMode", dashMode)
            o.put("collectionsList", JSONArray(collections.toList()))
            o.put("extras", JSONObject().put("carousel", carouselOn).put("tvView", tvView).put("intro", introOn).put("floatSmall", floatSmall))
            o.put("backupFormat", 3)
            contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray(Charsets.UTF_8)) }
            toast("Backup salvo")
        } catch (e: Exception) {
            toast("Erro ao exportar: ${e.message}")
        }
    }

    private fun readBackup(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            if (raw.isNullOrBlank()) {
                toast("Arquivo de backup vazio")
                return
            }
            val text = raw.removePrefix("\uFEFF")
            val o = JSONObject(text)
            if (!o.has("games")) {
                toast("Este arquivo não parece um backup do Nexus")
                return
            }
            // Lê tudo ANTES de mexer no estado: se algo falhar, nada é alterado.
            val list = LibraryStore.parse(text)
            val newGenres = o.optJSONArray("genresList")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
            } ?: emptyList()
            val newLinks = o.optJSONArray("platformLinks")?.let { LinkStore.parse(it.toString()) }
            val newPlatforms = o.optJSONArray("platforms")?.let { PlatformStore.parse(it.toString()) }

            games.clear()
            games.addAll(list)
            saveLibrary()

            if (newGenres.isNotEmpty()) {
                genres.clear()
                genres.addAll(newGenres)
            }
            o.optJSONObject("visualPrefs")?.let { v ->
                widthP = v.optInt("widthP", widthP)
                widthL = v.optInt("widthL", widthL)
                val r = v.optString("radius", "").filter { it.isDigit() }
                if (r.isNotEmpty()) radius = canonicalRadius(r.toInt())
                val c = v.optString("color", "")
                if (c.startsWith("#")) {
                    try {
                        android.graphics.Color.parseColor(c)
                        accentHex = normalizeAccent(c)
                    } catch (_: Exception) {
                    }
                }
            }
            if (o.has("cutoutPad")) cutoutPad = o.optBoolean("cutoutPad", cutoutPad)
            if (o.has("dashboardMode")) dashMode = if (o.optInt("dashboardMode", 0) == 1) 1 else 0
            dashPlatform = ""
            collections.clear()
            o.optJSONArray("collectionsList")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val n = arr.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            }
            for (g in list) for (c in g.collections) if (c !in collections) collections.add(c)
            ensureFixedCollections()
            o.optJSONObject("extras")?.let { ex ->
                applyCarouselOn(ex.optBoolean("carousel", carouselOn))
                if (ex.has("tvView")) {
                    tvView = ex.optInt("tvView", tvView).coerceIn(0, 3)
                    prefs.edit().putInt("tvView", tvView).apply()
                }
                applyIntroOn(ex.optBoolean("intro", introOn))
                applyFloatSmall(ex.optBoolean("floatSmall", floatSmall))
            }
            if (newLinks != null) {
                links.clear()
                links.addAll(newLinks)
            }
            if (!newPlatforms.isNullOrEmpty()) {
                platforms.clear()
                platforms.addAll(newPlatforms)
            }
            syncPlatforms()
            savePrefs()
            resetFilters()
            prefetchCovers()
            selectedId = firstNavId()
            if (!storageOk && links.any { it.folders.isNotEmpty() }) overlay = Overlay.StoragePrompt
            toast("Backup importado: ${list.size} jogos")
        } catch (e: Exception) {
            toast("Erro ao importar: ${e.message}")
        }
    }

    // ---------- Tela principal ----------
    @Composable
    private fun NexusScreen() {
        val ctx = LocalContext.current
        val list = visibleGames()
        val accent = parseColor(accentHex)
        val recents = recentIds()
        val inPlat = inPlatformList()
        val platCards = if (inPlat) platformCards() else emptyList()
        val ids = if (inPlat) platCards.map { PLAT_PREFIX + it.name } else list.map { it.id } + ADD_ID
        BackHandler(enabled = dashMode == 1 && dashPlatform.isNotEmpty() && overlay is Overlay.None) { exitPlatform() }
        // Como launcher padrão, o Nexus é a tela inicial: "Voltar" na tela principal não deve fechá-lo.
        BackHandler(enabled = isHome && !modalOpen() && !(dashMode == 1 && dashPlatform.isNotEmpty())) { }
        // TV (controle remoto): "Voltar" sai do cabeçalho/rodapé e fecha a tela de informações em vez de fechar o app.
        BackHandler(enabled = TvMode.isTv && (navZone != 0 || overlay is Overlay.Info)) { back() }
        // 4.7.0: com o vídeo aberto, "Voltar" sai da tela cheia / fecha o player (celular e TV).
        BackHandler(enabled = ytOpen || videoLinkFor != null) { back() }
        LaunchedEffect(selectedId, tvView) { navZone = 0 }
        val gridState = rememberLazyGridState()
        val rowState = rememberLazyListState()
        val listState = rememberLazyListState()   // TV, modo Lista (vertical)
        val dens = LocalDensity.current
        var rowW by remember { mutableStateOf(0) }
        val userDrag = remember { booleanArrayOf(false) }
        LaunchedEffect(rowState) {
            rowState.interactionSource.interactions.collect { if (it is DragInteraction.Start) userDrag[0] = true }
        }
        // Carrossel: ao terminar de arrastar, a capa que parou no centro vira a selecionada.
        LaunchedEffect(rowState, carouselOn) {
            snapshotFlow { rowState.isScrollInProgress }.collect { moving ->
                if (!moving && userDrag[0]) {
                    userDrag[0] = false
                    if (carouselOn) {
                        val info = rowState.layoutInfo
                        val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                        val c = info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2f - mid) }
                        (c?.key as? String)?.let { k -> if (k != selectedId) selectedId = k }
                    }
                }
            }
        }

        DisposableEffect(Unit) {
            val monitor = PowerMonitor(ctx) { power = it }
            monitor.start()
            onDispose { monitor.stop() }
        }

        val cols by remember {
            derivedStateOf {
                val v = gridState.layoutInfo.visibleItemsInfo
                if (v.isEmpty()) 2 else max(1, v.count { it.offset.y == v.first().offset.y })
            }
        }
        SideEffect { gridColumns = cols }

        var lastView by remember { mutableStateOf(tvView) }
        LaunchedEffect(selectedId, landscape, tvView) {
            val idx = ids.indexOf(selectedId)
            if (idx < 0) return@LaunchedEffect
            val viewChanged = lastView != tvView
            lastView = tvView
            if (tvListOn) {
                // Lista: a capa selecionada fica no meio da tela quando precisa rolar.
                val info = listState.layoutInfo
                val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                val ok = !viewChanged && item != null && item.offset >= info.viewportStartOffset &&
                    item.offset + item.size <= info.viewportEndOffset
                if (!ok) {
                    val vh = info.viewportEndOffset - info.viewportStartOffset
                    val h = with(dens) { LIST_ROW_H_DP.dp.toPx() }
                    val off = -(((vh - h) / 2f).toInt()).coerceAtLeast(0)
                    if (viewChanged) listState.scrollToItem(idx, off) else listState.animateScrollToItem(idx, off)
                }
            } else if (rowNav) {
                val info = rowState.layoutInfo
                val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                val ok = if (carouselOn) {
                    item != null && abs(item.offset + item.size / 2f -
                        (info.viewportStartOffset + info.viewportEndOffset) / 2f) < 2f
                } else item != null && item.offset >= 0 && item.offset + item.size <= info.viewportEndOffset
                if (!ok) rowState.animateScrollToItem(idx)
            } else {
                val info = gridState.layoutInfo
                val item = info.visibleItemsInfo.firstOrNull { x -> x.index == idx }
                val ok = !viewChanged && item != null && item.offset.y >= 0 &&
                    item.offset.y + item.size.height <= info.viewportEndOffset
                if (!ok) {
                    if (viewChanged) gridState.scrollToItem(idx) else gridState.animateScrollToItem(idx)
                }
            }
        }

        val blurR by animateDpAsState(if (overlay is Overlay.Info) 14.dp else 0.dp, label = "infoBlur")
        val title = when (val s = selectedId) {
            null -> ""
            ADD_ID -> "Adicionar Novo Jogo"
            else -> if (s.startsWith(PLAT_PREFIX)) s.removePrefix(PLAT_PREFIX) else (games.firstOrNull { it.id == s }?.title ?: "")
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0C10))
                .drawBehind {
                    drawRect(
                        Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.12f), Color.Transparent),
                            center = Offset(size.width * 0.32f, size.height * 0.52f),
                            radius = size.width * 0.52f
                        )
                    )
                }
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                .then(if (blurR > 0.dp) Modifier.blur(blurR) else Modifier)
                // Com a tela de informações aberta por cima, o D-pad não pode "vazar" para as capas de trás.
                .focusProperties { canFocus = overlay !is Overlay.Info }
        ) {
            // 4.6.1: o cabeçalho é desenhado por cima das capas (e do brilho delas); o rodapé continua por cima também.
            Box(Modifier.zIndex(1f)) { Header(title) }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (tvListOn) {
                    // TV, modo Lista: cartões com capa e informações; rola para cima e para baixo.
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = LIST_TOP_PAD_DP.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (inPlat) {
                            items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                                PlatformListRow(p, selectedId == PLAT_PREFIX + p.name, accent,
                                    if (platCards.firstOrNull()?.name == p.name) LIST_TOP_PAD_DP else -1f)
                            }
                        } else {
                            items(list, key = { it.id }) { g ->
                                GameListRow(g, selectedId == g.id, g.id in recents, accent,
                                    if (list.firstOrNull()?.id == g.id) LIST_TOP_PAD_DP else -1f)
                            }
                            item(key = ADD_ID) {
                                AddListRow(selectedId == ADD_ID, accent, if (list.isEmpty()) LIST_TOP_PAD_DP else -1f)
                            }
                        }
                    }
                } else if (rowNav) {
                    val car = carouselOn
                    val sidePad = if (car) with(LocalDensity.current) { max(18f, (rowW - widthL.dp.toPx()) / 2f / density).dp } else 18.dp
                    LazyRow(
                        state = rowState,
                        modifier = Modifier.fillMaxSize().onSizeChanged { rowW = it.width },
                        flingBehavior = if (car) rememberSnapFlingBehavior(rowState, SnapPosition.Center)
                            else androidx.compose.foundation.gestures.ScrollableDefaults.flingBehavior(),
                        verticalAlignment = Alignment.CenterVertically,
                        contentPadding = PaddingValues(horizontal = sidePad, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(if (car) ((if (TvMode.light) -0.06f else -0.16f) * widthL).dp else 16.dp)
                    ) {
                        if (inPlat) {
                            items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                                PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent,
                                    Modifier.width(widthL.dp).carouselFx(rowState, PLAT_PREFIX + p.name, car))
                            }
                        } else {
                            items(list, key = { it.id }) { g ->
                                GameCard(g, selectedId == g.id, g.id in recents, accent,
                                    Modifier.width(widthL.dp).carouselFx(rowState, g.id, car))
                            }
                            item(key = ADD_ID) {
                                AddTile(selectedId == ADD_ID, accent, Modifier.width(widthL.dp).carouselFx(rowState, ADD_ID, car))
                            }
                        }
                    }
                } else {
                    // Grade: celular em pé (3 por linha) ou TV (quantas couberem; o tamanho segue o da capa da horizontal).
                    val tvg = tvGridOn
                    // Primeira linha: o brilho encolhe para não ser cortado pela borda de cima da grade.
                    val firstRowIds = list.take(cols).map { it.id }.toSet()
                    val firstRowPlats = platCards.take(cols).map { PLAT_PREFIX + it.name }.toSet()
                    LazyVerticalGrid(
                        state = gridState,
                        // Celular: jogos 3 por linha, plataformas 2 por linha.
                        columns = if (tvg) GridCells.Adaptive(((if (inPlat) widthL * 0.95f else widthL * 0.6f).coerceAtLeast(90f)).dp)
                            else if (inPlat) GridCells.Fixed(2) else GridCells.Fixed(3),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = if (tvg) 18.dp else 8.dp, vertical = LIST_TOP_PAD_DP.dp),
                        horizontalArrangement = Arrangement.spacedBy(if (tvg) 16.dp else 14.dp),
                        verticalArrangement = Arrangement.spacedBy(if (tvg) 16.dp else 14.dp)
                    ) {
                        if (inPlat) {
                            items(platCards, key = { PLAT_PREFIX + it.name }) { p ->
                                PlatformCard(p, selectedId == PLAT_PREFIX + p.name, accent, Modifier.fillMaxWidth(),
                                    if ((PLAT_PREFIX + p.name) in firstRowPlats) LIST_TOP_PAD_DP else -1f)
                            }
                        } else {
                            items(list, key = { it.id }) { g ->
                                GameCard(g, selectedId == g.id, g.id in recents, accent, Modifier.fillMaxWidth(),
                                    if (g.id in firstRowIds) LIST_TOP_PAD_DP else -1f, grid = true)
                            }
                            item(key = ADD_ID) {
                                AddTile(selectedId == ADD_ID, accent, Modifier.fillMaxWidth(),
                                    if (list.size < cols) LIST_TOP_PAD_DP else -1f)
                            }
                        }
                    }
                }
            }

            BottomBar(inPlat)
        }

        when (val o = overlay) {
            Overlay.None -> {}
            is Overlay.Edit -> GameDialog(o.game)
            Overlay.Filter -> FilterDialog()
            Overlay.Settings -> SettingsDialog()
            Overlay.Genres -> GenresDialog()
            Overlay.Platforms -> PlatformsDialog()
            Overlay.CoverBatchSetup -> CoverBatchDialog()
            is Overlay.LinkEdit -> LinkEditDialog(o.link)
            Overlay.Search -> SearchDialog()
            Overlay.ResetGames -> ResetGamesDialog()
            Overlay.ConfirmFactory -> ConfirmFactoryDialog()
            is Overlay.ConfirmDelete -> ConfirmDeleteDialog(o.game)
            is Overlay.Info -> InfoOverlay(o.id)
            is Overlay.PlatformImage -> PlatformImageDialog(o.name)
            Overlay.Collections -> CollectionsDialog()
            is Overlay.ConfirmDeleteCollection -> ConfirmDeleteCollectionDialog(o.name)
            Overlay.StoragePrompt -> StoragePromptDialog()
            is Overlay.AddChoice -> AddChoiceDialog(o.first)
            Overlay.BatchSetup -> LinkEditDialog(null, batch = true)
            Overlay.ViewMode -> ViewModeDialog()
        }
        batch?.let { BatchHost(it) }
        if (appPickerOpen) AppPickerDialog()
        if (appFilterKind != 0) AppFilterDialog(appFilterKind)
        if (appsDrawerOpen) AppsDrawerDialog()
        emuPicker?.let { EmuPickerDialog(it) }
        platPicker?.let { PlatformPickerDialog(it) }
        if (collPickerOpen) CollectionPickerDialog()
        if (genrePickerOpen) GenrePickerDialog()
        sgdbPicker?.let { SgdbPickerDialog(it) }
        videoLinkFor?.let { VideoLinkDialog(it) }
        val rl = romList
        if (rl != null) RomListDialog(rl)
        explorer?.let { ex ->
            FileExplorerDialog(
                ex, parseColor(accentHex), rBtn, rCard, rPanel,
                hasAccess = { hasAllFiles() }, askAccess = { askStorage() }, onClose = { explorer = null }
            )
        }
        permHelp?.let { k -> PermHelpDialog(k, packageName, parseColor(accentHex), rBtn, rPanel) { permHelp = null } }
    }

    // ---------- Tela de informações do jogo ----------
    @Composable
    private fun InfoOverlay(id: String) {
        val g = games.firstOrNull { it.id == id }
        if (g == null) {
            SideEffect { overlay = Overlay.None }
            return
        }
        LaunchedEffect(id, sgdbKey) { fetchSgdb(g) }
        // 4.7.0: o vídeo é buscado só na 1ª vez que os detalhes abrem (e fica salvo no jogo).
        LaunchedEffect(id, ytKey) { ensureVideo(g) }
        LaunchedEffect(id) { infoNav = false }
        LaunchedEffect(landscape) { if (!landscape) ytFull = false }
        DisposableEffect(id) { onDispose { closeVideo() } }
        val info = sgdbCache[id]
        val extra = if (info != null && info.found) GameInfoData(released = fmtReleased(info.released)) else GameInfoData()
        val vState = when {
            g.videoId.isNotEmpty() -> VideoBtn.Ready
            ytKey.isBlank() -> VideoBtn.NoKey
            id in ytBusy || (g.videoTried == 0L && id !in ytErr) -> VideoBtn.Searching
            else -> VideoBtn.Retry
        }
        val dens = LocalDensity.current
        var rootPos by remember { mutableStateOf(Offset.Zero) }
        Box(Modifier.fillMaxSize().onGloballyPositioned { rootPos = it.positionInRoot() }) {
            GameInfoScreen(
                game = g,
                extra = extra,
                landscape = landscape,
                accent = parseColor(accentHex),
                cornerDp = rCard,
                panelDp = rPanel,
                btnDp = rBtn,
                video = vState,
                videoOpen = ytOpen,
                cover = { m -> InfoCover(g, m) },
                onVideo = { onVideoClick(g) },
                onRegion = { ytRegion = it },
                onPlay = { infoPlay(g) },
                onOptions = { overlay = Overlay.Edit(g) },
                onChangeFile = { changeRomFile(g) },
                onBack = { overlay = Overlay.None },
                onToggleFav = {
                    val nowFav = !g.isFavorite
                    replaceGame(g.copy(isFavorite = nowFav, favoriteTs = if (nowFav) System.currentTimeMillis() else g.favoriteTs))
                },
                onCollections = {
                    collPickerSel.clear()
                    collPickerSel.addAll(g.collections)
                    collPickerCb = { sel -> replaceGame(g.copy(collections = sel)) }
                    collPickerOpen = true
                }
            )
            if (ytOpen) {
                val r = ytRegion
                val winMod = when {
                    ytFull -> Modifier.fillMaxSize()
                    r != null -> Modifier
                        .offset { IntOffset((r.left - rootPos.x).toInt(), (r.top - rootPos.y).toInt()) }
                        .size(with(dens) { r.width.toDp() }, with(dens) { r.height.toDp() })
                    else -> Modifier.size(0.dp)
                }
                VideoWindow(
                    ctrl = ytCtrl, videoId = g.videoId, noKey = g.videoId.isEmpty(), full = ytFull, landscape = landscape,
                    ctl = ytCtl, navOn = ytNav, accent = parseColor(accentHex),
                    modifier = winMod,
                    onAction = { ytAct(it) }
                )
            }
        }
    }

    @Composable
    private fun InfoCover(g: Game, modifier: Modifier) {
        Box(modifier.background(Color(0xFF1A1E29))) {
            val appIcon = if (g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()) {
                remember(g.pkg) { bigIconFor(g.pkg) }
            } else null
            if (appIcon != null) {
                Image(
                    bitmap = appIcon, contentDescription = g.title,
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
                )
            } else {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(12.dp)
                )
            }
            if (g.cover.isNotBlank()) {
                val req = remember(g.cover) { Covers.request(this@MainActivity, g.cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = g.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    // ---------- Cabeçalho e rodapé ----------
    @Composable
    private fun Pill(text: String, hl: Boolean = false, onClick: () -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .height(28.dp)
                .clip(shape)
                .background(if (hl) FocusStyle.accent.copy(alpha = 0.25f) else HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .navHighlight(hl, shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text, color = Color(0xFFE2E8F0), fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.6.sp, maxLines = 1, softWrap = false
            )
        }
    }

    @Composable
    private fun BatteryPill(hl: Boolean = false) {
        // Temperatura (metade esquerda) + bateria (metade direita), borda bicolor. Em thermal throttling o fundo fica vermelho.
        val shape = RoundedCornerShape(rBtn.dp)
        // Tocar liga/desliga o painel flutuante de temperatura sobre qualquer app.
        PowerBadge(power, corner = rBtn.dp, modifier = Modifier.clip(shape).navHighlight(hl, shape).clickable { toggleFloat() })
    }

    @Composable
    private fun OrientButton(hl: Boolean = false) {
        val shape = RoundedCornerShape(rBtn.dp)
        val ic = Color(0xFFE2E8F0)
        Box(
            modifier = Modifier
                .height(28.dp)
                .width(34.dp)
                .clip(shape)
                .background(if (hl) FocusStyle.accent.copy(alpha = 0.25f) else HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .navHighlight(hl, shape)
                .clickable { toggleOrientation() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(16.dp)) {
                val w = size.width
                val h = size.height
                val sw = 1.5.dp.toPx()
                drawRoundRect(
                    ic, Offset(w * 0.06f, h * 0.04f), Size(w * 0.5f, h * 0.92f),
                    CornerRadius(w * 0.1f), style = Stroke(width = sw)
                )
                drawCircle(ic, sw * 0.8f, Offset(w * 0.2f, h * 0.8f))
                val p = Path().apply {
                    moveTo(w * 0.68f, h * 0.25f)
                    lineTo(w * 0.82f, h * 0.25f)
                    quadraticBezierTo(w * 0.96f, h * 0.25f, w * 0.96f, h * 0.4f)
                    lineTo(w * 0.96f, h * 0.6f)
                    quadraticBezierTo(w * 0.96f, h * 0.75f, w * 0.82f, h * 0.75f)
                    lineTo(w * 0.68f, h * 0.75f)
                }
                drawPath(p, ic, style = Stroke(width = sw, cap = StrokeCap.Round))
            }
        }
    }

    /** 4.6.1 / 4.7.7: olho que abre os modos de visualização das capas. A cor segue o destaque escolhido pelo usuário. */
    @Composable
    private fun EyeButton(hl: Boolean = false) {
        val shape = RoundedCornerShape(rBtn.dp)
        val ac = parseColor(accentHex)
        Box(
            modifier = Modifier
                .height(28.dp)
                .width(34.dp)
                .clip(shape)
                .background(if (hl) FocusStyle.accent.copy(alpha = 0.25f) else HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .navHighlight(hl, shape)
                .clickable { overlay = Overlay.ViewMode },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(width = 20.dp, height = 13.dp)) {
                val w = size.width
                val h = size.height
                val eye = Path().apply {
                    moveTo(0f, h / 2f)
                    quadraticBezierTo(w / 2f, -h * 0.5f, w, h / 2f)
                    quadraticBezierTo(w / 2f, h * 1.5f, 0f, h / 2f)
                    close()
                }
                drawPath(eye, ac)
                // íris: anel escuro com o centro na cor do olho
                drawCircle(Color(0xFF0A0C10), radius = h * 0.34f, center = Offset(w / 2f, h / 2f), style = Stroke(width = h * 0.15f))
            }
        }
    }

    @Composable
    private fun GearButton(hl: Boolean = false) {
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(shape)
                .background(if (hl) FocusStyle.accent.copy(alpha = 0.25f) else HDR_BG)
                .border(1.dp, HDR_LINE, shape)
                .navHighlight(hl, shape)
                .clickable { overlay = Overlay.Settings },
            contentAlignment = Alignment.Center
        ) {
            Text("\u2699\uFE0E", color = Color(0xFFE2E8F0), fontSize = 15.sp)
        }
    }

    @Composable
    private fun TitleText(title: String, modifier: Modifier) {
        // Títulos grandes rolam sozinhos, devagar, em vez de ficarem cortados.
        MarqueeText(title, Color.White, if (landscape) 16 else 14, FontWeight.ExtraBold, modifier)
    }

    @Composable
    private fun Header(title: String) {
        val tv = TvMode.isTv
        val hz = navZone == 1
        val cur = headerOrder().getOrNull(hdrIdx)
        if (landscape) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!tv) {
                    OrientButton(hz && cur == H_ORIENT)
                    Spacer(Modifier.width(8.dp))
                }
                // O olho dos modos de visualização existe na horizontal (celular e TV). No celular fica logo depois
                // do botão de girar a tela; na TV ocupa o lugar dele.
                EyeButton(hz && cur == H_EYE)
                Spacer(Modifier.width(12.dp))
                TitleText(title, Modifier.weight(1f).padding(end = 8.dp))
                BatteryPill(hz && cur == H_FLOAT)
                Spacer(Modifier.width(8.dp))
                Pill("SELECT", hz && cur == H_SELECT) { overlay = Overlay.Filter }
                Spacer(Modifier.width(8.dp))
                Pill("START", hz && cur == H_START) { editSelected() }
                Spacer(Modifier.width(8.dp))
                GearButton(hz && cur == H_GEAR)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 4.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (!tv) {
                        OrientButton(hz && cur == H_ORIENT)
                        Spacer(Modifier.width(8.dp))
                    }
                    Pill("SELECT", hz && cur == H_SELECT) { overlay = Overlay.Filter }
                    Spacer(Modifier.width(8.dp))
                    Pill("START", hz && cur == H_START) { editSelected() }
                    Spacer(Modifier.weight(1f))
                    BatteryPill(hz && cur == H_FLOAT)
                    Spacer(Modifier.width(8.dp))
                    GearButton(hz && cur == H_GEAR)
                }
                Spacer(Modifier.height(10.dp))
                TitleText(title, Modifier.fillMaxWidth())
            }
        }
    }

    @Composable
    @OptIn(ExperimentalTextApi::class)
    private fun PadButton(letter: String, label: String, color: Color, hl: Boolean = false, onClick: () -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        val fg = when (letter) {
            "Y" -> Color(0xFF1A1202)
            "A" -> Color(0xFF05140B)
            else -> Color.White
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(if (hl) FocusStyle.accent.copy(alpha = 0.25f) else Color(0xEB161A23))
                .border(1.dp, Color(0x17FFFFFF), shape)
                .navHighlight(hl, shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp)
        ) {
            Box(
                modifier = Modifier.size(16.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    letter, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 9.5.sp,
                    lineHeight = 9.5.sp, style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                label, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, softWrap = false,
                lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
    }

    @Composable
    private fun BottomBar(platformMode: Boolean = false) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x0FFFFFFF)))
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val fz = navZone == 2
                PadButton("A", if (platformMode) "Abrir" else "Detalhes", Color(0xFF10B981), fz && ftrIdx == 0) { openSelected() }
                PadButton("B", "Voltar", Color(0xFFF43F5E), fz && ftrIdx == 1) { navZone = 0; back() }
                PadButton("Y", if (searchTerm.isNotBlank()) "Pesquisar •" else "Pesquisar", Color(0xFFFBBF24), fz && ftrIdx == 2) { overlay = Overlay.Search }
                PadButton("X", "Aleatório", Color(0xFF0EA5E9), fz && ftrIdx == 3) { randomPick() }
            }
        }
    }

    // ---------- Cartão de plataforma (ocupa o espaço de 2 capas) ----------
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun PlatformCard(p: GamePlatform, selected: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f) {
        val shape = RoundedCornerShape(radius.dp)
        val sid = PLAT_PREFIX + p.name
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scalePlat")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowPlat")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                }
                .clip(shape)
                .background(Color(0xFF13161E))
                .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
                .combinedClickable(
                    onClick = { selectedId = sid },
                    onLongClick = {
                        selectedId = sid
                        overlay = Overlay.PlatformImage(p.name)
                    }
                )
        ) {
            Text(
                p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center).padding(14.dp)
            )
            if (p.image.isNotBlank()) {
                val req = remember(p.image) { Covers.request(this@MainActivity, p.image) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = p.name,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    // ---------- TV: modo Lista (4.6.1) ----------
    /** Casca comum dos cartões da lista: brilho, borda, escala e clique (1º toque seleciona, 2º abre). */
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun ListRowShell(
        selected: Boolean, accent: Color, haloTopDp: Float,
        onClick: () -> Unit, onLongClick: () -> Unit,
        content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit
    ) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.02f else 1f, label = "scaleList")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowList")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(LIST_ROW_H_DP.dp)
                .zIndex(if (selected) 1f else 0f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    drawHalo(
                        accent, glow, radius.dp.toPx(),
                        if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE, 1.02f
                    )
                }
                .clip(shape)
                .background(Color(0xFF13161E))
                .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }

    private fun listDate(ts: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(ts))

    @Composable
    private fun GameListRow(g: Game, selected: Boolean, recent: Boolean, accent: Color, haloTopDp: Float) {
        ListRowShell(
            selected, accent, haloTopDp,
            onClick = { if (selectedId == g.id) overlay = Overlay.Info(g.id) else selectedId = g.id },
            onLongClick = { selectedId = g.id; overlay = Overlay.Info(g.id) }
        ) {
            CoverThumb(g.cover, g.title, g.platform, g.pkg, Modifier.fillMaxHeight().aspectRatio(0.69f))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val maskBg = if (g.maskPlatform.isNotEmpty() && g.maskColor.isNotEmpty()) parseColor(g.maskColor) else null
                    Text(
                        g.shownPlatform.uppercase(),
                        color = if (maskBg != null) onAccent(maskBg) else Color(0xFFF1F5F9), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp, maxLines = 1, softWrap = false,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(maskBg ?: Color(0xD9000000))
                            .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                    if (g.genres.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            g.genres.joinToString(" · "), color = Color(0xFFB4BCCB), fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Legenda: última vez jogado e quantas vezes foi aberto.
                val meta = buildList {
                    if (g.lastPlayedTs > 0) add("Último jogo: " + listDate(g.lastPlayedTs))
                    if (g.openCount > 0) add("Aberto ${g.openCount}×")
                    if (g.missing) add("⚠ Arquivo não encontrado")
                }
                if (meta.isNotEmpty()) {
                    Text(
                        meta.joinToString("  ·  "), color = Color(0xFF8A93A6), fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            // 4.7.0: no fim do cartão, sem fundo: ampulheta (só nos recentes) à esquerda da estrela.
            // A estrela aparece em todos os jogos (cinza apagada / amarela) e é apenas um ícone, não um botão.
            Spacer(Modifier.width(10.dp))
            // 4.7.9: ícones redesenhados (NxIcons.kt): mesma altura (27 dp) e mesma caixa, cor de destaque do usuário,
            // cantos conforme o estilo de borda escolhido. 20 dp de distância entre os dois.
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                if (recent) NxHourglass(accent, styleIdx, Modifier.size(27.dp))
                NxStar(if (g.isFavorite) accent else Color(0x4DFFFFFF), styleIdx, Modifier.size(27.dp))
            }
            Spacer(Modifier.width(8.dp))
        }
    }

    @Composable
    private fun PlatformListRow(p: GamePlatform, selected: Boolean, accent: Color, haloTopDp: Float) {
        val sid = PLAT_PREFIX + p.name
        val count = filteredGames().count { it.shownPlatform == p.name }
        ListRowShell(
            selected, accent, haloTopDp,
            onClick = { if (selectedId == sid) enterPlatform(p.name) else selectedId = sid },
            onLongClick = { selectedId = sid; overlay = Overlay.PlatformImage(p.name) }
        ) {
            CoverThumb(p.image, p.name, p.name, "", Modifier.fillMaxHeight().aspectRatio(0.69f))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    p.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (count == 1) "1 jogo" else "$count jogos", color = Color(0xFFB4BCCB), fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Spacer(Modifier.width(10.dp))
        }
    }

    @Composable
    private fun AddListRow(selected: Boolean, accent: Color, haloTopDp: Float) {
        ListRowShell(
            selected, accent, haloTopDp,
            onClick = { if (selectedId == ADD_ID) openAdd() else selectedId = ADD_ID },
            onLongClick = { selectedId = ADD_ID }
        ) {
            Box(
                Modifier.fillMaxHeight().aspectRatio(0.69f).clip(RoundedCornerShape(rBtn.dp)).background(Color(0x0FFFFFFF)),
                contentAlignment = Alignment.Center
            ) { Text("+", color = Color(0xFFB4BCCB), fontSize = 28.sp, fontWeight = FontWeight.Light) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Adicionar Novo Jogo", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, maxLines = 1)
                Text("Cadastre um jogo, app ou site", color = Color(0xFFB4BCCB), fontSize = 12.sp, maxLines = 1)
            }
        }
    }

    // ---------- TV: escolha do modo de visualização (olho) ----------
    @Composable
    private fun ViewModeDialog() {
        val accent = parseColor(accentHex)
        val names = listOf("Padrão", "Carrossel", "Grade", "Lista")
        val descs = listOf(
            "Capas em fila, uma ao lado da outra",
            "A capa do centro fica selecionada, com efeito de carrossel",
            "Várias capas por tela, como no celular em pé",
            "Cartões com capa e informações. A abre o jogo; direita abre Detalhes"
        )
        val icons = listOf(R.drawable.ic_view_standard, R.drawable.ic_view_carousel, R.drawable.ic_view_grid, R.drawable.ic_view_list)
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            // o foco inicial da janela vai para o primeiro item; aqui passa para o modo em uso
            delay(320)
            try {
                fr.requestFocus()
            } catch (_: Exception) {
            }
        }
        NexusModal("Visualização", { overlay = Overlay.None }) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val shape = RoundedCornerShape(rBtn.dp)
                for (i in 0..3) {
                    val cur = tvView == i
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(if (cur) accent.copy(alpha = 0.16f) else Color(0xFF1A1E29))
                            .border(1.dp, if (cur) accent else Color(0x1FFFFFFF), shape)
                            .then(if (cur) Modifier.focusRequester(fr) else Modifier)
                            .clickable {
                                applyTvView(i)
                                overlay = Overlay.None
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // ícones em máscara transparente, pintados com a cor de destaque escolhida
                        Box(Modifier.width(54.dp), contentAlignment = Alignment.CenterStart) {
                            Image(
                                painter = painterResource(icons[i]),
                                contentDescription = names[i],
                                contentScale = ContentScale.Fit,
                                colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(accent),
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text(names[i], color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text(descs[i], color = Color(0xFF8A93A6), fontSize = 11.sp)
                        }
                        if (cur) Text("✓", color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                }
            }
        }
    }

    @Composable
    private fun PlatformImageDialog(name: String) {
        var url by remember { mutableStateOf(platforms.firstOrNull { it.name == name }?.image ?: "") }
        val accent = parseColor(accentHex)
        val panel = RoundedCornerShape(rPanel.dp)
        val danger = Color(0xFFFF6B81)
        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .widthIn(max = 620.dp)
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(horizontal = 14.dp, vertical = if (landscape) 8.dp else 12.dp)
                ) {
                    val pasteBtn: @Composable (Modifier) -> Unit = { m ->
                        EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), m) {
                            val t = clipboardText().trim()
                            if (t.isNotEmpty()) url = t else toast("Área de transferência vazia")
                        }
                    }
                    val clearBtn: @Composable (Modifier) -> Unit = { m ->
                        EBtn("Limpar", "✕", S_FIELD, S_LINE, Color(0xFFE2E6EF), m) { url = "" }
                    }
                    val siteBtn: @Composable (Modifier) -> Unit = { m ->
                        EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), m) { openSteamGrid(name) }
                    }
                    val pickBtn: @Composable (Modifier) -> Unit = { m ->
                        EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), m) {
                            openSgdbPicker("Imagem: $name", name, true) { u -> url = u }
                        }
                    }
                    if (landscape) {
                        // Paisagem: cabeçalho numa linha, tudo compacto para caber sem corte.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                            Spacer(Modifier.width(6.dp))
                            ELabel("IMAGEM DA PLATAFORMA")
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) { MarqueeText(name, Color.White, 16, FontWeight.ExtraBold) }
                        }
                        Spacer(Modifier.height(6.dp))
                        SCard(pad = 8.dp) {
                            Row {
                                CoverThumb(url, name, name, "", Modifier.width(46.dp).height(70.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PillField("LINK DA IMAGEM", url, { url = it }, "Cole a URL da imagem...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, 3.dp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        pasteBtn(Modifier.weight(1f))
                                        clearBtn(Modifier.weight(1f))
                                        siteBtn(Modifier.weight(1f))
                                        pickBtn(Modifier.weight(1.2f))
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Sem imagem, o cartão mostra só o nome.",
                                color = S_MUTED, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.widthIn(min = 120.dp)) { overlay = Overlay.None }
                            Spacer(Modifier.width(8.dp))
                            EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.widthIn(min = 120.dp)) {
                                savePlatformImage(name, url)
                                overlay = Overlay.None
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                            Spacer(Modifier.width(6.dp))
                            ELabel("IMAGEM DA PLATAFORMA")
                        }
                        Spacer(Modifier.height(2.dp))
                        MarqueeText(name, Color.White, 18, FontWeight.ExtraBold)
                        Spacer(Modifier.height(10.dp))
                        SCard(pad = 10.dp) {
                            Row {
                                CoverThumb(url, name, name, "", Modifier.width(52.dp).height(82.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    PillField("LINK DA IMAGEM", url, { url = it }, "Cole a URL da imagem...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, 6.dp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        pasteBtn(Modifier.weight(1f))
                                        clearBtn(Modifier.weight(1f))
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                siteBtn(Modifier.weight(1f))
                                pickBtn(Modifier.weight(1f))
                            }
                        }
                        Text(
                            "Sem imagem, o cartão da plataforma mostra só o nome.",
                            color = S_MUTED, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 2.dp, vertical = 8.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { overlay = Overlay.None }
                            EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                                savePlatformImage(name, url)
                                overlay = Overlay.None
                            }
                        }
                    }
                }
            }
        }
    }

    // ---------- Capas ----------
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun GameCard(g: Game, selected: Boolean, recent: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f, grid: Boolean = false) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scale")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glow")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                }
                .clip(shape)
                .background(Color(0xFF13161E))
                .border(if (selected) 2.2.dp else 1.5.dp, if (selected) accent else Color(0x1CFFFFFF), shape)
                .combinedClickable(
                    onClick = { selectedId = g.id },
                    onLongClick = {
                        selectedId = g.id
                        overlay = Overlay.Info(g.id)
                    }
                )
        ) {
            // 4.9.0: o ícone do app Android é decodificado em segundo plano (antes travava a rolagem na 1ª vez).
            val isApp = g.platform == ANDROID_PLATFORM && g.pkg.isNotEmpty()
            val iconState by produceState<ImageBitmap?>(if (isApp) cachedBigIcon(g.pkg) else null, g.pkg, isApp) {
                if (isApp && value == null) value = withContext(Dispatchers.Default) { bigIconFor(g.pkg) }
            }
            val appIcon: ImageBitmap? = iconState
            if (appIcon != null) {
                Column(
                    modifier = Modifier.align(Alignment.Center).padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        bitmap = appIcon, contentDescription = g.title,
                        modifier = Modifier.fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(rCard.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                Text(
                    g.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(10.dp)
                )
            }
            if (g.cover.isNotBlank()) {
                val req = remember(g.cover) { Covers.request(this@MainActivity, g.cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = g.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
            // 4.8.0: etiqueta + ícones num layout só (NxCardBadges, em NxIcons.kt).
            //  Grade e celular em pé: ícones (12 dp) acima da etiqueta, à direita. Padrão e Carrossel: ícones na linha da etiqueta
            //  (mesma altura dela) no canto esquerdo; se a etiqueta for grande demais, sobem para cima dela.
            val maskBg = if (g.maskPlatform.isNotEmpty() && g.maskColor.isNotEmpty()) parseColor(g.maskColor) else null
            NxCardBadges(
                inlineWhenFits = !grid, hasHour = recent, hasStar = g.isFavorite,
                modifier = Modifier.fillMaxSize()
            ) {
                Text(
                    g.shownPlatform.uppercase(),
                    color = if (maskBg != null) onAccent(maskBg) else Color(0xFFF1F5F9), fontSize = 8.sp, fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp, maxLines = 1, softWrap = false,
                    lineHeight = 8.sp, style = TextStyle(lineHeightStyle = CenteredLine),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(maskBg ?: Color(0xD9000000))
                        .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                        .height(18.dp)
                        .wrapContentHeight(Alignment.CenterVertically)
                        .padding(horizontal = 6.dp)
                )
                if (recent) NxHourglass(accent, styleIdx, Modifier.fillMaxSize())
                if (g.isFavorite) NxStar(accent, styleIdx, Modifier.fillMaxSize())
            }
        }
    }

    @Composable
    private fun AddTile(selected: Boolean, accent: Color, modifier: Modifier, haloTopDp: Float = -1f) {
        val shape = RoundedCornerShape(radius.dp)
        val sc by animateFloatAsState(if (selected) 1.04f else 1f, label = "scaleAdd")
        val glow by animateFloatAsState(if (selected) 1f else 0f, label = "glowAdd")
        Box(
            modifier = modifier
                .zIndex(if (selected) 1f else 0f)
                .aspectRatio(0.69f)
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .drawBehind {
                    drawHalo(accent, glow, radius.dp.toPx(), if (haloTopDp >= 0f) haloTopDp.dp.toPx() - 0.5.dp.toPx() else Float.MAX_VALUE)
                }
                .clip(shape)
                .background(Color(0xCC14171F))
                .then(
                    if (selected) Modifier.border(2.2.dp, accent, shape)
                    else Modifier.drawBehind {
                        val sw = 1.5.dp.toPx()
                        drawRoundRect(
                            Color(0x3DFFFFFF),
                            topLeft = Offset(sw / 2, sw / 2),
                            size = Size(size.width - sw, size.height - sw),
                            cornerRadius = CornerRadius(radius.dp.toPx()),
                            style = Stroke(
                                width = sw,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 7.dp.toPx()))
                            )
                        )
                    }
                )
                .clickable {
                    if (selectedId == ADD_ID) openAdd() else selectedId = ADD_ID
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, Color(0x26FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", color = Color(0xFFE2E8F0), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Adicionar", color = if (selected) Color.White else Color(0xFF94A3B8),
                    fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
                )
            }
        }
    }

    // ---------- Componentes de formulário ----------
    @Composable
    private fun CField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier, wrap: Boolean = false, paste: Boolean = false, mic: Boolean = true) {
        val shape = RoundedCornerShape(rBtn.dp)
        var focused by remember { mutableStateOf(false) }
        val tvEdit = rememberTvEdit()
        val hot = focused || tvEdit.selected
        BoxWithConstraints(
            modifier = modifier
                .then(if (wrap) Modifier.heightIn(min = 44.dp) else Modifier.height(44.dp))
                .clip(shape)
                .background(if (tvEdit.selected) parseColor(accentHex).copy(alpha = 0.16f) else C_FIELD)
                .border(if (tvEdit.selected) 3.dp else if (focused) 2.dp else 1.dp, if (hot) parseColor(accentHex) else C_BORDER, shape)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            // Microfone (4.0.8): fica dentro do campo, na altura que ele já tem. Em campos muito
            // estreitos ele some para não espremer o texto.
            val showMic = mic && maxWidth >= 130.dp
            Row(if (wrap) Modifier.fillMaxWidth().padding(vertical = 8.dp) else Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).tvFieldBox(tvEdit), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(hint, color = C_MUTED, fontSize = 13.sp, maxLines = 1)
                    BasicTextField(
                        value = value,
                        onValueChange = { onChange(if (wrap) it.replace("\n", "") else it) },
                        singleLine = !wrap, maxLines = if (wrap) 4 else 1,
                        textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth().tvFieldInput(tvEdit).onFocusChanged { focused = it.isFocused }
                    )
                }
                if (showMic && paste) {
                    Spacer(Modifier.width(6.dp))
                    val ps = RoundedCornerShape(rBtn.dp)
                    Box(
                        modifier = Modifier.height(30.dp).clip(ps)
                            .background(parseColor(accentHex).copy(alpha = 0.16f))
                            .border(1.dp, parseColor(accentHex).copy(alpha = 0.5f), ps)
                            .focusGlow(ps)
                            .clickable {
                                val t = clipboardText().trim()
                                if (t.isEmpty()) toast("Nada copiado para colar") else onChange(t)
                            }
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Colar", color = parseColor(accentHex), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) }
                } else if (showMic) {
                    Spacer(Modifier.width(6.dp))
                    VoiceMic(value, onChange, parseColor(accentHex), size = 30.dp)
                }
            }
        }
    }

    @Composable
    private fun CSelect(
        label: String, value: String, options: List<String>,
        modifier: Modifier = Modifier, subtitle: ((String) -> String)? = null, onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(rBtn.dp)
        Box(modifier) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(shape)
                    .background(C_FIELD)
                    .border(1.dp, C_BORDER, shape)
                    .clickable { open = true }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(
                    value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text("▾", color = C_MUTED, fontSize = 12.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(S_CARD)) {
                options.forEachIndexed { idx, o ->
                    val sub = subtitle?.invoke(o) ?: ""
                    DropdownMenuItem(modifier = Modifier.focusRing(), 
                        text = {
                            Column {
                                Text(o, color = Color.White, fontSize = 14.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C_MUTED)
                            }
                        },
                        onClick = {
                            onSelect(o)
                            open = false
                        }
                    )
                    if (subtitle != null && idx < options.lastIndex) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .height(1.dp)
                                .background(C_BORDER)
                        )
                    }
                }
            }
        }
    }

    @Composable
    private fun CButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        // Botões "azuis" (ação principal) seguem a cor de destaque escolhida.
        val bg = if (color == C_BLUE) accent else color
        val fg = if (color == C_BLUE) onAccent(accent) else Color.White
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(bg)
                .then(if (color == C_GRAY) Modifier.border(1.dp, Color(0x1FFFFFFF), shape) else Modifier)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }

    /** 4.8.0: botão cinza com até 3 linhas centralizadas (a altura se ajusta). */
    @Composable
    private fun CButtonLines(lines: List<String>, modifier: Modifier = Modifier, onClick: () -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        Column(
            modifier = modifier
                .heightIn(min = 44.dp)
                .clip(shape)
                .background(C_GRAY)
                .border(1.dp, Color(0x1FFFFFFF), shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp, vertical = if (lines.size > 1) 8.dp else 0.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            lines.forEachIndexed { i, t ->
                Text(
                    t, color = Color.White, fontSize = if (i == 0) 13.sp else 12.sp,
                    fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Medium,
                    textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }

    @Composable
    private fun CToggle(text: String, checked: Boolean, modifier: Modifier = Modifier, star: Boolean = false, onChange: (Boolean) -> Unit) {
        val shape = RoundedCornerShape(rBtn.dp)
        val accent = parseColor(accentHex)
        Box(
            modifier = modifier
                .height(44.dp)
                .clip(shape)
                .background(C_FIELD)
                .border(1.dp, if (checked) accent else C_BORDER, shape)
                .focusGlow(shape)
                .clickable { onChange(!checked) }
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (if (checked) "☑ " else "☐ ") + text,
                    color = if (checked) accent else Color.White, fontSize = 13.sp, maxLines = 1
                )
                if (star) {
                    Spacer(Modifier.width(6.dp))
                    NxStar(accent, styleIdx, Modifier.size(20.dp))
                }
            }
        }
    }

    @Composable
    private fun HideBarsInDialog() {
        val view = LocalView.current
        // TV: ao abrir uma janela, o destaque do D-pad já aparece no primeiro item.
        if (TvMode.isTv) {
            val fm = LocalFocusManager.current
            LaunchedEffect(Unit) {
                delay(160)
                try {
                    fm.moveFocus(FocusDirection.Next)
                } catch (_: Exception) {
                }
            }
        }
        SideEffect {
            val win = (view.parent as? DialogWindowProvider)?.window
            if (win != null) {
                WindowCompat.setDecorFitsSystemWindows(win, false)
                // Teclado só aparece quando o usuário toca na caixa de texto.
                win.setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or
                        android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                )
                val c = WindowInsetsControllerCompat(win, view)
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    /** Divisão de tela (paisagem): controles à esquerda, lista à direita. */
    @Composable
    private fun androidx.compose.foundation.layout.ColumnScope.Panes(
        leftW: Float = 0.4f,
        left: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
        right: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(leftW).fillMaxHeight().verticalScroll(rememberScrollState())) { left() }
            Column(Modifier.weight(1f - leftW).fillMaxHeight()) { right() }
        }
    }

    @Composable
    private fun NexusModal(
        title: String, onDismiss: () -> Unit, tall: Boolean = false,
        footer: (@Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
        leftPane: (@Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                val accent = parseColor(accentHex)
                val panelShape = RoundedCornerShape(rPanel.dp)
                val closeShape = RoundedCornerShape(rBtn.dp)
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (landscape) 0.86f else 0.94f)
                        .then(if (tall) Modifier.fillMaxHeight(if (landscape) 0.94f else 0.9f) else Modifier)
                        .shadow(14.dp, panelShape, ambientColor = accent, spotColor = accent)
                        .clip(panelShape)
                        .background(C_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) { MarqueeText(title, Color.White, 17, FontWeight.ExtraBold) }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(closeShape)
                                .background(Color(0x0FFFFFFF))
                                .border(1.dp, S_LINE, closeShape)
                                // TV: "Voltar" do controle já fecha; o destaque do D-pad começa no conteúdo, não no ✕.
                                .focusProperties { canFocus = !TvMode.isTv }
                                .focusGlow(closeShape)
                                .clickable(onClick = onDismiss),
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    if (tall && landscape && leftPane != null) {
                        // Paisagem: controles à esquerda, lista inteira à direita.
                        Row(
                            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Column(
                                modifier = Modifier.weight(0.38f).fillMaxHeight().verticalScroll(rememberScrollState())
                            ) { leftPane() }
                            Column(modifier = Modifier.weight(0.62f).fillMaxHeight()) { content() }
                        }
                    } else if (tall) {
                        Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) { content() }
                    } else {
                        // Janelas sem altura fixa rolam quando o conteúdo passa do tamanho da tela.
                        Column(
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) { content() }
                    }
                    if (footer != null && !(tall && landscape && leftPane != null)) {
                        Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) { footer() }
                    }
                }
            }
        }
    }

    /** Linha de lista em cartão de vidro escuro (com foco do controle). Use no lugar do padding simples. */
    @Composable
    private fun Modifier.cardRow(onClick: (() -> Unit)?): Modifier {
        val shape = RoundedCornerShape(rCard.dp)
        return this
            .padding(vertical = 3.dp)
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    }

    // ---------- Diálogos ----------
    @Composable
    private fun AppIcon(pkg: String) {
        val bmp = remember(pkg) { iconFor(pkg) }
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(36.dp))
        } else {
            Spacer(Modifier.size(36.dp))
        }
    }

    private fun appShownName(a: AppItem): String = appAliases[a.pkg]?.takeIf { it.isNotBlank() } ?: a.label

    /** Apps que aparecem ao escolher: só os ligados no filtro (jogos usam o nome que você deu). */
    private fun appsForPicker(mode: Int): List<AppItem> = when (mode) {
        1 -> allApps.filter { it.pkg !in hiddenGameApps }.map { AppItem(appShownName(it), it.pkg) }
        2 -> allApps.filter { it.pkg !in hiddenEmuApps }
        else -> allApps
    }

    @Composable
    private fun AppFilterDialog(kind: Int) {
        val games = kind == 1
        val hidden = if (games) hiddenGameApps else hiddenEmuApps
        val accent = parseColor(accentHex)
        var q by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        val k = foldText(q.trim())
        val list = if (k.isEmpty()) allApps else allApps.filter {
            foldText(it.label).contains(k) || foldText(appShownName(it)).contains(k) || it.pkg.lowercase().contains(k)
        }
        NexusModal(if (games) "Apps de jogos" else "Apps emuladores", { appFilterKind = 0 }, tall = true) {
            val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Text(
                if (games) "Ligado = aparece ao adicionar um jogo Android. Use o lápis para dar o nome real do jogo."
                else "Ligado = aparece como opção de emulador.",
                color = C_MUTED, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))
            CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Ligar todos", C_GRAY, Modifier.weight(1f)) {
                    list.forEach { hidden.remove(it.pkg) }
                    savePrefs()
                }
                CButton("Desligar todos", C_GRAY, Modifier.weight(1f)) {
                    list.forEach { if (it.pkg !in hidden) hidden.add(it.pkg) }
                    savePrefs()
                }
            }
            Spacer(Modifier.height(6.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    val on = a.pkg !in hidden
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppIcon(a.pkg)
                        if (editing == a.pkg) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                CField(editText, { editText = it }, "Nome do jogo", Modifier.fillMaxWidth(), wrap = true)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CButton("✔ Salvar", C_BLUE, Modifier.weight(1f)) {
                                        val t = editText.trim()
                                        if (t.isEmpty() || t == a.label) appAliases.remove(a.pkg) else appAliases[a.pkg] = t
                                        savePrefs()
                                        editing = null
                                    }
                                    CButton("✖ Cancelar", C_GRAY, Modifier.weight(1f)) { editing = null }
                                }
                            }
                        } else {
                            Column(Modifier.weight(1f)) {
                                MarqueeText(if (games) appShownName(a) else a.label, Color.White, 14, FontWeight.Normal)
                                if (games && appAliases[a.pkg] != null) {
                                    Text(a.label, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (games) MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) {
                                editing = a.pkg
                                editText = appShownName(a)
                            }
                            Box(
                                modifier = Modifier.clip(RoundedCornerShape(14.dp)).focusGlow(RoundedCornerShape(14.dp)).clickable {
                                    if (on) hidden.add(a.pkg) else hidden.remove(a.pkg)
                                    savePrefs()
                                }
                            ) { SSwitch(on, accent) }
                        }
                    }
                }
            }
            }
            if (landscape) {
                Panes(0.38f, {
                    topUi()
                    Spacer(Modifier.height(8.dp))
                    CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appFilterKind = 0 }
                }, { listUi() })
            } else {
                topUi()
                listUi()
            Spacer(Modifier.height(8.dp))
            CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appFilterKind = 0 }
            }
        }
    }

    @Composable
    private fun AppPickerDialog() {
        var q by remember { mutableStateOf("") }
        val k = foldText(q.trim())
        val base = appsForPicker(appPickerMode)
        val filtered = if (k.isEmpty()) base else base.filter {
            foldText(it.label).contains(k) || it.pkg.lowercase().contains(k)
        }
        NexusModal("Escolher app", { appPickerOpen = false }, tall = true) {
            val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                appPickerCb?.invoke(null)
                                appPickerOpen = false
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚙️  $appPickerNone", color = C_BLUE, fontSize = 14.sp)
                    }
                }
                if (filtered.isEmpty()) {
                    item {
                        Text(
                            if (appPickerMode == 0) "Nenhum app encontrado."
                            else "Nenhum app ligado. Ligue em Configurações > Biblioteca > Apps de " +
                                (if (appPickerMode == 1) "jogos." else "emuladores."),
                            color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
                items(filtered, key = { it.pkg }) { a ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                appPickerCb?.invoke(a)
                                appPickerOpen = false
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(a.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            MarqueeText(a.label, Color.White, 14, FontWeight.Normal)
                            Text(a.pkg, color = C_MUTED, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            }
            val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { appPickerOpen = false }
            }
            if (landscape) {
                Panes(0.36f, {
                    topUi()
                    botUi()
                }, { listUi() })
            } else {
                topUi()
                listUi()
                botUi()
            }
        }
    }

    // ---------- Tela de edição de jogo (3.9.7) ----------
    /** Texto de uma linha que rola sozinho (devagar) quando é maior que o espaço disponível. */
    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun MarqueeText(
        text: String, color: Color, size: Int,
        weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier
    ) {
        Text(
            text, color = color, fontSize = size.sp, fontWeight = weight,
            maxLines = 1, softWrap = false,
            modifier = modifier.basicMarquee(iterations = Int.MAX_VALUE, velocity = 28.dp)
        )
    }

    @Composable
    private fun ELabel(text: String, color: Color = S_MUTED) {
        Text(
            text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp, maxLines = 1
        )
    }

    @Composable
    private fun EPill(
        modifier: Modifier = Modifier, selected: Boolean = false, tint: Color? = null,
        vpad: Dp = 8.dp, onClick: (() -> Unit)? = null,
        content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit
    ) {
        val accent = tint ?: parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .clip(shape)
                .background(if (selected) accent.copy(alpha = 0.12f) else S_FIELD)
                .border(if (tint != null && selected) 2.dp else 1.dp, if (selected) accent.copy(alpha = if (tint != null) 1f else 0.55f) else S_LINE, shape)
                .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 10.dp, vertical = vpad),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }

    /** Seleção de vários itens (até [max]) em lista suspensa; o menu fica aberto para marcar mais de um. */
    @Composable
    private fun MultiSelectMenu(
        open: Boolean, onDismiss: () -> Unit, selected: List<String>, options: List<String>,
        max: Int, onChange: (List<String>) -> Unit
    ) {
        DropdownMenu(expanded = open, onDismissRequest = onDismiss, modifier = Modifier.background(S_CARD)) {
            if (options.isEmpty()) {
                DropdownMenuItem(modifier = Modifier.focusRing(), text = { Text("Nenhum gênero cadastrado", color = C_MUTED, fontSize = 13.sp) }, onClick = onDismiss)
            }
            options.forEach { o ->
                val on = o in selected
                DropdownMenuItem(modifier = Modifier.focusRing(), 
                    text = { Text((if (on) "✓  " else "     ") + o, color = if (on) Color.White else Color(0xFFCBD2E0), fontSize = 14.sp) },
                    onClick = {
                        if (on) onChange(selected - o)
                        else if (selected.size >= max) toast("No máximo $max gêneros por jogo")
                        else onChange(selected + o)
                    }
                )
            }
            DropdownMenuItem(modifier = Modifier.focusRing(), 
                text = { Text("Limpar", color = C_MUTED, fontSize = 13.sp) },
                onClick = { onChange(emptyList()); onDismiss() }
            )
        }
    }

    @Composable
    private fun MultiSelectPill(
        label: String, selected: List<String>, options: List<String>, max: Int,
        modifier: Modifier = Modifier, vpad: Dp = 8.dp, onChange: (List<String>) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        Box(modifier) {
            EPill(Modifier.fillMaxWidth(), vpad = vpad, onClick = { open = true }) {
                Column(Modifier.weight(1f)) {
                    ELabel(label)
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(if (selected.isEmpty()) "—" else selected.joinToString(", "), Color.White, 13)
                }
                Spacer(Modifier.width(6.dp))
                Text("▾", color = S_MUTED, fontSize = 13.sp)
            }
            MultiSelectMenu(open, { open = false }, selected, options, max, onChange)
        }
    }

    @Composable
    private fun MultiSelectField(
        label: String, selected: List<String>, options: List<String>, max: Int,
        modifier: Modifier = Modifier, onChange: (List<String>) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(rBtn.dp)
        Box(modifier) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(shape)
                    .background(C_FIELD)
                    .border(1.dp, C_BORDER, shape)
                    .clickable { open = true }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(
                    if (selected.isEmpty()) "—" else selected.joinToString(", "),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Text("▾", color = C_MUTED, fontSize = 12.sp)
            }
            MultiSelectMenu(open, { open = false }, selected, options, max, onChange)
        }
    }

    @Composable
    private fun PillSelect(
        label: String, value: String, options: List<String>,
        modifier: Modifier = Modifier, vpad: Dp = 8.dp, subtitle: ((String) -> String)? = null,
        onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        Box(modifier) {
            EPill(Modifier.fillMaxWidth(), vpad = vpad, onClick = { open = true }) {
                Column(Modifier.weight(1f)) {
                    ELabel(label)
                    Spacer(Modifier.height(3.dp))
                    MarqueeText(value, Color.White, 13)
                }
                Spacer(Modifier.width(6.dp))
                Text("▾", color = S_MUTED, fontSize = 13.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(S_CARD)) {
                options.forEach { o ->
                    val sub = subtitle?.invoke(o) ?: ""
                    DropdownMenuItem(modifier = Modifier.focusRing(), 
                        text = {
                            Column {
                                Text(o, color = Color.White, fontSize = 14.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 11.sp, color = C_MUTED)
                            }
                        },
                        onClick = {
                            onSelect(o)
                            open = false
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun PillField(
        label: String?, value: String, onChange: (String) -> Unit, hint: String,
        modifier: Modifier = Modifier, size: Int = 13, weight: FontWeight = FontWeight.Bold,
        vpad: Dp = 8.dp, trailing: (@Composable () -> Unit)? = null
    ) {
        var focused by remember { mutableStateOf(false) }
        val tvEdit = rememberTvEdit()
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        val hot = focused || tvEdit.selected
        BoxWithConstraints(modifier) {
        // Microfone (4.0.8): no fim da linha, menor que a altura mínima do campo (não aumenta nada).
        val showMic = maxWidth >= 150.dp
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(if (tvEdit.selected) accent.copy(alpha = 0.16f) else S_FIELD)
                .border(if (tvEdit.selected) 3.dp else if (focused) 2.dp else 1.dp, if (hot) accent else S_LINE, shape)
                .padding(horizontal = 10.dp, vertical = vpad),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).tvFieldBox(tvEdit)) {
                if (label != null) {
                    ELabel(label)
                    Spacer(Modifier.height(3.dp))
                }
                Box(Modifier.fillMaxWidth()) {
                    if (value.isEmpty()) Text(hint, color = S_MUTED, fontSize = size.sp, maxLines = 1)
                    BasicTextField(
                        value = value, onValueChange = onChange, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = size.sp, fontWeight = weight),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .tvFieldInput(tvEdit)
                            .alpha(if (focused || value.isEmpty()) 1f else 0f)
                            .onFocusChanged { focused = it.isFocused }
                    )
                    // Fora de edição, títulos/links longos rolam sozinhos para dar para ler tudo.
                    if (!focused && value.isNotEmpty()) MarqueeText(value, Color.White, size, weight)
                }
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
            if (showMic) {
                Spacer(Modifier.width(8.dp))
                VoiceMic(value, onChange, accent, size = if (label == null) 22.dp else 26.dp)
            }
        }
        }
    }

    @Composable
    private fun EBtn(
        label: String, glyph: String?, bg: Color, border: Color, fg: Color, modifier: Modifier = Modifier,
        tall: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .heightIn(min = if (tall) 44.dp else 34.dp)
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (glyph != null) {
                Text(glyph, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
            }
            Text(label, color = fg, fontSize = if (tall) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
    }

    @Composable
    private fun CoverThumb(cover: String, title: String, platform: String, pkg: String, modifier: Modifier) {
        val accent = parseColor(accentHex)
        val shape = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = modifier
                .clip(shape)
                .background(Color(0xFF0F2744))
                .border(1.dp, accent.copy(alpha = 0.4f), shape),
            contentAlignment = Alignment.Center
        ) {
            val appIcon = if (platform == ANDROID_PLATFORM && pkg.isNotEmpty()) {
                remember(pkg) { bigIconFor(pkg) }
            } else null
            if (appIcon != null) {
                Image(bitmap = appIcon, contentDescription = title, modifier = Modifier.fillMaxWidth(0.7f).aspectRatio(1f))
            } else if (cover.isBlank()) {
                Text("▣", color = S_MUTED, fontSize = 18.sp)
            }
            if (cover.isNotBlank()) {
                val req = remember(cover) { Covers.request(this@MainActivity, cover) }
                key(coverRev) {
                    AsyncImage(
                        model = req, imageLoader = Covers.loader, contentDescription = title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    @Composable
    private fun GameDialog(initial: Game?) {
        var title by remember { mutableStateOf(initial?.title ?: "") }
        var platform by remember {
            mutableStateOf(
                initial?.platform
                    ?: (if (dashMode == 1 && dashPlatform.isNotEmpty() && dashPlatform in addPlatforms(null)) dashPlatform
                    else defaultAddPlatform())
            )
        }
        var genreSel by remember { mutableStateOf(initial?.genres ?: emptyList<String>()) }
        var maskPlat by remember { mutableStateOf(initial?.maskPlatform ?: "") }
        var maskCol by remember { mutableStateOf(initial?.maskColor ?: "") }
        var gameCols by remember { mutableStateOf(initial?.collections ?: emptyList<String>()) }
        var cover by remember { mutableStateOf(initial?.cover ?: "") }
        var webUrl by remember { mutableStateOf(initial?.webUrl ?: "") }
        var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
        var romUri by remember { mutableStateOf(initial?.romUri ?: "") }
        var romName by remember {
            mutableStateOf(if (initial != null && initial.romUri.isNotEmpty()) fileNameOf(initial.romUri) else "")
        }
        var fav by remember { mutableStateOf(initial?.isFavorite ?: false) }
        var custom by remember { mutableStateOf(initial?.customCmd ?: "") }
        val isWeb = platform == WEB_PLATFORM
        val isAndroid = platform == ANDROID_PLATFORM
        val canMask = isWeb || isAndroid

        val save: () -> Unit = {
            if (isAndroid && pkg.isEmpty()) {
                toast("Escolha o app do jogo")
            } else if (title.isNotBlank()) {
                val now = System.currentTimeMillis()
                val exec = if (initial == null || initial.platform != platform) {
                    DEFAULT_EXEC[execKey(platform)] ?: "native"
                } else initial.execType
                val base = initial ?: Game(
                    id = UUID.randomUUID().toString(), title = "", platform = platform, genres = genreSel
                )
                val favTs = if (fav && initial?.isFavorite != true) now else (initial?.favoriteTs ?: 0L)
                // 4.7.0: o vídeo pode ter mudado enquanto este diálogo estava aberto; usa o dado mais novo.
                // Se o título ou a plataforma mudarem, o vídeo é descartado (a próxima abertura dos detalhes busca de novo).
                val fresh = if (initial != null) (games.firstOrNull { it.id == initial.id } ?: initial) else base
                val retitled = initial != null && (initial.title != title.trim() || initial.platform != platform)
                val saved = base.copy(
                    videoId = if (retitled) "" else fresh.videoId,
                    videoTitle = if (retitled) "" else fresh.videoTitle,
                    videoTried = if (retitled) 0L else fresh.videoTried,
                    title = title.trim(), platform = platform, genres = genreSel,
                    cover = cover.trim(), webUrl = webUrl.trim(), execType = exec,
                    pkg = pkg, romUri = romUri, isFavorite = fav, favoriteTs = favTs,
                    customCmd = custom.trim(), collections = gameCols,
                    maskPlatform = if (canMask) maskPlat else "",
                    maskColor = if (canMask && maskPlat.isNotEmpty()) maskCol.ifEmpty { ACCENTS[0].second } else "",
                    romFileName = if (base.isAuto && romUri != base.romUri) romName else base.romFileName,
                    missing = if (romUri != base.romUri) false else base.missing
                )
                registerPlatformIfNeeded(platform)
                if (saved.maskPlatform.isNotEmpty()) registerPlatformIfNeeded(saved.maskPlatform)
                if (initial == null) {
                    games.add(saved)
                    saveLibrary()
                } else replaceGame(saved)
                if (initial != null && initial.cover.isNotBlank() && initial.cover != saved.cover) {
                    Covers.purgeIfUnused(initial.cover, games.map { it.cover })
                }
                if (initial != null && (initial.title != saved.title || initial.platform != saved.platform)) {
                    if (sgdbCache.remove(saved.id) != null) saveSgdb()
                }
                prefetchCovers()
                selectGame(saved.id)
                overlay = Overlay.None
            } else toast("Digite o título")
        }

        val onPlatformSel: (String) -> Unit = { sel ->
            val wasAndroid = platform == ANDROID_PLATFORM
            platform = sel
            if ((sel == ANDROID_PLATFORM) != wasAndroid) {
                pkg = ""
                romUri = ""
                romName = ""
            }
        }
        val fPlat: @Composable () -> Unit = {
            CSelect("Plataforma:", platform, addPlatforms(initial?.platform), Modifier.fillMaxWidth()) { onPlatformSel(it) }
        }
        val pickGameApp: () -> Unit = {
            appPickerMode = 1
            appPickerNone = "Nenhum (voltar)"
            appPickerCb = { a ->
                if (a != null) {
                    pkg = a.pkg
                    if (title.isBlank()) title = a.label
                }
            }
            appPickerOpen = true
        }
        val pickRom: () -> Unit = {
            val link = linkFor(platform)
            val onRom: (String, String) -> Unit = { uriStr, name ->
                romUri = uriStr
                romName = name
                if (title.isBlank()) title = cleanTitle(name, platform == "PS Vita")
            }
            if (link != null && link.folders.isNotEmpty()) {
                romList = RomListRequest(platform, onRom)
            } else {
                dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
                pickRomFile(false)
            }
        }
        val fRom: @Composable () -> Unit = {
            if (isWeb) {
                CField(webUrl, { webUrl = it }, "Link Web do Jogo (URL)", Modifier.fillMaxWidth())
            } else if (isAndroid) {
                val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
                CButton(
                    if (pkg.isEmpty()) "📱 Escolher app instalado" else "📱 ${appLabel ?: pkg}",
                    C_BLUE, Modifier.fillMaxWidth()
                ) { pickGameApp() }
            } else {
                CButton(
                    if (romUri.isEmpty()) "📁 Escolher ROM" else "📁 $romName",
                    C_BLUE, Modifier.fillMaxWidth()
                ) { pickRom() }
            }
        }
        val fTitle: @Composable () -> Unit = {
            CField(title, { title = it }, "Título do jogo", Modifier.fillMaxWidth())
        }
        val fHint: @Composable () -> Unit = {
            if (platform == "PS Vita") {
                Text(
                    "⚠ Vita3K+: o título precisa conter o ID do jogo (ex.: PCSA00029)",
                    color = C_ORANGE, fontSize = 10.sp, maxLines = 2
                )
            }
            if (isAndroid) {
                Text(
                    "Sem URL de capa, o ícone do app é usado como capa.",
                    color = C_MUTED, fontSize = 10.sp, maxLines = 2
                )
            }
        }
        val fGenre: @Composable (Modifier) -> Unit = { m ->
            MultiSelectField("Gêneros:", genreSel, genres.sortedAlpha { it }, MAX_GENRES, m) { genreSel = it }
        }
        val fCols: @Composable () -> Unit = {
            CButton(
                "📚 Coleções: " + (if (gameCols.isEmpty()) "nenhuma" else gameCols.joinToString(", ")),
                C_GRAY, Modifier.fillMaxWidth()
            ) {
                collPickerSel.clear()
                collPickerSel.addAll(gameCols)
                collPickerCb = { sel -> gameCols = sel }
                collPickerOpen = true
            }
        }
        val fFav: @Composable (Modifier) -> Unit = { m ->
            CToggle("Favorito", fav, m, star = true) { fav = it }
        }
        val fCover: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(cover, { cover = it }, "URL da capa", Modifier.weight(1f))
                CButton("📋 Colar", C_ORANGE, Modifier.width(88.dp)) {
                    val t = clipboardText()
                    if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                }
                CButton("🔄", C_GRAY, Modifier.width(48.dp)) { refreshCover(cover) }
            }
        }
        val fSgdbCover: @Composable () -> Unit = {
            CButton("🎮 Escolher capa no SteamGridDB", C_BLUE, Modifier.fillMaxWidth()) {
                openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
            }
        }
        val fSteam: @Composable () -> Unit = {
            CButton("🌐 Abrir site do SteamGridDB", C_GRAY, Modifier.fillMaxWidth()) { openSteamGrid(title) }
        }
        val fApp: @Composable () -> Unit = {
            if (!isWeb && !isAndroid) {
                val label = allApps.firstOrNull { it.pkg == pkg }?.label
                val lp = linkFor(platform)?.pkg ?: ""
                val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
                CButton(
                    if (pkg.isEmpty()) "App/emulador: automático" + (if (linkLabel != null) " ($linkLabel)" else "")
                    else "App: ${label ?: pkg}",
                    C_GRAY, Modifier.fillMaxWidth()
                ) {
                    appPickerMode = 2
                    appPickerNone = "Automático (padrão da plataforma)"
                    appPickerCb = { a -> pkg = a?.pkg ?: "" }
                    appPickerOpen = true
                }
            }
        }
        val fCustom: @Composable () -> Unit = {
            val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
            if (!isWeb && !isAndroid && (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null))) {
                CField(custom, { custom = it }, "Comando personalizado (opcional)", Modifier.fillMaxWidth())
            }
        }
        val buttons: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                if (initial != null) {
                    CButton("Apagar", C_RED, Modifier.weight(1f)) {
                        overlay = Overlay.ConfirmDelete(initial)
                    }
                }
                CButton("Salvar", C_BLUE, Modifier.weight(1f)) { save() }
            }
        }

        // ----- Peças compartilhadas entre retrato e paisagem -----
        val accent = parseColor(accentHex)
        val amber = Color(0xFFFFC53D)
        val danger = Color(0xFFFF6B81)
        val green = Color(0xFF30D158)
        val vp = if (landscape) 4.dp else 6.dp
        val showEmu = !isWeb && !isAndroid
        val coverOk = cover.isNotBlank()

        val favPill: @Composable () -> Unit = {
            EPill(
                selected = fav, tint = accent, vpad = vp,
                modifier = Modifier,
                onClick = { fav = !fav }
            ) {
                NxStar(if (fav) accent else Color(0xFFD5DAE5), styleIdx, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("Favorito", color = if (fav) accent else Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, softWrap = false, lineHeight = 14.sp, style = TextStyle(lineHeightStyle = CenteredLine))
            }
        }
        val headerTitle = if (initial == null) "Adicionar Novo Jogo" else "Configurar: " + title.ifBlank { initial.title }
        val tagText = if (initial == null) "NOVO JOGO" else "EDITAR JOGO"

        val romPill: @Composable (Modifier) -> Unit = { m ->
            if (isWeb) {
                PillField("LINK WEB DO JOGO", webUrl, { webUrl = it }, "https://…", m, 12, vpad = vp)
            } else if (isAndroid) {
                val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
                EPill(m, selected = pkg.isNotEmpty(), vpad = vp, onClick = pickGameApp) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                        contentAlignment = Alignment.Center
                    ) { Text("📱", fontSize = 13.sp) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("APP DO JOGO", accent)
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (pkg.isEmpty()) "Escolher app instalado" else (appLabel ?: pkg), Color.White, 12)
                    }
                }
            } else {
                EPill(m, selected = true, vpad = vp, onClick = pickRom) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(rBtn.dp)).background(accent),
                        contentAlignment = Alignment.Center
                    ) { Text("📁", fontSize = 13.sp) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("ARQUIVO ROM", accent)
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (romUri.isEmpty()) "Escolher ROM" else romName, Color.White, 12)
                    }
                }
            }
        }

        val titlePill: @Composable () -> Unit = {
            PillField(
                "TÍTULO DO JOGO", title, { title = it }, "Título do jogo", Modifier.fillMaxWidth(), vpad = vp,
                trailing = {
                    if (title.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0x14FFFFFF))
                                .focusGlow(CircleShape)
                                .clickable { title = "" },
                            contentAlignment = Alignment.Center
                        ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            )
        }

        val maskBlock: @Composable () -> Unit = {
            if (canMask) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        EPill(
                            Modifier.weight(1f), selected = maskPlat.isNotEmpty(),
                            tint = if (maskPlat.isNotEmpty()) parseColor(maskCol.ifEmpty { ACCENTS[0].second }) else null, vpad = vp,
                            onClick = {
                                platPicker = PlatPickerRequest(
                                    "Máscara de etiqueta", maskPlat,
                                    { pn -> pn != ANDROID_PLATFORM && pn != WEB_PLATFORM },
                                    { o, n -> if (maskPlat == o) maskPlat = n },
                                    { pn ->
                                        maskPlat = pn
                                        if (maskCol.isEmpty()) maskCol = ACCENTS[0].second
                                    }
                                )
                            }
                        ) {
                            Column(Modifier.weight(1f)) {
                                ELabel("MÁSCARA DE ETIQUETA")
                                Spacer(Modifier.height(3.dp))
                                MarqueeText(if (maskPlat.isEmpty()) "Desligada" else "Aparece como $maskPlat", Color.White, 13)
                            }
                            Spacer(Modifier.width(6.dp))
                            Text("▾", color = S_MUTED, fontSize = 13.sp)
                        }
                        if (maskPlat.isNotEmpty()) MiniIcon("✕", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { maskPlat = ""; maskCol = "" }
                    }
                    if (maskPlat.isNotEmpty()) {
                        ELabel("COR DA ETIQUETA")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            ACCENTS.forEach { (_, hex) ->
                                val c = parseColor(hex)
                                val on = hex.equals(maskCol.ifEmpty { ACCENTS[0].second }, ignoreCase = true)
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else S_LINE, CircleShape)
                                        .focusGlow(CircleShape)
                                        .clickable { maskCol = hex }
                                )
                            }
                        }
                    }
                }
            }
        }

        val vitaRow: @Composable () -> Unit = {
            if (platform == "PS Vita") {
                val idRe = Regex("[A-Z]{4}\\d{5}")
                val idInTitle = idRe.find(title)?.value
                val idInRom = idRe.find(romName)?.value
                EPill(Modifier.fillMaxWidth(), selected = true, tint = if (idInTitle != null) green else amber, vpad = if (landscape) 4.dp else 8.dp) {
                    Text(if (idInTitle != null) "✓" else "⚠", color = if (idInTitle != null) green else amber, fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (idInTitle != null) "Vita3K+: ID encontrado ($idInTitle)" else "Vita3K+: inclua o ID no título",
                        color = if (idInTitle != null) Color(0xFFB7F5C8) else Color(0xFFFDE6A8),
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                    if (idInTitle == null && idInRom != null) {
                        Spacer(Modifier.width(8.dp))
                        EBtn("+ $idInRom", null, Color(0x33FFC53D), Color(0x80FFC53D), Color(0xFFFFD36B)) {
                            title = (title.trim() + " " + idInRom).trim()
                        }
                    }
                }
            }
        }

        val genreCols: @Composable () -> Unit = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EPill(
                    Modifier.weight(1f), vpad = vp,
                    onClick = {
                        genrePickerSel.clear()
                        genrePickerSel.addAll(genreSel)
                        genrePickerCb = { sel -> genreSel = sel }
                        genrePickerOpen = true
                    }
                ) {
                    Column(Modifier.weight(1f)) {
                        ELabel("GÊNEROS")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (genreSel.isEmpty()) NO_GENRE else genreSel.joinToString(", "), Color.White, 13)
                    }
                    Spacer(Modifier.width(6.dp))
                    Text("▾", color = S_MUTED, fontSize = 13.sp)
                }
                EPill(
                    Modifier.weight(1f), vpad = vp,
                    onClick = {
                        collPickerSel.clear()
                        collPickerSel.addAll(gameCols)
                        collPickerCb = { sel -> gameCols = sel }
                        collPickerOpen = true
                    }
                ) {
                    Column(Modifier.weight(1f)) {
                        ELabel("COLEÇÕES")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (gameCols.isEmpty()) "Nenhuma" else gameCols.joinToString(", "), Color.White, 13)
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, S_LINE, RoundedCornerShape(rBtn.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("▣", color = Color(0xFFD5DAE5), fontSize = 12.sp) }
                }
            }
        }

        val coverHeader: @Composable () -> Unit = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("CAPA DO JOGO (STEAMGRIDDB)", modifier = Modifier.weight(1f), compact = true)
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (coverOk) green else S_MUTED))
                Spacer(Modifier.width(4.dp))
                Text(
                    if (coverOk) "Capa ativa" else if (isAndroid) "Ícone do app" else "Sem capa",
                    color = if (coverOk) green else S_MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }

        val coverMain: @Composable () -> Unit = {
            Row(modifier = Modifier.fillMaxWidth()) {
                CoverThumb(cover, title, platform, pkg, Modifier.width(52.dp).height(if (landscape) 74.dp else 82.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PillField(null, cover, { cover = it }, "Cole a URL da capa...", Modifier.fillMaxWidth(), 11, FontWeight.Medium, vp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        EBtn("Colar URL", "📋", Color(0x1FFFC53D), Color(0x99FFC53D), Color(0xFFFFD36B), Modifier.weight(1f)) {
                            val t = clipboardText()
                            if (t.isNotEmpty()) cover = t else toast("Área de transferência vazia")
                        }
                        EBtn("Atualizar", "⟳", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { refreshCover(cover) }
                    }
                }
            }
        }

        val coverButtons: @Composable () -> Unit = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EBtn("Site SGDB", "🌐", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) { openSteamGrid(title) }
                EBtn("Escolher capa", "🖼", accent, accent, onAccent(accent), Modifier.weight(1f)) {
                    openSgdbPicker("Capa: ${title.trim()}", title, true) { url -> cover = url }
                }
            }
        }

        val emuBlock: @Composable () -> Unit = {
            val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label
            val lp = linkFor(platform)?.pkg ?: ""
            val linkLabel = if (lp.isEmpty()) null else (allApps.firstOrNull { it.pkg == lp }?.label ?: lp)
            val emu = if (pkg.isEmpty()) "Automático" + (if (linkLabel != null) " ($linkLabel)" else "") else (appLabel ?: pkg)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(accent.copy(alpha = 0.15f))
                            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(rBtn.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("⇄", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        ELabel("APP / EMULADOR")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(emu, Color.White, 13)
                    }
                    Spacer(Modifier.width(8.dp))
                    EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                        appPickerMode = 2
                    appPickerNone = "Automático (padrão da plataforma)"
                        appPickerCb = { a -> pkg = a?.pkg ?: "" }
                        appPickerOpen = true
                    }
                }
                val ep = pkg.ifEmpty { linkFor(platform)?.pkg ?: "" }
                if (custom.isNotEmpty() || (ep.isNotEmpty() && TEMPLATES[ep] == null)) {
                    PillField("COMANDO PERSONALIZADO (OPCIONAL)", custom, { custom = it }, "Comando", Modifier.fillMaxWidth(), 12, vpad = vp)
                }
            }
        }

        // 4.7.0: ações que saíram da tela de detalhes (atualizar dados) e o vídeo (trocar / buscar de novo).
        val dataBlock: @Composable () -> Unit = {
            if (initial != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SLabel("DADOS E VÍDEO", compact = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EBtn("Atualizar dados", "⟳", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) {
                            if (sgdbKey.isBlank()) toast("Adicione sua chave do SteamGridDB em Configurações")
                            else {
                                toast("Atualizando dados…")
                                fetchSgdb(games.firstOrNull { it.id == initial.id } ?: initial, force = true)
                            }
                        }
                        EBtn("Trocar vídeo", "▶", S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f)) {
                            videoLinkFor = games.firstOrNull { it.id == initial.id } ?: initial
                        }
                    }
                }
            }
        }

        val panel = RoundedCornerShape(rPanel.dp)

        if (landscape) {
            // Paisagem: janela cheia, cabeçalho numa linha, duas colunas e rodapé com dicas do controle.
            val view = LocalView.current
            Dialog(
                onDismissRequest = { overlay = Overlay.None },
                properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
            ) {
                HideBarsInDialog()
                SideEffect {
                    val w = (view.parent as? DialogWindowProvider)?.window
                    if (w != null) {
                        val lp = w.attributes
                        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        w.attributes = lp
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                        .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
                ) {
                        Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                            .clip(panel)
                            .background(S_PANEL)
                            .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(rBtn.dp))
                                    .background(accent.copy(alpha = 0.15f))
                                    .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(rBtn.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                                Spacer(Modifier.width(6.dp))
                                ELabel(tagText, accent)
                            }
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) { MarqueeText(headerTitle, Color.White, 16, FontWeight.ExtraBold) }
                            Spacer(Modifier.width(10.dp))
                            favPill()
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // 4.5.1: a "Máscara de etiqueta" foi para a coluna da direita (que tem espaço livre),
                            // então Gêneros e Coleções aparecem sempre. Se algum bloco extra surgir, a coluna rola.
                            SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                                Column(
                                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        PlatPill("PLATAFORMA", platform, Modifier.weight(5f), vp, onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) defaultAddPlatform() else n }) { onPlatformSel(it) }
                                        romPill(Modifier.weight(7f))
                                    }
                                    titlePill()
                                    vitaRow()
                                    genreCols()
                                }
                            }
                            SCard(Modifier.weight(1f).fillMaxHeight(), 10.dp) {
                                Column(
                                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    coverHeader()
                                    coverMain()
                                    coverButtons()
                                    maskBlock()
                                    if (showEmu) emuBlock()
                                    dataBlock()
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                PadHint("A", "Confirmar", S_PAD_A, compact = true, onClick = null)
                                Spacer(Modifier.width(8.dp))
                                PadHint("B", "Cancelar", S_PAD_B, compact = true, onClick = null)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.widthIn(min = 110.dp)) { overlay = Overlay.None }
                                if (initial != null) {
                                    EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.widthIn(min = 100.dp)) {
                                        overlay = Overlay.ConfirmDelete(initial)
                                    }
                                }
                                EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.widthIn(min = 110.dp)) { save() }
                            }
                        }
                    }
                }
            }
        } else {
            // Retrato: a tela rola na vertical quando o conteúdo não cabe (4.7.5). Textos longos rolam sozinhos (marquee).
            Dialog(
                onDismissRequest = { overlay = Overlay.None },
                properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
            ) {
                HideBarsInDialog()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                        .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.96f)
                            .then(if (canMask) Modifier else Modifier.fillMaxHeight(0.97f))
                            .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                            .clip(panel)
                            .background(S_PANEL)
                            .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                                    Spacer(Modifier.width(6.dp))
                                    ELabel(tagText)
                                }
                                Spacer(Modifier.height(2.dp))
                                MarqueeText(headerTitle, Color.White, 18, FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.width(10.dp))
                            favPill()
                        }
                        Spacer(Modifier.height(6.dp))

                        // 4.7.5: o conteúdo rola na vertical quando não cabe (o Editar tem muitas opções); os botões
                        // Cancelar/Apagar/Salvar ficam sempre visíveis embaixo.
                        Box(modifier = Modifier.weight(1f, fill = !canMask).fillMaxWidth()) {
                            Column(
                                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SCard(pad = 10.dp) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            PlatPill("PLATAFORMA", platform, Modifier.weight(5f), vp, onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) defaultAddPlatform() else n }) { onPlatformSel(it) }
                                            romPill(Modifier.weight(7f))
                                        }
                                        titlePill()
                                        maskBlock()
                                        vitaRow()
                                    }
                                }
                                SCard(pad = 10.dp) { genreCols() }
                                SCard(pad = 10.dp) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        coverHeader()
                                        coverMain()
                                        coverButtons()
                                    }
                                }
                                if (showEmu) SCard(pad = 10.dp) { emuBlock() }
                                if (initial != null) SCard(pad = 10.dp) { dataBlock() }
                            }
                        }

                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E6EF), Modifier.weight(1f), tall = true) { overlay = Overlay.None }
                            if (initial != null) {
                                EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), danger, Modifier.weight(1f), tall = true) {
                                    overlay = Overlay.ConfirmDelete(initial)
                                }
                            }
                            EBtn("Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) { save() }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun FilterDialog() {
        val present = platformNames().filter { p -> games.any { it.shownPlatform == p } }
        val fFavOnly: @Composable () -> Unit = {
            CToggle("Apenas Favoritos", favOnly, Modifier.fillMaxWidth(), star = true) { favOnly = it }
        }
        val fPlat: @Composable () -> Unit = {
            CSelect(
                "Plataforma:", if (fPlatform.isEmpty()) "Todas" else fPlatform,
                listOf("Todas") + present, Modifier.fillMaxWidth()
            ) { fPlatform = if (it == "Todas") "" else it }
        }
        val fGen: @Composable () -> Unit = {
            CSelect(
                "Gênero:", if (fGenre.isEmpty()) "Todos" else fGenre,
                listOf("Todos", NO_GENRE) + genres.sortedAlpha { it }, Modifier.fillMaxWidth()
            ) { fGenre = if (it == "Todos") "" else it }
        }
        val fColl: @Composable () -> Unit = {
            CSelect(
                "Coleção:", if (fCollection.isEmpty()) "Todas" else fCollection,
                listOf("Todas") + orderedCollections(), Modifier.fillMaxWidth()
            ) { fCollection = if (it == "Todas") "" else it }
        }
        val fSort: @Composable () -> Unit = {
            CSelect("Ordem:", SORTS[sortMode], SORTS, Modifier.fillMaxWidth()) { sortMode = SORTS.indexOf(it) }
        }
        NexusModal(
            "Filtrar Biblioteca", { overlay = Overlay.None },
            footer = {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Remover Filtros", C_ORANGE, Modifier.weight(1f)) { resetFilters() }
                    CButton("Fechar", C_BLUE, Modifier.weight(1f)) {
                        selectedId = firstNavId()
                        overlay = Overlay.None
                    }
                }
            }
        ) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fFavOnly()
                        fPlat()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fGen()
                        fColl()
                        fSort()
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fFavOnly()
                    fPlat()
                    fGen()
                    fColl()
                    fSort()
                }
            }
        }
    }

    @Composable
    private fun SearchGlyph(color: Color, dim: Dp) {
        Canvas(Modifier.size(dim)) {
            val w = this.size.minDimension
            val sw = w * 0.11f
            drawCircle(color, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(width = sw))
            drawLine(color, Offset(w * 0.66f, w * 0.66f), Offset(w * 0.9f, w * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }

    // Pesquisa em tempo real (3.9.9): o grid de trás filtra enquanto você digita.
    // "Ver Resultados" mantém o filtro; fechar (B) descarta e volta ao que estava antes.
    @Composable
    private fun SearchDialog() {
        val accent = parseColor(accentHex)
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        val prev = remember { searchTerm }
        var committed by remember { mutableStateOf(false) }
        DisposableEffect(Unit) {
            onDispose { if (!committed) searchTerm = prev }
        }
        val focus = remember { FocusRequester() }
        var fieldFocused by remember { mutableStateOf(false) }
        val tvEdit = rememberTvEdit()
        val q = searchTerm
        val active = q.isNotBlank()
        val count = filteredGames().size
        val countText = when {
            !active -> if (count == 1) "1 jogo disponível" else "$count jogos disponíveis"
            count == 0 -> "0 jogos encontrados"
            count == 1 -> "1 jogo encontrado"
            else -> "$count jogos encontrados"
        }
        // Atalhos rápidos: coleções e plataformas que existem na sua biblioteca.
        val chips = (collections.filter { !isFixedCollection(it) || games.any { g -> it in g.collections } } + (if (games.any { it.genres.isEmpty() }) listOf(NO_GENRE) else emptyList()) +
            games.groupBy { it.shownPlatform }.entries.sortedByDescending { it.value.size }.map { it.key })
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
            .take(8)

        val applySearch: () -> Unit = {
            if (active && count == 0) {
                toast("Nenhum jogo encontrado")
            } else {
                committed = true
                selectedId = firstNavId()
                overlay = Overlay.None
            }
        }
        val clearSearch: () -> Unit = {
            searchTerm = ""
        }

        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .onPreviewKeyEvent { ev ->
                        val n = ev.nativeKeyEvent
                        if (n.action != KeyEvent.ACTION_DOWN) {
                            false
                        } else when (n.keyCode) {
                            KeyEvent.KEYCODE_BUTTON_Y -> {
                                clearSearch()
                                true
                            }
                            KeyEvent.KEYCODE_DPAD_CENTER -> if (fieldFocused) {
                                applySearch()
                                true
                            } else false
                            else -> false
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(if (landscape) 0.6f else 0.92f)
                        .widthIn(max = 440.dp)
                        .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                        .clip(panel)
                        .background(S_PANEL)
                        .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                        .padding(16.dp)
                ) {
                    // Cabeçalho: ícone, título com contagem e termo ativo
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                            contentAlignment = Alignment.Center
                        ) { SearchGlyph(accent, 17.dp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Pesquisar", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Text(countText, color = S_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                        }
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .widthIn(max = 120.dp)
                                .clip(CircleShape)
                                .background(S_FIELD)
                                .border(1.dp, if (active) accent else Color(0x26FFFFFF), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            MarqueeText(
                                if (active) "\"${q.trim()}\"" else "Todos",
                                if (active) accent else Color(0xFFCBD2E0), 12
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))

                    // Campo de busca
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(btn)
                            .background(if (tvEdit.selected) accent.copy(alpha = 0.16f) else S_FIELD)
                            .border(
                                if (tvEdit.selected) 3.dp else if (fieldFocused) 2.dp else 1.dp,
                                if (fieldFocused || tvEdit.selected) accent else S_LINE, btn
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SearchGlyph(S_MUTED, 16.dp)
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f).tvFieldBox(tvEdit)) {
                            if (q.isEmpty()) Text("Digite o título...", color = S_MUTED, fontSize = 14.sp, maxLines = 1)
                            BasicTextField(
                                value = q, onValueChange = { searchTerm = it }, singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium),
                                cursorBrush = SolidColor(Color.White),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { applySearch() }),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(focus)
                                    .tvFieldInput(tvEdit)
                                    .onFocusChanged { fieldFocused = it.isFocused }
                            )
                        }
                        // Microfone (4.0.8): fala o título sem abrir o teclado; o filtro ao vivo atualiza sozinho.
                        Spacer(Modifier.width(8.dp))
                        VoiceMic(q, { searchTerm = it }, accent, size = 32.dp)
                        if (q.isNotEmpty()) {
                            Spacer(Modifier.width(8.dp))
                            EBtn("Limpar", null, Color(0xFF222734), Color(0x26FFFFFF), Color(0xFFE2E6EF)) { clearSearch() }
                        }
                    }

                    // Atalhos rápidos
                    if (chips.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "RÁPIDO:", color = S_MUTED, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp, maxLines = 1, softWrap = false
                            )
                            chips.forEach { c ->
                                val on = active && q.trim().equals(c, true)
                                Box(
                                    modifier = Modifier
                                        .clip(btn)
                                        .background(if (on) accent.copy(alpha = 0.12f) else S_FIELD)
                                        .border(1.dp, if (on) accent else S_LINE, btn)
                                        .focusGlow(btn)
                                        .clickable { searchTerm = if (on) "" else c }
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        c, color = if (on) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    // Botões menores, sem quebra de linha
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(btn)
                                .background(Color(0xFF1E222B))
                                .border(1.dp, S_LINE, btn)
                                .focusGlow(btn)
                                .clickable { overlay = Overlay.None }
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(18.dp).clip(CircleShape).background(S_PAD_B), contentAlignment = Alignment.Center) {
                                Text("B", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                                    lineHeight = 10.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Fechar (B)", color = Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, softWrap = false
                            )
                        }
                        EBtn("Ver Resultados", null, accent, accent, onAccent(accent), Modifier.weight(1f).height(38.dp)) { applySearch() }
                    }
                }

                // Legenda do controle, no rodapé da tela
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF20A0C10))) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PadHint("A", "Confirmar", S_PAD_A, compact = true) { applySearch() }
                        Spacer(Modifier.width(14.dp))
                        PadHint("B", "Voltar", S_PAD_B, compact = true) { overlay = Overlay.None }
                        Spacer(Modifier.width(14.dp))
                        PadHint("Y", "Limpar", Color(0xFFF6CE48), compact = true) { clearSearch() }
                    }
                }
            }
        }
    }

    // ---------- Configurações (redesign 3.9.6: retrato sem rolagem + paisagem dedicada) ----------
    @Composable
    private fun SLabel(text: String, color: Color = S_MUTED, modifier: Modifier = Modifier, compact: Boolean = false) {
        Text(
            text, color = color, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp, modifier = modifier
        )
    }

    /** Texto de uma linha com altura de linha justa (o padrão do tema deixa o espaço entre linhas enorme). */
    @Composable
    private fun LTxt(
        text: String, size: Float, color: Color, weight: FontWeight = FontWeight.Normal,
        spacing: Float = 0f, modifier: Modifier = Modifier
    ) {
        Text(
            text, color = color, fontSize = size.sp, fontWeight = weight, letterSpacing = spacing.sp,
            maxLines = 1, softWrap = false, lineHeight = (size * 1.25f).sp,
            style = TextStyle(lineHeightStyle = CenteredLine), modifier = modifier
        )
    }

    /** Cartão da aba Visual em paisagem: conteúdo centralizado na altura disponível. */
    @Composable
    private fun LCard(
        modifier: Modifier = Modifier,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .padding(horizontal = 13.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.Center,
            content = content
        )
    }

    /** Linha de título do cartão: nome à esquerda, valor atual na cor de destaque à direita. */
    @Composable
    private fun LHead(label: String, value: String, accent: Color) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LTxt(label, 10.5f, S_MUTED, FontWeight.Bold, 0.8f, Modifier.weight(1f))
            LTxt(value, 11f, accent, FontWeight.SemiBold)
        }
    }

    /** Barra de tamanho: trilho fino, parte preenchida grossa e bolinha com borda branca. */
    @Composable
    private fun LSlider(
        value: Int, lo: Int, hi: Int, accent: Color,
        onChange: (Int) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier
    ) {
        val frac = ((value - lo).toFloat() / (hi - lo)).coerceIn(0f, 1f)
        val thumb = 14.dp
        val change by rememberUpdatedState(onChange)
        val done by rememberUpdatedState(onDone)
        val shape = RoundedCornerShape(12.dp)
        BoxWithConstraints(
            modifier = modifier
                .height(28.dp)
                .clip(shape)
                .focusGlow(shape)
                .onPreviewKeyEvent { ev ->
                    val k = ev.nativeKeyEvent
                    if (k.action == android.view.KeyEvent.ACTION_DOWN &&
                        (k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT || k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT)
                    ) {
                        val d = if (k.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT) -5 else 5
                        change((value + d).coerceIn(lo, hi))
                        done()
                        true
                    } else false
                }
                .focusable()
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        val tp = thumb.toPx()
                        val f = ((off.x - tp / 2f) / (size.width - tp).coerceAtLeast(1f)).coerceIn(0f, 1f)
                        change((lo + f * (hi - lo)).roundToInt())
                        done()
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(onDragEnd = { done() }, onDragCancel = { done() }) { c, _ ->
                        c.consume()
                        val tp = thumb.toPx()
                        val f = ((c.position.x - tp / 2f) / (size.width - tp).coerceAtLeast(1f)).coerceIn(0f, 1f)
                        change((lo + f * (hi - lo)).roundToInt())
                    }
                },
            contentAlignment = Alignment.CenterStart
        ) {
            val travel = maxWidth - thumb
            Box(Modifier.fillMaxWidth().height(2.dp).clip(CircleShape).background(Color(0xFF334155)))
            Box(Modifier.width(travel * frac + thumb / 2).height(6.dp).clip(CircleShape).background(accent))
            Box(
                Modifier
                    .offset(x = travel * frac)
                    .size(thumb)
                    .shadow(6.dp, CircleShape, ambientColor = accent, spotColor = accent)
                    .clip(CircleShape)
                    .background(accent)
                    .border(2.dp, Color.White, CircleShape)
            )
        }
    }

    @Composable
    private fun SCard(
        modifier: Modifier = Modifier, pad: Dp = 14.dp,
        content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .padding(pad),
            content = content
        )
    }

    @Composable
    private fun SChip(text: String, accent: Color) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.14f))
                .border(1.dp, accent.copy(alpha = 0.45f), CircleShape)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(text, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun SSwitch(on: Boolean, accent: Color) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(28.dp)
                .clip(CircleShape)
                .background(if (on) accent else Color(0xFF2A2F3D))
                .border(2.dp, if (on) accent else Color(0xFF4B5267), CircleShape)
                .padding(horizontal = 4.dp),
            contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .size(if (on) 18.dp else 16.dp)
                    .clip(CircleShape)
                    .background(if (on) Color(0xFF080A0F) else S_MUTED)
            )
        }
    }

    @Composable
    private fun Swatch(hex: String, size: Dp = 44.dp, tight: Boolean = false) {
        val sel = accentHex.equals(hex, true)
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .focusGlow(CircleShape)
                .clickable {
                    accentHex = hex
                    savePrefs()
                },
            contentAlignment = Alignment.Center
        ) {
            if (sel) Box(Modifier.size(size - 2.dp).border(2.dp, Color.White, CircleShape))
            Box(
                Modifier.size(if (sel) size - (if (tight) 8.dp else 10.dp) else size - (if (tight) 2.dp else 6.dp))
                    .clip(CircleShape).background(parseColor(hex))
            )
        }
    }

    @Composable
    private fun CatalogTile(
        glyph: String, title: String, sub: String, count: Int, modifier: Modifier,
        compact: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        if (compact) {
            Row(
                modifier = modifier
                    .clip(shape)
                    .background(S_CARD)
                    .border(1.dp, S_LINE, shape)
                    .focusGlow(shape)
                    .clickable(onClick = onClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(30.dp).clip(CircleShape).background(S_FIELD),
                    contentAlignment = Alignment.Center
                ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    MarqueeText(title, Color.White, 13)
                    MarqueeText(sub, S_MUTED, 10, FontWeight.Normal)
                }
                Spacer(Modifier.width(6.dp))
                Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 8.dp, vertical = 3.dp)) {
                    Text("$count", color = S_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
            return
        }
        Column(
            modifier = modifier
                .clip(shape)
                .background(S_CARD)
                .border(1.dp, S_LINE, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .height(128.dp)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(S_FIELD),
                    contentAlignment = Alignment.Center
                ) { Text(glyph, color = Color(0xFFD5DAE5), fontSize = 16.sp) }
                Spacer(Modifier.weight(1f))
                Box(Modifier.clip(CircleShape).background(S_FIELD).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text("$count", color = S_MUTED, fontSize = if (compact) 12.sp else 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column {
                MarqueeText(title, Color.White, 15)
                MarqueeText(sub, S_MUTED, 11, FontWeight.Normal)
            }
        }
    }

    @Composable
    private fun ActionRow(
        glyph: String, title: String, sub: String,
        bg: Color, border: Color, iconBg: Color, iconFg: Color,
        titleColor: Color = Color.White, chevron: Boolean = true,
        modifier: Modifier = Modifier, compact: Boolean = false, onClick: () -> Unit
    ) {
        val shape = RoundedCornerShape(rCard.dp)
        val ib = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = if (compact) 12.dp else 14.dp, vertical = if (compact) 4.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 34.dp else 44.dp).clip(ib).background(iconBg),
                contentAlignment = Alignment.Center
            ) { Text(glyph, color = iconFg, fontSize = if (compact) 17.sp else 20.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = titleColor, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.Bold,
                    lineHeight = if (compact) 16.sp else 19.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                Text(sub, color = S_MUTED, fontSize = if (compact) 10.sp else 12.sp,
                    lineHeight = if (compact) 13.sp else 15.sp, style = TextStyle(lineHeightStyle = CenteredLine))
            }
            if (chevron) {
                Spacer(Modifier.width(8.dp))
                Text("›", color = parseColor(accentHex), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    private fun PadHint(letter: String, label: String, color: Color, compact: Boolean = false, onClick: (() -> Unit)?) {
        // Mesmo tamanho dos botões do rodapé da tela inicial (PadButton).
        val shape = RoundedCornerShape(rBtn.dp)
        val fg = when (letter) {
            "Y" -> Color(0xFF1A1202)
            "A" -> Color(0xFF05140B)
            else -> Color.White
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(Color(0xEB161A23))
                .border(1.dp, Color(0x17FFFFFF), shape)
                .focusGlow(shape)
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 10.dp)
        ) {
            Box(
                modifier = Modifier.size(16.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    letter, color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 9.5.sp,
                    lineHeight = 9.5.sp, style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                label, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, softWrap = false,
                lineHeight = 11.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
    }

    @Composable
    private fun KeyCap(label: String, onClick: () -> Unit) {
        val shape = RoundedCornerShape(5.dp)
        Box(
            modifier = Modifier
                .clip(shape)
                .background(Color(0x1AFFFFFF))
                .focusGlow(shape)
                .clickable(onClick = onClick)
                .padding(horizontal = 5.dp, vertical = 1.dp)
        ) { Text(label, color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold) }
    }

    @Composable
    private fun LRHint() {
        val shape = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = Modifier
                .height(26.dp)
                .clip(shape)
                .background(Color(0xEB161A23))
                .border(1.dp, Color(0x17FFFFFF), shape)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KeyCap("L1") { settingsTab = (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS }
            Spacer(Modifier.width(4.dp))
            KeyCap("R1") { settingsTab = (settingsTab + 1) % SETTINGS_TABS }
            Spacer(Modifier.width(6.dp))
            Text("Abas", color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun SettingsTabs(accent: Color, compact: Boolean) {
        val outer = RoundedCornerShape((if (compact) rBtn else rCard).dp)
        val inner = RoundedCornerShape(rBtn.dp)
        val tabs = listOf("◐" to "Visual", "▦" to "Biblioteca", "▤" to "Sistema", "✦" to "Extras")
        Row(
            modifier = (if (compact) Modifier else Modifier.fillMaxWidth())
                .clip(outer)
                .background(S_FIELD)
                .border(1.dp, S_LINE, outer)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEachIndexed { i, t ->
                val sel = settingsTab == i
                val fg = if (sel) onAccent(accent) else S_MUTED
                Row(
                    modifier = (if (compact) Modifier.height(30.dp) else Modifier.weight(t.second.length + (if (sel) 2.5f else 0f)).height(40.dp))
                        .clip(inner)
                        .background(if (sel) accent else Color.Transparent)
                        .focusGlow(inner)
                        .clickable {
                        settingsTab = i
                    }
                        .padding(horizontal = if (compact) 12.dp else 2.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Com 4 abas, o retrato usa letras um pouco menores para tudo caber na largura.
                    // Retrato: a aba escolhida fica mais larga e mostra o ícone; as outras mostram só o nome inteiro.
                    if (compact || sel) {
                        Text(t.first, color = fg, fontSize = if (compact) 12.sp else 11.sp)
                        Spacer(Modifier.width(if (compact) 5.dp else 3.dp))
                    }
                    Text(t.second, color = fg, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
            }
        }
    }

    @Composable
    private fun CornerOptions(compact: Boolean, vpad: Dp = 12.dp, land: Boolean = false) {
        val style = styleIdx
        val accent = parseColor(accentHex)
        val btn = RoundedCornerShape(rBtn.dp)
        if (land) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Reto", "Padrão", "Suave").forEachIndexed { i, name ->
                    val sel = style == i
                    val fg = if (sel) Color.White else Color(0xFFCBD2E0)
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(btn)
                            .background(if (sel) accent.copy(alpha = 0.15f) else S_FIELD)
                            .border(1.dp, if (sel) accent else S_LINE, btn)
                            .focusGlow(btn)
                            .clickable {
                                radius = intArrayOf(4, 14, 22)[i]
                                savePrefs()
                            },
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(16.dp).height(10.dp).border(1.5.dp, fg, RoundedCornerShape(intArrayOf(0, 3, 5)[i].dp)))
                        Spacer(Modifier.width(6.dp))
                        LTxt(name, 11f, fg, FontWeight.SemiBold)
                    }
                }
            }
            return
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Reto", "Padrão", "Suave").forEachIndexed { i, name ->
                val sel = style == i
                val mod = Modifier
                    .weight(1f)
                    .clip(btn)
                    .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
                    .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
                    .focusGlow(btn)
                    .clickable {
                        radius = intArrayOf(4, 14, 22)[i]
                        savePrefs()
                    }
                val icon: @Composable () -> Unit = {
                    Box(
                        Modifier
                            .width(if (compact) 14.dp else 24.dp)
                            .height(if (compact) 10.dp else 16.dp)
                            .border(2.dp, if (sel) Color.White else S_MUTED, RoundedCornerShape(intArrayOf(2, 6, 8)[i].dp))
                    )
                }
                val txtColor = if (sel) Color.White else Color(0xFFCBD2E0)
                if (compact) {
                    Row(
                        modifier = mod.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        icon()
                        Spacer(Modifier.width(6.dp))
                        Text(name, color = txtColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            lineHeight = 13.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                    }
                } else {
                    Column(modifier = mod.padding(vertical = vpad), horizontalAlignment = Alignment.CenterHorizontally) {
                        icon()
                        Spacer(Modifier.height(if (vpad < 12.dp) 3.dp else 6.dp))
                        Text(name, color = txtColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            lineHeight = 16.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                    }
                }
            }
        }
    }

    @Composable
    private fun ColorsCard(accent: Color, land: Boolean, modifier: Modifier = Modifier) {
        SCard(modifier, if (land) 12.dp else 14.dp) {
            val colorName = ACCENTS.firstOrNull { it.second.equals(accentHex, true) }?.first ?: "Personalizada"
            if (land) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    LTxt("COR DA BORDA & LED", 10.5f, S_MUTED, FontWeight.Bold, 0.8f, Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.15f))
                            .border(1.dp, accent, CircleShape)
                            .padding(horizontal = 11.dp),
                        contentAlignment = Alignment.Center
                    ) { LTxt(colorName, 11f, accent, FontWeight.Bold) }
                }
                Spacer(Modifier.height(3.dp))
                LTxt("Destaque dinâmico da interface", 10f, S_MUTED)
            } else {
                // O nome da cor fica colado ao título, assim a descrição nunca quebra de linha.
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SLabel("COR DA BORDA & LED")
                        Spacer(Modifier.width(10.dp))
                        SChip(colorName, accent)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("Destaque dinâmico da interface", color = S_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                }
            }
            if (land) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    // Cinco colunas iguais; o tamanho segue a altura disponível (no máximo 36dp).
                    val sw = minOf(36.dp, (maxHeight - 10.dp) / 2, maxWidth / 5)
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                        ACCENTS.chunked(5).forEach { rowItems ->
                            Row(Modifier.fillMaxWidth()) {
                                rowItems.forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Swatch(it.second, sw, tight = true) } }
                            }
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(10.dp))
                ACCENTS.chunked(5).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        rowItems.forEach { Swatch(it.second) }
                    }
                }
            }
        }
    }

    @Composable
    private fun CameraCard(sub: String, compact: Boolean, modifier: Modifier = Modifier) {
        val accent = parseColor(accentHex)
        val card = RoundedCornerShape(rCard.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clip(card)
                .background(S_CARD)
                .border(1.dp, S_LINE, card)
                .focusGlow(card)
                .clickable {
                    cutoutPad = !cutoutPad
                    savePrefs()
                }
                .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 6.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 30.dp else 44.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "📷", fontSize = if (compact) 14.sp else 19.sp,
                    lineHeight = if (compact) 16.sp else 24.sp, style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
            Spacer(Modifier.width(if (compact) 10.dp else 12.dp))
            if (compact) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    LTxt("Recuar área da câmera", 11.5f, Color.White, FontWeight.Bold)
                    LTxt(sub, 9.5f, S_MUTED)
                }
                Spacer(Modifier.width(10.dp))
                // Chave 40x20, como no desenho de referência.
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(20.dp)
                        .clip(CircleShape)
                        .background(if (cutoutPad) accent else Color(0xFF242C3D))
                        .padding(2.dp),
                    contentAlignment = if (cutoutPad) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        Modifier.size(16.dp).clip(CircleShape)
                            .background(if (cutoutPad) Color.White else Color(0xFF94A3B8))
                    )
                }
            } else {
                Column(Modifier.weight(1f)) {
                    Text("Recuar área da câmera", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2)
                    Text(sub, color = S_MUTED, fontSize = 12.sp, maxLines = 2)
                }
                Spacer(Modifier.width(12.dp))
                SSwitch(cutoutPad, accent)
            }
        }
    }

    @Composable
    private fun DashOption(label: String, mode: Int, glyph: String?, accent: Color, modifier: Modifier, land: Boolean = false) {
        val btn = RoundedCornerShape(rBtn.dp)
        val sel = dashMode == mode
        val pick = {
            if (dashMode != mode) {
                dashMode = mode
                dashPlatform = ""
                selectedId = firstNavId()
                savePrefs()
            }
        }
        if (land) {
            Row(
                modifier = modifier
                    .height(36.dp)
                    .clip(btn)
                    .background(if (sel) accent.copy(alpha = 0.15f) else S_FIELD)
                    .border(1.dp, if (sel) accent else S_LINE, btn)
                    .focusGlow(btn)
                    .clickable { pick() }
                    .padding(horizontal = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LTxt(label, 11.5f, if (sel) Color.White else Color(0xFFCBD2E0), FontWeight.Medium, 0f, Modifier.weight(1f))
                if (sel) Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
            }
            return
        }
        Row(
            modifier = modifier
                .heightIn(min = 44.dp)
                .clip(btn)
                .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
                .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
                .focusGlow(btn)
                .clickable { pick() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (glyph != null) {
                Text(glyph, color = if (sel) accent else S_MUTED, fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
            }
            Text(
                label, color = if (sel) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                modifier = Modifier.weight(1f)
            )
            if (sel) {
                Spacer(Modifier.width(4.dp))
                Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            }
        }
    }

    @Composable
    private fun SgdbCard(accent: Color, modifier: Modifier = Modifier, compact: Boolean = false) {
        SCard(modifier, if (compact) 10.dp else 14.dp) {
            if (compact) {
                SLabel("STEAMGRIDDB (CAPAS E DADOS)", compact = true)
                Spacer(Modifier.height(6.dp))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(sgdbKey, { v ->
                    sgdbKey = v.trim()
                    prefs.edit().putString("sgdbKey", sgdbKey).apply()
                }, "Cole sua chave aqui", Modifier.weight(1f), mic = false)
                // 4.7.1: o "Colar" fica FORA da caixa (o D-pad da TV alcança sem abrir o teclado).
                CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                    val t = clipboardText().trim()
                    if (t.isEmpty()) toast("Nada copiado para colar") else {
                        sgdbKey = t
                        prefs.edit().putString("sgdbKey", sgdbKey).apply()
                        toast("Chave colada")
                    }
                }
                CButton("Testar", C_BLUE, Modifier.width(76.dp)) { testSgdbKey() }
            }
            Text(
                "Criar chave grátis (steamgriddb.com)", color = accent, fontSize = 12.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier
                    .clickable { openUrl("https://www.steamgriddb.com/profile/preferences/api") }
                    .padding(top = 6.dp)
            )
            // 4.7.0: crédito movido da tela de detalhes para cá.
            Text(
                "Capas e dados dos jogos: SteamGridDB (steamgriddb.com)", color = S_MUTED, fontSize = if (compact) 10.sp else 11.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier
                    .clickable { openUrl("https://www.steamgriddb.com") }
                    .padding(top = 4.dp)
            )
        }
    }

    // 4.7.0: chave da API do YouTube. O "Colar" fica FORA da caixa para o D-pad alcançar sem abrir o teclado.
    @Composable
    private fun YouTubeCard(accent: Color, modifier: Modifier = Modifier, compact: Boolean = false) {
        SCard(modifier, if (compact) 10.dp else 14.dp) {
            if (compact) {
                SLabel("YOUTUBE (VÍDEO GAMEPLAY)", compact = true)
                Spacer(Modifier.height(6.dp))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(ytKey, { v ->
                    ytKey = v.trim()
                    prefs.edit().putString("ytKey", ytKey).apply()
                }, "Cole sua chave aqui", Modifier.weight(1f), mic = false)
                CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                    val t = clipboardText().trim()
                    if (t.isEmpty()) toast("Nada copiado para colar") else {
                        ytKey = t
                        prefs.edit().putString("ytKey", ytKey).apply()
                        toast("Chave colada")
                    }
                }
                CButton("Testar", C_BLUE, Modifier.width(76.dp)) { testYtKey() }
            }
            Text(
                "Criar chave grátis (Google Cloud › YouTube Data API v3)", color = accent, fontSize = if (compact) 11.sp else 12.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier
                    .clickable { openUrl("https://console.cloud.google.com/apis/library/youtube.googleapis.com") }
                    .padding(top = 6.dp)
            )
            Text(
                "Cada jogo faz 1 busca (a 1ª vez que abre os detalhes). Cota grátis: ~100 buscas por dia.",
                color = S_MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp)
            )
        }
    }

    // ----- Retrato: tudo cabe na tela, sem rolagem e sem texto cortado -----
    @Composable
    private fun TabVisual(accent: Color) {
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("TELA INICIAL", modifier = Modifier.weight(1f))
                Text(if (dashMode == 1) "Plataformas" else "Todos os Jogos", color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashOption("Plataformas", 1, null, accent, Modifier.weight(1f))
                DashOption("Todos os Jogos", 0, null, accent, Modifier.weight(1f))
            }
        }
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SLabel("ESTILO DAS BORDAS", modifier = Modifier.weight(1f))
                Text(listOf("Reto", "Padrão", "Suave")[styleIdx], color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            CornerOptions(false)
        }
        ColorsCard(accent, false)
        if (!TvMode.isTv) CameraCard("Evita corte pelo furo frontal", false)
    }

    @Composable
    private fun TabLibrary(accent: Color) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("🎮", "Apps de jogos", "Escolha o que é jogo", allApps.count { it.pkg !in hiddenGameApps }, Modifier.weight(1f)) { appFilterKind = 1 }
            CatalogTile("🧩", "Apps emuladores", "Escolha o que é emulador", allApps.count { it.pkg !in hiddenEmuApps }, Modifier.weight(1f)) { appFilterKind = 2 }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            SLabel("GERENCIAR CATÁLOGO", modifier = Modifier.weight(1f))
            Text("Toque para editar", color = S_MUTED, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f)) { overlay = Overlay.Genres }
            CatalogTile("▣", "Coleções", "${userCollectionCount()} criadas", userCollectionCount(), Modifier.weight(1f)) { overlay = Overlay.Collections }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("🖼", "Capas em lote", "SteamGridDB", coverMissingCount(), Modifier.weight(1f)) { overlay = Overlay.CoverBatchSetup }
            CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f)) { overlay = Overlay.Platforms }
        }
        Text(
            "Total de jogos no catálogo: ${games.size}", color = S_MUTED, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, bottom = 10.dp), textAlign = TextAlign.Center
        )
    }

    @Composable
    private fun TabSystem(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        val danger = Color(0xFFFF5A72)
        SLabel("BACKUP & RESTAURAÇÃO", modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
            bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent)) { doExport() }
        ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { doImport() }
        SLabel("STEAMGRIDDB (CAPAS E DADOS DOS JOGOS)", modifier = Modifier.padding(horizontal = 2.dp))
        SgdbCard(accent)
        SLabel("YOUTUBE (VÍDEO GAMEPLAY)", modifier = Modifier.padding(horizontal = 2.dp))
        YouTubeCard(accent)
        SLabel("ZONA DE PERIGO", color = danger, modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("🗑", "Resetar Jogos", "Apaga os jogos da tela inicial (todos ou por plataforma). Mantém vínculos, apps, gêneros, coleções e chaves de API",
            bg = Color(0x1AFF375F), border = Color(0x66FF375F), iconBg = Color(0x33FF375F), iconFg = danger,
            titleColor = danger, chevron = false) { overlay = Overlay.ResetGames }
        ActionRow("⚠", "Restaurar configurações de fábrica", "Apaga TUDO: jogos, configurações, vínculos e chaves de API. O Nexus reinicia",
            bg = Color(0x1AFF375F), border = Color(0x66FF375F), iconBg = Color(0x33FF375F), iconFg = danger,
            titleColor = danger, chevron = false) { overlay = Overlay.ConfirmFactory }
    }

    // ---------- Aba Extras (4.3.0) ----------
    @Composable
    private fun SwitchCard(
        glyph: String, title: String, sub: String, on: Boolean, compact: Boolean,
        modifier: Modifier = Modifier, enabled: Boolean = true, iconRes: Int? = null, onToggle: () -> Unit
    ) {
        val accent = parseColor(accentHex)
        val card = RoundedCornerShape(rCard.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .alpha(if (enabled) 1f else 0.4f)
                .clip(card)
                .background(S_CARD)
                .border(1.dp, S_LINE, card)
                .focusGlow(card)
                .clickable(enabled = enabled, onClick = onToggle)
                .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 6.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 30.dp else 44.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                contentAlignment = Alignment.Center
            ) {
                if (iconRes != null) {
                    Image(
                        painter = painterResource(iconRes), contentDescription = null, contentScale = ContentScale.Fit,
                        colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(accent),
                        modifier = Modifier.size(if (compact) 20.dp else 28.dp)
                    )
                } else Text(
                    glyph, fontSize = if (compact) 14.sp else 19.sp,
                    lineHeight = if (compact) 16.sp else 24.sp, style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
            Spacer(Modifier.width(if (compact) 10.dp else 12.dp))
            if (compact) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    LTxt(title, 11.5f, Color.White, FontWeight.Bold)
                    LTxt(sub, 9.5f, S_MUTED)
                }
                Spacer(Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(20.dp)
                        .clip(CircleShape)
                        .background(if (on) accent else Color(0xFF242C3D))
                        .padding(2.dp),
                    contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(if (on) Color.White else Color(0xFF94A3B8)))
                }
            } else {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text(sub, color = S_MUTED, fontSize = 12.sp, maxLines = 2)
                }
                Spacer(Modifier.width(12.dp))
                SSwitch(on, accent)
            }
        }
    }

    @Composable
    private fun TabExtras(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        SLabel("VISUAL", modifier = Modifier.padding(horizontal = 2.dp))
        // 4.7.7: o carrossel agora é escolhido pelo olho do cabeçalho (celular deitado e TV).
        SwitchCard("✨", "Animação de abertura", "Desligue para o app abrir mais rápido", introOn, false) { applyIntroOn(!introOn) }
        if (!TvMode.isRealTv) {
            SwitchCard("📺", "Modo TV", "Interface para controle remoto. Reabra o Nexus para ajustar o tamanho", TvMode.isForced, false) {
                TvMode.setForced(this@MainActivity, !TvMode.isForced)
            }
        }
        SLabel("PAINEL FLUTUANTE", modifier = Modifier.padding(horizontal = 2.dp))
        SwitchCard("📌", "Temperatura sobre qualquer app",
            if (TvMode.isTv) "Painel com a temperatura do aparelho" else "Painel arrastável com temperatura e bateria",
            FloatState.on, false) { toggleFloat() }
        SwitchCard("📏", "Painel flutuante menor", if (FloatState.on) "Painel compacto, ainda legível" else "Ligue o painel flutuante para usar",
            floatSmall, false, enabled = FloatState.on) { applyFloatSmall(!floatSmall) }
        Text(
            if (TvMode.isTv) "Também liga e desliga pela temperatura no cabeçalho. Avisa quando o aparelho esquenta demais."
            else "Também liga e desliga tocando na temperatura/bateria do cabeçalho. Avisa e vibra quando o aparelho esquenta demais.",
            color = S_MUTED, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp)
        )
        // TV: launcher padrão, apps ocultos e configurações do Android são coisas de celular e ficam escondidos.
        if (!TvMode.isTv) SLabel("LAUNCHER", modifier = Modifier.padding(horizontal = 2.dp))
        if (TvMode.isTv) {
            // sem opções de launcher na TV
        } else if (!isHome) {
            ActionRow("⌂", "Definir como launcher padrão", "Use o Nexus como tela inicial do aparelho",
                bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent)) { askDefaultLauncher() }
            Text(
                "Com o Nexus como launcher padrão, aparecem aqui os apps ocultos e o acesso às configurações do Android.",
                color = S_MUTED, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp)
            )
        } else {
            ActionRow("⌂", "Launcher padrão ativo", "O Nexus é a tela inicial do aparelho",
                bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent), chevron = false) { }
            SLabel("MODO LAUNCHER", modifier = Modifier.padding(horizontal = 2.dp))
            ActionRow("▦", "Apps ocultos", "Todos os apps do aparelho, abertos por aqui",
                bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { appsDrawerOpen = true }
            ActionRow("⚙", "Configurações do Android", "Abre as configurações originais do aparelho",
                bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { openSystemSettings() }
            ActionRow("⇄", "Trocar launcher padrão", "Escolher outro launcher do aparelho",
                bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { openHomeSettings() }
        }
    }

    @Composable
    private fun TabExtrasL(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        // Cada coluna rola se precisar; nenhum cartão é espremido: todos têm altura própria.
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SwitchCard("✨", "Animação de abertura", "Desligue para abrir mais rápido", introOn, true, Modifier.height(54.dp)) { applyIntroOn(!introOn) }
                SwitchCard("📌", "Painel flutuante", "Temperatura sobre qualquer app", FloatState.on, true, Modifier.height(54.dp)) { toggleFloat() }
                // "Painel flutuante menor" fica SEMPRE logo abaixo de "Painel flutuante", aconteça o que acontecer.
                SwitchCard("📏", "Painel flutuante menor", if (FloatState.on) "Painel compacto, ainda legível" else "Ligue o painel flutuante",
                    floatSmall, true, Modifier.height(54.dp), enabled = FloatState.on) { applyFloatSmall(!floatSmall) }
                if (!TvMode.isRealTv) {
                    SwitchCard("📺", "Modo TV", "Controle remoto. Reabra o Nexus", TvMode.isForced, true, Modifier.height(54.dp)) {
                        TvMode.setForced(this@MainActivity, !TvMode.isForced)
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (TvMode.isTv) {
                    // sem opções de launcher na TV
                } else if (!isHome) {
                    ActionRow("⌂", "Definir como launcher padrão", "Use o Nexus como tela inicial do aparelho",
                        bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent),
                        modifier = Modifier.height(60.dp), compact = true) { askDefaultLauncher() }
                    Text(
                        "Com o Nexus como launcher padrão, aparecem aqui os apps ocultos e o acesso às configurações do Android.",
                        color = S_MUTED, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp)
                    )
                } else {
                    ActionRow("⌂", "Launcher padrão ativo", "O Nexus é a tela inicial do aparelho",
                        bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent), chevron = false,
                        modifier = Modifier.height(54.dp), compact = true) { }
                    ActionRow("▦", "Apps ocultos", "Todos os apps do aparelho, abertos por aqui",
                        bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                        modifier = Modifier.height(54.dp), compact = true) { appsDrawerOpen = true }
                    ActionRow("⚙", "Configurações do Android", "Abre as configurações originais do aparelho",
                        bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                        modifier = Modifier.height(54.dp), compact = true) { openSystemSettings() }
                    ActionRow("⇄", "Trocar launcher padrão", "Escolher outro launcher do aparelho",
                        bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                        modifier = Modifier.height(54.dp), compact = true) { openHomeSettings() }
                }
            }
        }
    }

    // Lista de TODOS os apps do aparelho (o "Apps ocultos" do modo launcher): tocar abre o app.
    @Composable
    private fun AppsDrawerDialog() {
        var q by remember { mutableStateOf("") }
        val apps = remember { loadApps().filter { it.pkg != packageName } }
        val k = foldText(q.trim())
        val list = if (k.isEmpty()) apps else apps.filter { foldText(it.label).contains(k) || it.pkg.lowercase().contains(k) }
        NexusModal("Apps ocultos", { appsDrawerOpen = false }, tall = true) {
            val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                Text(
                    "Todos os apps instalados. Toque para abrir. O botão ⓘ abre as informações do app no Android.",
                    color = C_MUTED, fontSize = 11.sp
                )
                Spacer(Modifier.height(6.dp))
                CField(q, { q = it }, "🔍 Buscar app", Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text("${list.size} apps", color = C_MUTED, fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(list, key = { it.pkg }) { a ->
                        Row(
                            modifier = Modifier.fillMaxWidth().cardRow { launchApp(a.pkg) },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AppIcon(a.pkg)
                            Column(Modifier.weight(1f)) {
                                MarqueeText(a.label, Color.White, 14, FontWeight.Normal)
                            }
                            MiniIcon("ⓘ", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { openAppInfo(a.pkg) }
                        }
                    }
                }
            }
            if (landscape) {
                Panes(0.38f, {
                    topUi()
                    Spacer(Modifier.height(8.dp))
                    CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appsDrawerOpen = false }
                }, { listUi() })
            } else {
                topUi()
                listUi()
                Spacer(Modifier.height(8.dp))
                CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) { appsDrawerOpen = false }
            }
        }
    }

    private fun doExport() {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (TvMode.isTv) {
            // TV: escolhe a pasta no explorador do Nexus e grava o arquivo lá.
            explorer = ExplorerState(true, "Salvar o backup em qual pasta?", null, null) { dir ->
                writeBackup(Uri.fromFile(File(dir, "nexus_backup_$d.json")))
            }
            return
        }
        exportLauncher.launch("nexus_backup_$d.json")
    }

    private fun doImport() {
        if (TvMode.isTv) {
            explorer = ExplorerState(false, "Escolher o arquivo de backup (.json)", setOf("json"), null) { f ->
                readBackup(Uri.fromFile(f))
            }
            return
        }
        importLauncher.launch(arrayOf("*/*"))
    }

    private fun doStorage() {
        if (storageOk) toast("O acesso ao armazenamento já está concedido") else askStorage()
    }

    // ----- Paisagem: layout em duas colunas, igual ao protótipo, sem rolagem -----
    @Composable
    private fun TabVisualL(accent: Color) {
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                LCard(Modifier.weight(1f)) {
                    LHead("TELA INICIAL", if (dashMode == 1) "Plataformas" else "Todos os Jogos", accent)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DashOption("Plataformas", 1, null, accent, Modifier.weight(1f), land = true)
                        DashOption("Todos os Jogos", 0, null, accent, Modifier.weight(1f), land = true)
                    }
                }
                LCard(Modifier.weight(1f)) {
                    LHead("ESTILO DAS BORDAS", listOf("Reto", "Padrão", "Suave")[styleIdx], accent)
                    Spacer(Modifier.height(6.dp))
                    CornerOptions(false, land = true)
                }
                LCard(Modifier.weight(1f)) {
                    LHead("TAMANHO DAS CAPAS", "${widthL}px", accent)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LTxt("110px", 10f, S_MUTED, FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        LSlider(
                            value = widthL, lo = 110, hi = 260, accent = accent,
                            onChange = { v -> widthL = v },
                            onDone = { savePrefs() },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        LTxt("260px", 10f, S_MUTED, FontWeight.SemiBold)
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ColorsCard(accent, true, Modifier.weight(1f))
                if (!TvMode.isTv) CameraCard("Evita corte pelo furo frontal", true, Modifier.height(52.dp))
            }
        }
    }

    @Composable
    private fun TabLibraryL(accent: Color) {
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CatalogTile("🎮", "Apps de jogos", "Escolha o que é jogo", allApps.count { it.pkg !in hiddenGameApps }, Modifier.weight(1f).fillMaxWidth(), true) { appFilterKind = 1 }
                CatalogTile("🧩", "Apps emuladores", "Escolha o que é emulador", allApps.count { it.pkg !in hiddenEmuApps }, Modifier.weight(1f).fillMaxWidth(), true) { appFilterKind = 2 }
            }
            Column(Modifier.weight(7f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Genres }
                    CatalogTile("▣", "Coleções", "${userCollectionCount()} criadas", userCollectionCount(), Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Collections }
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CatalogTile("🖼", "Capas em lote", "SteamGridDB", coverMissingCount(), Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.CoverBatchSetup }
                    CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f).fillMaxHeight(), true) { overlay = Overlay.Platforms }
                }
                Text(
                    "Total de jogos no catálogo: ${games.size}", color = S_MUTED, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    private fun TabSystemL(accent: Color) {
        val soft = accent.copy(alpha = 0.14f)
        val edge = accent.copy(alpha = 0.45f)
        val danger = Color(0xFFFF5A72)
        val shape = RoundedCornerShape(rCard.dp)
        // 4.7.8: coluna da esquerda: backup, SteamGridDB e (embaixo dele) YouTube; coluna da direita: zona de perigo.
        // Alturas naturais: a aba inteira rola na vertical quando não cabe.
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(7f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
                    bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent),
                    modifier = Modifier.height(58.dp), compact = true) { doExport() }
                ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.height(58.dp), compact = true) { doImport() }
                SgdbCard(accent, compact = true)
                YouTubeCard(accent, compact = true)
            }
            Column(Modifier.weight(5f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Color(0x1AFF375F))
                        .border(1.dp, Color(0x66FF375F), shape)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\u26A0\uFE0E", color = danger, fontSize = 13.sp)
                        Spacer(Modifier.width(6.dp))
                        SLabel("ZONA DE PERIGO", danger, compact = true)
                    }
                    Column {
                        Text("Resetar Jogos", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Apaga os jogos da tela inicial, todos ou de uma plataforma. Mantém vínculos, apps de jogos e emuladores, gêneros, coleções e chaves de API.",
                            color = Color(0xB3FFC9D1), fontSize = 10.sp
                        )
                    }
                    DangerButton("Resetar Jogos", Color(0xE6E11D48)) { overlay = Overlay.ResetGames }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x33FF375F)))
                    Column {
                        Text("Restaurar configurações de fábrica", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Apaga TUDO: jogos, configurações, vínculos, gêneros, coleções e chaves de API. O Nexus reinicia. Seus arquivos de ROM não são apagados.",
                            color = Color(0xB3FFC9D1), fontSize = 10.sp
                        )
                    }
                    DangerButton("Restaurar de fábrica", Color(0xFF9F1239)) { overlay = Overlay.ConfirmFactory }
                }
            }
        }
    }

    @Composable
    private fun DangerButton(label: String, bg: Color, onClick: () -> Unit) {
        val btn = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(btn)
                .background(bg)
                .focusGlow(btn)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }

    @Composable
    private fun SettingsLandscape(accent: Color) {
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                // Cabeçalho compacto: título à esquerda, abas e fechar à direita
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(btn)
                            .background(accent.copy(alpha = 0.14f))
                            .border(1.dp, accent.copy(alpha = 0.45f), btn),
                        contentAlignment = Alignment.Center
                    ) { Text("\u2699\uFE0E", color = accent, fontSize = 16.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        LTxt("Configurações do Nexus", 14f, Color.White, FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        LTxt("Frontend & Launcher • v$APP_VERSION", 10f, S_MUTED, FontWeight.Medium)
                    }
                    SettingsTabs(accent, true)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))

                // 4.7.7: a paisagem também rola na vertical. Cada aba tem uma altura mínima (a que ela precisa para
                // não espremer os cartões); se a janela for mais baixa que isso, o conteúdo rola.
                BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp)) {
                    val avail = maxHeight
                    val minH = if (settingsTab == 2) 340.dp else 270.dp
                    key(settingsTab) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                            // Aba Sistema: altura natural (rola se passar da janela); as outras ocupam a janela.
                            Box(Modifier.fillMaxWidth().then(if (settingsTab == 2) Modifier else Modifier.height(if (avail > minH) avail else minH))) {
                                when (settingsTab) {
                                    0 -> TabVisualL(accent)
                                    1 -> TabLibraryL(accent)
                                    2 -> TabSystemL(accent)
                                    else -> TabExtrasL(accent)
                                }
                            }
                        }
                    }
                }

                // Rodapé central: L1/R1 Abas, A Selecionar, B Voltar
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xF20E1017))
                        .padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LRHint()
                    Spacer(Modifier.width(14.dp))
                    PadHint("A", "Selecionar", S_PAD_A, compact = true, onClick = null)
                    Spacer(Modifier.width(14.dp))
                    PadHint("B", "Voltar", S_PAD_B, compact = true) { overlay = Overlay.None }
                }
            }
        }
    }

    @Composable
    private fun SettingsPortrait(accent: Color) {
        val panel = RoundedCornerShape(rPanel.dp)
        val btn = RoundedCornerShape(rBtn.dp)
        Box(
            modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.95f)
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(btn)
                                .background(accent.copy(alpha = 0.14f))
                                .border(1.dp, accent.copy(alpha = 0.45f), btn),
                            contentAlignment = Alignment.Center
                        ) { Text("\u2699\uFE0E", color = accent, fontSize = 20.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Configurações do Nexus", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("Frontend & Launcher • v$APP_VERSION", color = S_MUTED, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    SettingsTabs(accent, false)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))

                // Cabe inteiro na tela. A rolagem só existiria como rede de segurança em telas muito baixas.
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(if (settingsTab == 2) 8.dp else 12.dp)
                ) {
                    when (settingsTab) {
                        0 -> TabVisual(accent)
                        1 -> TabLibrary(accent)
                        2 -> TabSystem(accent)
                        else -> TabExtras(accent)
                    }
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PadHint("A", "Selecionar", S_PAD_A, onClick = null)
                    Spacer(Modifier.width(20.dp))
                    PadHint("B", "Voltar", S_PAD_B) { overlay = Overlay.None }
                }
            }
        }
    }

    @Composable
    private fun SettingsDialog() {
        val accent = parseColor(accentHex)
        Dialog(
            onDismissRequest = { overlay = Overlay.None },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            HideBarsInDialog()
            if (landscape) {
                // Na paisagem a janela ocupa a tela toda, inclusive sob o furo da câmera,
                // e o "Recuar área da câmera" afasta a borda esquerda na hora.
                val view = LocalView.current
                SideEffect {
                    val w = (view.parent as? DialogWindowProvider)?.window
                    if (w != null) {
                        val lp = w.attributes
                        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        w.attributes = lp
                    }
                }
                SettingsLandscape(accent)
            } else {
                SettingsPortrait(accent)
            }
        }
    }

    @Composable
    private fun CollectionsDialog() {
        var newName by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        NexusModal("Coleções", { overlay = Overlay.Settings }, tall = true) {
            val addUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newName, { newName = it }, "Nova coleção (franquia ou grupo)", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    addCollection(newName)
                    newName = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (collections.isEmpty()) {
                    item {
                        Text("Nenhuma coleção ainda.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                items(orderedCollections(), key = { it }) { c ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == c) {
                            CField(editText, { editText = it }, "Nome da coleção", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                renameCollection(c, editText)
                                editing = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else {
                            val used = games.count { c in it.collections }
                            Text(
                                "$c  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            if (isFixedCollection(c)) {
                                Box(Modifier.width(102.dp).height(40.dp), contentAlignment = Alignment.Center) {
                                    Text("🔒 Fixa", color = C_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                                }
                            } else {
                                CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                    editing = c
                                    editText = c
                                }
                                CButton("🗑", C_RED, Modifier.width(48.dp)) { overlay = Overlay.ConfirmDeleteCollection(c) }
                            }
                        }
                    }
                }
            }
            }
            if (landscape) {
                Panes(0.4f, {
                    addUi()
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "As coleções com 🔒 já vêm no Nexus e não podem ser renomeadas nem apagadas. Um jogo pode estar em várias coleções: escolha ao editar o jogo.",
                        color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
                }, { listUi() })
            } else {
                addUi()
                Spacer(Modifier.height(8.dp))
                listUi()
            Spacer(Modifier.height(8.dp))
            Text(
                "As coleções com 🔒 já vêm no Nexus e não podem ser renomeadas nem apagadas. Um jogo pode estar em várias coleções: escolha ao editar o jogo.",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
            }
        }
    }

    @Composable
    private fun ConfirmDeleteCollectionDialog(name: String) {
        NexusModal("Apagar coleção?", { overlay = Overlay.Collections }) {
            Text(
                "Apagar a coleção \"$name\"? Os jogos continuam na biblioteca, só saem dessa coleção.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.Collections }
                CButton("Apagar", C_RED, Modifier.weight(1f)) {
                    deleteCollection(name)
                    overlay = Overlay.Collections
                }
            }
        }
    }

    // Escolha de coleções de um jogo (seleção múltipla). Também permite criar uma coleção na hora.
    // Escolha de imagem no SteamGridDB: busca o jogo (ou a plataforma) e mostra miniaturas para tocar.
    @Composable
    private fun SgdbPickerDialog(p: SgdbPicker) {
        var term by remember { mutableStateOf(p.term) }
        var tick by remember { mutableStateOf(0) }
        var loading by remember { mutableStateOf(true) }
        var error by remember { mutableStateOf("") }
        var gameName by remember { mutableStateOf("") }
        var grids by remember { mutableStateOf(emptyList<SgdbGrid>()) }
        LaunchedEffect(tick) {
            loading = true
            error = ""
            val key = sgdbKey.trim()
            val res = withContext(Dispatchers.IO) { SgdbApi.findGrids(key, term, p.portrait) }
            when (res) {
                is SgdbGridsResult.Ok -> {
                    gameName = res.game?.name ?: ""
                    grids = res.grids
                }
                is SgdbGridsResult.Failure -> {
                    error = res.message
                    grids = emptyList()
                }
            }
            loading = false
        }
        val statusText = when {
            loading -> "Buscando…"
            error.isNotEmpty() -> error
            gameName.isEmpty() -> "Nada encontrado. Tente outro nome."
            else -> "Resultado para: $gameName. Toque em uma imagem."
        }
        if (p.portrait && landscape) {
            // Paisagem: busca numa coluna estreita à esquerda e as capas ocupam todo o resto à direita.
            // O grid mostra 2 linhas inteiras (6+ capas) e deixa uma faixa da 3ª linha à vista, indicando a rolagem.
            val accent = parseColor(accentHex)
            val panelShape = RoundedCornerShape(rPanel.dp)
            val closeShape = RoundedCornerShape(rBtn.dp)
            Dialog(
                onDismissRequest = { sgdbPicker = null },
                properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
            ) {
                HideBarsInDialog()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                        .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(0.96f)
                            .fillMaxHeight()
                            .shadow(14.dp, panelShape, ambientColor = accent, spotColor = accent)
                            .clip(panelShape)
                            .background(C_PANEL)
                            .border(1.5.dp, accent.copy(alpha = 0.75f), panelShape)
                            .padding(12.dp)
                    ) {
                        Column(Modifier.width(210.dp).fillMaxHeight()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f)) { MarqueeText(p.title, Color.White, 15, FontWeight.ExtraBold) }
                                Spacer(Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(closeShape)
                                        .background(Color(0x0FFFFFFF))
                                        .border(1.dp, S_LINE, closeShape)
                                        .focusGlow(closeShape)
                                        .clickable { sgdbPicker = null },
                                    contentAlignment = Alignment.Center
                                ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 13.sp) }
                            }
                            Spacer(Modifier.height(10.dp))
                            CField(term, { term = it }, "Nome para buscar", Modifier.fillMaxWidth())
                            Spacer(Modifier.height(6.dp))
                            CButton("🔍 Buscar", C_BLUE, Modifier.fillMaxWidth()) { tick++ }
                            Spacer(Modifier.height(8.dp))
                            Text(statusText, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.weight(1f))
                            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { sgdbPicker = null }
                        }
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.width(1.dp).fillMaxHeight().background(S_LINE))
                        Spacer(Modifier.width(12.dp))
                        BoxWithConstraints(Modifier.weight(1f).fillMaxHeight()) {
                            val gap = 8.dp
                            val cellH = (maxHeight - gap * 2) / 2.35f
                            val cellW = cellH * 0.67f
                            val cols = ((maxWidth + gap) / (cellW + gap)).toInt().coerceIn(3, 8)
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(cols),
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.spacedBy(gap),
                                verticalArrangement = Arrangement.spacedBy(gap)
                            ) {
                                items(grids, key = { it.url }) { g ->
                                    AsyncImage(
                                        model = g.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(cellH)
                                            .clip(RoundedCornerShape(rBtn.dp))
                                            .background(Color(0xFF1A1E29))
                                            .clickable {
                                                p.onPick(g.url)
                                                sgdbPicker = null
                                            }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            return
        }
        NexusModal(p.title, { sgdbPicker = null }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(term, { term = it }, "Nome para buscar", Modifier.weight(1f))
                CButton("🔍", C_BLUE, Modifier.width(52.dp)) { tick++ }
            }
            Spacer(Modifier.height(6.dp))
            Text(statusText, color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (p.portrait) 3 else 2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(grids, key = { it.url }) { g ->
                    AsyncImage(
                        model = g.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(if (p.portrait) 0.67f else 1.43f)
                            .clip(RoundedCornerShape(rBtn.dp))
                            .background(Color(0xFF1A1E29))
                            .clickable {
                                p.onPick(g.url)
                                sgdbPicker = null
                            }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { sgdbPicker = null }
        }
    }

    @Composable
    private fun CollectionPickerDialog() {
        var newName by remember { mutableStateOf("") }
        NexusModal("Coleções do jogo", { collPickerOpen = false }, tall = true) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newName, { newName = it }, "Nova coleção (ex.: Zelda)", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        if (collections.none { it.equals(n, ignoreCase = true) }) {
                            collections.add(n)
                            savePrefs()
                        }
                        val canon = collections.first { it.equals(n, ignoreCase = true) }
                        if (canon !in collPickerSel) collPickerSel.add(canon)
                    }
                    newName = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (collections.isEmpty()) {
                    item {
                        Text("Nenhuma coleção ainda. Crie uma acima.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                items(orderedCollections(), key = { it }) { c ->
                    val on = c in collPickerSel
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow { if (on) collPickerSel.remove(c) else collPickerSel.add(c) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (on) "☑" else "☐", color = if (on) C_BLUE else C_MUTED, fontSize = 20.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(c, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) {
                collPickerCb?.invoke(collections.filter { it in collPickerSel })
                collPickerOpen = false
            }
            Spacer(Modifier.height(6.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { collPickerOpen = false }
        }
    }

    @Composable
    private fun GenresDialog() {
        var newGenre by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        NexusModal("Gêneros", { overlay = Overlay.Settings }, tall = true) {
            val addUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newGenre, { newGenre = it }, "Novo gênero", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val g = newGenre.trim()
                    if (g.isNotEmpty() && g !in genres) {
                        genres.add(g)
                        savePrefs()
                    }
                    newGenre = ""
                }
            }
            Spacer(Modifier.height(8.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(genres.sortedAlpha { it }, key = { it }) { g ->
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(null),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == g) {
                            CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                renameGenre(g, editText)
                                editing = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else {
                            val used = games.count { g in it.genres }
                            Text(
                                "$g  ($used)", color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            CButton("✏", C_GRAY, Modifier.width(48.dp)) {
                                editing = g
                                editText = g
                            }
                            CButton("🗑", C_RED, Modifier.width(48.dp)) { deleteGenre(g) }
                        }
                    }
                }
            }
            }
            if (landscape) {
                Panes(0.4f, {
                    addUi()
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Ao apagar, os jogos desse gênero ficam sem gênero.",
                        color = C_MUTED, fontSize = 11.sp, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
                }, { listUi() })
            } else {
                addUi()
                Spacer(Modifier.height(8.dp))
                listUi()
            Spacer(Modifier.height(8.dp))
            Text(
                "Ao apagar, os jogos desse gênero ficam sem gênero.",
                color = C_MUTED, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
            }
        }
    }

    @Composable
    private fun GenrePickerDialog() {
        var newName by remember { mutableStateOf("") }
        var editing by remember { mutableStateOf<String?>(null) }
        var editText by remember { mutableStateOf("") }
        var delAsk by remember { mutableStateOf<String?>(null) }
        NexusModal("Gêneros do jogo", { genrePickerOpen = false }, tall = true) {
            val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(newName, { newName = it }, "Novo gênero (ex.: RPG)", Modifier.weight(1f))
                CButton("+", C_ORANGE, Modifier.width(52.dp)) {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        if (genres.none { it.equals(n, ignoreCase = true) }) {
                            genres.add(n)
                            savePrefs()
                        }
                        val canon = genres.first { it.equals(n, ignoreCase = true) }
                        if (canon !in genrePickerSel) {
                            if (genrePickerSel.size >= MAX_GENRES) toast("No máximo $MAX_GENRES gêneros por jogo")
                            else genrePickerSel.add(canon)
                        }
                    }
                    newName = ""
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Marque até $MAX_GENRES. Sem nada marcado, o jogo fica em \"$NO_GENRE\".",
                color = C_MUTED, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (genres.isEmpty()) {
                    item {
                        Text("Nenhum gênero ainda. Crie um acima.", color = C_MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
                items(genres.sortedAlpha { it }, key = { it }) { g ->
                    val on = g in genrePickerSel
                    Row(
                        modifier = Modifier.fillMaxWidth().cardRow(
                            if (editing == g || delAsk == g) null else ({
                                if (on) genrePickerSel.remove(g)
                                else if (genrePickerSel.size >= MAX_GENRES) toast("No máximo $MAX_GENRES gêneros por jogo")
                                else genrePickerSel.add(g)
                            })
                        ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (editing == g) {
                            CField(editText, { editText = it }, "Nome do gênero", Modifier.weight(1f))
                            CButton("✔", C_BLUE, Modifier.width(48.dp)) {
                                val nn = editText.trim()
                                if (nn.isNotEmpty() && (nn == g || genres.none { it.equals(nn, ignoreCase = true) })) {
                                    renameGenre(g, nn)
                                    val i = genrePickerSel.indexOf(g)
                                    if (i >= 0) genrePickerSel[i] = nn
                                    editing = null
                                } else toast("Esse nome já existe")
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { editing = null }
                        } else if (delAsk == g) {
                            Text(
                                "Apagar \"$g\"? Os jogos ficam sem esse gênero.", color = Color(0xFFFFB4BF),
                                fontSize = 12.sp, modifier = Modifier.weight(1f)
                            )
                            CButton("Apagar", C_RED, Modifier.width(78.dp)) {
                                deleteGenre(g)
                                genrePickerSel.remove(g)
                                delAsk = null
                            }
                            CButton("✖", C_GRAY, Modifier.width(48.dp)) { delAsk = null }
                        } else {
                            Text(if (on) "☑" else "☐", color = if (on) C_BLUE else C_MUTED, fontSize = 20.sp)
                            Text(
                                g, color = Color.White, fontSize = 14.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) { editing = g; editText = g }
                            MiniIcon("🗑", Color(0xFFFF6B81), Color(0x26E11D48)) { delAsk = g }
                        }
                    }
                }
            }
            }
            val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Spacer(Modifier.height(8.dp))
            CButton("Concluir", C_BLUE, Modifier.fillMaxWidth()) {
                genrePickerCb?.invoke(genres.filter { it in genrePickerSel })
                genrePickerOpen = false
            }
            Spacer(Modifier.height(6.dp))
            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { genrePickerOpen = false }
            }
            if (landscape) {
                Panes(0.4f, {
                    topUi()
                    Spacer(Modifier.height(10.dp))
                    botUi()
                }, { listUi() })
            } else {
                topUi()
                listUi()
                botUi()
            }
        }
    }

    @Composable
    private fun RomListDialog(req: RomListRequest) {
        var entries by remember(req) { mutableStateOf<ScanResult?>(null) }
        var q by remember(req) { mutableStateOf("") }
        LaunchedEffect(req) { entries = withContext(Dispatchers.IO) { scanRoms(req.platform) } }
        val k = q.trim().lowercase()
        val all = entries?.roms
        val failed = entries?.failed ?: 0
        val shown = if (all == null) emptyList() else if (k.isEmpty()) all else all.filter { it.name.lowercase().contains(k) }
        NexusModal("ROMs · ${req.platform}", { romList = null }, tall = true) {
            CField(q, { q = it }, "🔍 Buscar ROM", Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Text(
                if (all == null) "Lendo pastas…" else "${shown.size} de ${all.size} arquivo(s)",
                color = C_MUTED, fontSize = 11.sp
            )
            if (failed > 0) {
                Text(
                    "⚠ $failed pasta(s) sem acesso. Vincule de novo em Configurações.",
                    color = C_ORANGE, fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(4.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(shown, key = { it.uri }) { e ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                romList = null
                                req.onPick(e.uri, e.name)
                            }
                    ) {
                        Text(e.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (e.folder.isNotEmpty()) Text(e.folder, color = C_MUTED, fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Escolher manualmente", C_GRAY, Modifier.weight(1f)) {
                    romList = null
                    dialogRomCb = { uri -> req.onPick(uri.toString(), displayName(uri)) }
                    pickRomFile(false)
                }
                CButton("Fechar (B)", C_BLUE, Modifier.weight(1f)) { romList = null }
            }
        }
    }

    @Composable
    private fun PlatformsDialog() {
        NexusModal("Plataformas e emuladores", { overlay = Overlay.Settings }, tall = true) {
            if (links.isEmpty()) {
                Text(
                    "Nenhuma plataforma vinculada ainda. Vincule uma plataforma a um emulador e às pastas das ROMs.",
                    color = C_MUTED, fontSize = 12.sp, modifier = Modifier.fillMaxWidth()
                )
            }
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(links.sortedAlpha { it.platform }, key = { it.platform }) { l ->
                    val emu = if (l.pkg.isEmpty()) "sem emulador (app nativo)"
                    else if (l.playerName.isNotEmpty()) l.playerName
                    else (allApps.firstOrNull { it.pkg == l.pkg }?.label ?: l.pkg)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow { overlay = Overlay.LinkEdit(l) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(l.pkg)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(l.platform, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("$emu · ${l.folders.size} pasta(s)", color = C_MUTED, fontSize = 11.sp, maxLines = 1)
                        }
                        Text("›", color = C_MUTED, fontSize = 20.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            CButton("+ Vincular plataforma", C_BLUE, Modifier.fillMaxWidth()) { overlay = Overlay.LinkEdit(null) }
            Spacer(Modifier.height(8.dp))
            CButton("Voltar (B)", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.Settings }
        }
    }

    @Composable
    private fun LinkEditDialog(initial: PlatformLink?, batch: Boolean = false) {
        // Plataformas já cadastradas + todas as plataformas do catálogo ainda não cadastradas.
        val emuAll = remember { EmuCatalog.all(this@MainActivity) }
        val registered = linkablePlatforms()
        val extra = emuAll.map { it.name }
            .filter { n -> registered.none { it.equals(n, ignoreCase = true) } }
            .sortedAlpha { it }
        // Marca (fabricante) de cada plataforma: cadastrada primeiro, senão a do catálogo.
        val brandOf: (String) -> String = { n ->
            (platforms.firstOrNull { it.name == n }?.manufacturer
                ?: emuAll.firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
                ?: "").ifBlank { "Outros" }
        }
        // Ordem alfabética pela marca (Outros por último) e depois pelo nome da plataforma.
        val options = (registered + extra)
            .filter { p -> if (batch) p != WEB_PLATFORM else (p == initial?.platform || links.none { it.platform == p }) }
            .sortedWith(
                compareBy<String> { brandOf(it) == "Outros" }
                    .thenBy(ALPHA) { brandOf(it) }
                    .thenBy(ALPHA) { it }
            )

        // Em lote, se a primeira plataforma da lista já tem vínculo, parte dele (emulador e pastas).
        val startLink = initial ?: (if (batch) linkFor(options.firstOrNull() ?: "") else null)
        var platform by remember { mutableStateOf(initial?.platform ?: (options.firstOrNull() ?: WEB_PLATFORM)) }
        var pkg by remember { mutableStateOf(startLink?.pkg ?: "") }
        var tpl by remember {
            mutableStateOf(startLink?.template?.takeIf { it.isNotBlank() } ?: (TEMPLATES[startLink?.pkg ?: ""] ?: ""))
        }
        var playerName by remember { mutableStateOf(startLink?.playerName ?: "") }
        var exts by remember { mutableStateOf(startLink?.exts ?: emptyList<String>()) }
        val folders = remember {
            mutableStateListOf<String>().apply { if (startLink != null) addAll(startLink.folders) }
        }
        val emuPlat = remember(platform) { EmuCatalog.forPlatform(this@MainActivity, execKey(platform)) }

        val accent = parseColor(accentHex)
        val fPlat: @Composable () -> Unit = {
            PlatPill(
                "PLATAFORMA", platform, Modifier.fillMaxWidth(),
                filter = { pn ->
                    pn != ANDROID_PLATFORM &&
                        (if (batch) pn != WEB_PLATFORM else (pn == initial?.platform || links.none { it.platform == pn }))
                },
                onChanged = { o, n -> if (platform == o) platform = if (n.isEmpty()) (options.firstOrNull() ?: WEB_PLATFORM) else n }
            ) {
                if (batch && it != platform) {
                    // Plataforma já vinculada: traz o emulador e as pastas dela.
                    val ex = linkFor(it)
                    pkg = ex?.pkg ?: ""
                    tpl = ex?.template?.takeIf { t -> t.isNotBlank() } ?: (TEMPLATES[ex?.pkg ?: ""] ?: "")
                    playerName = ex?.playerName ?: ""
                    exts = ex?.exts ?: emptyList()
                    folders.clear()
                    if (ex != null) folders.addAll(ex.folders)
                } else if (it != platform && playerName.isNotEmpty()) {
                    pkg = ""
                    tpl = ""
                    playerName = ""
                    exts = emptyList()
                }
                platform = it
            }
        }
        val fEmu: @Composable () -> Unit = {
            val label = allApps.firstOrNull { it.pkg == pkg }?.label ?: pkg
            val shown = if (playerName.isNotEmpty()) playerName else label
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val dp = emuPlat
                if (dp != null && dp.players.isNotEmpty()) {
                    ActionRow("📚", "Catálogo de emuladores", "${dp.players.size} disponíveis para esta plataforma",
                        bg = accent.copy(alpha = 0.14f), border = accent.copy(alpha = 0.45f),
                        iconBg = accent, iconFg = onAccent(accent), compact = true) {
                        emuPicker = EmuPickerRequest(dp) { pl ->
                            pkg = pl.pkg
                            tpl = pl.template
                            playerName = pl.name
                            exts = pl.exts
                        }
                    }
                } else {
                    Text(
                        "Esta plataforma não tem emuladores no catálogo. Escolha um app instalado.",
                        color = C_MUTED, fontSize = 11.sp
                    )
                }
                EPill(Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        ELabel("EMULADOR")
                        Spacer(Modifier.height(3.dp))
                        MarqueeText(if (pkg.isEmpty()) "Nenhum (app nativo)" else shown, Color.White, 13)
                    }
                    Spacer(Modifier.width(8.dp))
                    EBtn("Alterar", null, S_FIELD, accent.copy(alpha = 0.65f), accent) {
                        appPickerMode = 2
                        appPickerNone = "Nenhum (app nativo / escolho por jogo)"
                        appPickerCb = { a ->
                            val np = a?.pkg ?: ""
                            pkg = np
                            // Se o catálogo tem um único emulador com esse pacote para a plataforma, usa o comando dele.
                            val only = emuPlat?.players?.filter { it.pkg == np }?.singleOrNull()
                            tpl = TEMPLATES[np] ?: only?.template ?: ""
                            playerName = only?.name ?: ""
                            exts = only?.exts ?: emptyList()
                        }
                        appPickerOpen = true
                    }
                }
            }
        }
        val fFolders: @Composable () -> Unit = {
            Column {
                ELabel("PASTAS DE ROMS (${folders.size})")
                Spacer(Modifier.height(6.dp))
                LazyColumn(modifier = Modifier.heightIn(max = if (landscape) 96.dp else 130.dp)) {
                    items(folders.sortedAlpha { folderLabel(it) }, key = { it }) { f ->
                        Row(
                            modifier = Modifier.fillMaxWidth().cardRow(null),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.weight(1f)) { MarqueeText(folderLabel(f), Color(0xFFCBD2E0), 11, FontWeight.Medium) }
                            Spacer(Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x26E11D48))
                                    .focusGlow(CircleShape)
                                    .clickable { folders.remove(f) },
                                contentAlignment = Alignment.Center
                            ) { Text("✕", color = Color(0xFFFF6B81), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                EBtn("Adicionar pasta", "+", accent.copy(alpha = 0.14f), accent.copy(alpha = 0.5f), accent, Modifier.fillMaxWidth()) {
                    treeCb = { u -> if (u !in folders) folders.add(u) }
                    pickFolder()
                }
            }
        }
        val fTpl: @Composable () -> Unit = {
            Column {
                ELabel("COMANDO DE ABERTURA (AVANÇADO)")
                Spacer(Modifier.height(6.dp))
                PillField(null, tpl, { tpl = it }, "-n pacote/.Activity -d {file.uri}", Modifier.fillMaxWidth(), 12, FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                // Toque em um item para inserir no comando.
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("{file.uri}", "{file.path}", "{file.mime}", "{tags.vita_game_id}").forEach { tk ->
                        val chip = RoundedCornerShape(rBtn.dp)
                        Box(
                            modifier = Modifier
                                .clip(chip)
                                .background(S_FIELD)
                                .border(1.dp, S_LINE, chip)
                                .focusGlow(chip)
                                .clickable { tpl = if (tpl.isEmpty() || tpl.endsWith(" ")) tpl + tk else tpl + " " + tk }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) { Text(tk, color = C_MUTED, fontSize = 10.sp, maxLines = 1, softWrap = false) }
                    }
                }
            }
        }

        NexusModal(
            if (batch) "Adicionar jogos em lote" else if (initial == null) "Vincular plataforma" else "Editar: ${initial.platform}",
            { overlay = if (batch) Overlay.None else Overlay.Platforms },
            footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EBtn("Cancelar", null, S_FIELD, S_LINE, Color(0xFFE2E8F0), Modifier.weight(1f), tall = true) {
                    overlay = if (batch) Overlay.None else Overlay.Platforms
                }
                if (initial != null) {
                    EBtn("Apagar", "●", Color(0x1AFF375F), Color(0x66FF375F), Color(0xFFFF6B81), Modifier.weight(1f), tall = true) {
                        links.removeAll { it.platform == initial.platform }
                        savePrefs()
                        overlay = Overlay.Platforms
                    }
                }
                EBtn(if (batch) "Varrer pastas" else "Salvar", "✓", accent, accent, onAccent(accent), Modifier.weight(1f), tall = true) {
                    if (batch) {
                        if (folders.isEmpty()) {
                            toast("Adicione ao menos uma pasta de jogos")
                            return@EBtn
                        }
                        if (ScanEngine.profileFor(platform, execBase(platform), batchExts(platform, exts)) == null) {
                            toast("Escolha um emulador para esta plataforma")
                            return@EBtn
                        }
                    }
                    val clean = if (tpl.trim() == (TEMPLATES[pkg] ?: "")) "" else tpl.trim()
                    val nl = PlatformLink(platform, pkg, clean, folders.toList(), playerName, exts)
                    // Plataforma do catálogo ainda não cadastrada: cadastra ao vincular,
                    // assim ela passa a aparecer ao adicionar jogos.
                    if (platforms.none { it.name == platform }) {
                        val dp = EmuCatalog.forPlatform(this@MainActivity, platform)
                        platforms.add(GamePlatform(platform, dp?.manufacturer ?: "", platform))
                    }
                    val idx = if (batch) links.indexOfFirst { it.platform == platform }
                    else if (initial == null) -1 else links.indexOfFirst { it.platform == initial.platform }
                    if (idx >= 0) links[idx] = nl else links.add(nl)
                    savePrefs()
                    if (batch) {
                        overlay = Overlay.None
                        startBatchScan(platform)
                    } else overlay = Overlay.Platforms
                }
            }
            }
        ) {
            if (landscape) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        fPlat()
                        fEmu()
                        if (!batch) fTpl()
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) { fFolders() }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fPlat()
                    fEmu()
                    fFolders()
                    if (!batch) fTpl()
                }
            }
        }
    }

    private val PKG_LIKE = Regex("^[a-z0-9_]+(\\.[A-Za-z0-9_\\-]+)+$")

    /** Nome do app para mostrar: o nome real quando o catálogo só traz o pacote. */
    private fun emuDisplayName(pl: EmuPlayer, installed: Boolean, rec: EmuRec?): String {
        if (!PKG_LIKE.matches(pl.name)) return pl.name
        if (installed) allApps.firstOrNull { it.pkg == pl.pkg }?.label?.takeIf { it.isNotBlank() }?.let { return it }
        if (rec != null) return rec.name
        val seg = pl.name.substringAfterLast('.')
        return seg.replaceFirstChar { it.uppercase() }
    }

    @Composable
    private fun EmuPickerDialog(req: EmuPickerRequest) {
        var q by remember { mutableStateOf("") }
        val k = foldText(q.trim())
        val accent = parseColor(accentHex)
        class Row2(val pl: EmuPlayer, val inst: Boolean, val recIdx: Int, val name: String)
        val rows = remember(req) {
            val recs = EmuCatalog.recommended(this@MainActivity)[req.platform.id] ?: emptyList()
            req.platform.players.map { pl ->
                val idx = recs.indexOfFirst { it.pkg == pl.pkg }
                val inst = isInstalled(pl.pkg)
                Row2(pl, inst, idx, emuDisplayName(pl, inst, recs.getOrNull(idx)))
            }
                .sortedWith(
                    compareBy<Row2> {
                        when {
                            it.inst && it.recIdx >= 0 -> 0
                            it.inst -> 1
                            it.recIdx >= 0 -> 2
                            else -> 3
                        }
                    }.thenBy { if (it.recIdx >= 0) it.recIdx else 0 }.thenBy(ALPHA) { it.name }
                )
        }
        val filtered = if (k.isEmpty()) rows else rows.filter {
            foldText(it.name).contains(k) || foldText(it.pl.name).contains(k) || it.pl.pkg.lowercase().contains(k)
        }
        NexusModal("Emuladores: ${req.platform.name}", { emuPicker = null }, tall = true) {
            val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            CField(q, { q = it }, "🔍 Buscar emulador", Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            }
            val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(filtered) { row ->
                    val pl = row.pl
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .cardRow {
                                req.onPick(pl)
                                emuPicker = null
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(if (row.inst) pl.pkg else "")
                        Spacer(Modifier.width(12.dp))
                        Text(
                            row.name, color = Color.White, fontSize = 14.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            if (row.recIdx >= 0) {
                                Text(
                                    "recomendado", color = onAccent(accent), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    maxLines = 1, softWrap = false,
                                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(accent)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                if (row.inst) "instalado" else "não instalado",
                                color = if (row.inst) Color(0xFF34D399) else C_MUTED, fontSize = 10.sp,
                                fontWeight = if (row.inst) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
            }
            val botUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Spacer(Modifier.height(8.dp))
            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { emuPicker = null }
            }
            if (landscape) {
                Panes(0.36f, {
                    topUi()
                    Spacer(Modifier.height(10.dp))
                    botUi()
                }, { listUi() })
            } else {
                topUi()
                listUi()
                botUi()
            }
        }
    }


    @Composable
    private fun MiniIcon(glyph: String, tint: Color, bg: Color, onClick: () -> Unit) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(bg)
                .focusGlow(CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Text(glyph, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
    }

    /** Campo "Plataforma" (estilo pílula) que abre o seletor com busca. */
    @Composable
    private fun PlatPill(
        label: String, value: String, modifier: Modifier, vpad: Dp = 8.dp,
        filter: (String) -> Boolean = { true },
        onChanged: (String, String) -> Unit = { _, _ -> },
        onSelect: (String) -> Unit
    ) {
        EPill(
            modifier, vpad = vpad,
            onClick = { platPicker = PlatPickerRequest("Plataforma", value, filter, onChanged, onSelect) }
        ) {
            Column(Modifier.weight(1f)) {
                ELabel(label)
                Spacer(Modifier.height(3.dp))
                MarqueeText(value.ifEmpty { "Escolher" }, Color.White, 13)
            }
            Spacer(Modifier.width(6.dp))
            Text("▾", color = S_MUTED, fontSize = 13.sp)
        }
    }

    @Composable
    private fun PlatformPickerDialog(req: PlatPickerRequest) {
        var q by remember { mutableStateOf("") }
        var mode by remember { mutableStateOf(0) } // 0 lista, 1 formulário, 2 confirmar exclusão
        var target by remember { mutableStateOf<GamePlatform?>(null) }
        var nameF by remember { mutableStateOf("") }
        var manF by remember { mutableStateOf("") }
        val accent = parseColor(accentHex)
        val close: () -> Unit = { platPicker = null }
        val title = when (mode) {
            1 -> if (target == null) "Nova plataforma" else "Editar plataforma"
            2 -> "Apagar plataforma?"
            else -> req.title
        }
        NexusModal(title, { if (mode != 0) mode = 0 else close() }, tall = mode == 0) {
            when (mode) {
                1 -> {
                    PillField("NOME DA PLATAFORMA", nameF, { nameF = it }, "Ex.: Dreamcast", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    PillField("FABRICANTE (OPCIONAL)", manF, { manF = it }, "Ex.: Sega", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { mode = 0 }
                        CButton("Salvar", C_BLUE, Modifier.weight(1f)) {
                            val n = nameF.trim()
                            val t = target
                            val clash = EmuCatalog.all(this@MainActivity).any { it.name.equals(n, ignoreCase = true) } &&
                                (t == null || !t.name.equals(n, ignoreCase = true))
                            if (clash) {
                                toast("Já existe uma plataforma com esse nome")
                            } else if (savePlatform(t, n, manF)) {
                                if (t == null) {
                                    req.onPick(n)
                                    close()
                                } else {
                                    if (t.name != n) req.onChanged(t.name, n)
                                    mode = 0
                                }
                            }
                        }
                    }
                }
                2 -> {
                    val t = target
                    if (t != null) {
                        Text(
                            "Apagar \"${t.name}\"? O vínculo dela com emulador e pastas também será removido.",
                            color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { mode = 0 }
                            CButton("Apagar", C_RED, Modifier.weight(1f)) {
                                deletePlatform(t)
                                req.onChanged(t.name, "")
                                mode = 0
                            }
                        }
                    }
                }
                else -> {
                    val k = foldText(q.trim())
                    val shown = platformPickList(req.filter).filter {
                        k.isEmpty() || foldText(it).contains(k) || foldText(brandOfPlatform(it)).contains(k)
                    }
                    val topUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                    CField(q, { q = it }, "🔍 Buscar plataforma (digite ou fale)", Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    CButton("＋ Nova plataforma", C_GRAY, Modifier.fillMaxWidth()) {
                        target = null
                        nameF = q.trim()
                        manF = ""
                        mode = 1
                    }
                    Spacer(Modifier.height(8.dp))
                    }
                    val listUi: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(shown, key = { it }) { n ->
                            val custom = isCustomPlatform(n)
                            Row(
                                modifier = Modifier.fillMaxWidth().cardRow { req.onPick(n); close() },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        n, color = if (n == req.selected) accent else Color.White,
                                        fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        brandOfPlatform(n) + if (custom) " · personalizada" else "",
                                        color = C_MUTED, fontSize = 11.sp, maxLines = 1
                                    )
                                }
                                if (custom) {
                                    MiniIcon("✎", Color(0xFFD5DAE5), Color(0x14FFFFFF)) {
                                        val gp = platforms.firstOrNull { it.name == n }
                                        target = gp
                                        nameF = n
                                        manF = gp?.manufacturer ?: ""
                                        mode = 1
                                    }
                                    Spacer(Modifier.width(6.dp))
                                    MiniIcon("🗑", Color(0xFFFF6B81), Color(0x26E11D48)) {
                                        val used = games.count { it.platform == n || it.maskPlatform == n }
                                        if (used > 0) {
                                            toast("Esta plataforma tem $used jogo(s). Apague ou mude esses jogos antes.")
                                        } else {
                                            target = platforms.firstOrNull { it.name == n }
                                            mode = 2
                                        }
                                    }
                                }
                            }
                        }
                    }
                    }
                    if (landscape) {
                        Panes(0.36f, {
                            topUi()
                            Spacer(Modifier.height(10.dp))
                            CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { close() }
                        }, { listUi() })
                    } else {
                        topUi()
                        listUi()
                    Spacer(Modifier.height(8.dp))
                    CButton("Fechar (B)", C_GRAY, Modifier.fillMaxWidth()) { close() }
                    }
                }
            }
        }
    }

    @Composable
    private fun CoverBatchDialog() {
        val job = coverBatch
        var scope by remember { mutableStateOf("") }
        var askMobile by remember { mutableStateOf(false) }
        val accent = parseColor(accentHex)
        NexusModal("Capas em lote", { overlay = Overlay.None }, tall = landscape && job == null && sgdbKey.isNotBlank()) {
            if (job != null && job.running) {
                Text("Buscando capas no SteamGridDB…", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { if (job.total == 0) 0f else job.done.toFloat() / job.total },
                    modifier = Modifier.fillMaxWidth(), color = accent
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "${job.done} de ${job.total} · ${job.applied} aplicada(s)",
                    color = C_MUTED, fontSize = 12.sp
                )
                Spacer(Modifier.height(4.dp))
                Text("Pode minimizar: a busca continua e avisa na notificação.", color = C_MUTED, fontSize = 11.sp)
                Spacer(Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Cancelar busca", C_RED, Modifier.weight(1f)) { job.cancelled = true }
                    CButton("Minimizar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                }
            } else if (job != null) {
                Text(
                    "${job.applied} capa(s) aplicada(s) de ${job.total}.",
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                if (job.error.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Parou: ${job.error}", color = C_ORANGE, fontSize = 12.sp)
                }
                if (job.cancelled) {
                    Spacer(Modifier.height(6.dp))
                    Text("Busca cancelada.", color = C_MUTED, fontSize = 12.sp)
                }
                if (job.notFound.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Não encontrados (${job.notFound.size}):", color = C_MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    job.notFound.take(40).forEach {
                        Text("• $it", color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (job.notFound.size > 40) Text("… e mais ${job.notFound.size - 40}", color = C_MUTED, fontSize = 11.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CButton("Nova busca", C_GRAY, Modifier.weight(1f)) { coverBatch = null }
                    CButton("Fechar", C_BLUE, Modifier.weight(1f)) { coverBatch = null; overlay = Overlay.None }
                }
            } else {
                val missing = games.count { coverEligible(it, scope) }
                if (!(landscape && sgdbKey.isNotBlank())) Text(
                    "Procura no SteamGridDB a primeira capa vertical de cada jogo sem capa, pelo título. " +
                        "Capas que você já tem nunca são trocadas. O ícone do app não conta como capa.",
                    color = Color(0xFFCBD2E0), fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                if (sgdbKey.isBlank()) {
                    Text("Cole sua chave do SteamGridDB em Sistema > SteamGridDB antes de começar.", color = C_ORANGE, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    CButton("Fechar", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
                } else {
                    if (landscape) {
                        Panes(0.46f, {
                            Text(
                                "Procura no SteamGridDB a primeira capa vertical de cada jogo sem capa, pelo título. " +
                                    "Capas que você já tem nunca são trocadas. O ícone do app não conta como capa.",
                                color = Color(0xFFCBD2E0), fontSize = 12.sp
                            )
                            Spacer(Modifier.height(8.dp))
                    CButton(
                        "Plataforma: " + scope.ifEmpty { "Todas" }, C_GRAY, Modifier.fillMaxWidth()
                    ) {
                        platPicker = PlatPickerRequest(
                            "Capas de qual plataforma?", scope,
                            { p -> games.any { it.shownPlatform == p && coverEligible(it, "") } },
                            { _, _ -> }, { scope = it }
                        )
                    }
                    if (scope.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        CButton("Usar todas as plataformas", C_GRAY, Modifier.fillMaxWidth()) { scope = "" }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                        }, {
                            if (askMobile) {
                                val mob = games.count { isMobileGame(it) && coverEligible(it, scope) }
                                Text(
                                    "$mob jogo(s) de Android/Web também estão sem capa. Colocar capas nesses jogos?",
                                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(8.dp))
                                CButton("Sim, incluir Android/Web", C_BLUE, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, true) }
                                Spacer(Modifier.height(6.dp))
                                CButton("Não, só os outros jogos", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, false) }
                                Spacer(Modifier.height(6.dp))
                                CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false }
                            } else {
                                Spacer(Modifier.weight(1f))
                                CButton("Começar", C_BLUE, Modifier.fillMaxWidth()) {
                                    if (games.any { isMobileGame(it) && coverEligible(it, scope) }) askMobile = true
                                    else startCoverBatch(scope, true)
                                }
                                Spacer(Modifier.height(8.dp))
                                CButton("Fechar", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
                                Spacer(Modifier.weight(1f))
                            }
                        })
                    } else {
                        CButton(
                            "Plataforma: " + scope.ifEmpty { "Todas" }, C_GRAY, Modifier.fillMaxWidth()
                        ) {
                            platPicker = PlatPickerRequest(
                                "Capas de qual plataforma?", scope,
                                { p -> games.any { it.shownPlatform == p && coverEligible(it, "") } },
                                { _, _ -> }, { scope = it }
                            )
                        }
                        if (scope.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            CButton("Usar todas as plataformas", C_GRAY, Modifier.fillMaxWidth()) { scope = "" }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("$missing jogo(s) sem capa", color = C_MUTED, fontSize = 12.sp)
                        if (askMobile) {
                            val mob = games.count { isMobileGame(it) && coverEligible(it, scope) }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "$mob jogo(s) de Android/Web também estão sem capa. Colocar capas nesses jogos?",
                                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(8.dp))
                            CButton("Sim, incluir Android/Web", C_BLUE, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, true) }
                            Spacer(Modifier.height(6.dp))
                            CButton("Não, só os outros jogos", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false; startCoverBatch(scope, false) }
                            Spacer(Modifier.height(6.dp))
                            CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { askMobile = false }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CButton("Fechar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                            CButton("Começar", C_BLUE, Modifier.weight(1f)) {
                                if (games.any { isMobileGame(it) && coverEligible(it, scope) }) askMobile = true
                                else startCoverBatch(scope, true)
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun StoragePromptDialog() {
        NexusModal("Acesso ao armazenamento", { overlay = Overlay.None }) {
            Text(
                "Para ler suas pastas de ROMs e abrir os jogos nos emuladores, permita o acesso a todos os arquivos. " +
                    "Isso também faz funcionar as pastas que vierem de um backup importado.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            CButton("Permitir acesso", C_BLUE, Modifier.fillMaxWidth()) {
                overlay = Overlay.None
                askStorage()
                maybeWelcome()
            }
            Spacer(Modifier.height(8.dp))
            CButton("Agora não", C_GRAY, Modifier.fillMaxWidth()) {
                overlay = Overlay.None
                maybeWelcome()
            }
        }
    }

    // 4.7.0: trocar o vídeo do jogo colando um link do YouTube (ou buscar de novo / remover).
    @Composable
    private fun VideoLinkDialog(g: Game) {
        var link by remember { mutableStateOf("") }
        val cur = games.firstOrNull { it.id == g.id } ?: g
        NexusModal("Vídeo gameplay", { videoLinkFor = null }) {
            Text(
                if (cur.videoId.isNotEmpty()) "Vídeo atual: " + cur.videoTitle.ifBlank { "youtu.be/" + cur.videoId } else "Nenhum vídeo salvo para este jogo.",
                color = Color(0xFFCBD2E0), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CField(link, { link = it.trim() }, "Cole o link do vídeo do YouTube", Modifier.weight(1f), mic = false)
                CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                    val t = clipboardText()
                    if (t.isEmpty()) toast("Nada copiado para colar") else link = t
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Salvar link", C_BLUE, Modifier.weight(1f)) {
                    val vid = YouTubeApi.parseId(link)
                    if (vid == null) toast("Link do YouTube não reconhecido")
                    else {
                        replaceGame(cur.copy(videoId = vid, videoTitle = "", videoTried = System.currentTimeMillis()))
                        toast("Vídeo salvo")
                        videoLinkFor = null
                    }
                }
                CButton("Buscar de novo", C_GRAY, Modifier.weight(1f)) {
                    if (ytKey.isBlank()) toast("Adicione sua chave do YouTube em Configurações > Sistema")
                    else {
                        val cleared = cur.copy(videoId = "", videoTitle = "", videoTried = 0L)
                        replaceGame(cleared)
                        ensureVideo(cleared, force = true)
                        toast("Buscando vídeo…")
                        videoLinkFor = null
                    }
                }
            }
            if (cur.videoId.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                CButton("Remover vídeo", C_RED, Modifier.fillMaxWidth()) {
                    // videoTried > 0: não busca sozinho de novo; o botão nos detalhes permite buscar quando o usuário quiser.
                    replaceGame(cur.copy(videoId = "", videoTitle = "", videoTried = System.currentTimeMillis()))
                    videoLinkFor = null
                }
            }
        }
    }

    @Composable
    private fun ConfirmDeleteDialog(g: Game) {
        NexusModal("Apagar jogo?", { overlay = Overlay.Edit(g) }) {
            Text(
                "Apagar \"${g.title}\" da biblioteca? Essa ação não pode ser desfeita.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.Edit(g) }
                CButton("Apagar", C_RED, Modifier.weight(1f)) { deleteGame(g) }
            }
        }
    }

    /** 4.7.8: apaga só os jogos (todos ou de uma plataforma). Não mexe em vínculos, apps, gêneros, coleções nem chaves de API. */
    private fun deleteGamesWhere(all: Boolean, platform: String = "") {
        // 4.7.9: por plataforma ORIGINAL (jogos com máscara de etiqueta contam na plataforma real, ex.: Android).
        val gone = if (all) games.toList() else games.filter { it.platform == platform }
        val ids = gone.map { it.id }.toSet()
        games.removeAll { it.id in ids }
        saveLibrary()
        var sg = false
        for (g in gone) if (sgdbCache.remove(g.id) != null) sg = true
        if (sg) saveSgdb()
        if (all) {
            Covers.clearAll()
            resetFilters()
        } else {
            val keep = games.map { it.cover }
            for (g in gone) Covers.purgeIfUnused(g.cover, keep)
            if (fPlatform.isNotEmpty() && games.none { it.shownPlatform == fPlatform }) fPlatform = ""
        }
        dashPlatform = ""
        selectedId = firstNavId()
        overlay = Overlay.None
        toast(if (gone.size == 1) "1 jogo apagado" else "${gone.size} jogos apagados")
    }

    @Composable
    private fun ResetGamesDialog() {
        // 0 = escolher, 1 = lista de plataformas, 2 = confirmar "todos", 3 = confirmar uma plataforma
        var step by remember { mutableStateOf(0) }
        var plat by remember { mutableStateOf("") }
        val title = when (step) {
            0 -> "Resetar Jogos"
            1 -> "Apagar por plataforma"
            else -> "Apagar jogos?"
        }
        NexusModal(title, { if (step == 0) overlay = Overlay.None else step = 0 }) {
            val note = Color(0xFFCBD2E0)
            when (step) {
                0 -> {
                    Text(
                        "Apaga só os jogos da tela inicial. Os vínculos (apps de jogos, apps emuladores, emuladores), os gêneros, as coleções e as chaves de API continuam como estão.",
                        color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    CButton("Apagar por plataforma", C_BLUE, Modifier.fillMaxWidth()) { step = 1 }
                    Spacer(Modifier.height(8.dp))
                    CButton("Apagar todos os jogos", C_RED, Modifier.fillMaxWidth()) { step = 2 }
                    Spacer(Modifier.height(8.dp))
                    CButton("Cancelar", C_GRAY, Modifier.fillMaxWidth()) { overlay = Overlay.None }
                }
                1 -> {
                    // 4.7.9: conta pela plataforma original; os mascarados aparecem separados na própria linha.
                    val names = (platformNames() + games.map { it.platform }.distinct()).distinct()
                    val plats = names.filter { n -> games.any { it.platform == n } }
                    if (plats.isEmpty()) {
                        Text("Nenhum jogo na biblioteca.", color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    } else {
                        for (name in plats) {
                            val inPlat = games.filter { it.platform == name }
                            val masked = inPlat.count { it.maskPlatform.isNotEmpty() }
                            val plain = inPlat.size - masked
                            // 4.8.0: até 3 linhas (o botão cresce): nome / jogos com a etiqueta da plataforma / jogos com máscara.
                            val lines = if (masked > 0) {
                                buildList {
                                    add(name)
                                    if (plain > 0) add("$plain " + (if (plain == 1) "jogo" else "jogos") + " com etiqueta $name")
                                    add("$masked " + (if (masked == 1) "jogo" else "jogos") + " com Máscara de Etiqueta")
                                }
                            } else {
                                listOf("$name · $plain " + (if (plain == 1) "jogo" else "jogos"))
                            }
                            CButtonLines(lines, Modifier.fillMaxWidth()) {
                                plat = name
                                step = 3
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                    CButton("Voltar", C_GRAY, Modifier.fillMaxWidth()) { step = 0 }
                }
                2 -> {
                    Text(
                        "Isso apaga todos os ${games.size} jogos da tela inicial. Vínculos, gêneros, coleções e chaves de API não são apagados.",
                        color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { step = 0 }
                        CButton("Apagar todos", C_RED, Modifier.weight(1f)) { deleteGamesWhere(true) }
                    }
                }
                else -> {
                    val inPlat = games.filter { it.platform == plat }
                    val n = inPlat.size
                    val masked = inPlat.count { it.maskPlatform.isNotEmpty() }
                    val extra = if (masked > 0) " ($masked com máscara de etiqueta)" else ""
                    Text(
                        "Isso apaga os $n " + (if (n == 1) "jogo" else "jogos") + " de $plat$extra. Vínculos, gêneros, coleções e chaves de API não são apagados.",
                        color = note, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { step = 1 }
                        CButton("Apagar", C_RED, Modifier.weight(1f)) { deleteGamesWhere(false, plat) }
                    }
                }
            }
        }
    }

    /** 4.7.8: apaga TUDO (jogos, configurações, vínculos, gêneros, coleções, chaves de API, capas) e reinicia o Nexus. */
    private fun factoryReset() {
        wiping = true
        try { stopService(Intent(this, FloatingPanelService::class.java)) } catch (_: Exception) { }
        try { Covers.clearAll() } catch (_: Exception) { }
        try { prefs.edit().clear().commit() } catch (_: Exception) { }
        try { filesDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
        try { cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        } catch (_: Exception) { }
        // O processo termina logo depois para que o Nexus volte do zero (nada em memória é regravado).
        Handler(Looper.getMainLooper()).postDelayed({ Runtime.getRuntime().exit(0) }, 500)
    }

    @Composable
    private fun ConfirmFactoryDialog() {
        NexusModal("Restaurar configurações de fábrica?", { overlay = Overlay.None }) {
            Text(
                "Isso apaga TUDO: todos os jogos, as configurações, os vínculos de apps e emuladores, os gêneros, as coleções e as chaves de API (SteamGridDB e YouTube). Seus arquivos de ROM não são apagados. O Nexus será reiniciado.",
                color = Color(0xFFCBD2E0), fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Cancelar", C_GRAY, Modifier.weight(1f)) { overlay = Overlay.None }
                CButton("Restaurar", C_RED, Modifier.weight(1f)) { factoryReset() }
            }
        }
    }
}
