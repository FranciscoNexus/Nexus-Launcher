package com.nexus.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import java.util.UUID

data class AppItem(val label: String, val pkg: String)

private val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

class MainActivity : ComponentActivity() {

    private val games = mutableStateListOf<Game>()
    private var allApps: List<AppItem> = emptyList()
    private val libFile by lazy { File(filesDir, "library.json") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        allApps = loadApps()
        loadLibrary()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    NexusScreen()
                }
            }
        }
    }

    // ---------- Dados ----------

    private fun loadLibrary() {
        val existed = libFile.exists()
        val list = try {
            val text = if (existed) {
                libFile.readText()
            } else {
                assets.open("default_library.json").bufferedReader().use { it.readText() }
            }
            LibraryStore.parse(text)
        } catch (e: Exception) {
            toast("Erro ao ler biblioteca: ${e.message}")
            emptyList()
        }
        games.addAll(list)
        if (!existed) saveLibrary()
    }

    private fun saveLibrary() {
        try {
            libFile.writeText(LibraryStore.toJson(games))
        } catch (e: Exception) {
            toast("Erro ao salvar: ${e.message}")
        }
    }

    private fun replaceGame(updated: Game) {
        val idx = games.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            games[idx] = updated
            saveLibrary()
        }
    }

    private fun deleteGame(id: String) {
        games.removeAll { it.id == id }
        saveLibrary()
    }

    private fun markPlayed(g: Game) {
        val idx = games.indexOfFirst { it.id == g.id }
        if (idx >= 0) {
            games[idx] = games[idx].copy(lastPlayedTs = System.currentTimeMillis())
            saveLibrary()
        }
    }

    private fun groupOf(g: Game): Int =
        if (g.lastPlayedTs > 0) 0 else if (g.isFavorite) 1 else 2

    // ---------- Apps / lançamento ----------

    private fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun resolvePkg(g: Game): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    private fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    private fun launchGame(g: Game) {
        if (g.execType == "browser") {
            if (g.webUrl.isBlank()) {
                toast("Este jogo não tem link configurado")
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }

        val pkg = resolvePkg(g)
        if (pkg == null) {
            toast("Defina o app em Editar (segure a capa)")
            return
        }
        try {
            val intent: Intent? = if (g.execType == "ppsspp" && g.romUri.isNotEmpty()) {
                Intent(Intent.ACTION_VIEW).apply {
                    setClassName(pkg, "org.ppsspp.ppsspp.PpssppActivity")
                    data = Uri.parse(g.romUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                packageManager.getLaunchIntentForPackage(pkg)
            }
            if (intent == null) {
                toast("Não foi possível abrir $pkg")
                return
            }
            startActivity(intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- Telas ----------

    @Composable
    private fun NexusScreen() {
        var showDialog by remember { mutableStateOf(false) }
        var editing by remember { mutableStateOf<Game?>(null) }
        var pendingRom by remember { mutableStateOf<Game?>(null) }

        val romPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri: Uri? ->
            val g = pendingRom
            pendingRom = null
            if (uri != null && g != null) {
                persist(uri)
                val updated = g.copy(romUri = uri.toString())
                replaceGame(updated)
                launchGame(updated)
            }
        }

        val sorted = games.sortedWith(
            compareBy<Game> { groupOf(it) }
                .thenByDescending { it.lastPlayedTs }
                .thenBy { it.title.lowercase() }
        )

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Nexus",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = {
                    editing = null
                    showDialog = true
                }) {
                    Text("+ Adicionar")
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(sorted, key = { it.id }) { g ->
                    GameCard(
                        g = g,
                        onClick = {
                            if (g.execType == "ppsspp" && g.romUri.isEmpty() && resolvePkg(g) != null) {
                                pendingRom = g
                                romPicker.launch(arrayOf("*/*"))
                            } else {
                                launchGame(g)
                            }
                        },
                        onLong = {
                            editing = g
                            showDialog = true
                        }
                    )
                }
            }
        }

        if (showDialog) {
            GameDialog(
                initial = editing,
                onSave = { g ->
                    if (editing != null) {
                        replaceGame(g)
                    } else {
                        games.add(g)
                        saveLibrary()
                    }
                    showDialog = false
                    editing = null
                },
                onDelete = editing?.let { e ->
                    {
                        deleteGame(e.id)
                        showDialog = false
                        editing = null
                    }
                },
                onDismiss = {
                    showDialog = false
                    editing = null
                }
            )
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    private fun GameCard(g: Game, onClick: () -> Unit, onLong: () -> Unit) {
        val shape = RoundedCornerShape(10.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.69f)
                .clip(shape)
                .background(Color(0xFF1C1C1E))
                .border(2.dp, Color(0xFF2C2C2E), shape)
                .combinedClickable(onClick = onClick, onLongClick = onLong)
        ) {
            Text(
                g.title,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(8.dp)
            )
            AsyncImage(
                model = g.cover,
                contentDescription = g.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (g.isFavorite) {
                Text(
                    "⭐",
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                )
            }
            Text(
                g.platform.uppercase(),
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            )
        }
    }

    @Composable
    private fun DropdownField(
        label: String,
        value: String,
        options: List<String>,
        onSelect: (String) -> Unit
    ) {
        var open by remember { mutableStateOf(false) }
        Box(modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)) {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
                Text("$label: $value")
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { o ->
                    DropdownMenuItem(
                        text = { Text(o) },
                        onClick = {
                            onSelect(o)
                            open = false
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun AppPickerDialog(onPick: (AppItem?) -> Unit, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Escolher app") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    item {
                        TextButton(onClick = { onPick(null) }) {
                            Text("Automático (padrão da plataforma)")
                        }
                    }
                    items(allApps) { a ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(a) }
                                .padding(vertical = 8.dp)
                        ) {
                            Text(a.label)
                            Text(a.pkg, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
        )
    }

    @Composable
    private fun GameDialog(
        initial: Game?,
        onSave: (Game) -> Unit,
        onDelete: (() -> Unit)?,
        onDismiss: () -> Unit
    ) {
        var title by remember { mutableStateOf(initial?.title ?: "") }
        var platform by remember { mutableStateOf(initial?.platform ?: PLATFORMS[0]) }
        var genre by remember { mutableStateOf(initial?.genre ?: GENRES[0]) }
        var cover by remember { mutableStateOf(initial?.cover ?: "") }
        var webUrl by remember { mutableStateOf(initial?.webUrl ?: "") }
        var pkg by remember { mutableStateOf(initial?.pkg ?: "") }
        var romUri by remember { mutableStateOf(initial?.romUri ?: "") }
        var fav by remember { mutableStateOf(initial?.isFavorite ?: false) }
        var showAppPicker by remember { mutableStateOf(false) }

        val romPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri: Uri? ->
            if (uri != null) {
                persist(uri)
                romUri = uri.toString()
            }
        }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(if (initial == null) "Adicionar jogo" else "Editar jogo") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Título") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    DropdownField("Plataforma", platform, PLATFORMS) { platform = it }
                    DropdownField("Gênero", genre, GENRES) { genre = it }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = cover,
                        onValueChange = { cover = it },
                        label = { Text("URL da capa") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    if (platform == WEB_PLATFORM) {
                        OutlinedTextField(
                            value = webUrl,
                            onValueChange = { webUrl = it },
                            label = { Text("Link do jogo (URL)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        val appLabel = allApps.firstOrNull { it.pkg == pkg }?.label ?: pkg
                        OutlinedButton(
                            onClick = { showAppPicker = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (pkg.isEmpty()) "App/emulador: automático" else "App: $appLabel")
                        }
                        OutlinedButton(
                            onClick = { romPicker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (romUri.isEmpty()) "Escolher ROM" else "ROM selecionada ✓")
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = fav, onCheckedChange = { fav = it })
                        Text("Favorito ⭐")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) {
                        val now = System.currentTimeMillis()
                        val exec = if (initial == null || initial.platform != platform) {
                            DEFAULT_EXEC[platform] ?: "native"
                        } else {
                            initial.execType
                        }
                        val base = initial ?: Game(
                            id = UUID.randomUUID().toString(),
                            title = "",
                            platform = platform,
                            genre = genre
                        )
                        val favTs = if (fav && initial?.isFavorite != true) now else (initial?.favoriteTs ?: 0L)
                        onSave(
                            base.copy(
                                title = title.trim(),
                                platform = platform,
                                genre = genre,
                                cover = cover.trim(),
                                webUrl = webUrl.trim(),
                                execType = exec,
                                pkg = pkg,
                                romUri = romUri,
                                isFavorite = fav,
                                favoriteTs = favTs
                            )
                        )
                    }
                }) { Text("Salvar") }
            },
            dismissButton = {
                Row {
                    if (onDelete != null) {
                        TextButton(onClick = onDelete) { Text("Apagar", color = Color(0xFFFF453A)) }
                    }
                    TextButton(onClick = onDismiss) { Text("Cancelar") }
                }
            }
        )

        if (showAppPicker) {
            AppPickerDialog(
                onPick = { a ->
                    pkg = a?.pkg ?: ""
                    showAppPicker = false
                },
                onDismiss = { showAppPicker = false }
            )
        }
    }
}
