package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class RomEntry(val name: String, val folder: String, val uri: String)

class RomListRequest(val platform: String, val onPick: (String, String) -> Unit)

class EmuPickerRequest(val platform: EmuPlatform, val onPick: (EmuPlayer) -> Unit)

/** Capas em lote: andamento da busca no SteamGridDB (roda em segundo plano). */
class CoverBatch(val scope: String, val total: Int) {
    var done by androidx.compose.runtime.mutableIntStateOf(0)
    var applied by androidx.compose.runtime.mutableIntStateOf(0)
    var running by androidx.compose.runtime.mutableStateOf(true)
    var error by androidx.compose.runtime.mutableStateOf("")
    val notFound = androidx.compose.runtime.mutableStateListOf<String>()
    @Volatile var cancelled = false
}

/** Seletor de plataforma (busca + lista completa + criar/editar/apagar personalizadas). */
class PlatPickerRequest(
    val title: String,
    val selected: String,
    val filter: (String) -> Boolean,
    /** Chamado quando uma plataforma personalizada é renomeada (new = novo nome) ou apagada (new = ""). */
    val onChanged: (old: String, new: String) -> Unit,
    val onPick: (String) -> Unit
)

class BuiltIntent(val intent: Intent, val kill: Boolean)

class ScanResult(val roms: List<RomEntry>, val failed: Int)

// ---------- Cadastro em lote ----------
class BatchItem(val key: String, val variants: List<ScanCandidate>, chosen: ScanCandidate) {
    var cand by mutableStateOf(chosen)
    var checked by mutableStateOf(true)
}

class BatchIgnored(val item: IgnoredItem) {
    var checked by mutableStateOf(false)
}

enum class BatchPhase { SCANNING, REGIONS, LIST }

class BatchSession(val platform: String, val profile: ScanProfile) {
    var phase by mutableStateOf(BatchPhase.SCANNING)
    var found by mutableStateOf(0)
    @Volatile var cancelled = false
    @Volatile var failedFolders = 0
    var all: List<ScanCandidate> = emptyList()
    var ignored: List<IgnoredItem> = emptyList()
    var alreadyCount by mutableStateOf(0)
    var dupGroups by mutableStateOf(0)
    val items = mutableStateListOf<BatchItem>()
    val ignoredItems = mutableStateListOf<BatchIgnored>()
    var query by mutableStateOf("")
    var showIgnored by mutableStateOf(false)
}

/** 4.9.5: rolagem da janela aberta (as janelas sem item focável rolam com as setas do controle). */
val LocalModalScroll = androidx.compose.runtime.compositionLocalOf<androidx.compose.foundation.ScrollState?> { null }

sealed class Overlay {
    object None : Overlay()
    class Edit(val game: Game?) : Overlay()
    object Filter : Overlay()
    object Settings : Overlay()
    object Genres : Overlay()
    object Platforms : Overlay()
    object CoverBatchSetup : Overlay()
    class LinkEdit(val link: PlatformLink?) : Overlay()
    object Search : Overlay()
    object ResetGames : Overlay()
    object ConfirmFactory : Overlay()
    class ConfirmDelete(val game: Game) : Overlay()
    class Info(val id: String) : Overlay()
    class PlatformImage(val name: String) : Overlay()
    object Collections : Overlay()
    class ConfirmDeleteCollection(val name: String) : Overlay()
    object StoragePrompt : Overlay()
    class AddChoice(val first: Boolean) : Overlay()
    object BatchSetup : Overlay()
    /** 4.6.1 (TV): escolha do modo de visualização das capas (botão do olho). */
    object ViewMode : Overlay()
    /** 4.9.3: botão START (cabeçalho ou controle): adicionar novo jogo ou editar o jogo em foco. */
    object StartMenu : Overlay()
    /** 4.9.3: tela que mostra ao vivo o que o controle manda (Configurações > Sistema). */
    object PadTest : Overlay()
    /** 4.9.4: botão "?" das Configurações: estatísticas, aparelho, diagnóstico, atualização e créditos. */
    object About : Overlay()
}

internal const val SETTINGS_TABS = 4   // Visual, Biblioteca, Sistema, Extras
internal const val ADD_ID = "__add__"
internal const val H_ORIENT = 0
internal const val H_FLOAT = 1
internal const val H_SELECT = 2
internal const val H_START = 3
internal const val H_GEAR = 4
internal const val H_EYE = 5
/** Modos de visualização da TV (4.6.1). */
internal const val TV_VIEW_STD = 0
internal const val TV_VIEW_CAROUSEL = 1
internal const val TV_VIEW_GRID = 2
internal const val TV_VIEW_LIST = 3
/** Espaço acima da primeira linha da grade/lista; o brilho da capa não pode passar disso sem ser cortado. */
internal const val LIST_TOP_PAD_DP = 10f
internal const val LIST_ROW_H_DP = 96
internal const val LIST_ROW_MIN_DP = 72
internal const val LIST_ROW_MAX_DP = 170
internal const val NO_GENRE = "Sem gênero"
internal const val PLAT_PREFIX = "plat:"

/** 4.9.3: quanto rolar (px; positivo = avançar) para um item que começa em [start] e tem [size] ficar inteiro dentro de [0, end - margin]. */
internal fun fitDelta(start: Float, size: Float, end: Float, margin: Float): Float = when {
    start < 0f -> start
    start + size > end - margin -> start + size - end + margin
    else -> 0f
}

class SgdbPicker(val title: String, val term: String, val portrait: Boolean, val onPick: (String) -> Unit)

internal const val APP_VERSION = "4.9.9"

// Paleta do destaque (borda e LED). A ordem é a mesma da paleta antiga, para migrar quem já tinha uma cor salva.
internal val ACCENTS = listOf(
    "Azul" to "#0A84FF", "Verde" to "#30D158", "Laranja" to "#FF9F0A", "Vermelho" to "#FF453A",
    "Roxo" to "#BF5AF2", "Amarelo" to "#FFD60A", "Branco" to "#FFFFFF", "Ciano" to "#00E5FF",
    "Rosa" to "#FF4DA6", "Verde-limão" to "#AEEA00"
)
internal val OLD_COLORS = listOf(
    "#007AFF", "#4CD964", "#FF9500", "#FF3B30", "#AF52DE", "#FFCC00", "#FFFFFF",
    "#00E5FF", "#FF2D95", "#C6FF00"
)

internal val SORTS = listOf(
    "Padrão (Recentes > Favoritos > A-Z)",
    "Jogados recentemente (últimos 10)",
    "A-Z (crescente)",
    "Z-A (decrescente)"
)

internal val EXEC_KEYWORD = mapOf(
    "aethersx2" to "aethersx2",
    "dolphin" to "dolphin",
    "eden" to "eden",
    "gamehub" to "gamehub",
    "pizzaboy" to "pizza boy",
    "ppsspp" to "ppsspp",
    "snes9x" to "snes9x",
    "vita3k" to "vita3k"
)

/** Tempo (ms) com o OK apertado para valer como toque longo. */
internal const val OK_LONG_MS = 500L

internal val PAD_KEYS = setOf(
    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
    KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2
)

// Navegação com repetição: 1 toque = 1 item; segurando, repete após HOLD_DELAY_MS
// e acelera de RATE_MIN até RATE_MAX itens/segundo ao longo de RATE_RAMP_MS.
internal const val HOLD_DELAY_MS = 400L
internal const val RATE_MIN = 3f
internal const val RATE_MAX = 6f
internal const val RATE_RAMP_MS = 2000L
internal const val PAGE_ITEMS = 4
internal const val TRIGGER_PRESS = 0.10f   // zona morta de 10% dos gatilhos
internal const val TRIGGER_RELEASE = 0.05f
internal const val STICK_ON = 0.6f
internal const val STICK_OFF = 0.4f

internal val C_PANEL = Color(0xFF141720)
internal val C_FIELD = Color(0xFF11141C)
internal val C_BORDER = Color(0x24FFFFFF)
internal val C_MUTED = Color(0xFF9AA3B5)
internal val C_BLUE = Color(0xFF0A84FF)
internal val C_ORANGE = Color(0xFFF59E0B)
internal val C_RED = Color(0xFFE11D48)
internal val C_GRAY = Color(0xFF1E222B)
internal val C_YELLOW = Color(0xFFFBBF24)
internal val S_PANEL = Color(0xFF141720)
internal val HDR_BG = Color(0xE0181C25)
internal val HDR_LINE = Color(0x1AFFFFFF)
internal val S_CARD = Color(0xFF1A1E29)
internal val S_FIELD = Color(0xFF11141C)
internal val S_LINE = Color(0x1AFFFFFF)
internal val S_MUTED = Color(0xFF9AA3B5)
internal val S_PAD_A = Color(0xFF1DB87A)
internal val S_PAD_B = Color(0xFFE5484D)

class MainActivity : ComponentActivity() {

    // ---------- Estado ----------
    internal val prefs by lazy { getSharedPreferences("nexus_prefs", MODE_PRIVATE) }
    internal val libFile by lazy { File(filesDir, "library.json") }
    internal val sgdbFile by lazy { File(filesDir, "sgdb_cache.json") }
    internal val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    internal var sgdbKey by mutableStateOf("")
    internal var ytKey by mutableStateOf("") // 4.7.0: chave da API do YouTube (vídeo gameplay)
    internal var hideSgdbHint by mutableStateOf(false)
    internal val sgdbCache = mutableStateMapOf<String, SgdbInfo>()
    internal val sgdbErr = mutableStateMapOf<String, String>()
    internal var sgdbBusy by mutableStateOf(setOf<String>())
    // ---- 4.7.0: vídeo gameplay ----
    internal val ytCtrl = YtController().also { c -> c.onRevealed = { ytCtl = YT_PLAY } }
    internal var ytOpen by mutableStateOf(false)
    internal var ytNav by mutableStateOf(false)
    internal var ytFull by mutableStateOf(false)
    internal var ytCtl by mutableStateOf(YT_PLAY)
    internal var ytBusy by mutableStateOf(setOf<String>())
    internal val ytErr = mutableStateMapOf<String, String>()
    internal var ytRegion by mutableStateOf<androidx.compose.ui.geometry.Rect?>(null)
    internal var videoLinkFor by mutableStateOf<Game?>(null)
    internal var sgdbPicker by mutableStateOf<SgdbPicker?>(null)
    internal val games = mutableStateListOf<Game>()
    internal val genres = mutableStateListOf<String>()
    internal val links = mutableStateListOf<PlatformLink>()
    internal val platforms = mutableStateListOf<GamePlatform>()
    internal var allApps: List<AppItem> = emptyList()
    internal val iconCache = HashMap<String, ImageBitmap?>()
    internal val bigIconCache = HashMap<String, ImageBitmap?>()

    internal var selectedId by mutableStateOf<String?>(null)
    internal var coverRev by mutableStateOf(0)
    internal var storageOk by mutableStateOf(false)
    internal var overlayState by mutableStateOf<Overlay>(Overlay.None)

    /**
     * 4.9.5: pilha de telas. Ao ir para uma tela "filha" a atual é empilhada; ao pedir a tela que está no topo da pilha
     * (Voltar) ela é desempilhada. "Voltar" sempre volta UMA tela só, para a que abriu a atual.
     */
    internal val overlayStack = ArrayList<Overlay>()
    internal var overlay: Overlay
        get() = overlayState
        set(v) {
            val cur = overlayState
            if (v is Overlay.Settings && cur is Overlay.None) settingsTab = 0   // 4.9.5: Configurações sempre abre na aba Visual
            if (v is Overlay.None) {
                returnKey = ""
                overlayStack.clear()
            } else if (overlayStack.isNotEmpty() && overlayStack[overlayStack.size - 1] == v) {
                overlayStack.removeAt(overlayStack.size - 1)
            } else if (cur !is Overlay.None && cur != v) {
                // Info -> Editar -> (salvar) volta pra Info; Info nunca fica empilhada duas vezes.
                if (overlayStack.none { it == cur }) overlayStack.add(cur)
            }
            overlayState = v
        }
    /** 4.9.4: celular — true enquanto o usuário usa o controle (volta a false no primeiro toque na tela). */
    internal var padActive by mutableStateOf(false)
    /** 4.9.4: navegação por controle na tela inicial: sempre na TV; no celular só deitado e com o controle em uso. */
    internal val padNav: Boolean get() = TvMode.isTv || (landscape && padActive)
    /** 4.9.4: página aberta dentro da tela "?" (0 = menu). */
    internal var aboutPage by mutableStateOf(0)
    internal var landscape by mutableStateOf(false)
    internal var widthP by mutableStateOf(175)
    /** 4.9.4: o tamanho das capas na paisagem é individual por modo de visualização (padrão e carrossel não se afetam). */
    internal var widthLStd by mutableStateOf(170)
    internal var widthLCar by mutableStateOf(170)
    internal var widthL: Int
        get() = if (tvView == TV_VIEW_CAROUSEL) widthLCar else widthLStd
        set(v) { if (tvView == TV_VIEW_CAROUSEL) widthLCar = v else widthLStd = v }
    /** 4.9.3: grade — 0 = capas pequenas (mais por linha), 1 = médias, 2 = grandes (menos por linha). 4.9.4: um valor por orientação. */
    internal var gridSizeP by mutableStateOf(1)
    internal var gridSizeL by mutableStateOf(1)
    internal var gridSize: Int
        get() = if (landscape) gridSizeL else gridSizeP
        set(v) { if (landscape) gridSizeL = v else gridSizeP = v }
    /** 4.9.3: lista — altura da linha em dp (a capa acompanha a altura; a largura da linha nunca muda). */
    internal var listRowH by mutableStateOf(LIST_ROW_H_DP)
    internal var radius by mutableStateOf(14)
    internal var accentHex by mutableStateOf("#0A84FF")
    internal var settingsTab by mutableStateOf(0)
    internal var cutoutPad by mutableStateOf(false)
    internal var favOnly by mutableStateOf(false)
    internal var searchTerm by mutableStateOf("")
    internal var fPlatform by mutableStateOf("")
    internal var dashMode by mutableStateOf(0)
    internal var dashPlatform by mutableStateOf("")
    internal var fGenre by mutableStateOf("")
    internal var fCollection by mutableStateOf("")
    internal var sortMode by mutableStateOf(0)
    internal var power by mutableStateOf(PowerSnapshot())
    /** O Nexus é o launcher padrão do aparelho agora? (libera as opções do modo launcher) */
    internal var isHome by mutableStateOf(false)
    internal var appsDrawerOpen by mutableStateOf(false)
    internal var carouselOn by mutableStateOf(true)
    internal var introOn by mutableStateOf(true)
    internal var floatSmall by mutableStateOf(false)   // 4.5.4: painel flutuante compacto
    internal var appPickerOpen by mutableStateOf(false)
    /** 0 = todos os apps, 1 = só os marcados como jogo, 2 = só os marcados como emulador. */
    internal var appPickerMode by mutableStateOf(0)
    internal var appFilterKind by mutableStateOf(0)
    internal val hiddenGameApps = mutableStateListOf<String>()
    internal val hiddenEmuApps = mutableStateListOf<String>()
    internal val appAliases = androidx.compose.runtime.mutableStateMapOf<String, String>()
    internal var appPickerNone by mutableStateOf("Automático (padrão da plataforma)")
    internal var romList by mutableStateOf<RomListRequest?>(null)
    internal var batch by mutableStateOf<BatchSession?>(null)
    internal var emuPicker by mutableStateOf<EmuPickerRequest?>(null)
    internal var platPicker by mutableStateOf<PlatPickerRequest?>(null)
    internal var coverBatch by mutableStateOf<CoverBatch?>(null)

    internal var appPickerCb: ((AppItem?) -> Unit)? = null
    internal val collections = mutableStateListOf<String>()
    internal var collPickerOpen by mutableStateOf(false)
    internal val collPickerSel = mutableStateListOf<String>()
    internal var collPickerCb: ((List<String>) -> Unit)? = null
    internal var genrePickerOpen by mutableStateOf(false)
    internal val genrePickerSel = mutableStateListOf<String>()
    internal var genrePickerCb: ((List<String>) -> Unit)? = null
    internal var gridColumns = 2
    internal val padHandler = Handler(Looper.getMainLooper())
    internal val heldKeys = LinkedHashSet<Int>()
    internal var axisDx = 0
    internal var axisDy = 0
    internal var holdDx = 0
    internal var holdDy = 0
    internal var holdStartMs = 0L
    /** 4.9.3: tela de detalhes e player (dentro da janela principal): setas e alavanca viram um passo só, sem duplicar. */
    internal val infoPad = PadFilter { code ->
        val t = SystemClock.uptimeMillis()
        superDispatch(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        superDispatch(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
    internal val ytPad = PadFilter { code ->
        val t = SystemClock.uptimeMillis()
        ytHandleKey(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0), code)
    }
    internal fun superDispatch(ev: KeyEvent): Boolean = super.dispatchKeyEvent(ev)
    internal var ltDown = false
    internal var rtDown = false
    internal val repeatTick = object : Runnable {
        override fun run() {
            if ((holdDx == 0 && holdDy == 0) || modalOpen()) {
                stopHold()
                return
            }
            stepSelection(holdDx, holdDy)
            val held = SystemClock.uptimeMillis() - holdStartMs - HOLD_DELAY_MS
            val t = (held.toFloat() / RATE_RAMP_MS).coerceIn(0f, 1f)
            val rate = RATE_MIN + (RATE_MAX - RATE_MIN) * t
            padHandler.postDelayed(this, (1000f / rate).toLong())
        }
    }
    internal var pendingPlay: Game? = null
    internal var dialogRomCb: ((Uri) -> Unit)? = null
    internal var treeCb: ((String) -> Unit)? = null

    // ---------- Modo TV (4.6.0) ----------
    /** Zona de navegação da tela inicial na TV: 0 = capas, 1 = cabeçalho, 2 = rodapé (A / B / Y / X). */
    internal var navZone by mutableStateOf(0)
    internal var hdrIdx by mutableStateOf(0)
    /**
     * 4.9.3 (TV, modo Padrão): sublinhado fino embaixo da capa focada. Só aparece quando o foco chega na capa vindo do
     * cabeçalho/rodapé (navegação vertical); some assim que o D-pad anda para os lados.
     */
    internal var coverUnderline by mutableStateOf(false)
    internal var ftrIdx by mutableStateOf(0)
    /** Explorador de arquivos embutido (substitui o seletor do Android na TV). */
    internal var explorer by mutableStateOf<ExplorerState?>(null)
    /** Ajuda quando o Android da TV não tem a tela de permissão: "overlay" ou "storage". */
    internal var permHelp by mutableStateOf<String?>(null)
    /** Na tela de informações: o D-pad já foi usado, então A/OK clicam no item destacado em vez de "Jogar". */
    internal var infoNav = false
    /** 4.6.1: modo de visualização da tela inicial na TV: 0 padrão, 1 carrossel, 2 grade, 3 lista. */
    internal var tvView by mutableStateOf(TV_VIEW_STD)

    // ---------- Launchers ----------
    internal val pickRomForPlay = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val g = pendingPlay
        pendingPlay = null
        if (uri != null && g != null) {
            persist(uri)
            val updated = g.copy(romUri = uri.toString())
            replaceGame(updated)
            launchGame(updated)
        }
    }

    internal val pickRomForDialog = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            dialogRomCb?.invoke(uri)
        }
    }

    internal val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) writeBackup(uri) }

    internal val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) readBackup(uri) }

    internal val homeRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { isHome = LauncherMode.isDefault(this) }

    // Painel flutuante (4.5.0): 1) permissão "Exibir sobre outros apps"  2) permissão de notificação  3) liga o serviço.
    internal val overlayPermRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (FloatingPanelService.canDraw(this)) askNotifThenStartFloat() else toast("Sem a permissão, o painel não pode aparecer sobre outros apps") }

    internal val notifPermRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startFloat() }

    internal val treePicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            persist(uri)
            treeCb?.invoke(uri.toString())
        }
    }

    // 4.6.0: na TV a tela é vista de longe, então toda a interface fica maior (equivale a "tamanho de exibição").
    override fun attachBaseContext(newBase: Context) {
        var ctx = newBase
        try {
            TvMode.init(newBase)
            if (TvMode.isTv) {
                val cfg = Configuration(newBase.resources.configuration)
                val sc = TvMode.UI_SCALE
                cfg.densityDpi = (cfg.densityDpi * sc).toInt()
                cfg.screenWidthDp = (cfg.screenWidthDp / sc).toInt()
                cfg.screenHeightDp = (cfg.screenHeightDp / sc).toInt()
                cfg.smallestScreenWidthDp = (cfg.smallestScreenWidthDp / sc).toInt()
                ctx = newBase.createConfigurationContext(cfg)
            }
        } catch (_: Exception) {
        }
        super.attachBaseContext(ctx)
    }

    // ---------- Seletores de arquivo/pasta (4.6.0): na TV usam o explorador embutido ----------
    internal fun openExplorerFile(forPlay: Boolean) {
        explorer = ExplorerState(false, "Escolher o arquivo do jogo", null, null) { f ->
            val uri = Uri.parse(fileUri(f))
            if (forPlay) {
                val g = pendingPlay
                pendingPlay = null
                if (g != null) {
                    val updated = g.copy(romUri = uri.toString())
                    replaceGame(updated)
                    launchGame(updated)
                }
            } else {
                dialogRomCb?.invoke(uri)
            }
        }
    }

    internal fun pickRomFile(forPlay: Boolean) {
        if (TvMode.isTv) {
            openExplorerFile(forPlay)
            return
        }
        try {
            if (forPlay) pickRomForPlay.launch(arrayOf("*/*")) else pickRomForDialog.launch(arrayOf("*/*"))
        } catch (_: Exception) {
            openExplorerFile(forPlay)
        }
    }

    internal fun openExplorerFolder() {
        explorer = ExplorerState(true, "Escolher a pasta", null, null) { f ->
            treeCb?.invoke(ExplorerFs.treeUriFor(f.path))
        }
    }

    internal fun pickFolder() {
        if (TvMode.isTv) {
            openExplorerFolder()
            return
        }
        try {
            treePicker.launch(null)
        } catch (_: Exception) {
            openExplorerFolder()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPrefs()
        // 4.5.4: o Nexus obedece ao Android — gira pelo sensor se o giro automático estiver ligado e fica
        // travado se o usuário bloqueou a rotação. Só o botão do cabeçalho passa por cima do bloqueio.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
        landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        applyFullscreen()
        allApps = loadApps()
        loadLibrary()
        importPendingShortcuts()
        syncPlatforms()
        ensureFixedCollections()
        isHome = LauncherMode.isDefault(this)
        sgdbCache.putAll(SgdbStore.load(sgdbFile))
        File(filesDir, "rawg_cache.json").delete() // restos da integração antiga
        Covers.init(this)
        storageOk = hasAllFiles()
        if (!storageOk && !prefs.getBoolean("storagePrompted", false)) {
            prefs.edit().putBoolean("storagePrompted", true).apply()
            overlay = Overlay.StoragePrompt
        } else {
            maybeWelcome()
        }
        prefetchCovers()
        selectedId = firstNavId()
        setContent {
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, 1f)) {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                        // 4.9.2: lê as cores/raios AQUI (na composição) para o anel de foco acompanhar a troca em tempo real.
                        val focusAccentNow = parseColor(accentHex)
                        val focusRadiusNow = rBtn.toFloat()
                        SideEffect {
                            FocusStyle.accent = focusAccentNow
                            FocusStyle.radiusDp = focusRadiusNow
                        }
                        var showIntro by remember { mutableStateOf(introOn && !NexusIntroState.shown && overlay is Overlay.None) }
                        Box(Modifier.fillMaxSize()) {
                            NexusScreen()
                            if (showIntro) {
                                NexusIntro(
                                    accent = parseColor(accentHex),
                                    onDone = { NexusIntroState.shown = true; showIntro = false }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 4.9.3: se a janela perde/ganha o foco (abriu ou fechou uma janela), nenhuma direção pode ficar "presa":
    // o soltar da tecla chegaria na outra janela e o D-pad pararia de responder.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyFullscreen()
        stopHold()
        infoPad.reset()
        ytPad.reset()
    }

    internal fun applyFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Preferências ----------
    internal fun loadPrefs() {
        widthP = prefs.getInt("widthP", 175)
        widthLStd = prefs.getInt("widthL", 170)
        widthLCar = prefs.getInt("widthLCar", widthLStd)
        gridSizeP = prefs.getInt("gridSizeP", prefs.getInt("gridSize", 1)).coerceIn(0, 2)
        gridSizeL = prefs.getInt("gridSizeL", prefs.getInt("gridSize", 1)).coerceIn(0, 2)
        listRowH = prefs.getInt("listRowH", LIST_ROW_H_DP).coerceIn(LIST_ROW_MIN_DP, LIST_ROW_MAX_DP)
        radius = canonicalRadius(prefs.getInt("radius", 14))
        accentHex = normalizeAccent(prefs.getString("color", "#0A84FF") ?: "#0A84FF")
        cutoutPad = prefs.getBoolean("cutoutPad", false)
        sgdbKey = prefs.getString("sgdbKey", "") ?: ""
        ytKey = prefs.getString("ytKey", "") ?: ""
        hideSgdbHint = prefs.getBoolean("hideSgdbHint", false)
        if (prefs.contains("rawgKey")) prefs.edit().remove("rawgKey").apply()
        dashMode = prefs.getInt("dashMode", 0)
        carouselOn = prefs.getBoolean("carouselOn", true)
        tvView = prefs.getInt("tvView", if (carouselOn) TV_VIEW_CAROUSEL else TV_VIEW_STD).coerceIn(0, 3)
        introOn = prefs.getBoolean("introOn", true)
        floatSmall = prefs.getBoolean("floatSmall", false)
        // 4.5.2: os sons foram removidos; apaga o que ficou salvo.
        if (prefs.contains("soundsOn") || prefs.contains("soundStyle")) prefs.edit().remove("soundsOn").remove("soundStyle").apply()
        collections.clear()
        prefs.getString("collectionsList", null)?.let { s ->
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val n = a.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            } catch (_: Exception) {
            }
        }
        hiddenGameApps.clear()
        hiddenEmuApps.clear()
        appAliases.clear()
        try {
            prefs.getString("hiddenGameApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenGameApps.add(a.getString(i)) } }
            prefs.getString("hiddenEmuApps", null)?.let { j -> JSONArray(j).let { a -> for (i in 0 until a.length()) hiddenEmuApps.add(a.getString(i)) } }
            prefs.getString("appAliases", null)?.let { j ->
                val o = org.json.JSONObject(j)
                for (k in o.keys()) appAliases[k] = o.getString(k)
            }
        } catch (_: Exception) {
        }
        genres.clear()
        val gs = prefs.getString("genres", null)
        if (gs != null) {
            try {
                val a = JSONArray(gs)
                for (i in 0 until a.length()) genres.add(a.getString(i))
            } catch (_: Exception) {
            }
        }
        if (genres.isEmpty()) genres.addAll(GENRES)
        platforms.clear()
        val ps = prefs.getString("platformsList", null)
        if (ps != null) {
            try {
                platforms.addAll(PlatformStore.parse(ps))
            } catch (_: Exception) {
            }
        }
        if (platforms.isEmpty()) platforms.addAll(defaultPlatforms())
        links.clear()
        val ls = prefs.getString("links", null)
        if (ls != null) {
            try {
                links.addAll(LinkStore.parse(ls))
            } catch (_: Exception) {
            }
        }
    }

    /** 4.7.8: true durante "Restaurar configurações de fábrica": nada pode ser regravado antes do reinício. */
    internal var wiping = false

    internal fun savePrefs() {
        if (wiping) return
        prefs.edit()
            .putInt("widthP", widthP)
            .putInt("widthL", widthLStd)
            .putInt("widthLCar", widthLCar)
            .putInt("gridSizeP", gridSizeP)
            .putInt("gridSizeL", gridSizeL)
            .putInt("listRowH", listRowH)
            .putInt("radius", radius)
            .putString("color", accentHex)
            .putBoolean("cutoutPad", cutoutPad)
            .putInt("dashMode", dashMode)
            .putString("collectionsList", JSONArray(collections.toList()).toString())
            .putString("genres", JSONArray(genres.toList()).toString())
            .putString("hiddenGameApps", JSONArray(hiddenGameApps.toList()).toString())
            .putString("hiddenEmuApps", JSONArray(hiddenEmuApps.toList()).toString())
            .putString("appAliases", org.json.JSONObject(appAliases.toMap()).toString())
            .putString("links", LinkStore.toJson(links.toList()))
            .putString("platformsList", PlatformStore.toJson(platforms.toList()))
            .apply()
    }

    /** Orientação que o botão do cabeçalho forçou (null = quem manda é o Android). */
    internal var forcedLandscape: Boolean? = null
    internal var orientListener: OrientationEventListener? = null

    /** O giro automático do Android está ligado? (false = o usuário bloqueou a rotação) */
    internal fun autoRotateOn(): Boolean = try {
        android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.ACCELEROMETER_ROTATION, 0) == 1
    } catch (e: Exception) { true }

    /**
     * O botão gira a tela na hora, mesmo com o giro automático bloqueado. Com o giro automático LIGADO, quando
     * o aparelho for girado de verdade para a mesma posição o Android volta a mandar. Com o giro BLOQUEADO, o
     * Nexus fica na orientação escolhida até o botão ser tocado de novo.
     */
    internal fun toggleOrientation() {
        val target = !landscape
        forcedLandscape = target
        landscape = target
        requestedOrientation =
            if (target) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    internal fun startOrientationWatch() {
        if (orientListener == null) {
            orientListener = object : OrientationEventListener(this) {
                override fun onOrientationChanged(deg: Int) {
                    val forced = forcedLandscape ?: return
                    if (deg == OrientationEventListener.ORIENTATION_UNKNOWN) return
                    if (!autoRotateOn()) return
                    val physLand = deg in 60..120 || deg in 240..300
                    val physPort = deg <= 30 || deg >= 330 || deg in 150..210
                    if ((forced && physLand) || (!forced && physPort)) {
                        forcedLandscape = null
                        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                    }
                }
            }
        }
        orientListener?.let { if (it.canDetectOrientation()) it.enable() }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        landscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    // ---------- Tema ao vivo (3.9.5) ----------
    // 0 = Reto, 1 = Padrão, 2 = Suave. Tudo (painéis, cards, botões, campos) lê estes valores.
    internal fun styleOf(r: Int): Int = when {
        r <= 6 -> 0
        r <= 17 -> 1
        else -> 2
    }
    internal fun canonicalRadius(r: Int): Int = intArrayOf(4, 14, 22)[styleOf(r)]
    internal fun normalizeAccent(hex: String): String {
        if (hex.equals("#FF375F", true)) return ACCENTS[8].second // rosa antigo (parecido com o vermelho)
        ACCENTS.firstOrNull { it.second.equals(hex, true) }?.let { return it.second }
        val i = OLD_COLORS.indexOfFirst { it.equals(hex, true) }
        return if (i >= 0) ACCENTS[i].second else hex
    }
    internal val styleIdx: Int get() = styleOf(radius)
    internal val rPanel: Int get() = intArrayOf(6, 18, 28)[styleIdx]
    internal val rCard: Int get() = intArrayOf(4, 14, 22)[styleIdx]
    internal val rBtn: Int get() = intArrayOf(4, 11, 18)[styleIdx]
    internal fun onAccent(c: Color): Color = if (c.luminance() > 0.55f) Color(0xFF07090D) else Color.White

    /** Borda de foco na cor de destaque (navegação por controle). Deve vir ANTES do clickable. */
    @Composable
    internal fun Modifier.focusGlow(shape: Shape): Modifier {
        var focused by remember { mutableStateOf(false) }
        val accent = FocusStyle.navColor
        return this
            .ownRing()
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) FocusProbe.touch() }
            .then(
                if (focused) Modifier.border(3.dp, accent, shape).background(accent.copy(alpha = 0.18f), shape)
                else Modifier
            )
    }

    internal fun parseColor(hex: String): Color = try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (_: Exception) {
        Color(0xFF0A84FF)
    }

    // ---------- Biblioteca ----------
    internal fun defaultGames(): List<Game> =
        LibraryStore.parse(assets.open("default_library.json").bufferedReader().use { it.readText() })

    internal fun loadLibrary() {
        val existed = libFile.exists()
        val list = try {
            if (existed) LibraryStore.parse(libFile.readText()) else defaultGames()
        } catch (e: Exception) {
            toast("Erro ao ler biblioteca: ${e.message}")
            emptyList()
        }
        games.addAll(list)
        if (!existed) saveLibrary()
    }

    internal fun saveLibrary() {
        if (wiping) return
        try {
            libFile.writeText(LibraryStore.toJson(games.toList()))
        } catch (e: Exception) {
            toast("Erro ao salvar: ${e.message}")
        }
    }

    internal fun replaceGame(updated: Game) {
        val idx = games.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            games[idx] = updated
            saveLibrary()
        }
    }

    internal fun markPlayed(g: Game) {
        val idx = games.indexOfFirst { it.id == g.id }
        if (idx >= 0) {
            games[idx] = games[idx].copy(
                lastPlayedTs = System.currentTimeMillis(),
                openCount = games[idx].openCount + 1
            )
            saveLibrary()
        }
    }

    // 4.7.0: sempre os 3 últimos; com o filtro "Jogados recentemente" (Select) valem os 10 últimos.
    // 4.9.0: listas calculadas UMA vez e reaproveitadas (só recalculam quando jogos/filtros mudam).
    internal val recentIdsD = derivedStateOf { computeRecentIds() }
    internal val filteredGamesD = derivedStateOf { computeFilteredGames() }
    internal val visibleGamesD = derivedStateOf { computeVisibleGames() }
    internal val platformCardsD = derivedStateOf { computePlatformCards() }
    internal fun recentIds(): Set<String> = recentIdsD.value
    internal fun filteredGames(): List<Game> = filteredGamesD.value
    internal fun visibleGames(): List<Game> = visibleGamesD.value
    internal fun platformCards(): List<GamePlatform> = platformCardsD.value

    internal fun computeRecentIds(): Set<String> =
        games.filter { it.lastPlayedTs > 0 }
            .sortedByDescending { it.lastPlayedTs }
            .take(if (sortMode == 1) 10 else 3).map { it.id }.toSet()

    // Filtros do botão Select (favoritos, plataforma, gênero e coleção), sem o recorte do dashboard.
    internal fun computeFilteredGames(): List<Game> {
        var l: List<Game> = games.toList()
        if (favOnly) l = l.filter { it.isFavorite }
        if (fPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == fPlatform }
        if (fGenre.isNotEmpty()) l = l.filter { if (fGenre == NO_GENRE) it.genres.isEmpty() else fGenre in it.genres }
        if (fCollection.isNotEmpty()) l = l.filter { fCollection in it.collections }
        val k = searchTerm.trim().lowercase()
        if (k.isNotEmpty()) {
            l = l.filter { g ->
                g.title.lowercase().contains(k) || g.shownPlatform.lowercase().contains(k) ||
                    g.genres.any { it.lowercase().contains(k) } || (k.length >= 3 && g.genres.isEmpty() && foldText(NO_GENRE).contains(foldText(k))) || g.collections.any { it.lowercase().contains(k) }
            }
        }
        return l
    }

    internal fun computeVisibleGames(): List<Game> {
        var l: List<Game> = filteredGames()
        if (dashMode == 1 && dashPlatform.isNotEmpty()) l = l.filter { it.shownPlatform == dashPlatform }
        return when (sortMode) {
            1 -> l.filter { it.lastPlayedTs > 0 }.sortedByDescending { it.lastPlayedTs }.take(10)
            2 -> l.sortedAlpha { it.title }
            3 -> l.sortedAlpha { it.title }.reversed()
            else -> {
                val rec = l.filter { it.lastPlayedTs > 0 }
                    .sortedByDescending { it.lastPlayedTs }.take(3)
                val ids = rec.map { it.id }.toSet()
                val rest = l.filter { it.id !in ids }
                rec +
                    rest.filter { it.isFavorite }.sortedAlpha { it.title } +
                    rest.filter { !it.isFavorite }.sortedAlpha { it.title }
            }
        }
    }

    // ---------- Dashboard por plataformas ----------
    internal fun computePlatformCards(): List<GamePlatform> =
        filteredGames().let { fg ->
            platforms.filter { p -> fg.any { it.shownPlatform == p.name } }
                .sortedAlpha { it.name }
        }

    // Tela de plataformas ativa (modo Plataformas, fora de qualquer plataforma e com ao menos um jogo).
    internal fun inPlatformList(): Boolean =
        dashMode == 1 && dashPlatform.isEmpty() && platformCards().isNotEmpty()

    internal fun navIds(): List<String> =
        if (inPlatformList()) platformCards().map { PLAT_PREFIX + it.name }
        else visibleGames().map { it.id } + ADD_ID

    internal fun firstNavId(): String? =
        if (inPlatformList()) navIds().firstOrNull() else visibleGames().firstOrNull()?.id

    internal fun enterPlatform(name: String) {
        dashPlatform = name
        selectedId = visibleGames().firstOrNull()?.id
    }

    internal fun exitPlatform() {
        val left = dashPlatform
        dashPlatform = ""
        selectedId = if (platformCards().any { it.name == left }) PLAT_PREFIX + left else firstNavId()
    }

    internal fun savePlatformImage(name: String, url: String) {
        val i = platforms.indexOfFirst { it.name == name }
        if (i < 0) return
        val old = platforms[i].image
        val u = url.trim()
        platforms[i] = platforms[i].copy(image = u)
        savePrefs()
        if (old.isNotBlank() && old != u) {
            Covers.purgeIfUnused(old, games.map { it.cover } + platforms.map { it.image })
        }
        prefetchCovers()
    }

    internal fun resetFilters() {
        favOnly = false
        fPlatform = ""
        fGenre = ""
        fCollection = ""
        searchTerm = ""
        sortMode = 0
    }

    internal fun selectGame(id: String) {
        if (dashMode == 1) {
            games.firstOrNull { it.id == id }?.let { if (dashPlatform != it.shownPlatform) dashPlatform = it.shownPlatform }
        }
        if (visibleGames().none { it.id == id }) resetFilters()
        selectedId = id
    }

    // ---------- Coleções (franquias e grupos) ----------
    /**
     * Garante as coleções fixas (Já zerei, Jogando agora, Quero jogar, Clássicos, Abandonados).
     * Uma coleção sua com o mesmo nome (mesmo com maiúsculas diferentes) é unida à fixa, sem perder os jogos.
     */
    internal fun ensureFixedCollections() {
        val rename = HashMap<String, String>()
        for (c in collections.toList()) {
            val f = FIXED_COLLECTIONS.firstOrNull { it.equals(c, ignoreCase = true) }
            if (f != null && f != c) rename[c] = f
        }
        var changedGames = false
        if (rename.isNotEmpty()) {
            for (old in rename.keys) collections.remove(old)
            for (k in games.indices) {
                val cs = games[k].collections
                if (cs.any { it in rename }) {
                    games[k] = games[k].copy(collections = cs.map { rename[it] ?: it }.distinct())
                    changedGames = true
                }
            }
            if (fCollection in rename) fCollection = rename[fCollection] ?: ""
        }
        var changed = rename.isNotEmpty()
        for (f in FIXED_COLLECTIONS) {
            if (f !in collections) {
                collections.add(f)
                changed = true
            }
        }
        if (changedGames) saveLibrary()
        if (changed) savePrefs()
    }

    /** Fixas primeiro (na ordem definida), depois as suas em ordem alfabética. */
    internal fun orderedCollections(): List<String> =
        FIXED_COLLECTIONS.filter { it in collections } + collections.filter { !isFixedCollection(it) }.sortedAlpha { it }

    internal fun userCollectionCount(): Int = collections.count { !isFixedCollection(it) }

    internal fun addCollection(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        if (collections.any { it.equals(n, ignoreCase = true) }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        collections.add(n)
        savePrefs()
    }

    internal fun renameCollection(old: String, new: String) {
        if (isFixedCollection(old)) {
            toast("Esta coleção é fixa e não pode ser renomeada")
            return
        }
        val n = new.trim()
        if (n.isEmpty() || n == old) return
        if (collections.any { it.equals(n, ignoreCase = true) && it != old }) {
            toast("Já existe uma coleção com esse nome")
            return
        }
        val i = collections.indexOf(old)
        if (i >= 0) collections[i] = n
        if (fCollection == old) fCollection = n
        for (k in games.indices) {
            if (old in games[k].collections) {
                games[k] = games[k].copy(collections = games[k].collections.map { if (it == old) n else it })
            }
        }
        saveLibrary()
        savePrefs()
    }

    internal fun deleteCollection(c: String) {
        if (isFixedCollection(c)) {
            toast("Esta coleção é fixa e não pode ser apagada")
            return
        }
        collections.remove(c)
        if (fCollection == c) fCollection = ""
        for (k in games.indices) {
            if (c in games[k].collections) games[k] = games[k].copy(collections = games[k].collections - c)
        }
        saveLibrary()
        savePrefs()
    }

    internal fun renameGenre(old: String, new: String) {
        val n = new.trim()
        if (n.isEmpty() || (n != old && n in genres)) return
        val i = genres.indexOf(old)
        if (i >= 0) genres[i] = n
        for (k in games.indices) if (old in games[k].genres) games[k] = games[k].copy(genres = games[k].genres.map { if (it == old) n else it }.distinct())
        if (fGenre == old) fGenre = n
        saveLibrary()
        savePrefs()
    }

    internal fun deleteGenre(g: String) {
        genres.remove(g)
        for (k in games.indices) if (g in games[k].genres) games[k] = games[k].copy(genres = games[k].genres - g)
        if (fGenre == g) fGenre = ""
        saveLibrary()
        savePrefs()
    }

    // ---------- Ações ----------
    // Um passo na direção (dx, dy). Na paisagem só importa dx; no retrato dy anda uma linha.
    internal fun stepSelection(dx: Int, dy: Int) {
        if (dx != 0) coverUnderline = false
        if (padNav) {
            // TV: o D-pad também chega ao cabeçalho (cima) e ao rodapé (baixo) da tela inicial.
            if (navZone != 0) {
                zoneStep(dx, dy)
                return
            }
            // Modo Lista: só cima/baixo andam pelos cartões.
            if (tvListOn && dx != 0) return
            if (zoneEnter(dx, dy)) return
        }
        stepSelectionRaw(dx, dy)
    }

    /** 4.6.1 (TV, horizontal): modo Grade — igual ao do celular em pé, adaptado para a tela deitada. */
    internal val tvGridOn: Boolean get() = landscape && tvView == TV_VIEW_GRID
    /** 4.6.1 (TV, horizontal): modo Lista — cartões com capa e informações, rolagem para cima e para baixo. */
    internal val tvListOn: Boolean get() = landscape && tvView == TV_VIEW_LIST
    /** Navegação numa fila só, para os lados (celular deitado e TV nos modos Padrão/Carrossel). */
    internal val rowNav: Boolean get() = landscape && !tvGridOn && !tvListOn
    /** Colunas usadas pelo D-pad: 1 na lista; as da grade nos outros modos de grade. */
    internal fun navCols(): Int = if (tvListOn) 1 else max(1, gridColumns)

    /**
     * 4.9.3: quantas capas cabem por linha na grade. Conta os dp da tela e oferece 3 tamanhos:
     * size 0 = pequenas (uma a mais que o confortável), 1 = médias, 2 = grandes (uma a menos).
     * Os cartões de plataforma são mais largos (cerca de 1,5 capa), então usam menos colunas.
     */
    internal fun gridColsFor(screenDp: Float, size: Int, plat: Boolean): Int {
        val gap = 14f
        val avail = screenDp - (if (TvMode.isTv) 36f else 16f)
        val c0 = ((avail + gap) / (120f + gap)).roundToInt().coerceIn(2, 10)
        val cMax = max(c0, ((avail + gap) / (70f + gap)).toInt())
        val g = when (size.coerceIn(0, 2)) {
            0 -> min(c0 + 1, cMax)
            2 -> max(2, c0 - 1)
            else -> c0
        }
        return if (plat) max(2, (g / 1.5f).roundToInt()) else g
    }

    /** Itens do cabeçalho na ordem em que aparecem (a TV não tem o botão de girar a tela). */
    internal fun headerOrder(): List<Int> {
        val l0 = if (landscape) listOf(H_ORIENT, H_FLOAT, H_SELECT, H_START, H_GEAR)
        else listOf(H_ORIENT, H_SELECT, H_START, H_FLOAT, H_GEAR)
        // 4.9.3: Fire TV não mostra temperatura nem painel flutuante, então o botão sai do cabeçalho.
        val l = if (TvMode.isFireTv) l0.filter { it != H_FLOAT } else l0
        // 4.7.7: no celular deitado o olho vem logo depois do botão de girar a tela.
        if (!TvMode.isTv) return if (landscape) listOf(H_ORIENT, H_EYE) + l.drop(1) else l
        // TV deitada: o olho (modos de visualização) ocupa o lugar do botão de girar a tela.
        val tvl = l.filter { it != H_ORIENT }
        return if (landscape) listOf(H_EYE) + tvl else tvl
    }

    internal fun zoneCount(): Int = when (navZone) {
        1 -> headerOrder().size
        2 -> 4
        else -> 0
    }

    internal fun zoneStep(dx: Int, dy: Int) {
        if (dx != 0) {
            val n = max(1, zoneCount())
            if (navZone == 1) hdrIdx = (hdrIdx + dx).coerceIn(0, n - 1)
            else ftrIdx = (ftrIdx + dx).coerceIn(0, n - 1)
            return
        }
        if ((navZone == 1 && dy > 0) || (navZone == 2 && dy < 0)) {
            navZone = 0
            coverUnderline = true   // 4.9.3: o foco voltou para a capa pela vertical: mostra o sublinhado
        }
    }

    /** O sublinhado aparece só no modo Padrão da TV, na capa em foco, enquanto o D-pad não anda para os lados. */
    internal fun showUnderline(selected: Boolean): Boolean =
        selected && coverUnderline && navZone == 0 && padNav && rowNav && !carouselOn

    internal fun zoneEnter(dx: Int, dy: Int): Boolean {
        if (dy == 0 || dx != 0) return false
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        val cols = navCols()
        val firstRow = rowNav || idx < cols
        val lastRow = rowNav || idx < 0 || idx >= ((ids.size - 1) / cols) * cols
        if (dy < 0 && firstRow) {
            hdrIdx = hdrIdx.coerceIn(0, max(0, headerOrder().size - 1))
            navZone = 1
            return true
        }
        if (dy > 0 && lastRow) {
            ftrIdx = ftrIdx.coerceIn(0, 3)
            navZone = 2
            return true
        }
        return false
    }

    /** OK do controle remoto / botão A: age sobre o que está destacado (capa, botão do cabeçalho ou do rodapé). */
    internal fun zoneActivate() {
        when (navZone) {
            1 -> when (headerOrder().getOrNull(hdrIdx)) {
                H_ORIENT -> toggleOrientation()
                H_EYE -> overlay = Overlay.ViewMode
                H_FLOAT -> toggleFloat()
                H_SELECT -> overlay = Overlay.Filter
                H_START -> overlay = Overlay.StartMenu
                H_GEAR -> overlay = Overlay.Settings
            }
            2 -> when (ftrIdx) {
                0 -> openSelected()
                1 -> {
                    navZone = 0
                    back()
                }
                2 -> overlay = Overlay.Search
                3 -> randomPick()
            }
            else -> openSelected()
        }
    }

    internal fun stepSelectionRaw(dx: Int, dy: Int) {
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val step = if (rowNav) dx else if (tvListOn) dy else dx + dy * navCols()
        if (step == 0) return
        val target = idx + step
        if (target in ids.indices) {
            selectedId = ids[target]
        } else if (dy > 0 && !rowNav) {
            selectedId = ids.last()
        }
    }

    // RB (+1) / LB (-1): PAGE_ITEMS jogos. Paisagem = para o lado; retrato = linhas para baixo/cima na mesma coluna.
    internal fun pageStep(sign: Int) {
        val before = selectedId
        pageStepRaw(sign)
    }

    internal fun pageStepRaw(sign: Int) {
        coverUnderline = false
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val unit = if (rowNav) 1 else navCols()
        selectedId = ids[(idx + sign * PAGE_ITEMS * unit).coerceIn(0, ids.lastIndex)]
    }

    // RT (toEnd = true) / LT (false): último/primeiro jogo da fila.
    // Paisagem = fim/começo da lista; retrato = fim/topo da coluna em que está.
    internal fun jumpEdge(toEnd: Boolean) {
        val before = selectedId
        jumpEdgeRaw(toEnd)
    }

    internal fun jumpEdgeRaw(toEnd: Boolean) {
        coverUnderline = false
        val ids = navIds()
        val idx = ids.indexOf(selectedId)
        if (idx < 0) {
            selectedId = ids.first()
            return
        }
        val lastGame = if (ids.lastOrNull() == ADD_ID) ids.size - 2 else ids.size - 1 // "Adicionar" não conta
        if (lastGame < 0) return
        if (rowNav) {
            selectedId = ids[if (toEnd) lastGame else 0]
            return
        }
        val cols = navCols()
        val col = idx % cols
        val target = if (toEnd) {
            if (lastGame >= col) lastGame - ((lastGame - col) % cols) else lastGame
        } else {
            if (col <= lastGame) col else 0
        }
        selectedId = ids[target]
    }

    internal fun currentDir(): Pair<Int, Int> {
        when (heldKeys.lastOrNull()) {
            KeyEvent.KEYCODE_DPAD_LEFT -> return Pair(-1, 0)
            KeyEvent.KEYCODE_DPAD_RIGHT -> return Pair(1, 0)
            KeyEvent.KEYCODE_DPAD_UP -> return Pair(0, -1)
            KeyEvent.KEYCODE_DPAD_DOWN -> return Pair(0, 1)
        }
        return Pair(axisDx, axisDy)
    }

    // Chamado sempre que botão/alavanca muda: nova direção = um passo imediato + início da contagem de "segurar".
    internal fun updateHold() {
        val (dx, dy) = currentDir()
        if (dx == holdDx && dy == holdDy) return
        holdDx = dx
        holdDy = dy
        padHandler.removeCallbacks(repeatTick)
        if (dx == 0 && dy == 0) return
        stepSelection(dx, dy)
        holdStartMs = SystemClock.uptimeMillis()
        padHandler.postDelayed(repeatTick, HOLD_DELAY_MS)
    }

    internal fun stopHold() {
        padHandler.removeCallbacks(repeatTick)
        heldKeys.clear()
        axisDx = 0
        axisDy = 0
        holdDx = 0
        holdDy = 0
        ltDown = false
        rtDown = false
    }

    internal fun handleTriggers(ev: MotionEvent) {
        val l = max(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val r = max(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        if (!ltDown && l >= TRIGGER_PRESS) {
            ltDown = true
            jumpEdge(false)
        } else if (ltDown && l < TRIGGER_RELEASE) {
            ltDown = false
        }
        if (!rtDown && r >= TRIGGER_PRESS) {
            rtDown = true
            jumpEdge(true)
        } else if (rtDown && r < TRIGGER_RELEASE) {
            rtDown = false
        }
    }

    // ---------- Plataformas cadastradas ----------
    internal fun platformNames(): List<String> = sortPlatforms(platforms.toList()).map { it.name }

    // Android não usa emulador, então não entra no vínculo de plataformas e emuladores.
    internal fun linkablePlatforms(): List<String> = platformNames().filter { it != ANDROID_PLATFORM }

    // Chave para tabelas embutidas (extensões de ROM, emulador padrão), mesmo se a plataforma foi renomeada.
    internal fun execKey(platform: String): String {
        val b = platforms.firstOrNull { it.name == platform }?.base ?: ""
        return if (b.isEmpty()) platform else b
    }

    // Garante que "Web / Navegador" exista e que toda plataforma usada por algum jogo esteja cadastrada.
    internal fun syncPlatforms() {
        var changed = false
        for (fixed in listOf(WEB_PLATFORM, ANDROID_PLATFORM)) {
            if (platforms.none { it.name == fixed }) {
                platforms.add(GamePlatform(fixed, DEFAULT_MANUFACTURER[fixed] ?: "", fixed))
                changed = true
            }
        }
        for (g in games) {
            if (g.platform.isNotBlank() && platforms.none { it.name == g.platform }) {
                platforms.add(
                    GamePlatform(g.platform, DEFAULT_MANUFACTURER[g.platform] ?: "", if (g.platform in PLATFORMS || EmuCatalog.all(this).any { it.name == g.platform }) g.platform else "")
                )
                changed = true
            }
        }
        if (changed) savePrefs()
    }

    internal fun savePlatform(old: GamePlatform?, name: String, manufacturer: String): Boolean {
        val n = name.trim()
        if (n.isEmpty()) {
            toast("Digite o nome da plataforma")
            return false
        }
        if (platforms.any { it.name.equals(n, ignoreCase = true) && it.name != old?.name }) {
            toast("Já existe uma plataforma com esse nome")
            return false
        }
        val m0 = manufacturer.trim()
        val m = platforms.map { it.manufacturer }.firstOrNull { it.isNotBlank() && it.equals(m0, ignoreCase = true) } ?: m0
        if (old == null) {
            platforms.add(GamePlatform(n, m, ""))
        } else {
            val i = platforms.indexOfFirst { it.name == old.name }
            if (i >= 0) platforms[i] = old.copy(name = n, manufacturer = m)
            if (n != old.name) {
                for (k in games.indices) {
                    if (games[k].platform == old.name) games[k] = games[k].copy(platform = n)
                    if (games[k].maskPlatform == old.name) games[k] = games[k].copy(maskPlatform = n)
                }
                for (k in links.indices) if (links[k].platform == old.name) links[k] = links[k].copy(platform = n)
                if (fPlatform == old.name) fPlatform = n
                if (dashPlatform == old.name) dashPlatform = n
                saveLibrary()
            }
        }
        savePrefs()
        return true
    }

    internal fun deletePlatform(p: GamePlatform) {
        platforms.removeAll { it.name == p.name }
        links.removeAll { it.platform == p.name }
        if (fPlatform == p.name) fPlatform = ""
        savePrefs()
    }

    // ---------- Capas em lote ----------
    internal fun isMobileGame(g: Game): Boolean = g.platform == ANDROID_PLATFORM || g.platform == WEB_PLATFORM

    /** Sem capa própria (o ícone do app não conta como capa). Android/Web só entram se [includeMobile]. */
    internal fun coverEligible(g: Game, scope: String, includeMobile: Boolean = true): Boolean =
        g.cover.isBlank() && (includeMobile || !isMobileGame(g)) &&
            (scope.isEmpty() || g.shownPlatform == scope)

    internal fun coverMissingCount(): Int = games.count { coverEligible(it, "") }

    internal fun startCoverBatch(scope: String, includeMobile: Boolean) {
        val key = sgdbKey.trim()
        if (key.isEmpty()) {
            toast("Informe a chave do SteamGridDB em Sistema")
            return
        }
        val targets = games.filter { coverEligible(it, scope, includeMobile) }.sortedWith(compareBy(ALPHA) { it.platform })
        if (targets.isEmpty()) {
            toast("Nenhum jogo sem capa")
            return
        }
        val job = CoverBatch(scope, targets.size)
        coverBatch = job
        ScanService.start(this)
        mainScope.launch {
            withContext(Dispatchers.IO) {
                for (g in targets) {
                    if (job.cancelled) break
                    val r = SgdbApi.findGrids(key, g.title, true)
                    if (r is SgdbGridsResult.Failure) {
                        job.error = r.message
                        break
                    }
                    val url = (r as SgdbGridsResult.Ok).grids.firstOrNull()?.url
                    if (url == null) {
                        job.notFound.add(g.title)
                    } else {
                        withContext(Dispatchers.Main) {
                            val i = games.indexOfFirst { it.id == g.id }
                            // Nunca sobrescreve uma capa que já exista.
                            if (i >= 0 && games[i].cover.isBlank()) {
                                games[i] = games[i].copy(cover = url)
                                job.applied++
                            }
                        }
                    }
                    job.done++
                    ScanNotify.progressText(this@MainActivity, "Capas em lote", "${job.done} de ${job.total} jogos")
                    kotlinx.coroutines.delay(120)
                }
            }
            job.running = false
            saveLibrary()
            prefetchCovers()
            ScanService.stop(this@MainActivity)
            ScanNotify.doneTitled(
                this@MainActivity, "Capas em lote concluído",
                "${job.applied} capa(s) aplicada(s), ${job.notFound.size} não encontrada(s)"
            )
        }
    }

    // ---------- SteamGridDB ----------
    internal fun saveSgdb() { if (!wiping) SgdbStore.save(sgdbFile, sgdbCache.toMap()) }

    internal fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    internal fun fmtReleased(secs: Long): String {
        if (secs <= 0L) return ""
        val f = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(secs * 1000L))
    }

    // Busca nome oficial e data de lançamento no SteamGridDB e guarda no aparelho. Só repete se force = true.
    internal fun fetchSgdb(g: Game, force: Boolean = false) {
        val key = sgdbKey.trim()
        if (key.isEmpty() || g.id in sgdbBusy) return
        if (!force && sgdbCache[g.id] != null) return
        sgdbBusy = sgdbBusy + g.id
        sgdbErr.remove(g.id)
        mainScope.launch {
            val res = withContext(Dispatchers.IO) { SgdbApi.lookup(key, g.title) }
            sgdbBusy = sgdbBusy - g.id
            when (res) {
                is SgdbResult.Ok -> {
                    sgdbCache[g.id] = res.info
                    saveSgdb()
                }
                is SgdbResult.Failure -> {
                    sgdbErr[g.id] = res.message
                }
            }
        }
    }

    // Abre o seletor de imagens do SteamGridDB (capas de jogos em pé; imagens de plataformas em qualquer formato).
    internal fun openSgdbPicker(title: String, term: String, portrait: Boolean, onPick: (String) -> Unit) {
        if (sgdbKey.isBlank()) {
            toast("Adicione sua chave do SteamGridDB em Configurações")
            return
        }
        if (term.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        sgdbPicker = SgdbPicker(title, term, portrait, onPick)
    }

    // ---------- Vídeo gameplay (4.7.0) ----------
    /**
     * Procura o vídeo do jogo no YouTube. Só roda na 1ª vez que a tela de detalhes abre (ou quando o usuário
     * toca no botão depois de uma busca sem resultado). O vídeo achado fica salvo e a busca nunca se repete.
     */
    internal fun ensureVideo(g: Game, force: Boolean = false) {
        val key = ytKey.trim()
        if (key.isEmpty() || g.id in ytBusy || g.videoId.isNotEmpty()) return
        if (!force && g.videoTried > 0) return
        ytBusy = ytBusy + g.id
        ytErr.remove(g.id)
        val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        mainScope.launch {
            val res = withContext(Dispatchers.IO) { YouTubeApi.search(key, g.title, plat) }
            ytBusy = ytBusy - g.id
            val cur = games.firstOrNull { it.id == g.id } ?: return@launch
            when (res) {
                is YtResult.Ok -> replaceGame(cur.copy(videoId = res.video.id, videoTitle = res.video.title, videoTried = System.currentTimeMillis()))
                YtResult.NotFound -> {
                    replaceGame(cur.copy(videoTried = System.currentTimeMillis()))
                    if (force) toast("Nenhum vídeo encontrado. Use Opções para colar um link.")
                }
                is YtResult.Failure -> {
                    ytErr[g.id] = res.message
                    if (force) toast(res.message)
                }
            }
        }
    }

    internal fun onVideoClick(g: Game) {
        when {
            g.videoId.isNotEmpty() -> {
                ytCtl = YT_PLAY
                ytFull = false
                ytNav = infoNav
                ytCtrl.reset()
                ytOpen = true
            }
            ytKey.isBlank() -> {
                // 4.7.6: sem chave de API o player abre só com o aviso e o botão YouTube (busca no app/navegador).
                ytCtl = YT_EXT
                ytFull = false
                ytNav = infoNav
                ytCtrl.reset()
                ytOpen = true
            }
            g.id in ytBusy -> toast("Buscando vídeo…")
            else -> {
                toast("Buscando vídeo…")
                ensureVideo(g, force = true)
            }
        }
    }

    /** Abre o vídeo no app do YouTube (ou no navegador, se o app não existir). */
    internal fun openInYouTube(videoId: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")))
        } catch (e: Exception) {
            openUrl("https://www.youtube.com/watch?v=$videoId")
        }
    }

    /** Sem vídeo salvo (e sem chave de API): abre a busca do jogo no app do YouTube ou, se não houver, no navegador. */
    internal fun openYouTubeSearch(g: Game) {
        val plat = if (g.shownPlatform == ANDROID_PLATFORM || g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        openUrl(YouTubeApi.searchUrl(g.title, plat))
    }

    /**
     * 4.9.0 (TV): abre o app do YouTube já na busca "título plataforma gameplay", no último usuário usado.
     * Tenta o app do Google TV, o do Fire TV e, por último, o navegador. (O app não consegue escolher o perfil.)
     */
    internal fun openYouTubeSearchTv(g: Game) {
        val plat = if (g.shownPlatform == WEB_PLATFORM) "" else g.shownPlatform
        val url = YouTubeApi.searchUrl(g.title, plat, simple = true)
        val q = listOf(g.title, plat, "gameplay").filter { it.isNotBlank() }.joinToString(" ")
        val pkgs = listOf("com.google.android.youtube.tv", "com.amazon.firetv.youtube", "com.google.android.youtube")
        for (pkg in pkgs) {
            if (!isInstalled(pkg)) continue
            val tries = listOf(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg),
                Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(android.app.SearchManager.QUERY, q)
            )
            for (intent in tries) {
                if (intent.resolveActivity(packageManager) == null) continue
                try {
                    startActivity(intent)
                    return
                } catch (_: Exception) { }
            }
        }
        openUrl(url)
    }

    internal fun closeVideo() {
        ytOpen = false
        ytFull = false
        ytCtl = YT_PLAY
    }

    internal fun infoGame(): Game? = (overlay as? Overlay.Info)?.let { o -> games.firstOrNull { it.id == o.id } }

    /** Ação de um botão do player (toque, OK do controle remoto ou A do gamepad). */
    internal fun ytAct(i: Int) {
        ytCtl = i
        when (i) {
            YT_CLOSE -> closeVideo()
            YT_BACK -> ytCtrl.seekBy(-10)
            YT_FWD -> ytCtrl.seekBy(10)
            YT_PLAY -> if (ytCtrl.error != 0) {
                infoGame()?.let { openInYouTube(it.videoId) }
            } else ytCtrl.toggle()
            YT_FULL -> if (landscape) ytFull = !ytFull
            // 4.9.3: OK/A na barra de progresso = pausar/continuar (esquerda/direita andam 10 s).
            YT_SEEK -> if (ytCtrl.error == 0) ytCtrl.toggle()
            YT_EXT -> infoGame()?.let {
                if (TvMode.isTv) openYouTubeSearchTv(it)
                else if (it.videoId.isNotEmpty()) openInYouTube(it.videoId) else openYouTubeSearch(it)
            }
        }
    }

    /** Teclas com o player aberto: o D-pad anda pelos botões do player e nada vaza para a tela de trás. */
    internal fun ytHandleKey(ev: KeyEvent, code: Int): Boolean {
        if (ev.action != KeyEvent.ACTION_DOWN) return true
        // Paisagem com os controles escondidos: qualquer tecla só os traz de volta (foco no play/pause);
        // só B / Voltar agem.
        val isBack = code == KeyEvent.KEYCODE_BUTTON_B || code == KeyEvent.KEYCODE_BACK
        if (landscape && !ytCtrl.uiVisible && !isBack) {
            ytCtl = YT_PLAY
            ytNav = true
            infoNav = true
            ytCtrl.wake()
            return true
        }
        ytCtrl.wake()
        val canFull = landscape
        infoNav = true
        ytNav = true
        val noVideo = infoGame()?.videoId.isNullOrEmpty()
        val transport = !noVideo && ytCtrl.error == 0
        // Ordem na tela, da esquerda para a direita: YouTube, −10s, play/pause, +10s, tela cheia.
        val order = when {
            !transport -> listOf(YT_EXT)
            canFull -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD, YT_FULL)
            else -> listOf(YT_EXT, YT_BACK, YT_PLAY, YT_FWD)
        }
        val home = if (YT_PLAY in order) YT_PLAY else YT_EXT
        // 4.9.3: com os controles fora do vídeo (celular em pé e TV fora da tela cheia) a barra de progresso fica
        // entre o vídeo e os botões: ✕ (em cima) → barra → botões.
        val seekRow = transport && (!landscape || (TvMode.isTv && !ytFull))
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (ytCtl == YT_SEEK) ytCtrl.seekBy(-10) else if (ytCtl != YT_CLOSE) {
                val i = order.indexOf(if (ytCtl in order) ytCtl else home)
                ytCtl = order[(i - 1).coerceAtLeast(0)]
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (ytCtl == YT_SEEK) ytCtrl.seekBy(10) else if (ytCtl != YT_CLOSE) {
                val i = order.indexOf(if (ytCtl in order) ytCtl else home)
                ytCtl = order[(i + 1).coerceAtMost(order.lastIndex)]
            }
            KeyEvent.KEYCODE_DPAD_UP -> when {
                ytCtl == YT_CLOSE -> {}
                seekRow && ytCtl != YT_SEEK -> { ytLast = ytCtl; ytCtl = YT_SEEK }
                else -> { if (ytCtl != YT_SEEK) ytLast = ytCtl; ytCtl = YT_CLOSE }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> when {
                ytCtl == YT_CLOSE -> ytCtl = if (seekRow) YT_SEEK else if (ytLast in order) ytLast else home
                ytCtl == YT_SEEK -> ytCtl = if (ytLast in order) ytLast else home
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A -> if (ev.repeatCount == 0) ytAct(if (ytCtl in order || ytCtl == YT_CLOSE || ytCtl == YT_SEEK) ytCtl else home)
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> if (ev.repeatCount == 0) back()
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> if (transport && ev.repeatCount == 0) ytCtrl.toggle()
            KeyEvent.KEYCODE_MEDIA_PLAY -> if (transport) ytCtrl.play()
            KeyEvent.KEYCODE_MEDIA_PAUSE -> if (transport) ytCtrl.pause()
            KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_MEDIA_REWIND -> if (transport) ytCtrl.seekBy(-10)
            KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> if (transport) ytCtrl.seekBy(10)
            KeyEvent.KEYCODE_BUTTON_Y -> if (landscape && transport && ev.repeatCount == 0) ytFull = !ytFull
        }
        return true
    }
    internal var ytLast = YT_PLAY

    internal fun testSgdbKey() {
        val key = sgdbKey.trim()
        if (key.isEmpty()) {
            toast("Cole sua chave primeiro")
            return
        }
        toast("Testando chave…")
        mainScope.launch {
            val err = withContext(Dispatchers.IO) { SgdbApi.ping(key) }
            toast(err ?: "Chave válida ✓")
        }
    }

    internal fun testYtKey() {
        val key = ytKey.trim()
        if (key.isEmpty()) {
            toast("Cole sua chave do YouTube primeiro")
            return
        }
        toast("Testando chave…")
        mainScope.launch {
            val err = withContext(Dispatchers.IO) { YouTubeApi.ping(key) }
            toast(err ?: "Chave válida ✓")
        }
    }

    internal fun prefetchCovers() = Covers.prefetch(this, games.map { it.cover } + platforms.map { it.image })

    internal fun refreshCover(url: String) {
        val u = url.trim()
        if (u.isEmpty()) {
            toast("Sem URL de capa")
            return
        }
        toast("Atualizando capa…")
        Covers.refresh(this, u) { ok ->
            if (ok) coverRev++
            toast(if (ok) "Capa atualizada" else "Não foi possível atualizar. Mantive a capa salva.")
        }
    }

    internal fun deleteGame(g: Game) {
        games.removeAll { it.id == g.id }
        saveLibrary()
        Covers.purgeIfUnused(g.cover, games.map { it.cover })
        if (sgdbCache.remove(g.id) != null) saveSgdb()
        selectedId = visibleGames().firstOrNull()?.id
        overlay = Overlay.None
    }

    /** Primeiro uso: pergunta como o usuário quer cadastrar o primeiro jogo (uma vez só). */
    internal fun maybeWelcome() {
        if (prefs.getBoolean("welcomeDone", false)) return
        prefs.edit().putBoolean("welcomeDone", true).apply()
        if (games.isEmpty() && overlay is Overlay.None) overlay = Overlay.AddChoice(true)
    }

    internal fun openAdd() {
        overlay = Overlay.AddChoice(false)
    }

    internal fun openSelected() {
        val id = selectedId ?: return
        if (id.startsWith(PLAT_PREFIX)) {
            enterPlatform(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == ADD_ID) {
            openAdd()
            return
        }
        if (games.none { it.id == id }) return
        overlay = Overlay.Info(id)
    }

    internal fun infoPlay(g: Game) {
        overlay = Overlay.None
        playGame(g)
    }

    internal fun editSelected() {
        val id = selectedId
        if (id != null && id.startsWith(PLAT_PREFIX)) {
            overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
            return
        }
        if (id == null || id == ADD_ID) {
            openAdd()
            return
        }
        games.firstOrNull { it.id == id }?.let { overlay = Overlay.Edit(it) }
    }

    internal fun randomPick() {
        coverUnderline = false
        if (inPlatformList()) {
            selectedId = navIds().random()
            return
        }
        val l = visibleGames()
        if (l.isNotEmpty()) selectedId = l.random().id
    }

    /** 4.9.5: item que abriu a tela filha; quando a filha fecha (Voltar), o foco volta para ele. */
    internal var returnKey by mutableStateOf("")

    @Composable
    internal fun Modifier.returnFocus(key: String): Modifier {
        val req = remember { FocusRequester() }
        val pad = padNav
        LaunchedEffect(returnKey, pad) {
            if (pad && returnKey == key) {
                delay(130)
                try {
                    req.requestFocus()
                } catch (_: Exception) {
                }
                returnKey = ""
            }
        }
        return this.focusRequester(req)
    }

    /** 4.9.5: sem controle conectado o teste nem abre (avisa na tela) — antes, em pé, ele travava o Nexus. */
    internal fun openPadTest() {
        if (PadInput.gamepadDevice() == null) {
            toast("Conecte um controle (Bluetooth ou cabo) para usar o teste.")
            return
        }
        returnKey = "pad"
        overlay = Overlay.PadTest
    }

    /** Volta uma tela (a que abriu a atual) ou fecha tudo se não houver. */
    internal fun popOverlay() {
        overlay = if (overlayStack.isNotEmpty()) overlayStack[overlayStack.size - 1] else Overlay.None
    }

    internal fun back() {
        when {
            ytOpen -> if (ytFull) ytFull = false else closeVideo()
            videoLinkFor != null -> videoLinkFor = null
            permHelp != null -> permHelp = null
            explorer != null -> explorer?.let { if (!it.up()) explorer = null }
            !modalOpen() && navZone != 0 -> navZone = 0
            appsDrawerOpen -> appsDrawerOpen = false
            romList != null -> romList = null
            batch != null -> {
                val b = batch
                if (b != null && b.phase == BatchPhase.SCANNING) toast("Varredura em andamento. Use Cancelar ou Minimizar.")
                else closeBatch()
            }
            platPicker != null -> platPicker = null
            emuPicker != null -> emuPicker = null
            appFilterKind != 0 -> appFilterKind = 0
            appPickerOpen -> appPickerOpen = false
            sgdbPicker != null -> sgdbPicker = null
            genrePickerOpen -> genrePickerOpen = false
            collPickerOpen -> collPickerOpen = false
            overlay is Overlay.About && aboutPage != 0 -> aboutPage = 0
            overlay is Overlay.About -> { returnKey = "about"; popOverlay() }
            overlay !is Overlay.None && overlayStack.isNotEmpty() -> overlay = overlayStack[overlayStack.size - 1]
            overlay is Overlay.About -> overlay = Overlay.Settings
            overlay is Overlay.Genres || overlay is Overlay.Platforms || overlay is Overlay.Collections -> overlay = Overlay.Settings
            overlay is Overlay.ConfirmDeleteCollection -> overlay = Overlay.Collections
            overlay is Overlay.LinkEdit -> overlay = Overlay.Platforms
            overlay is Overlay.ConfirmDelete -> overlay = Overlay.Edit((overlay as Overlay.ConfirmDelete).game)
            overlay !is Overlay.None -> overlay = Overlay.None
            dashMode == 1 && dashPlatform.isNotEmpty() -> exitPlatform()
            else -> selectedId = null
        }
    }

    internal fun playGame(g: Game) {
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        val tpl = if (g.customCmd.isNotBlank()) g.customCmd
        else if (pkg != null) templateFor(pkg, link) else null
        if (tpl != null && tpl.contains("{file.") && g.romUri.isEmpty()) {
            if (link != null && link.folders.isNotEmpty()) {
                romList = RomListRequest(g.platform) { uri, _ ->
                    val u = g.copy(romUri = uri)
                    replaceGame(u)
                    launchGame(u)
                }
            } else {
                pendingPlay = g
                pickRomFile(true)
            }
        } else {
            launchGame(g)
        }
    }

    // ---------- Controle (gamepad) ----------
    internal fun modalOpen(): Boolean = overlay !is Overlay.None || appsDrawerOpen || appPickerOpen || appFilterKind != 0 || emuPicker != null || platPicker != null || genrePickerOpen || collPickerOpen || sgdbPicker != null || videoLinkFor != null || romList != null || batch != null || explorer != null || permHelp != null

    // ---------- 4.9.5: Voltar na tela inicial (Google TV e Fire OS) ----------
    internal var tvBackCount = 0
    internal var tvBackLastMs = 0L
    internal var tvBackDownMs = 0L
    internal var tvBackHoldToast = false

    /**
     * Tela inicial da TV: Voltar NUNCA fecha o Nexus de primeira. Fora da primeira capa, leva o foco para ela.
     * Na primeira capa só avisa; fecha com 3 toques rápidos (até 1,5 s entre eles) ou segurando 3 segundos.
     */
    internal fun tvHomeBack(ev: KeyEvent): Boolean {
        if (modalOpen() || ytOpen || overlay !is Overlay.None) return false
        if (dashMode == 1 && dashPlatform.isNotEmpty()) { tvBackCount = 0; return false }   // dentro de uma plataforma: sobe um nível
        val now = SystemClock.uptimeMillis()
        if (ev.action == KeyEvent.ACTION_UP) {
            tvBackHoldToast = false
            return true
        }
        if (ev.repeatCount > 0) {
            val held = now - tvBackDownMs
            if (held >= 3000L) {
                tvBackCount = 0
                if (isHome) moveTaskToBack(true) else finish()
            } else if (held >= 700L && !tvBackHoldToast) {
                tvBackHoldToast = true
                toast("Continue segurando para sair…")
            }
            return true
        }
        tvBackDownMs = now
        tvBackHoldToast = false
        val first = firstNavId()
        val onFirst = navZone == 0 && selectedId == first
        if (!onFirst) {
            tvBackCount = 0
            navZone = 0
            coverUnderline = false
            if (first != null) selectedId = first
            return true
        }
        tvBackCount = if (tvBackCount > 0 && now - tvBackLastMs <= 1500L) tvBackCount + 1 else 1
        tvBackLastMs = now
        when {
            tvBackCount >= 3 -> {
                tvBackCount = 0
                if (isHome) moveTaskToBack(true) else finish()
            }
            tvBackCount == 1 -> toast("Aperte Voltar 3 vezes seguidas, ou segure por 3 segundos, para sair")
            else -> toast("Mais uma vez para sair")
        }
        return true
    }

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        val code = ev.keyCode
        if (TvMode.isTv) {
            if (code == KeyEvent.KEYCODE_BACK) {
                if (tvHomeBack(ev)) return true
            } else if (ev.action == KeyEvent.ACTION_DOWN) tvBackCount = 0
        }
        // 4.9.4: celular — o controle só vale com o aparelho deitado; em pé o Nexus é usado só por toque.
        if (!TvMode.isTv && (ev.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK)) != 0) {
            if (!landscape) return super.dispatchKeyEvent(ev)
            if (!padActive) padActive = true
        }
        // TV: OK do controle remoto (DPAD_CENTER / ENTER) age como "clicar no item destacado".
        val isOk = TvMode.isTv && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
            code == KeyEvent.KEYCODE_NUMPAD_ENTER)
        // 4.9.0: depois de um OK segurado, o resto do toque (repetições e soltar) não pode vazar para a tela que abriu.
        if (okSwallow && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER ||
                code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A)) {
            if (ev.action == KeyEvent.ACTION_UP) okSwallow = false
            return true
        }
        val ytMedia = ytOpen && (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY ||
            code == KeyEvent.KEYCODE_MEDIA_PAUSE || code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
        // 4.9.0: TV, tela principal: teclas de "página" do controle remoto (avançar/voltar, canal +/-) pulam vários jogos.
        val pageKey = TvMode.isTv && !ytOpen && (code == KeyEvent.KEYCODE_MEDIA_REWIND || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
            code == KeyEvent.KEYCODE_MEDIA_PREVIOUS || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
            code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN ||
            code == KeyEvent.KEYCODE_PAGE_UP || code == KeyEvent.KEYCODE_PAGE_DOWN)
        if (code !in PAD_KEYS && !isOk && !ytMedia && !pageKey) return super.dispatchKeyEvent(ev)
        val isDirKey = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT

        if (modalOpen()) {
            stopHold()
            val inf = overlay
            if (ytOpen && inf is Overlay.Info) {
                // 4.9.3: as setas passam pelo filtro (um passo por toque; repete se segurar).
                if (isDirKey) {
                    if (ev.action == KeyEvent.ACTION_DOWN) {
                        if (ev.repeatCount == 0) ytPad.key(code, true)
                    } else ytPad.key(code, false)
                    return true
                }
                // Em TV/controle remoto também vale o "Voltar" (KEYCODE_BACK) quando o player está aberto.
                return ytHandleKey(ev, code)
            }
            if (inf is Overlay.Info && !collPickerOpen && !genrePickerOpen) {
                // 4.6.0: o D-pad / OK navegam pelos botões da tela de informações (controle remoto).
                if (isDirKey) {
                    infoNav = true
                    if (ev.action == KeyEvent.ACTION_DOWN) {
                        if (ev.repeatCount == 0) infoPad.key(code, true)
                    } else infoPad.key(code, false)
                    return true
                }
                if (isOk) {
                    infoNav = true
                    return super.dispatchKeyEvent(ev)
                }
                if (code == KeyEvent.KEYCODE_BUTTON_A && infoNav) {
                    return super.dispatchKeyEvent(
                        KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                    )
                }
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    when (code) {
                        KeyEvent.KEYCODE_BUTTON_A -> games.firstOrNull { it.id == inf.id }?.let { infoPlay(it) }
                        KeyEvent.KEYCODE_BUTTON_B -> back()
                        KeyEvent.KEYCODE_BUTTON_START -> games.firstOrNull { it.id == inf.id }?.let { overlay = Overlay.Edit(it) }
                    }
                }
                return true
            }
            if (overlay is Overlay.Settings && (code == KeyEvent.KEYCODE_BUTTON_L1 || code == KeyEvent.KEYCODE_BUTTON_R1)) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                    settingsTab = if (code == KeyEvent.KEYCODE_BUTTON_R1) (settingsTab + 1) % SETTINGS_TABS else (settingsTab + SETTINGS_TABS - 1) % SETTINGS_TABS
                }
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_B) {
                if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) back()
                return true
            }
            if (code == KeyEvent.KEYCODE_BUTTON_A) {
                return super.dispatchKeyEvent(
                    KeyEvent(ev.downTime, ev.eventTime, ev.action, KeyEvent.KEYCODE_DPAD_CENTER, ev.repeatCount)
                )
            }
            return super.dispatchKeyEvent(ev)
        }

        if (pageKey) {
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                val fwd = code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code == KeyEvent.KEYCODE_MEDIA_NEXT ||
                    code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_DOWN
                pageStep(if (fwd) 1 else -1)
            }
            return true
        }

        // 4.9.0: na TV o OK (e o A do gamepad) na tela principal: toque = abrir; segurar (meio segundo) = toque longo.
        if (isOk || (padNav && code == KeyEvent.KEYCODE_BUTTON_A)) return okKey(ev)

        if (isDirKey) {
            // A repetição é feita por nós (com aceleração); ignora o auto-repeat do sistema.
            if (ev.action == KeyEvent.ACTION_DOWN) {
                if (ev.repeatCount == 0) {
                    heldKeys.remove(code)
                    heldKeys.add(code)
                    updateHold()
                }
            } else if (ev.action == KeyEvent.ACTION_UP) {
                heldKeys.remove(code)
                updateHold()
            }
            return true
        }

        if (ev.action == KeyEvent.ACTION_DOWN) {
            val first = ev.repeatCount == 0
            when (code) {
                KeyEvent.KEYCODE_BUTTON_R1 -> if (first) pageStep(1)
                KeyEvent.KEYCODE_BUTTON_L1 -> if (first) pageStep(-1)
                KeyEvent.KEYCODE_BUTTON_R2 -> if (first) jumpEdge(true)
                KeyEvent.KEYCODE_BUTTON_L2 -> if (first) jumpEdge(false)
                KeyEvent.KEYCODE_BUTTON_A -> if (first) { zoneActivate() }
                KeyEvent.KEYCODE_BUTTON_B -> if (first) back()
                KeyEvent.KEYCODE_BUTTON_X -> if (first) { randomPick() }
                KeyEvent.KEYCODE_BUTTON_Y -> if (first) { overlay = Overlay.Search }
                KeyEvent.KEYCODE_BUTTON_START -> if (first) { overlay = Overlay.StartMenu }
                KeyEvent.KEYCODE_BUTTON_SELECT -> if (first) { overlay = Overlay.Filter }
            }
        }
        return true
    }

    internal var okPending = false
    internal var okLong = false
    internal var okSwallow = false

    /** Toque longo (OK segurado) no item selecionado: jogo = detalhes; plataforma = trocar a imagem dela. */
    internal fun longPressSelected() {
        val id = selectedId ?: return
        when {
            id.startsWith(PLAT_PREFIX) -> overlay = Overlay.PlatformImage(id.removePrefix(PLAT_PREFIX))
            id == ADD_ID -> return
            games.any { it.id == id } -> overlay = Overlay.Info(id)
        }
    }

    internal fun okKey(ev: KeyEvent): Boolean {
        if (navZone != 0) {
            // Cabeçalho e rodapé: age na hora, como antes.
            if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) zoneActivate()
            return true
        }
        when (ev.action) {
            KeyEvent.ACTION_DOWN -> {
                if (ev.repeatCount == 0) {
                    okPending = true
                    okLong = false
                } else if (okPending && !okLong && (ev.isLongPress || ev.eventTime - ev.downTime >= OK_LONG_MS)) {
                    okLong = true
                    okSwallow = true
                    longPressSelected()
                }
            }
            KeyEvent.ACTION_UP -> {
                if (okPending && !okLong) {
                    // Alguns controles não repetem a tecla: se ficou apertado o tempo do toque longo, vale como longo.
                    if (ev.eventTime - ev.downTime >= OK_LONG_MS) longPressSelected() else zoneActivate()
                }
                okPending = false
                okLong = false
            }
        }
        return true
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // 4.9.4: tocou na tela = volta ao modo toque (sem contorno de navegação do controle).
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && padActive) {
            padActive = false
            navZone = 0
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoy = PadInput.isJoystick(ev)
        if (isJoy && !TvMode.isTv) {
            if (!landscape) return super.dispatchGenericMotionEvent(ev)
            if (!padActive && ev.action == MotionEvent.ACTION_MOVE) padActive = true
        }
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE && ytOpen && overlay is Overlay.Info) {
            // 4.9.3: player aberto: D-pad por eixo e alavanca andam pelos botões como as setas do teclado (sem duplicar).
            ytPad.axis(PadInput.axisDir(ev, ytPad.axisDir))
            return true
        }
        if (isJoy && ev.action == MotionEvent.ACTION_MOVE) {
            if (modalOpen()) {
                stopHold()
                if (overlay is Overlay.Info && !collPickerOpen && !genrePickerOpen) {
                    // Tela de detalhes: o eixo vira um passo só (o Android também cria setas a partir do eixo, o que duplicava).
                    infoNav = true
                    infoPad.axis(PadInput.axisDir(ev, infoPad.axisDir))
                    return true
                }
                return super.dispatchGenericMotionEvent(ev)
            }
            val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val sx = ev.getAxisValue(MotionEvent.AXIS_X)
            val sy = ev.getAxisValue(MotionEvent.AXIS_Y)
            val ax = if (abs(hx) > 0.5f) hx else sx
            val ay = if (abs(hy) > 0.5f) hy else sy
            val limit = if (axisDx != 0 || axisDy != 0) STICK_OFF else STICK_ON
            var ndx = 0
            var ndy = 0
            if (abs(ax) > limit || abs(ay) > limit) {
                if (abs(ax) >= abs(ay)) ndx = if (ax > 0) 1 else -1
                else ndy = if (ay > 0) 1 else -1
            }
            axisDx = ndx
            axisDy = ndy
            updateHold()
            handleTriggers(ev)
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        ytCtrl.onHostResume()
        importPendingShortcuts()
        storageOk = hasAllFiles() // volta da tela de permissões do Android
        isHome = LauncherMode.isDefault(this) // volta da tela de escolha do launcher
        startOrientationWatch()
        FloatState.hostVisible = true
        FloatingPanelService.instance?.applyVisibility()
        // Se o painel estava ligado e o sistema encerrou o serviço, religa sozinho.
        if (!TvMode.isFireTv && prefs.getBoolean("floatOn", false) && !FloatState.on && FloatingPanelService.canDraw(this)) {
            FloatingPanelService.start(this)
        }
    }

    // Botão Home com o Nexus como launcher padrão: volta para a tela principal (fecha as janelas abertas).
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) goHome()
    }

    internal fun goHome() {
        stopHold()
        overlay = Overlay.None
        appsDrawerOpen = false
        appPickerOpen = false
        appFilterKind = 0
        emuPicker = null
        platPicker = null
        genrePickerOpen = false
        collPickerOpen = false
        sgdbPicker = null
        videoLinkFor = null
        closeVideo()
        romList = null
    }

    // ---------- Modo launcher (4.3.0) ----------
    /** Liga/desliga o painel flutuante de temperatura e bateria (toque no cabeçalho ou em Extras). */
    internal fun toggleFloat() {
        if (FloatState.on) {
            FloatingPanelService.stop(this)
            toast("Painel flutuante desligado")
            return
        }
        if (!FloatingPanelService.canDraw(this)) {
            if (!TvMode.isTv) toast("Permita \"Exibir sobre outros apps\" para o Nexus e volte")
            try {
                overlayPermRequest.launch(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (_: Exception) {
                // Muitas TVs não têm essa tela: mostra como liberar pelo computador (ADB).
                if (TvMode.isTv) permHelp = "overlay" else toast("Não foi possível abrir a permissão de sobreposição")
            }
            return
        }
        askNotifThenStartFloat()
    }

    internal fun askNotifThenStartFloat() {
        if (!FloatingPanelService.notificationsAllowed(this) && Build.VERSION.SDK_INT >= 33) {
            try {
                notifPermRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            } catch (_: Exception) {
            }
        }
        startFloat()
    }

    internal fun startFloat() {
        prefs.edit().putBoolean("floatOn", true).apply()
        FloatingPanelService.start(this)
        FloatState.on = true
        toast(if (TvMode.isTv) "Painel ligado: a temperatura aparece sobre os outros apps." else "Painel ligado: aparece sobre os outros apps. Arraste para onde quiser.")
    }

    internal fun askDefaultLauncher() {
        try {
            homeRequest.launch(LauncherMode.requestIntent(this))
        } catch (_: Exception) {
            openHomeSettings()
        }
    }

    internal fun openHomeSettings() {
        try {
            startActivity(LauncherMode.homeSettingsIntent())
        } catch (_: Exception) {
            toast("Não foi possível abrir as configurações de launcher")
        }
    }

    internal fun openSystemSettings() {
        try {
            startActivity(LauncherMode.systemSettingsIntent())
        } catch (_: Exception) {
            toast("Não foi possível abrir as configurações do Android")
        }
    }

    internal fun openAppInfo(pkg: String) {
        try {
            startActivity(LauncherMode.appInfoIntent(pkg))
        } catch (_: Exception) {
            toast("Não foi possível abrir as informações do app")
        }
    }

    /** Intent de abertura do app. Na TV, apps feitos para Android TV só têm a entrada "leanback". */
    internal fun launchIntentFor(pkg: String): Intent? {
        val pm = packageManager
        return if (TvMode.isTv) (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))
        else (pm.getLaunchIntentForPackage(pkg) ?: pm.getLeanbackLaunchIntentForPackage(pkg))
    }

    internal fun launchApp(pkg: String) {
        val i = launchIntentFor(pkg)
        if (i == null) {
            toast("Este app não pode ser aberto")
            return
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    internal fun applyCarouselOn(v: Boolean) {
        carouselOn = v
        prefs.edit().putBoolean("carouselOn", v).apply()
        // "Padrão" e "Carrossel" são os dois estados desta opção; Grade e Lista não mudam.
        if (tvView <= TV_VIEW_CAROUSEL) {
            tvView = if (v) TV_VIEW_CAROUSEL else TV_VIEW_STD
            prefs.edit().putInt("tvView", tvView).apply()
        }
    }

    /** Escolhe o modo de visualização da TV (olho do cabeçalho). */
    internal fun applyTvView(v: Int) {
        tvView = v.coerceIn(0, 3)
        prefs.edit().putInt("tvView", tvView).apply()
        if (tvView == TV_VIEW_STD) applyCarouselOn(false)
        else if (tvView == TV_VIEW_CAROUSEL) applyCarouselOn(true)
    }

    internal fun applyFloatSmall(v: Boolean) {
        floatSmall = v
        prefs.edit().putBoolean("floatSmall", v).apply()
        FloatingPanelService.instance?.applySize()
    }

    internal fun applyIntroOn(v: Boolean) {
        introOn = v
        prefs.edit().putBoolean("introOn", v).apply()
    }

    override fun onPause() {
        orientListener?.disable()
        FloatState.hostVisible = false
        FloatingPanelService.instance?.applyVisibility()
        stopHold()
        ytCtrl.onHostPause()
        super.onPause()
    }

    // ---------- Apps / lançamento ----------
    internal fun loadApps(): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = ArrayList<android.content.pm.ResolveInfo>(packageManager.queryIntentActivities(intent, 0))
        if (TvMode.isTv) {
            // Apps de Android TV (emuladores, jogos) podem ter só a entrada "leanback".
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            found.addAll(packageManager.queryIntentActivities(tvIntent, 0))
        }
        return found
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedAlpha { it.label }
    }

    internal fun iconFor(pkg: String): ImageBitmap? = iconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    // Ícone em alta resolução (usado como capa dos jogos da plataforma Android).
    /** 4.9.0: só consulta o cache (rápido, pode ser chamado na tela). */
    internal fun cachedBigIcon(pkg: String): ImageBitmap? = synchronized(bigIconCache) { bigIconCache[pkg] }

    /** Pode ser chamado em segundo plano (a primeira vez decodifica o ícone do app). */
    internal fun bigIconFor(pkg: String): ImageBitmap? {
        synchronized(bigIconCache) { if (bigIconCache.containsKey(pkg)) return bigIconCache[pkg] }
        val v = try {
            packageManager.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (_: Exception) {
            null
        }
        synchronized(bigIconCache) { bigIconCache[pkg] = v }
        return v
    }

    internal fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    internal fun resolvePkg(g: Game): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    internal fun persist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
    }

    /** 4.7.4: transforma em jogos os atalhos recebidos de outros apps (ver PinShortcut.kt). */
    internal fun importPendingShortcuts() {
        val pend = PinShortcuts.take(this)
        if (pend.isEmpty()) return
        var added = 0
        var lastId: String? = null
        for (p in pend) {
            if (games.any { it.pkg == p.pkg && it.shortcutId == p.shortcutId }) continue
            val g = Game(
                id = UUID.randomUUID().toString(), title = p.label, platform = ANDROID_PLATFORM,
                cover = p.iconPath, pkg = p.pkg, shortcutId = p.shortcutId,
                execType = DEFAULT_EXEC[execKey(ANDROID_PLATFORM)] ?: "native"
            )
            games.add(g)
            lastId = g.id
            added++
        }
        if (added > 0) {
            saveLibrary()
            lastId?.let { selectGame(it) }
            toast(if (added == 1) "Atalho adicionado como jogo" else "$added atalhos adicionados como jogos")
        }
    }

    internal fun launchShortcutGame(g: Game) {
        val err = PinShortcuts.start(this, g.pkg, g.shortcutId)
        if (err == null) {
            markPlayed(g)
            return
        }
        // Plano B: abre o próprio app do atalho.
        val intent = launchIntentFor(g.pkg)
        if (intent != null) {
            try {
                startActivity(intent)
                markPlayed(g)
                toast("Não deu para abrir o atalho direto (deixe o Nexus como launcher padrão). Abrindo o app.")
                return
            } catch (_: Exception) {
            }
        }
        toast("Não foi possível abrir o atalho: $err")
    }

    internal fun launchGame(g: Game) {
        if (g.shortcutId.isNotEmpty()) {
            launchShortcutGame(g)
            return
        }
        if (g.execType == "browser") {
            if (g.webUrl.isBlank()) {
                toast("Este jogo não tem link configurado")
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g.webUrl)))
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val custom = g.customCmd.trim()
        if (custom.isNotEmpty()) {
            val b = buildIntent(custom, g) ?: return
            try {
                startActivity(b.intent)
                markPlayed(g)
            } catch (e: Exception) {
                toast("Erro ao abrir: ${e.message}")
            }
            return
        }
        val link = linkFor(g.platform)
        val pkg = effectivePkg(g, link)
        if (pkg == null) {
            if (link != null && link.pkg.isNotEmpty()) {
                toast("O emulador ${link.playerName.ifEmpty { link.pkg }} não está instalado")
            } else {
                toast("Defina o app em Editar (segure a capa ou aperte START)")
            }
            return
        }
        val tpl = templateFor(pkg, link)
        try {
            if (tpl != null && !(tpl.contains("{file.") && g.romUri.isEmpty())) {
                val b = buildIntent(tpl, g) ?: return
                if (b.kill) {
                    try {
                        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                    } catch (_: Exception) {
                    }
                }
                startActivity(b.intent)
                markPlayed(g)
                return
            }
            val intent = launchIntentFor(pkg)
            if (intent == null) {
                toast("Não foi possível abrir $pkg")
                return
            }
            startActivity(intent)
            markPlayed(g)
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    internal fun effectivePkg(g: Game, link: PlatformLink?): String? {
        if (g.pkg.isNotEmpty() && isInstalled(g.pkg)) return g.pkg
        if (link != null && link.pkg.isNotEmpty() && isInstalled(link.pkg)) return link.pkg
        val kw = EXEC_KEYWORD[g.execType] ?: return null
        return allApps.firstOrNull { it.label.lowercase().startsWith(kw) }?.pkg
    }

    internal fun templateFor(pkg: String, link: PlatformLink?): String? {
        if (link != null && link.pkg == pkg && link.template.isNotBlank()) return link.template
        return TEMPLATES[pkg]
    }

    // ---------- Acesso a todos os arquivos (para pastas de ROMs vindas de backup) ----------
    internal fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    internal fun askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: Exception) {
                    if (TvMode.isTv) permHelp = "storage"
                    else toast("Abra Configurações > Apps > Nexus e libere o acesso a todos os arquivos")
                }
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77)
        }
    }

    internal fun fileUri(f: File): String =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", f).toString()

    internal fun safReadable(uri: String): Boolean = try {
        val pfd = contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) {
            false
        } else {
            pfd.close()
            true
        }
    } catch (_: Exception) {
        false
    }

    // Se o Nexus não tem mais a permissão da pasta (ex.: backup importado), usa o arquivo direto pelo acesso a todos os arquivos.
    internal fun effectiveRomUri(uri: String): String {
        if (uri.isEmpty() || !hasAllFiles()) return uri
        val u = Uri.parse(uri)
        if (u.authority != "com.android.externalstorage.documents") return uri
        if (safReadable(uri)) return uri
        val f = File(pathOf(uri))
        if (!f.isFile) return uri
        return try {
            fileUri(f)
        } catch (_: Exception) {
            uri
        }
    }

    internal fun treePath(tree: String): String {
        val id = try {
            DocumentsContract.getTreeDocumentId(Uri.parse(tree))
        } catch (_: Exception) {
            ""
        }
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    internal fun walkFiles(dir: File, path: String, exts: Set<String>?, out: MutableList<RomEntry>, depth: Int) {
        if (depth > 12 || out.size > 20000) return
        val kids = dir.listFiles() ?: return
        for (k in kids) {
            if (k.isDirectory) {
                walkFiles(k, "$path${k.name}/", exts, out, depth + 1)
            } else {
                val ext = k.name.substringAfterLast('.', "").lowercase()
                if (exts == null || ext in exts) out.add(RomEntry(k.name, path, fileUri(k)))
            }
        }
    }

    internal fun pathOf(uri: String): String {
        if (!uri.startsWith("content://")) return Uri.parse(uri).path ?: uri
        val pu = Uri.parse(uri)
        if (pu.authority == "$packageName.fileprovider") return "/" + (pu.path ?: "").removePrefix("/root/")
        val id = docIdOf(uri)
        val vol = id.substringBefore(':', "")
        val rel = id.substringAfter(':', "")
        return if (vol.equals("primary", true)) "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }

    // Converte o comando em um Intent.
    internal fun buildIntent(tpl: String, g: Game): BuiltIntent? {
        val uriStr = effectiveRomUri(g.romUri)
        val fileName = if (uriStr.isEmpty()) "" else fileNameOf(uriStr)
        val unsupported = Regex("\\{tags\\.([A-Za-z0-9_]+)\\}").findAll(tpl)
            .map { it.groupValues[1] }.firstOrNull { it != "vita_game_id" }
        if (unsupported != null) {
            toast("Este emulador usa {tags.$unsupported}, que o Nexus ainda não preenche. Use um comando personalizado no jogo.")
            return null
        }
        val idRe = Regex("[A-Z]{4}\\d{5}")
        val vitaId = idRe.find(g.title)?.value ?: idRe.find(fileName)?.value ?: ""
        if (tpl.contains("{tags.vita_game_id}") && vitaId.isEmpty()) {
            toast("Vita3K+ precisa do ID do jogo no título (ex.: PCSA00029)")
            return null
        }
        fun sub(x: String): String = x
            .replace("{file.uri}", uriStr)
            .replace("{file.path}", if (uriStr.isEmpty()) "" else pathOf(uriStr))
            .replace("{file.name}", fileName)
            .replace("{file.mime}", if (uriStr.isEmpty()) "" else mimeOf(fileName))
            .replace("{tags.vita_game_id}", vitaId)

        val t = tpl.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var comp: ComponentName? = null
        var action: String? = null
        var data: String? = null
        var type: String? = null
        val cats = ArrayList<String>()
        val extras = LinkedHashMap<String, String>()
        val arrays = LinkedHashMap<String, List<String>>()
        val typed = ArrayList<Triple<String, Char, String>>()
        var flags = Intent.FLAG_ACTIVITY_NEW_TASK
        var kill = false
        try {
            var i = 0
            while (i < t.size) {
                when (t[i]) {
                    "-n" -> {
                        i++
                        val p = sub(t[i]).split("/")
                        if (p.size == 2) {
                            val cls = if (p[1].startsWith(".")) p[0] + p[1] else p[1]
                            comp = ComponentName(p[0], cls)
                        }
                    }
                    "-a" -> { i++; action = sub(t[i]) }
                    "-c" -> { i++; cats.add(sub(t[i])) }
                    "-d" -> { i++; data = sub(t[i]) }
                    "-t" -> { i++; type = sub(t[i]) }
                    "-e", "--es" -> {
                        i++
                        val k = t[i]
                        i++
                        extras[k] = sub(t[i])
                    }
                    "--esa" -> {
                        i++
                        val k = t[i]
                        i++
                        arrays[k] = sub(t[i]).split(",")
                    }
                    "--ez", "--ei", "--el" -> {
                        val kind = t[i].last()
                        i++
                        val k = t[i]
                        i++
                        typed.add(Triple(k, kind, sub(t[i])))
                    }
                    "-f" -> {
                        i++
                        flags = flags or java.lang.Long.decode(t[i]).toInt()
                    }
                    "--activity-clear-task" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    "--activity-clear-top" -> flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    "--activity-no-history" -> flags = flags or Intent.FLAG_ACTIVITY_NO_HISTORY
                    "--nexus-kill" -> kill = true
                }
                i++
            }
        } catch (_: Exception) {
            toast("Comando de abertura inválido")
            return null
        }
        val intent = Intent()
        val a = action
        if (a != null) intent.action = a
        val c = comp
        if (c != null) intent.component = c
        for (cat in cats) intent.addCategory(cat)
        val d = data
        val ty = type
        if (d != null && ty != null) intent.setDataAndType(Uri.parse(d), ty)
        else if (d != null) intent.data = Uri.parse(d)
        else if (ty != null) intent.type = ty
        for ((k, v) in extras) intent.putExtra(k, v)
        for ((k, v) in arrays) intent.putExtra(k, v.toTypedArray())
        for ((k, kind, v) in typed) {
            when (kind) {
                'z' -> intent.putExtra(k, v.equals("true", ignoreCase = true))
                'i' -> intent.putExtra(k, v.toIntOrNull() ?: 0)
                else -> intent.putExtra(k, v.toLongOrNull() ?: 0L)
            }
        }
        intent.addFlags(flags)
        if (uriStr.startsWith("content://")) {
            intent.clipData = ClipData.newRawUri("rom", Uri.parse(uriStr))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return BuiltIntent(intent, kill)
    }

    internal fun mimeOf(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    internal fun linkFor(platform: String): PlatformLink? = links.firstOrNull { it.platform == platform }

    /** Lista completa (cadastradas + catálogo) que o seletor mostra, em ordem alfabética. */
    internal fun platformPickList(filter: (String) -> Boolean): List<String> {
        val reg = platformNames()
        val extra = EmuCatalog.all(this).map { it.name }.filter { n -> reg.none { it.equals(n, ignoreCase = true) } }
        return (reg + extra).filter(filter).distinctBy { it.lowercase() }.sortedAlpha { it }
    }

    internal fun addPlatforms(current: String?): List<String> {
        val base = platformPickList { true }
        return if (current != null && current !in base) base + current else base
    }

    /** Jogos de emulador entram em lote; o que sobra no cadastro manual quase sempre é Android. */
    internal fun defaultAddPlatform(): String = ANDROID_PLATFORM

    /** Só as plataformas criadas pelo usuário podem ser editadas ou apagadas. */
    internal fun isCustomPlatform(name: String): Boolean =
        name != WEB_PLATFORM && name != ANDROID_PLATFORM &&
            platforms.firstOrNull { it.name == name }?.base?.isEmpty() == true

    internal fun brandOfPlatform(n: String): String =
        (platforms.firstOrNull { it.name == n }?.manufacturer
            ?: EmuCatalog.all(this).firstOrNull { it.name.equals(n, ignoreCase = true) }?.manufacturer
            ?: "").ifBlank { "Outros" }

    /** Cadastra a plataforma (do catálogo) quando um jogo ou emulador passa a usá-la. */
    internal fun registerPlatformIfNeeded(name: String) {
        if (name.isBlank() || platforms.any { it.name == name }) return
        val dp = EmuCatalog.forPlatform(this, name)
        platforms.add(GamePlatform(name, dp?.manufacturer ?: DEFAULT_MANUFACTURER[name] ?: "", name))
        savePrefs()
    }

    internal fun foldText(s: String): String =
        java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    internal fun docIdOf(uri: String): String = try {
        DocumentsContract.getDocumentId(Uri.parse(uri))
    } catch (_: Exception) {
        Uri.parse(uri).lastPathSegment ?: ""
    }

    internal fun fileNameOf(uri: String): String =
        docIdOf(uri).substringAfterLast('/').substringAfterLast(':')

    internal fun scanRoms(platform: String): ScanResult {
        val link = linkFor(platform) ?: return ScanResult(emptyList(), 0)
        val exts = link.exts.takeIf { it.isNotEmpty() }?.toSet() ?: ROM_EXT[execKey(platform)]
        val out = ArrayList<RomEntry>()
        var failed = 0
        val granted = contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }.map { it.uri.toString() }
        for (f in link.folders) {
            if (f in granted) {
                try {
                    val tree = Uri.parse(f)
                    walkTree(tree, DocumentsContract.getTreeDocumentId(tree), "", exts, out, 0)
                } catch (_: Exception) {
                    failed++
                }
            } else if (hasAllFiles()) {
                // Sem permissão da pasta (ex.: veio de backup): lê direto pelo acesso a todos os arquivos.
                try {
                    val dir = File(treePath(f))
                    if (dir.isDirectory) walkFiles(dir, "", exts, out, 0) else failed++
                } catch (_: Exception) {
                    failed++
                }
            } else {
                failed++
            }
        }
        return ScanResult(out.distinctBy { it.uri }.sortedAlpha { it.name }, failed)
    }

    internal fun walkTree(
        tree: Uri, docId: String, path: String, exts: Set<String>?,
        out: MutableList<RomEntry>, depth: Int
    ) {
        if (depth > 12 || out.size > 20000) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(kids, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walkTree(tree, id, "$path$name/", exts, out, depth + 1)
                } else {
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (exts == null || ext in exts) {
                        out.add(RomEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()))
                    }
                }
            }
        }
    }

    internal fun folderLabel(s: String): String = try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(s))
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        (if (vol.equals("primary", true)) "Interno" else vol) + "/" + rel
    } catch (_: Exception) {
        s
    }

    internal fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    internal fun clipboardText(): String {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return ""
        if (clip.itemCount == 0) return ""
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: ""
    }

    internal fun openSteamGrid(title: String) {
        if (title.isBlank()) {
            toast("Digite o título primeiro")
            return
        }
        val url = "https://www.steamgriddb.com/search/grids?term=" + URLEncoder.encode(title.trim(), "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("Erro ao abrir o navegador")
        }
    }

    internal fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    internal fun cleanTitle(file: String, keepId: Boolean): String {
        var s = file.substringBeforeLast('.', file)
        s = s.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "")
        if (!keepId) s = s.replace(Regex("\\s*-\\s*[A-Z]{4}\\d{5}\\s*$"), "")
        return s.trim()
    }

    // ---------- Cadastro em lote (varredura automática) ----------
    internal fun execBase(platform: String): String = platforms.firstOrNull { it.name == platform }?.base ?: ""

    /** Extensões do emulador escolhido; sem elas, a tabela embutida da plataforma. */
    internal fun batchExts(platform: String, linkExts: List<String>): List<String> =
        if (linkExts.isNotEmpty()) linkExts
        else (ROM_EXT[execKey(platform)]?.toList()
            ?: if (isCustomPlatform(platform)) ScanEngine.GENERIC_EXTS.toList() else emptyList())

    internal fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("notifAsked", false)
        ) {
            prefs.edit().putBoolean("notifAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 78)
        }
    }

    internal fun closeBatch() {
        batch?.cancelled = true
        batch = null
        ScanService.stop(this)
    }

    internal fun regionLabel(r: String): String = when (r) {
        "Brazil" -> "Brasil"
        "PT-BR" -> "PT-BR (tradução)"
        "World" -> "Mundo"
        "Japan" -> "Japão"
        "Europe" -> "Europa"
        else -> r
    }

    internal fun regionText(c: ScanCandidate): String =
        if (c.regions.isEmpty()) "Sem região" else c.regions.joinToString(" + ") { regionLabel(it) }

    internal fun startBatchScan(platform: String) {
        val link = linkFor(platform) ?: return
        val profile = ScanEngine.profileFor(platform, execBase(platform), batchExts(platform, link.exts))
        if (profile == null) {
            toast("Escolha um emulador para $platform")
            return
        }
        val s = BatchSession(platform, profile)
        batch = s
        askNotifications()
        ScanService.start(this)
        mainScope.launch {
            val raw = withContext(Dispatchers.IO) { collectRaw(link, s) }
            if (batch !== s || s.cancelled) return@launch
            val outcome = withContext(Dispatchers.Default) { ScanEngine.process(raw, profile) }
            if (batch !== s || s.cancelled) return@launch
            finishScan(s, raw, outcome)
        }
    }

    internal fun collectRaw(link: PlatformLink, s: BatchSession): List<RawEntry> {
        val out = ArrayList<RawEntry>()
        var failed = 0
        val granted = contentResolver.persistedUriPermissions.filter { it.isReadPermission }.map { it.uri.toString() }
        val cancelled = { s.cancelled }
        val onFound: (Int) -> Unit = { n ->
            s.found = n
            ScanNotify.progress(this, s.platform, n)
        }
        for (f in link.folders) {
            if (s.cancelled) break
            val inSaf = f in granted
            if (hasAllFiles()) {
                // Caminho rápido: lê direto pelo sistema de arquivos. Os endereços seguem o mesmo formato do cadastro manual.
                try {
                    val root = File(treePath(f))
                    if (root.isDirectory) {
                        ScanEngine.walkFiles(
                            root, s.profile, out,
                            uriOf = { file -> if (inSaf) safUri(f, file) else fileUri(file) },
                            cancelled = cancelled, onFound = onFound
                        )
                    } else failed++
                } catch (_: Exception) {
                    failed++
                }
            } else if (inSaf) {
                try {
                    val tree = Uri.parse(f)
                    walkTreeRaw(tree, DocumentsContract.getTreeDocumentId(tree), "", s.profile, out, 0, cancelled, onFound)
                } catch (_: Exception) {
                    failed++
                }
            } else {
                failed++
            }
        }
        s.failedFolders = failed
        return out.distinctBy { it.uri }
    }

    /** Endereço SAF (o mesmo que a lista de ROMs gera) de um arquivo dentro de uma pasta já autorizada. */
    internal fun safUri(tree: String, file: File): String {
        val tu = Uri.parse(tree)
        val treeId = DocumentsContract.getTreeDocumentId(tu)
        val rel = file.path.removePrefix(treePath(tree)).trim('/')
        val docId = when {
            rel.isEmpty() -> treeId
            treeId.endsWith(":") || treeId.endsWith("/") -> treeId + rel
            else -> "$treeId/$rel"
        }
        return DocumentsContract.buildDocumentUriUsingTree(tu, docId).toString()
    }

    internal fun walkTreeRaw(
        tree: Uri, docId: String, path: String, p: ScanProfile, out: MutableList<RawEntry>,
        depth: Int, cancelled: () -> Boolean, onFound: (Int) -> Unit
    ) {
        if (depth > 12 || out.size > 60000 || cancelled()) return
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(kids, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (cancelled()) return
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val isDir = (c.getString(2) ?: "") == DocumentsContract.Document.MIME_TYPE_DIR
                if (ScanEngine.wanted(p, name, isDir)) {
                    out.add(RawEntry(name, path, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString(), isDir))
                    onFound(out.size)
                } else if (isDir && ScanEngine.shouldDescend(p, name, depth)) {
                    walkTreeRaw(tree, id, "$path$name/", p, out, depth + 1, cancelled, onFound)
                }
            }
        }
    }

    internal fun finishScan(s: BatchSession, raw: List<RawEntry>, outcome: ScanOutcome) {
        val platform = s.platform
        // Jogos que já estão no catálogo (mesmo arquivo): não entram de novo.
        val existing = games.filter { it.platform == platform && it.romUri.isNotEmpty() }.map { pathOf(it.romUri) }.toSet()
        val fresh = outcome.candidates.filter { pathOf(it.uri) !in existing }
        s.alreadyCount = outcome.candidates.size - fresh.size
        s.all = fresh
        s.ignored = outcome.ignored.filter { pathOf(it.candidate.uri) !in existing }

        // Arquivos ausentes: jogos em lote cujo arquivo não foi achado ficam marcados (nunca são removidos).
        if (s.failedFolders == 0) {
            val scanned = raw.map { pathOf(it.uri) }.toSet()
            var changed = false
            for (i in games.indices) {
                val g = games[i]
                if (g.platform == platform && g.isAuto && g.romUri.isNotEmpty()) {
                    val miss = pathOf(g.romUri) !in scanned
                    if (miss != g.missing) {
                        games[i] = g.copy(missing = miss)
                        changed = true
                    }
                }
            }
            if (changed) saveLibrary()
        }

        val text = "${fresh.size} jogo(s) encontrado(s) em $platform"
        val inBackground = !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
        ScanService.stop(this)
        if (inBackground) ScanNotify.done(this, text)

        if (fresh.isEmpty() && s.ignored.isEmpty()) {
            batch = null
            toast(
                if (s.failedFolders > 0) "Não consegui ler as pastas. Vincule-as de novo e libere o acesso."
                else if (s.alreadyCount > 0) "Nenhum jogo novo: os ${s.alreadyCount} jogo(s) encontrados já estão no catálogo."
                else "Nenhum jogo encontrado nessas pastas para ${platform}."
            )
            return
        }
        val groups = ScanEngine.dupGroups(fresh)
        s.dupGroups = groups.size
        if (groups.isNotEmpty()) {
            s.phase = BatchPhase.REGIONS
        } else {
            buildBatchItems(s, ScanEngine.regionPriority("USA"))
        }
    }

    internal fun buildBatchItems(s: BatchSession, priority: List<String>) {
        val chosen = ScanEngine.resolveRegions(s.all, priority)
        val byKey = s.all.groupBy { it.key }
        s.items.clear()
        s.items.addAll(chosen.map { BatchItem(it.key, byKey[it.key] ?: listOf(it), it) }.sortedAlpha { it.cand.title })
        s.ignoredItems.clear()
        s.ignoredItems.addAll(s.ignored.sortedAlpha { it.name }.map { BatchIgnored(it) })
        s.phase = BatchPhase.LIST
    }

    internal fun confirmBatch(s: BatchSession) {
        val platform = s.platform
        val exec = DEFAULT_EXEC[execKey(platform)] ?: "native"
        val chosen = ArrayList<ScanCandidate>()
        for (bi in s.items) if (bi.checked) chosen.add(bi.cand)
        for (ig in s.ignoredItems) if (ig.checked) chosen.add(ig.item.candidate)
        val added = chosen.distinctBy { it.uri }.map { c ->
            Game(
                id = UUID.randomUUID().toString(), title = c.title, platform = platform,
                execType = exec, romUri = c.uri, source = SOURCE_AUTO,
                romFileName = c.fileName, region = c.region
            )
        }
        batch = null
        if (added.isEmpty()) return
        games.addAll(added)
        saveLibrary()
        prefetchCovers()
        toast("${added.size} jogo(s) adicionados em $platform")
    }

    /** Tela de informações: troca o arquivo em que um jogo em lote se baseia. */
    internal fun changeRomFile(g: Game) {
        val onRom: (String, String) -> Unit = { uriStr, name ->
            games.firstOrNull { it.id == g.id }?.let { cur ->
                replaceGame(cur.copy(romUri = uriStr, romFileName = name, missing = false))
                toast("Arquivo trocado: $name")
            }
        }
        val link = linkFor(g.platform)
        if (link != null && link.folders.isNotEmpty()) {
            romList = RomListRequest(g.platform, onRom)
        } else {
            dialogRomCb = { uri -> onRom(uri.toString(), displayName(uri)) }
            pickRomFile(false)
        }
    }

    internal fun aboutDeviceLines(): List<Pair<String, String>> {
        val dm = resources.displayMetrics
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ramGb = mi.totalMem / (1024.0 * 1024.0 * 1024.0)
        val webView = try {
            android.webkit.WebView.getCurrentWebViewPackage()?.let { "${it.packageName} ${it.versionName}" } ?: "indisponível"
        } catch (_: Throwable) { "indisponível" }
        val kind = when {
            TvMode.isFireTv -> "Fire TV"
            TvMode.isRealTv -> "TV (Google TV / Android TV)"
            TvMode.isTv -> "TV (modo TV)"
            else -> "Celular / tablet"
        }
        val pads = padNames()
        return listOf(
            "Nexus" to "v$APP_VERSION",
            "Aparelho" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "Tipo" to kind,
            "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Escala da interface" to if (TvMode.isTv) "ampliada ×${TvMode.UI_SCALE} (modo TV)" else "normal ×1,0",
            "Tela" to "${dm.widthPixels}x${dm.heightPixels} px · ${"%.0f".format(dm.densityDpi.toFloat())} dpi · ${if (landscape) "paisagem" else "retrato"}",
            "Memória" to "%.1f GB".format(ramGb),
            "WebView" to webView,
            "Controles" to if (pads.isEmpty()) "nenhum conectado" else pads.joinToString(", ")
        )
    }

    internal fun padNames(): List<String> {
        val out = ArrayList<String>()
        for (id in InputDevice.getDeviceIds()) {
            val d = InputDevice.getDevice(id) ?: continue
            val src = d.sources
            val pad = (src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
            if (pad && !d.isVirtual) out.add(d.name)
        }
        return out
    }

    internal fun diagnosticReport(): String {
        val sb = StringBuilder()
        sb.append("Relatório do Nexus\n")
        for ((k, v) in aboutDeviceLines()) sb.append(k).append(": ").append(v).append('\n')
        sb.append("Jogos: ${games.size} (favoritos ${games.count { it.isFavorite }}, arquivo não encontrado ${games.count { it.missing }})\n")
        sb.append("Plataformas com vínculo: ${links.size}\n")
        sb.append("Chave SteamGridDB: ${if (sgdbKey.isNotBlank()) "configurada" else "não configurada"}\n")
        sb.append("Chave YouTube: ${if (ytKey.isNotBlank()) "configurada" else "não configurada"}\n")
        sb.append("Acesso a todos os arquivos: ${if (hasAllFiles()) "sim" else "não"}\n")
        sb.append("Visualização: ${listOf("padrão", "carrossel", "grade", "lista")[tvView.coerceIn(0, 3)]}\n")
        sb.append("Tamanho (padrão/carrossel/retrato): $widthLStd / $widthLCar / $widthP px\n")
        sb.append("Capas por linha (retrato/paisagem): ${gridColsFor(resources.displayMetrics.widthPixels / resources.displayMetrics.density, gridSizeP, false)} / ${gridColsFor(resources.displayMetrics.widthPixels / resources.displayMetrics.density, gridSizeL, false)}\n")
        sb.append("Modo leve: ${TvMode.light}\n")
        return sb.toString()
    }

    // ---------- Backup ----------
    internal fun writeBackup(uri: Uri) {
        try {
            val o = JSONObject(LibraryStore.toJson(games.toList()))
            o.put("platforms", PlatformStore.toJsonArray(platforms.toList()))
            o.put("genresList", JSONArray(genres.toList()))
            o.put("platformLinks", LinkStore.toJsonArray(links.toList()))
            o.put(
                "visualPrefs",
                JSONObject().put("widthP", widthP).put("widthL", widthLStd).put("widthLCar", widthLCar)
                    .put("gridSizeP", gridSizeP).put("gridSizeL", gridSizeL).put("listRowH", listRowH)
                    .put("radius", "${radius}px").put("color", accentHex)
            )
            o.put("cutoutPad", cutoutPad)
            o.put("dashboardMode", dashMode)
            o.put("collectionsList", JSONArray(collections.toList()))
            o.put("extras", JSONObject().put("carousel", carouselOn).put("tvView", tvView).put("intro", introOn).put("floatSmall", floatSmall))
            o.put("backupFormat", 3)
            contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray(Charsets.UTF_8)) }
            toast("Backup salvo")
        } catch (e: Exception) {
            toast("Erro ao exportar: ${e.message}")
        }
    }

    internal fun readBackup(uri: Uri) {
        try {
            val raw = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            if (raw.isNullOrBlank()) {
                toast("Arquivo de backup vazio")
                return
            }
            val text = raw.removePrefix("\uFEFF")
            val o = JSONObject(text)
            if (!o.has("games")) {
                toast("Este arquivo não parece um backup do Nexus")
                return
            }
            // Lê tudo ANTES de mexer no estado: se algo falhar, nada é alterado.
            val list = LibraryStore.parse(text)
            val newGenres = o.optJSONArray("genresList")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
            } ?: emptyList()
            val newLinks = o.optJSONArray("platformLinks")?.let { LinkStore.parse(it.toString()) }
            val newPlatforms = o.optJSONArray("platforms")?.let { PlatformStore.parse(it.toString()) }

            games.clear()
            games.addAll(list)
            saveLibrary()

            if (newGenres.isNotEmpty()) {
                genres.clear()
                genres.addAll(newGenres)
            }
            o.optJSONObject("visualPrefs")?.let { v ->
                widthP = v.optInt("widthP", widthP)
                widthLStd = v.optInt("widthL", widthLStd)
                widthLCar = v.optInt("widthLCar", widthLStd)
                val oldGrid = v.optInt("gridSize", gridSizeL)
                gridSizeP = v.optInt("gridSizeP", oldGrid).coerceIn(0, 2)
                gridSizeL = v.optInt("gridSizeL", oldGrid).coerceIn(0, 2)
                listRowH = v.optInt("listRowH", listRowH).coerceIn(LIST_ROW_MIN_DP, LIST_ROW_MAX_DP)
                val r = v.optString("radius", "").filter { it.isDigit() }
                if (r.isNotEmpty()) radius = canonicalRadius(r.toInt())
                val c = v.optString("color", "")
                if (c.startsWith("#")) {
                    try {
                        android.graphics.Color.parseColor(c)
                        accentHex = normalizeAccent(c)
                    } catch (_: Exception) {
                    }
                }
            }
            if (o.has("cutoutPad")) cutoutPad = o.optBoolean("cutoutPad", cutoutPad)
            if (o.has("dashboardMode")) dashMode = if (o.optInt("dashboardMode", 0) == 1) 1 else 0
            dashPlatform = ""
            collections.clear()
            o.optJSONArray("collectionsList")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val n = arr.optString(i, "").trim()
                    if (n.isNotEmpty() && n !in collections) collections.add(n)
                }
            }
            for (g in list) for (c in g.collections) if (c !in collections) collections.add(c)
            ensureFixedCollections()
            o.optJSONObject("extras")?.let { ex ->
                applyCarouselOn(ex.optBoolean("carousel", carouselOn))
                if (ex.has("tvView")) {
                    tvView = ex.optInt("tvView", tvView).coerceIn(0, 3)
                    prefs.edit().putInt("tvView", tvView).apply()
                }
                applyIntroOn(ex.optBoolean("intro", introOn))
                applyFloatSmall(ex.optBoolean("floatSmall", floatSmall))
            }
            if (newLinks != null) {
                links.clear()
                links.addAll(newLinks)
            }
            if (!newPlatforms.isNullOrEmpty()) {
                platforms.clear()
                platforms.addAll(newPlatforms)
            }
            syncPlatforms()
            savePrefs()
            resetFilters()
            prefetchCovers()
            selectedId = firstNavId()
            if (!storageOk && links.any { it.folders.isNotEmpty() }) overlay = Overlay.StoragePrompt
            toast("Backup importado: ${list.size} jogos")
        } catch (e: Exception) {
            toast("Erro ao importar: ${e.message}")
        }
    }

    internal fun listDate(ts: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(ts))

    /** Divisão de tela (paisagem): controles à esquerda, lista à direita. */
    @Composable
    internal fun androidx.compose.foundation.layout.ColumnScope.Panes(
        leftW: Float = 0.4f,
        left: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
        right: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
    ) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.weight(leftW).fillMaxHeight().verticalScroll(rememberScrollState())) { left() }
            Column(Modifier.weight(1f - leftW).fillMaxHeight()) { right() }
        }
    }

    /** Linha de lista em cartão de vidro escuro (com foco do controle). Use no lugar do padding simples. */
    @Composable
    internal fun Modifier.cardRow(onClick: (() -> Unit)?): Modifier {
        val shape = RoundedCornerShape(rCard.dp)
        return this
            .padding(vertical = 3.dp)
            .clip(shape)
            .background(S_CARD)
            .border(1.dp, S_LINE, shape)
            .then(if (onClick != null) Modifier.focusGlow(shape).clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    }

    internal fun appShownName(a: AppItem): String = appAliases[a.pkg]?.takeIf { it.isNotBlank() } ?: a.label

    /** Apps que aparecem ao escolher: só os ligados no filtro (jogos usam o nome que você deu). */
    internal fun appsForPicker(mode: Int): List<AppItem> = when (mode) {
        1 -> allApps.filter { it.pkg !in hiddenGameApps }.map { AppItem(appShownName(it), it.pkg) }
        2 -> allApps.filter { it.pkg !in hiddenEmuApps }
        else -> allApps
    }

    internal fun doExport() {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (TvMode.isTv) {
            // TV: escolhe a pasta no explorador do Nexus e grava o arquivo lá.
            explorer = ExplorerState(true, "Salvar o backup em qual pasta?", null, null) { dir ->
                writeBackup(Uri.fromFile(File(dir, "nexus_backup_$d.json")))
            }
            return
        }
        exportLauncher.launch("nexus_backup_$d.json")
    }

    internal fun doImport() {
        if (TvMode.isTv) {
            explorer = ExplorerState(false, "Escolher o arquivo de backup (.json)", setOf("json"), null) { f ->
                readBackup(Uri.fromFile(f))
            }
            return
        }
        importLauncher.launch(arrayOf("*/*"))
    }

    internal fun doStorage() {
        if (storageOk) toast("O acesso ao armazenamento já está concedido") else askStorage()
    }

    internal val PKG_LIKE = Regex("^[a-z0-9_]+(\\.[A-Za-z0-9_\\-]+)+$")

    /** Nome do app para mostrar: o nome real quando o catálogo só traz o pacote. */
    internal fun emuDisplayName(pl: EmuPlayer, installed: Boolean, rec: EmuRec?): String {
        if (!PKG_LIKE.matches(pl.name)) return pl.name
        if (installed) allApps.firstOrNull { it.pkg == pl.pkg }?.label?.takeIf { it.isNotBlank() }?.let { return it }
        if (rec != null) return rec.name
        val seg = pl.name.substringAfterLast('.')
        return seg.replaceFirstChar { it.uppercase() }
    }

    /** 4.7.8: apaga só os jogos (todos ou de uma plataforma). Não mexe em vínculos, apps, gêneros, coleções nem chaves de API. */
    internal fun deleteGamesWhere(all: Boolean, platform: String = "") {
        // 4.7.9: por plataforma ORIGINAL (jogos com máscara de etiqueta contam na plataforma real, ex.: Android).
        val gone = if (all) games.toList() else games.filter { it.platform == platform }
        val ids = gone.map { it.id }.toSet()
        games.removeAll { it.id in ids }
        saveLibrary()
        var sg = false
        for (g in gone) if (sgdbCache.remove(g.id) != null) sg = true
        if (sg) saveSgdb()
        if (all) {
            Covers.clearAll()
            resetFilters()
        } else {
            val keep = games.map { it.cover }
            for (g in gone) Covers.purgeIfUnused(g.cover, keep)
            if (fPlatform.isNotEmpty() && games.none { it.shownPlatform == fPlatform }) fPlatform = ""
        }
        dashPlatform = ""
        selectedId = firstNavId()
        overlay = Overlay.None
        toast(if (gone.size == 1) "1 jogo apagado" else "${gone.size} jogos apagados")
    }

    /** 4.7.8: apaga TUDO (jogos, configurações, vínculos, gêneros, coleções, chaves de API, capas) e reinicia o Nexus. */
    internal fun factoryReset() {
        wiping = true
        try { stopService(Intent(this, FloatingPanelService::class.java)) } catch (_: Exception) { }
        try { Covers.clearAll() } catch (_: Exception) { }
        try { prefs.edit().clear().commit() } catch (_: Exception) { }
        try { filesDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
        try { cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) { }
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        } catch (_: Exception) { }
        // O processo termina logo depois para que o Nexus volte do zero (nada em memória é regravado).
        Handler(Looper.getMainLooper()).postDelayed({ Runtime.getRuntime().exit(0) }, 500)
    }

}
