package com.nexus.launcher

import android.Manifest
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.toArgb
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils

/** Estado do painel flutuante, observável pela tela (Compose). */
object FloatState {
    var on by mutableStateOf(false)

    /** true enquanto a tela do Nexus está visível: nesse caso o painel some (o cabeçalho já mostra tudo). */
    @Volatile
    var hostVisible = false
}

/** Painel arrastável com temperatura + bateria, desenhado por cima de qualquer app. */
class FloatingPanelService : Service() {

    private var wm: WindowManager? = null
    private var panel: PanelView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var monitor: PowerMonitor? = null
    private var lastThermal = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("nexus_prefs", MODE_PRIVATE).edit().putBoolean("floatOn", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (panel == null) createPanel()
        instance = this
        FloatState.on = true
        applyVisibility()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Painel flutuante", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), flags)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle("Nexus: painel de temperatura")
            .setContentText("Arraste o painel para onde quiser")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Fechar", stop)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun createPanel() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val prefs = getSharedPreferences("nexus_prefs", MODE_PRIVATE)
        val v = PanelView(this)
        v.setCompact(prefs.getBoolean("floatSmall", false))
        val d = resources.displayMetrics.density
        val params = WindowManager.LayoutParams(
            v.panelW, v.panelH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.getInt("floatX", (16 * d).toInt())
        params.y = prefs.getInt("floatY", (110 * d).toInt())
        clamp(params, v)
        lp = params
        panel = v
        v.onMoved = { x, y ->
            params.x = x
            params.y = y
            clamp(params, v)
            try {
                w.updateViewLayout(v, params)
            } catch (_: Exception) {
            }
        }
        v.onReleased = {
            prefs.edit().putInt("floatX", params.x).putInt("floatY", params.y).apply()
        }
        try {
            w.addView(v, params)
        } catch (_: Exception) {
            stopSelf()
            return
        }
        monitor = PowerMonitor(this) { s ->
            v.update(s)
            if (s.thermal >= 3 && lastThermal < 3) vibrateOnce()
            lastThermal = s.thermal
        }.also { it.start() }
    }

    private fun clamp(p: WindowManager.LayoutParams, v: PanelView) {
        val m = resources.displayMetrics
        p.x = p.x.coerceIn(0, (m.widthPixels - v.panelW).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (m.heightPixels - v.panelH).coerceAtLeast(0))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val p = lp ?: return
        val v = panel ?: return
        clamp(p, v)
        try {
            wm?.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    /** 4.5.4: troca entre o tamanho padrão e o compacto (painel menor) sem religar o serviço. */
    fun applySize() {
        val v = panel ?: return
        val p = lp ?: return
        v.setCompact(getSharedPreferences("nexus_prefs", MODE_PRIVATE).getBoolean("floatSmall", false))
        p.width = v.panelW
        p.height = v.panelH
        clamp(p, v)
        try {
            wm?.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    fun applyVisibility() {
        panel?.visibility = if (FloatState.hostVisible) View.GONE else View.VISIBLE
    }

    private fun vibrateOnce() {
        try {
            val effect = VibrationEffect.createOneShot(450, VibrationEffect.DEFAULT_AMPLITUDE)
            if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(effect)
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        monitor?.stop()
        monitor = null
        panel?.let {
            it.stopPulse()
            try {
                wm?.removeView(it)
            } catch (_: Exception) {
            }
        }
        panel = null
        if (instance === this) instance = null
        FloatState.on = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.nexus.launcher.FLOAT_STOP"
        private const val CHANNEL = "nexus_float"
        private const val NOTIF_ID = 4501
        /** Fator do tamanho compacto (painel menor, ainda legível). */
        const val COMPACT = 0.66f

        @Volatile
        var instance: FloatingPanelService? = null

        fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingPanelService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.getSharedPreferences("nexus_prefs", MODE_PRIVATE).edit().putBoolean("floatOn", false).apply()
            try {
                ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
            } catch (_: Exception) {
            }
            FloatState.on = false
        }

        fun notificationsAllowed(ctx: Context): Boolean =
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
}

/** A peça flutuante: borda bicolor (esquerda = temperatura, direita = bateria), fundo quase preto. */
private class PanelView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    /** unidade de desenho: densidade × fator (1 = padrão, 0.66 = compacto). */
    private var u = d
    var panelW = (124 * u).toInt()
        private set
    var panelH = (34 * u).toInt()
        private set

    fun setCompact(compact: Boolean) {
        u = d * (if (compact) FloatingPanelService.COMPACT else 1f)
        panelW = (124 * u).toInt()
        panelH = (34 * u).toInt()
        stroke.strokeWidth = 2f * u
        text.textSize = 14f * u
        requestLayout()
        invalidate()
    }

    private var snap = PowerSnapshot()
    private var pulse = 0f
    private var animator: ValueAnimator? = null

    var onMoved: ((Int, Int) -> Unit)? = null
    var onReleased: (() -> Unit)? = null
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * d
        textAlign = Paint.Align.CENTER
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelW, panelH)
    }

    fun update(s: PowerSnapshot) {
        snap = s
        if (s.thermal >= 3) startPulse() else stopPulse()
        invalidate()
    }

    private fun startPulse() {
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stopPulse() {
        animator?.cancel()
        animator = null
        pulse = 0f
    }

    override fun onDraw(c: Canvas) {
        val s = snap
        val critical = s.thermal >= 3
        val warn = s.thermal == 2
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        val bg = when {
            critical -> ColorUtils.blendARGB(PowerColors.ALERT_A.toArgb(), PowerColors.ALERT_B.toArgb(), pulse)
            warn -> PowerColors.WARN_BG.toArgb()
            else -> PowerColors.BG.toArgb()
        }
        val tempColor = PowerColors.temp(s.tempC).toArgb()
        val batColor = PowerColors.battery(s.level).toArgb()
        fill.color = bg
        c.drawRoundRect(RectF(0f, 0f, w, h), r, r, fill)

        val inset = stroke.strokeWidth / 2f
        val box = RectF(inset, inset, w - inset, h - inset)
        c.save()
        c.clipRect(0f, 0f, w / 2f, h)
        stroke.color = tempColor
        c.drawRoundRect(box, r - inset, r - inset, stroke)
        c.restore()
        c.save()
        c.clipRect(w / 2f, 0f, w, h)
        stroke.color = batColor
        c.drawRoundRect(box, r - inset, r - inset, stroke)
        c.restore()
        if (critical) {
            val i2 = stroke.strokeWidth + 2f * u
            stroke.color = 0xE6FFFFFF.toInt()
            stroke.strokeWidth = 1f * u
            c.drawRoundRect(RectF(i2, i2, w - i2, h - i2), r - i2, r - i2, stroke)
            stroke.strokeWidth = 2f * u
        }

        val t = s.tempC
        val tempTxt = (if (critical) "⚠ " else "") + (if (t == null) "--°" else "${Math.round(t)}°")
        val batTxt = (if (s.charging) "⚡" else "") + "${s.level}%"
        val base = h / 2f - (text.ascent() + text.descent()) / 2f
        text.color = if (critical || warn) 0xFFFFFFFF.toInt() else tempColor
        c.drawText(tempTxt, w * 0.25f, base, text)
        text.color = if (critical || warn) 0xFFFFFFFF.toInt() else batColor
        c.drawText(batTxt, w * 0.75f, base, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val lp = layoutParams as? WindowManager.LayoutParams ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX
                downRawY = e.rawY
                startX = lp.x
                startY = lp.y
            }
            MotionEvent.ACTION_MOVE -> {
                onMoved?.invoke(startX + (e.rawX - downRawX).toInt(), startY + (e.rawY - downRawY).toInt())
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onReleased?.invoke()
        }
        return true
    }

    override fun onDetachedFromWindow() {
        stopPulse()
        super.onDetachedFromWindow()
    }
}
