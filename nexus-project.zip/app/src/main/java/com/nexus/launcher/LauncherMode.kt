package com.nexus.launcher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/**
 * Modo launcher (4.3.0): o Nexus como tela inicial do aparelho.
 * Quando é o launcher padrão, a "gaveta de apps" do celular passa a ser o próprio Nexus.
 */
object LauncherMode {

    /** O Nexus é, neste momento, o launcher padrão do sistema? */
    fun isDefault(ctx: Context): Boolean = try {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = ctx.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        ri?.activityInfo?.packageName == ctx.packageName
    } catch (_: Exception) {
        false
    }

    /**
     * Intent para pedir que o Nexus vire o launcher padrão.
     * Android 10+: caixa de diálogo do sistema (RoleManager). Antes disso: tela "App de início padrão".
     */
    fun requestIntent(ctx: Context): Intent {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = ctx.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                return rm.createRequestRoleIntent(RoleManager.ROLE_HOME)
            }
        }
        return homeSettingsIntent()
    }

    /** Tela do Android onde se escolhe o launcher padrão. */
    fun homeSettingsIntent(): Intent = Intent(Settings.ACTION_HOME_SETTINGS)

    /** Configurações originais do aparelho. */
    fun systemSettingsIntent(): Intent = Intent(Settings.ACTION_SETTINGS)

    /** Tela "Informações do app" do Android (configurações, desinstalar, permissões). */
    fun appInfoIntent(pkg: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$pkg"))
}
