package com.nexus.launcher

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.io.File

/**
 * Explorador de arquivos do Nexus (4.6.0).
 * Na TV não existe o seletor de pastas do Android, então o Nexus tem o seu: navegável só com D-pad / OK / Voltar,
 * lê o armazenamento interno e pen drives/cartões (precisa do acesso a todos os arquivos, que o Nexus já pede).
 */
class ExplorerState(
    /** true = escolhe uma pasta; false = escolhe um arquivo. */
    val folderMode: Boolean,
    val title: String,
    /** Extensões aceitas (minúsculas, sem ponto) quando escolhe arquivo. null = qualquer arquivo. */
    val exts: Set<String>?,
    startPath: String?,
    val onPick: (File) -> Unit
) {
    /** Pasta aberta. null = lista de armazenamentos. */
    var path by mutableStateOf(startPath?.takeIf { File(it).isDirectory })

    /** Sobe um nível. false = já está no topo (o chamador fecha o explorador). */
    fun up(): Boolean {
        val p = path ?: return false
        val roots = ExplorerFs.roots()
        if (roots.any { it.path == p }) {
            return if (roots.size > 1) {
                path = null
                true
            } else false
        }
        val parent = File(p).parentFile ?: return false
        path = parent.path
        return true
    }
}

object ExplorerFs {
    class Root(val label: String, val path: String)

    fun roots(): List<Root> {
        val out = ArrayList<Root>()
        @Suppress("DEPRECATION")
        val internal = Environment.getExternalStorageDirectory()
        out.add(Root("Armazenamento interno", internal.path))
        try {
            File("/storage").listFiles()?.forEach { f ->
                val n = f.name
                if (f.isDirectory && n != "emulated" && n != "self" && f.canRead()) out.add(Root("USB / cartão ($n)", f.path))
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** Pastas primeiro, depois arquivos, em ordem alfabética. null = o Android não deixou abrir a pasta. */
    fun list(dir: File): List<File>? {
        val kids = try {
            dir.listFiles()
        } catch (_: Exception) {
            null
        } ?: return null
        return kids.filter { !it.name.startsWith(".") }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
    }

    fun sizeText(f: File): String {
        val b = f.length()
        return when {
            b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.1f GB", b / (1024.0 * 1024.0 * 1024.0))
            b >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
            b >= 1L shl 10 -> "${b shr 10} KB"
            else -> "$b B"
        }
    }

    /** Endereço de pasta no mesmo formato que o seletor do Android devolve (usado nos vínculos de plataforma). */
    fun treeUriFor(path: String): String {
        val internal = Environment.getExternalStorageDirectory().path.trimEnd('/')
        val docId = if (path == internal || path.startsWith("$internal/")) {
            "primary:" + path.removePrefix(internal).trim('/')
        } else if (path.startsWith("/storage/")) {
            val rest = path.removePrefix("/storage/")
            rest.substringBefore('/') + ":" + rest.substringAfter('/', "")
        } else {
            "primary:" + path.trim('/')
        }
        return android.provider.DocumentsContract.buildTreeDocumentUri("com.android.externalstorage.documents", docId).toString()
    }
}

private val EX_PANEL = Color(0xFF141720)
private val EX_CARD = Color(0xFF1A1E29)
private val EX_LINE = Color(0x1AFFFFFF)
private val EX_MUTED = Color(0xFF9AA3B5)

@Composable
private fun ExpRow(
    glyph: String, name: String, sub: String, enabled: Boolean, radius: Int,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(radius.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(EX_CARD)
            .border(1.dp, EX_LINE, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = EX_MUTED, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ExpButton(text: String, filled: Boolean, accent: Color, radius: Int, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(radius.dp)
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .background(if (filled) accent else Color(0xFF1E222B))
            .border(1.dp, if (filled) accent else Color(0x1FFFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (filled) Color(0xFF05140B) else Color.White, fontSize = 13.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ExpBars() {
    val view = LocalView.current
    androidx.compose.runtime.SideEffect {
        val win = (view.parent as? DialogWindowProvider)?.window
        if (win != null) {
            WindowCompat.setDecorFitsSystemWindows(win, false)
            val c = WindowInsetsControllerCompat(win, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}

@Composable
fun FileExplorerDialog(
    st: ExplorerState, accent: Color, rBtn: Int, rCard: Int, rPanel: Int,
    hasAccess: () -> Boolean, askAccess: () -> Unit, onClose: () -> Unit
) {
    var access by remember { mutableStateOf(hasAccess()) }
    var tick by remember { mutableStateOf(0) }
    val panel = RoundedCornerShape(rPanel.dp)
    val closeShape = RoundedCornerShape(rBtn.dp)
    val first = remember { FocusRequester() }
    val path = st.path
    val roots = remember(tick) { ExplorerFs.roots() }
    val entries: List<File>? = remember(path, tick, access) { if (path == null || !access) null else ExplorerFs.list(File(path)) }

    // Cada pasta aberta devolve o destaque do D-pad para o primeiro item da lista.
    LaunchedEffect(path, access, tick) {
        delay(90)
        try {
            first.requestFocus()
        } catch (_: Exception) {
        }
    }

    Dialog(
        onDismissRequest = { if (!st.up()) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        ExpBars()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 8.dp)
                .onPreviewKeyEvent { ev ->
                    val n = ev.nativeKeyEvent
                    if (n.keyCode == android.view.KeyEvent.KEYCODE_BUTTON_B) {
                        if (n.action == android.view.KeyEvent.ACTION_DOWN && n.repeatCount == 0) {
                            if (!st.up()) onClose()
                        }
                        true
                    } else false
                },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .fillMaxHeight(0.94f)
                    .shadow(14.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(EX_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(st.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            path ?: "Escolha onde procurar", color = accent, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(closeShape)
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, EX_LINE, closeShape)
                            .clickable { onClose() },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(EX_LINE))

                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
                    if (!access) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "Para listar as pastas, o Nexus precisa do acesso a todos os arquivos.",
                                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Toque em \"Conceder acesso\" e ligue a chave do Nexus. Se esta TV não tiver essa tela, " +
                                    "libere pelo computador com ADB: adb shell appops set com.nexus.launcher MANAGE_EXTERNAL_STORAGE allow",
                                color = EX_MUTED, fontSize = 12.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ExpButton("Conceder acesso", true, accent, rBtn, Modifier.weight(1f).focusRequester(first)) { askAccess() }
                                ExpButton("Verificar de novo", false, accent, rBtn, Modifier.weight(1f)) {
                                    access = hasAccess()
                                    tick++
                                }
                            }
                        }
                    } else {
                        LazyColumn(state = rememberLazyListState(), modifier = Modifier.fillMaxSize()) {
                            if (path == null) {
                                items(roots, key = { it.path }) { r ->
                                    val mod = if (r === roots.first()) Modifier.focusRequester(first) else Modifier
                                    ExpRow("💾", r.label, r.path, true, rCard, mod) { st.path = r.path }
                                }
                            } else {
                                item(key = "__up__") {
                                    ExpRow("⬆", "Subir (pasta acima)", "", true, rCard, Modifier.focusRequester(first)) {
                                        if (!st.up()) onClose()
                                    }
                                }
                                if (entries == null) {
                                    item(key = "__denied__") {
                                        Text(
                                            "O Android não deixou abrir esta pasta.", color = EX_MUTED, fontSize = 12.sp,
                                            modifier = Modifier.padding(12.dp)
                                        )
                                    }
                                } else if (entries.isEmpty()) {
                                    item(key = "__empty__") {
                                        Text("Pasta vazia.", color = EX_MUTED, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                    }
                                } else {
                                    items(entries, key = { it.path }) { f ->
                                        if (f.isDirectory) {
                                            ExpRow("📁", f.name, "", true, rCard) { st.path = f.path }
                                        } else {
                                            val ext = f.name.substringAfterLast('.', "").lowercase()
                                            val ok = !st.folderMode && (st.exts == null || ext in st.exts)
                                            ExpRow("📄", f.name, ExplorerFs.sizeText(f), ok, rCard) {
                                                st.onPick(f)
                                                onClose()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(EX_LINE))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (st.folderMode && access && path != null) {
                        ExpButton("Usar esta pasta", true, accent, rBtn, Modifier.weight(1f)) {
                            st.onPick(File(path))
                            onClose()
                        }
                    }
                    ExpButton("Cancelar (B)", false, accent, rBtn, Modifier.weight(1f)) { onClose() }
                }
            }
        }
    }
}

/** Ajuda para TVs que não têm a tela do Android para conceder a permissão (mostra o comando de ADB). */
@Composable
fun PermHelpDialog(kind: String, pkg: String, accent: Color, rBtn: Int, rPanel: Int, onClose: () -> Unit) {
    val panel = RoundedCornerShape(rPanel.dp)
    val perm = if (kind == "overlay") "SYSTEM_ALERT_WINDOW" else "MANAGE_EXTERNAL_STORAGE"
    val title = if (kind == "overlay") "Permitir o painel sobre outros apps" else "Permitir acesso aos arquivos"
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(90)
        try {
            first.requestFocus()
        } catch (_: Exception) {
        }
    }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        ExpBars()
        Box(Modifier.fillMaxSize().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .shadow(14.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(EX_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Esta TV não tem a tela do Android para liberar essa permissão. Com o computador e o ADB conectados " +
                        "ao aparelho (Opções do desenvolvedor), rode:",
                    color = EX_MUTED, fontSize = 13.sp
                )
                Text(
                    "adb shell appops set $pkg $perm allow", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(rBtn.dp))
                        .background(Color(0xFF0E1118))
                        .padding(12.dp)
                )
                Text("Depois abra o Nexus de novo e tente outra vez.", color = EX_MUTED, fontSize = 12.sp)
                ExpButton("Entendi", true, accent, rBtn, Modifier.fillMaxWidth().focusRequester(first)) { onClose() }
            }
        }
    }
}
