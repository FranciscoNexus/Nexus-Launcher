package com.nexus.launcher

import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.io.File

/**
 * Explorador de arquivos do Nexus (4.6.0).
 * Na TV não existe o seletor de pastas do Android, então o Nexus tem o seu: navegável só com D-pad / OK / Voltar,
 * lê o armazenamento interno e pen drives/cartões (precisa do acesso a todos os arquivos, que o Nexus já pede).
 */
class ExplorerState(
    /** true = escolhe uma pasta; false = escolhe um arquivo. */
    val folderMode: Boolean,
    val title: String,
    /** Extensões aceitas (minúsculas, sem ponto) quando escolhe arquivo. null = qualquer arquivo. */
    val exts: Set<String>?,
    startPath: String?,
    val onPick: (File) -> Unit
) {
    /** Pasta aberta. null = lista de armazenamentos. */
    var path by mutableStateOf(startPath?.takeIf { File(it).isDirectory })

    /** Sobe um nível. false = já está no topo (o chamador fecha o explorador). */
    fun up(): Boolean {
        val p = path ?: return false
        val roots = ExplorerFs.roots()
        if (roots.any { it.path == p }) {
            return if (roots.size > 1) {
                path = null
                true
            } else false
        }
        val parent = File(p).parentFile ?: return false
        path = parent.path
        return true
    }
}

object ExplorerFs {
    class Root(val label: String, val path: String)

    fun roots(): List<Root> {
        val out = ArrayList<Root>()
        @Suppress("DEPRECATION")
        val internal = Environment.getExternalStorageDirectory()
        out.add(Root("Armazenamento interno", internal.path))
        try {
            File("/storage").listFiles()?.forEach { f ->
                val n = f.name
                if (f.isDirectory && n != "emulated" && n != "self" && f.canRead()) out.add(Root("USB / cartão ($n)", f.path))
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** Pastas primeiro, depois arquivos, em ordem alfabética. null = o Android não deixou abrir a pasta. */
    fun list(dir: File): List<File>? {
        val kids = try {
            dir.listFiles()
        } catch (_: Exception) {
            null
        } ?: return null
        return kids.filter { !it.name.startsWith(".") }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
    }

    fun sizeText(f: File): String {
        val b = f.length()
        return when {
            b >= 1L shl 30 -> String.format(java.util.Locale.US, "%.1f GB", b / (1024.0 * 1024.0 * 1024.0))
            b >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
            b >= 1L shl 10 -> "${b shr 10} KB"
            else -> "$b B"
        }
    }

    /** Endereço de pasta no mesmo formato que o seletor do Android devolve (usado nos vínculos de plataforma). */
    fun treeUriFor(path: String): String {
        val internal = Environment.getExternalStorageDirectory().path.trimEnd('/')
        val docId = if (path == internal || path.startsWith("$internal/")) {
            "primary:" + path.removePrefix(internal).trim('/')
        } else if (path.startsWith("/storage/")) {
            val rest = path.removePrefix("/storage/")
            rest.substringBefore('/') + ":" + rest.substringAfter('/', "")
        } else {
            "primary:" + path.trim('/')
        }
        return android.provider.DocumentsContract.buildTreeDocumentUri("com.android.externalstorage.documents", docId).toString()
    }
}

private val EX_PANEL = Color(0xFF141720)
private val EX_CARD = Color(0xFF1A1E29)
private val EX_LINE = Color(0x1AFFFFFF)
private val EX_MUTED = Color(0xFF9AA3B5)

/** Um item da lista do explorador. [text] = só uma mensagem (não é item de navegação). */
private class ExpItem(
    val key: String, val glyph: String, val name: String, val sub: String, val enabled: Boolean,
    val text: Boolean = false, val onClick: () -> Unit = {}
)

@Composable
private fun ExpRow(
    glyph: String, name: String, sub: String, enabled: Boolean, radius: Int, hl: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(radius.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(if (hl) FocusStyle.navColor.copy(alpha = 0.22f) else EX_CARD)
            .border(if (hl) 3.dp else 1.dp, if (hl) FocusStyle.navColor else EX_LINE, shape)
            // 4.9.3: quem move o destaque é o próprio explorador (sem foco do Compose): fluido e sem "pular" itens.
            .focusProperties { canFocus = false }
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(glyph, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = EX_MUTED, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ExpButton(
    text: String, filled: Boolean, accent: Color, radius: Int, modifier: Modifier = Modifier,
    manual: Boolean = false, hl: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(radius.dp)
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(shape)
            .background(if (filled) accent else Color(0xFF1E222B))
            .border(if (hl) 3.dp else 1.dp, if (hl) FocusStyle.navColor else if (filled) accent else Color(0x1FFFFFFF), shape)
            .then(if (manual) Modifier.focusProperties { canFocus = false } else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (filled) Color(0xFF05140B) else Color.White, fontSize = 13.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ExpBars() {
    val view = LocalView.current
    androidx.compose.runtime.SideEffect {
        val win = (view.parent as? DialogWindowProvider)?.window
        if (win != null) {
            WindowCompat.setDecorFitsSystemWindows(win, false)
            val c = WindowInsetsControllerCompat(win, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}

/**
 * 4.9.3: a navegação por D-pad é do próprio explorador (não do foco do Compose):
 * - abre sempre no primeiro item de cima;
 * - cima/baixo andam UM item por toque (só pastas e arquivos que servem; os demais são só para ver);
 * - no último item, "baixo" vai direto para "Usar esta pasta"; "cima" volta;
 * - L1/R1 pulam 5 itens; L2/R2 vão ao primeiro/último.
 */
@Composable
fun FileExplorerDialog(
    st: ExplorerState, accent: Color, rBtn: Int, rCard: Int, rPanel: Int,
    hasAccess: () -> Boolean, askAccess: () -> Unit, onClose: () -> Unit
) {
    var access by remember { mutableStateOf(hasAccess()) }
    var tick by remember { mutableStateOf(0) }
    val panel = RoundedCornerShape(rPanel.dp)
    val closeShape = RoundedCornerShape(rBtn.dp)
    val rootFocus = remember { FocusRequester() }
    val listState = rememberLazyListState()
    val path = st.path
    val roots = remember(tick) { ExplorerFs.roots() }
    val entries: List<File>? = remember(path, tick, access) { if (path == null || !access) null else ExplorerFs.list(File(path)) }

    // Itens da lista, na ordem em que aparecem.
    val rows = ArrayList<ExpItem>()
    if (access) {
        if (path == null) {
            for (r in roots) rows.add(ExpItem("root:" + r.path, "💾", r.label, r.path, true) { st.path = r.path })
        } else {
            rows.add(ExpItem("__up__", "⬆", "Subir (pasta acima)", "", true) { if (!st.up()) onClose() })
            if (entries == null) {
                rows.add(ExpItem("__denied__", "", "O Android não deixou abrir esta pasta.", "", false, text = true))
            } else if (entries.isEmpty()) {
                rows.add(ExpItem("__empty__", "", "Pasta vazia.", "", false, text = true))
            } else {
                for (f in entries) {
                    if (f.isDirectory) {
                        rows.add(ExpItem(f.path, "📁", f.name, "", true) { st.path = f.path })
                    } else {
                        val ext = f.name.substringAfterLast('.', "").lowercase()
                        val ok = !st.folderMode && (st.exts == null || ext in st.exts)
                        rows.add(ExpItem(f.path, "📄", f.name, ExplorerFs.sizeText(f), ok) {
                            st.onPick(f)
                            onClose()
                        })
                    }
                }
            }
        }
    }
    // Sem acesso aos arquivos: os dois botões do aviso são os itens de navegação.
    val navKeys: List<String> = if (!access) listOf("grant", "verify") else rows.filter { it.enabled }.map { it.key }

    // Cada pasta aberta devolve o destaque para o primeiro item da lista.
    var sel by remember(path, access, tick) { mutableStateOf(navKeys.firstOrNull() ?: "") }
    var zone by remember(path, access, tick) { mutableStateOf(0) }   // 0 = lista, 1 = botões de baixo
    var fbtn by remember { mutableStateOf(0) }
    val showUse = st.folderMode && access && path != null
    val footerCount = if (showUse) 2 else 1

    val activate: () -> Unit = {
        if (zone == 1) {
            if (showUse && fbtn == 0) {
                if (path != null) {
                    st.onPick(File(path))
                    onClose()
                }
            } else onClose()
        } else if (!access) {
            if (sel == "verify") {
                access = hasAccess()
                tick++
            } else askAccess()
        } else {
            rows.firstOrNull { it.key == sel }?.onClick?.invoke()
        }
    }

    LaunchedEffect(Unit) {
        delay(50)
        try {
            rootFocus.requestFocus()
        } catch (_: Exception) {
        }
    }
    // Mantém o item destacado à vista, rolando o mínimo (sem pulo).
    LaunchedEffect(sel, zone, path, access) {
        if (zone != 0 || !access) return@LaunchedEffect
        val idx = rows.indexOfFirst { it.key == sel }
        if (idx < 0) return@LaunchedEffect
        val info = listState.layoutInfo
        val v = info.visibleItemsInfo.firstOrNull { it.index == idx }
        if (v == null) {
            listState.scrollToItem(idx)
        } else if (v.offset < info.viewportStartOffset) {
            listState.animateScrollBy((v.offset - info.viewportStartOffset).toFloat())
        } else if (v.offset + v.size > info.viewportEndOffset) {
            listState.animateScrollBy((v.offset + v.size - info.viewportEndOffset).toFloat())
        }
    }

    Dialog(
        onDismissRequest = { if (!st.up()) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        ExpBars()
        // Setas e alavanca passam pelo filtro (um passo por toque); L1/R1 pulam 5, L2/R2 vão ao primeiro/último.
        DialogPad { ev ->
            val c = ev.keyCode
            if (c == android.view.KeyEvent.KEYCODE_BUTTON_L1 || c == android.view.KeyEvent.KEYCODE_BUTTON_R1 ||
                c == android.view.KeyEvent.KEYCODE_BUTTON_L2 || c == android.view.KeyEvent.KEYCODE_BUTTON_R2
            ) {
                if (ev.action == android.view.KeyEvent.ACTION_DOWN && ev.repeatCount == 0 && zone == 0 && navKeys.isNotEmpty()) {
                    val i = navKeys.indexOf(sel).coerceAtLeast(0)
                    val last = navKeys.lastIndex
                    sel = navKeys[
                        when (c) {
                            android.view.KeyEvent.KEYCODE_BUTTON_R1 -> (i + 5).coerceAtMost(last)
                            android.view.KeyEvent.KEYCODE_BUTTON_L1 -> (i - 5).coerceAtLeast(0)
                            android.view.KeyEvent.KEYCODE_BUTTON_L2 -> 0
                            else -> last
                        }
                    ]
                }
                true
            } else false
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 8.dp)
                .onPreviewKeyEvent { ev ->
                    val n = ev.nativeKeyEvent
                    val down = n.action == android.view.KeyEvent.ACTION_DOWN
                    when (n.keyCode) {
                        android.view.KeyEvent.KEYCODE_BUTTON_B -> {
                            if (down && n.repeatCount == 0) {
                                if (!st.up()) onClose()
                            }
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                            if (down) {
                                if (zone == 1) zone = 0
                                else {
                                    val i = navKeys.indexOf(sel)
                                    if (access && i > 0) sel = navKeys[i - 1]
                                }
                            }
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (down && zone == 0) {
                                val i = navKeys.indexOf(sel)
                                if (access && i in 0 until navKeys.lastIndex) sel = navKeys[i + 1]
                                else {
                                    zone = 1
                                    fbtn = 0
                                }
                            }
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (down) {
                                val d = if (n.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT) -1 else 1
                                if (zone == 1) fbtn = (fbtn + d).coerceIn(0, footerCount - 1)
                                else if (!access) sel = if (d < 0) "grant" else "verify"
                            }
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER,
                        android.view.KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                            if (down && n.repeatCount == 0) activate()
                            true
                        }
                        else -> false
                    }
                }
                .focusRequester(rootFocus)
                .focusable(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .fillMaxHeight(0.94f)
                    .shadow(14.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(EX_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(st.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            path ?: "Escolha onde procurar", color = accent, fontSize = 12.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(closeShape)
                            .background(Color(0x0FFFFFFF))
                            .border(1.dp, EX_LINE, closeShape)
                            .focusProperties { canFocus = false }
                            .clickable { onClose() },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = Color(0xFFD5DAE5), fontSize = 14.sp) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(EX_LINE))

                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
                    if (!access) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "Para listar as pastas, o Nexus precisa do acesso a todos os arquivos.",
                                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Toque em \"Conceder acesso\" e ligue a chave do Nexus. Se esta TV não tiver essa tela, " +
                                    "libere pelo computador com ADB: adb shell appops set com.nexus.launcher MANAGE_EXTERNAL_STORAGE allow",
                                color = EX_MUTED, fontSize = 12.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ExpButton("Conceder acesso", true, accent, rBtn, Modifier.weight(1f), manual = true, hl = zone == 0 && sel == "grant") { askAccess() }
                                ExpButton("Verificar de novo", false, accent, rBtn, Modifier.weight(1f), manual = true, hl = zone == 0 && sel == "verify") {
                                    access = hasAccess()
                                    tick++
                                }
                            }
                        }
                    } else {
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                            items(rows, key = { row -> row.key }) { row ->
                                if (row.text) {
                                    Text(row.name, color = EX_MUTED, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
                                } else {
                                    ExpRow(row.glyph, row.name, row.sub, row.enabled, rCard, zone == 0 && sel == row.key) {
                                        sel = row.key
                                        row.onClick()
                                    }
                                }
                            }
                        }
                    }
                }

                Box(Modifier.fillMaxWidth().height(1.dp).background(EX_LINE))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (showUse) {
                        ExpButton("Usar esta pasta", true, accent, rBtn, Modifier.weight(1f), manual = true, hl = zone == 1 && fbtn == 0) {
                            if (path != null) {
                                st.onPick(File(path))
                                onClose()
                            }
                        }
                    }
                    ExpButton("Cancelar (B)", false, accent, rBtn, Modifier.weight(1f), manual = true, hl = zone == 1 && fbtn == footerCount - 1) { onClose() }
                }
            }
        }
    }
}

/** Ajuda para TVs que não têm a tela do Android para conceder a permissão (mostra o comando de ADB). */
@Composable
fun PermHelpDialog(kind: String, pkg: String, accent: Color, rBtn: Int, rPanel: Int, onClose: () -> Unit) {
    val panel = RoundedCornerShape(rPanel.dp)
    val perm = if (kind == "overlay") "SYSTEM_ALERT_WINDOW" else "MANAGE_EXTERNAL_STORAGE"
    val title = if (kind == "overlay") "Permitir o painel sobre outros apps" else "Permitir acesso aos arquivos"
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(90)
        try {
            first.requestFocus()
        } catch (_: Exception) {
        }
    }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        ExpBars()
        DialogPad()
        Box(Modifier.fillMaxSize().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .shadow(14.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(EX_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Esta TV não tem a tela do Android para liberar essa permissão. Com o computador e o ADB conectados " +
                        "ao aparelho (Opções do desenvolvedor), rode:",
                    color = EX_MUTED, fontSize = 13.sp
                )
                Text(
                    "adb shell appops set $pkg $perm allow", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(rBtn.dp))
                        .background(Color(0xFF0E1118))
                        .padding(12.dp)
                )
                Text("Depois abra o Nexus de novo e tente outra vez.", color = EX_MUTED, fontSize = 12.sp)
                ExpButton("Entendi", true, accent, rBtn, Modifier.fillMaxWidth().focusRequester(first)) { onClose() }
            }
        }
    }
}
