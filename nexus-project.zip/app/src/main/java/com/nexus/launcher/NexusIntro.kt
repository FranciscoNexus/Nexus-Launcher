package com.nexus.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Controla que a abertura apareça só uma vez por vez que o app é aberto do zero. */
object NexusIntroState {
    var shown = false
}

const val INTRO_MS = 3600

private fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun ease(x: Float): Float = x * x * (3f - 2f * x)
private fun easeOut(x: Float): Float = 1f - (1f - x) * (1f - x) * (1f - x)
private fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val y = x - 1f
    return 1f + c3 * y * y * y + c1 * y * y
}
private fun lerpF(a: Float, b: Float, x: Float): Float = a + (b - a) * x

// ---- Geometria do ícone (em pixels da imagem original do ícone; tools/build_icon.py gerou as peças) ----
private const val TAB_L = 480f
private const val TAB_T = 186f
private const val TAB_R = 901f
private const val TAB_B = 611f
private const val DEV_CX = 690f          // centro do conjunto (texto + tablet + controles)
private const val DEV_CY = 371f
private const val DEV_W = 610f
private const val DEV_H = 482f

/** Retângulos das 9 capas na tela do tablet: left, top, right, bottom. */
private val COVER_BOX = arrayOf(
    floatArrayOf(493f, 199f, 606f, 319f), floatArrayOf(614f, 199f, 766f, 316f), floatArrayOf(774f, 198f, 889f, 320f),
    floatArrayOf(493f, 328f, 606f, 458f), floatArrayOf(614f, 328f, 766f, 458f), floatArrayOf(775f, 328f, 888f, 458f),
    floatArrayOf(493f, 466f, 606f, 597f), floatArrayOf(615f, 467f, 766f, 600f), floatArrayOf(775f, 467f, 888f, 600f)
)
private val COVER_RES = intArrayOf(
    R.drawable.intro_cover_1, R.drawable.intro_cover_2, R.drawable.intro_cover_3,
    R.drawable.intro_cover_4, R.drawable.intro_cover_5, R.drawable.intro_cover_6,
    R.drawable.intro_cover_7, R.drawable.intro_cover_8, R.drawable.intro_cover_9
)
/** Ordem de chegada das capas: cantos, depois bordas, por último a do centro. */
private val ARRIVAL = intArrayOf(0, 2, 6, 8, 1, 3, 5, 7, 4)

private val BG_L = Color(0xFFC00705)
private val BG_M = Color(0xFF724887)
private val BG_R = Color(0xFF1390E5)

/**
 * Abertura do Nexus (3,6 s), com as 9 capas do ícone:
 *  1. as capas voam de todos os lados e formam um mosaico enorme;
 *  2. o mosaico encolhe e vira a tela de um tablet;
 *  3. dos lados saem os controles telescópicos (azul e vermelho) em três etapas;
 *  4. o fundo vermelho/azul varre a tela e o nome NEXUS cai no lugar: é o ícone do app.
 * Toque (ou Voltar) para pular.
 */
@Composable
fun NexusIntro(accent: Color, onDone: () -> Unit) {
    val done by rememberUpdatedState(onDone)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        prog.animateTo(1f, tween(INTRO_MS, easing = LinearEasing))
        done()
    }
    BackHandler(true) { done() }
    val t = prog.value

    val covers = COVER_RES.map { ImageBitmap.imageResource(it) }
    val ctrlL = ImageBitmap.imageResource(R.drawable.intro_ctrl_left)
    val ctrlR = ImageBitmap.imageResource(R.drawable.intro_ctrl_right)
    val title = ImageBitmap.imageResource(R.drawable.intro_nexus_text)

    val outA = 1f - ease(seg(t, 0.95f, 1f))

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = outA }
            .background(Color(0xFF05070B))
            .pointerInput(Unit) { detectTapGestures { done() } }
    ) {
        val W = constraints.maxWidth.toFloat()
        val H = constraints.maxHeight.toFloat()
        Canvas(Modifier.fillMaxSize()) {
            val cx = W / 2f
            val cy = H / 2f
            // u = pixels da tela por pixel do ícone (o conjunto final ocupa ~80% da altura ou 90% da largura)
            val u = min(W * 0.90f / DEV_W, H * 0.80f / DEV_H)
            val gBig = (0.92f * H / ((TAB_B - TAB_T) * u)).coerceAtMost(W * 0.95f / ((TAB_R - TAB_L) * u)).coerceAtLeast(1f)

            val shrink = ease(seg(t, 0.30f, 0.47f))
            val g = lerpF(gBig, 1f, shrink) * (1f + 0.025f * sin(PI.toFloat() * seg(t, 0.80f, 0.90f)))

            // ---------- fundo: brilho + varredura vermelho/azul ----------
            val glowA = 0.10f + 0.18f * ease(seg(t, 0.30f, 0.70f))
            drawRect(
                Brush.radialGradient(listOf(accent.copy(alpha = glowA), Color.Transparent), center = Offset(cx, cy), radius = max(W, H) * 0.7f)
            )
            val sweep = ease(seg(t, 0.66f, 0.84f)) * (W / 2f + 2f)
            if (sweep > 0f) {
                val brush = Brush.horizontalGradient(listOf(BG_L, BG_M, BG_R), startX = 0f, endX = W)
                clipRect(left = 0f, top = 0f, right = sweep, bottom = H) { drawRect(brush) }
                clipRect(left = W - sweep, top = 0f, right = W, bottom = H) { drawRect(brush) }
            }

            withTransform({
                translate(cx, cy)
                scale(u * g, u * g, Offset.Zero)
                translate(-DEV_CX, -DEV_CY)
            }) {
                // ---------- controles telescópicos (atrás do tablet) ----------
                val p = seg(t, 0.48f, 0.68f)
                if (p > 0f) {
                    val s = (ease(seg(p, 0.00f, 0.20f)) + ease(seg(p, 0.25f, 0.45f)) + ease(seg(p, 0.50f, 0.70f))) / 3f
                    val over = 34f * sin(PI.toFloat() * seg(p, 0.70f, 1.00f))
                    val hide = 100f
                    val dxL = (1f - s) * hide - over          // + = para dentro do tablet
                    val dxR = -(1f - s) * hide + over
                    // hastes (aparecem quando o controle passa do ponto e sobra um vão)
                    if (over > 0.5f) {
                        for (side in intArrayOf(-1, 1)) {
                            val edge = if (side < 0) TAB_L else TAB_R
                            for (yy in floatArrayOf(318f, 492f)) {
                                for (k in 0 until 3) {
                                    val seg0 = over * k / 3f
                                    val seg1 = over * (k + 1) / 3f + 1.5f
                                    val h = 13f - 3f * k
                                    val xa = edge + side * seg0
                                    val xb = edge + side * seg1
                                    drawRoundRect(
                                        Color(0xFF2F343F), Offset(min(xa, xb), yy - h / 2f), Size(abs(xb - xa), h), CornerRadius(2.5f)
                                    )
                                    drawRoundRect(
                                        Color(0xFF8A93A6).copy(alpha = 0.6f), Offset(min(xa, xb), yy - h / 2f), Size(abs(xb - xa), 2f), CornerRadius(1f)
                                    )
                                }
                            }
                        }
                    }
                    drawPiece(ctrlL, 378f + dxL, 272f, 105f, 284f)
                    drawPiece(ctrlR, 898f + dxR, 272f, 105f, 284f)
                }

                // ---------- corpo do tablet ----------
                val body = ease(seg(t, 0.26f, 0.36f))
                if (body > 0f) {
                    val r = 22f
                    drawRoundRect(Color(0xFF0B0B0F).copy(alpha = body), Offset(TAB_L, TAB_T), Size(TAB_R - TAB_L, TAB_B - TAB_T), CornerRadius(r))
                    // moldura de luz que se traça e depois acalma
                    val trace = easeOut(seg(t, 0.28f, 0.44f))
                    val calm = 1f - ease(seg(t, 0.46f, 0.56f))
                    if (calm > 0f) {
                        val path = Path().apply { addRoundRect(RoundRect(TAB_L, TAB_T, TAB_R, TAB_B, CornerRadius(r))) }
                        val pm = PathMeasure()
                        pm.setPath(path, false)
                        val part = Path()
                        pm.getSegment(0f, pm.length * trace, part, true)
                        drawPath(part, accent.copy(alpha = calm), style = Stroke(width = 4f, cap = StrokeCap.Round))
                    }
                }

                // ---------- as 9 capas ----------
                val cTx = (TAB_L + TAB_R) / 2f
                val cTy = (TAB_T + TAB_B) / 2f
                val far = max(W, H) / (u * gBig) * 0.85f
                for (k in ARRIVAL.indices) {
                    val i = ARRIVAL[k]
                    val b = COVER_BOX[i]
                    val x0 = b[0] + 1f
                    val y0 = b[1] + 1f
                    val w = b[2] - b[0] - 2f
                    val h = b[3] - b[1] - 2f
                    val delay = k * 0.022f
                    val f = easeOut(seg(t, delay, delay + 0.20f))
                    if (f <= 0f) continue
                    var dx = (x0 + w / 2f) - cTx
                    var dy = (y0 + h / 2f) - cTy
                    val len = sqrt(dx * dx + dy * dy)
                    if (len < 1f) { dx = 0f; dy = 1f } else { dx /= len; dy /= len }
                    val sign = if (i % 2 == 0) 1f else -1f
                    val offX = dx * far * (1f - f)
                    val offY = dy * far * (1f - f)
                    val rot = 38f * sign * (1f - f)
                    val tilt = max(0.2f, cos((1f - f) * 1.15f))
                    val sc = lerpF(0.55f, 1f, f)
                    withTransform({
                        translate(x0 + w / 2f + offX, y0 + h / 2f + offY)
                        rotate(rot, Offset.Zero)
                        scale(sc * tilt, sc, Offset.Zero)
                    }) {
                        drawPiece(covers[i], -w / 2f, -h / 2f, w, h, alpha = min(1f, f * 2.2f))
                    }
                }

                // ---------- NEXUS cai no lugar ----------
                val dropA = seg(t, 0.72f, 0.78f)
                if (dropA > 0f) {
                    val pop = easeOutBack(seg(t, 0.72f, 0.85f))
                    val ty = lerpF(-110f, 0f, pop)
                    val sc = lerpF(1.25f, 1f, pop.coerceIn(0f, 1f))
                    withTransform({
                        translate(572f + 120f, 118f + 33f + ty)
                        scale(sc, sc, Offset.Zero)
                    }) {
                        drawPiece(title, -120f, -33f, 240f, 66f, alpha = dropA)
                    }
                }
            }

            // ---------- clarão quando o ícone se completa ----------
            val fl = seg(t, 0.78f, 0.90f)
            if (fl > 0f && fl < 1f) {
                val a = sin(fl * PI.toFloat())
                val rad = DEV_W * u * (0.35f + 0.5f * fl)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.55f * a), accent.copy(alpha = 0.25f * a), Color.Transparent),
                        center = Offset(cx, cy), radius = rad
                    ),
                    rad, Offset(cx, cy)
                )
            }
        }
    }
}

/** Desenha uma imagem no retângulo (x, y, w, h) do espaço atual, com boa qualidade ao ampliar. */
private fun DrawScope.drawPiece(bmp: ImageBitmap, x: Float, y: Float, w: Float, h: Float, alpha: Float = 1f) {
    withTransform({
        translate(x, y)
        scale(w / bmp.width, h / bmp.height, Offset.Zero)
    }) {
        drawImage(
            bmp, IntOffset.Zero, IntSize(bmp.width, bmp.height), IntOffset.Zero, IntSize(bmp.width, bmp.height),
            alpha = alpha, filterQuality = FilterQuality.High
        )
    }
}
