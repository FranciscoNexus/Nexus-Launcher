package com.nexus.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.gestures.detectTapGestures
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Controla que a abertura apareça só uma vez por vez que o app é aberto do zero. */
object NexusIntroState {
    var shown = false
}

private fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun ease(x: Float): Float = x * x * (3f - 2f * x)

/**
 * Abertura do Nexus (~3,6 s): capas de plataformas diferentes voam até o centro, viram a tela de um
 * tablet, controles telescópicos se estendem dos lados e tudo vira o ícone do Nexus. Toque para pular.
 */
@Composable
fun NexusIntro(
    covers: Int,
    coverContent: @Composable (Int, Modifier) -> Unit,
    accent: Color,
    onDone: () -> Unit
) {
    val done by rememberUpdatedState(onDone)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        prog.animateTo(1f, tween(3600, easing = LinearEasing))
        done()
    }
    BackHandler(true) { done() }
    val t = prog.value
    val n = covers.coerceAtMost(6)

    // fases
    val fly = ease(seg(t, 0.00f, 0.32f))      // capas voam ao centro
    val merge = ease(seg(t, 0.30f, 0.46f))    // viram a tela do tablet
    val ext = ease(seg(t, 0.44f, 0.68f))      // controles telescópicos
    val toLogo = ease(seg(t, 0.68f, 0.84f))   // tudo vira o logo
    val outA = 1f - ease(seg(t, 0.92f, 1f))   // desaparece

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = outA }
            .background(Color(0xFF05070B))
            .pointerInput(Unit) { detectTapGestures { done() } }
    ) {
        // brilho de fundo
        Canvas(Modifier.fillMaxSize()) {
            val g = 0.10f + 0.22f * ease(seg(t, 0.3f, 0.85f))
            drawRect(
                Brush.radialGradient(
                    listOf(accent.copy(alpha = g), Color.Transparent),
                    center = center, radius = size.minDimension * 0.9f
                )
            )
        }

        // capas voando
        if (n > 0 && merge < 1f) {
            val cw = 70.dp
            val ch = 100.dp
            for (i in 0 until n) {
                val ang = (2.0 * PI * i / n - PI / 2).toFloat()
                val dist = (1f - fly) * 520f      // dp de distância do centro
                val spin = (1f - fly) * (i % 2 * 2 - 1) * 140f
                val sc = (0.9f - 0.35f * fly) * (1f - 0.6f * merge)
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(cw, ch)
                        .graphicsLayer {
                            translationX = cos(ang) * dist * density
                            translationY = sin(ang) * dist * density * 0.6f
                            rotationZ = spin
                            scaleX = sc
                            scaleY = sc
                            alpha = (1f - merge) * (0.25f + 0.75f * seg(t, 0f, 0.1f))
                        }
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF13161E))
                ) { coverContent(i, Modifier.fillMaxSize()) }
            }
        }

        // tablet + controle telescópico
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val s = 1f - 0.55f * toLogo
                    scaleX = s
                    scaleY = s
                    alpha = 1f - toLogo
                }
        ) {
            val show = merge
            if (show > 0.01f) {
                val tw = size.minDimension * 0.46f * 1.5f
                val th = tw * 0.62f
                val cx = size.width / 2f
                val cy = size.height / 2f
                val tl = Offset(cx - tw / 2f, cy - th / 2f)
                val r = th * 0.08f
                // braços telescópicos (saem dos lados)
                val armLen = tw * 0.28f * ext
                val armH = th * 0.46f
                val steel = Color(0xFF2A303C)
                for (side in intArrayOf(-1, 1)) {
                    val baseX = if (side < 0) tl.x else tl.x + tw
                    // 3 seções que deslizam, cada uma menor que a anterior
                    for (k in 0 until 3) {
                        val secLen = armLen * (1f - 0.22f * k) / 1.6f
                        val off = armLen * 0.42f * k
                        val h = armH * (1f - 0.16f * k)
                        val x0 = if (side < 0) baseX - off - secLen else baseX + off
                        drawRoundRect(
                            steel.copy(alpha = show),
                            Offset(x0, cy - h / 2f), Size(secLen, h), CornerRadius(h * 0.2f)
                        )
                        drawRoundRect(
                            accent.copy(alpha = 0.55f * show),
                            Offset(x0, cy - h / 2f), Size(secLen, h), CornerRadius(h * 0.2f),
                            style = Stroke(width = 1.5f * density)
                        )
                    }
                    // manopla (grip) na ponta
                    val gw = tw * 0.16f * ext
                    val gh = th * 0.8f
                    val gx = if (side < 0) baseX - armLen * 1.2f - gw else baseX + armLen * 1.2f
                    if (ext > 0.05f) {
                        drawRoundRect(
                            Color(0xFF1B2029).copy(alpha = show), Offset(gx, cy - gh / 2f),
                            Size(gw, gh), CornerRadius(gw * 0.5f)
                        )
                        drawCircle(accent.copy(alpha = show * ext), gw * 0.18f, Offset(gx + gw / 2f, cy - gh * 0.18f))
                        drawCircle(Color.White.copy(alpha = 0.55f * show * ext), gw * 0.12f, Offset(gx + gw / 2f, cy + gh * 0.12f))
                    }
                }
                // corpo do tablet
                drawRoundRect(Color(0xFF0E1117).copy(alpha = show), tl, Size(tw, th), CornerRadius(r))
                drawRoundRect(
                    accent.copy(alpha = show), tl, Size(tw, th), CornerRadius(r),
                    style = Stroke(width = 2.5f * density)
                )
                // tela brilhando com as capas "dentro"
                val m = th * 0.07f
                drawRoundRect(
                    Brush.linearGradient(
                        listOf(accent.copy(alpha = 0.55f * show), Color(0xFF8A5CFF).copy(alpha = 0.45f * show)),
                        start = tl, end = Offset(tl.x + tw, tl.y + th)
                    ),
                    Offset(tl.x + m, tl.y + m), Size(tw - 2 * m, th - 2 * m), CornerRadius(r * 0.6f)
                )
            }
        }

        // logo final
        if (toLogo > 0.01f) {
            Image(
                painter = painterResource(R.drawable.ic_nexus_logo),
                contentDescription = "Nexus",
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(150.dp)
                    .graphicsLayer {
                        val s = 0.55f + 0.45f * toLogo + 0.06f * sin(toLogo * PI.toFloat())
                        scaleX = s
                        scaleY = s
                        alpha = toLogo
                    },
                contentScale = ContentScale.Fit
            )
        }
    }
}
