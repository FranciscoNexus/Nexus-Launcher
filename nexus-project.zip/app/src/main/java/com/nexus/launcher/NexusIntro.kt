package com.nexus.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Controla que a abertura apareça só uma vez por vez que o app é aberto do zero. */
object NexusIntroState {
    var shown = false
}

/** Duração da abertura. O som (tools/gen_sounds.py, snd_*_intro) tem exatamente esta duração e os mesmos tempos. */
const val INTRO_MS = 3800

private fun seg(t: Float, a: Float, b: Float): Float = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun ease(x: Float): Float = x * x * (3f - 2f * x)
private fun easeOut(x: Float): Float = 1f - (1f - x) * (1f - x) * (1f - x)
private fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val y = x - 1f
    return 1f + c3 * y * y * y + c1 * y * y
}
private fun lerp(a: Float, b: Float, x: Float): Float = a + (b - a) * x

private val PLACEHOLDERS = listOf(
    Color(0xFF3B5BDB), Color(0xFFD6336C), Color(0xFF2F9E44),
    Color(0xFFF08C00), Color(0xFF7048E8), Color(0xFF0C8599)
)

/**
 * Abertura do Nexus (3,8 s):
 *  1. capas de plataformas diferentes giram em órbita e convergem para o centro;
 *  2. viram a tela de um tablet (a moldura se desenha sozinha);
 *  3. dos dois lados saem os braços telescópicos de um controle, com direcional e botões;
 *  4. o aparelho gira de lado e revela o ícone do Nexus.
 * Toque (ou Voltar) para pular.
 */
@Composable
fun NexusIntro(
    covers: Int,
    coverContent: @Composable (Int, Modifier) -> Unit,
    accent: Color,
    onDone: () -> Unit
) {
    val done by rememberUpdatedState(onDone)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        Sfx.playIntro()
        prog.animateTo(1f, tween(INTRO_MS, easing = LinearEasing))
        done()
    }
    val skip = { Sfx.stopIntro(); done() }
    BackHandler(true) { skip() }
    val t = prog.value
    val n = 6
    val real = covers.coerceAtMost(n)

    val outA = 1f - ease(seg(t, 0.95f, 1f))

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = outA }
            .background(Color(0xFF05070B))
            .pointerInput(Unit) { detectTapGestures { skip() } }
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val W = constraints.maxWidth.toFloat()
            val H = constraints.maxHeight.toFloat()
            val dens = LocalDensity.current.density
            val cx = W / 2f
            val cy = H / 2f
            // Tamanho do tablet: cabe com os braços abertos (largura total = 1,86 x tablet).
            val tw = min(W / 1.95f, H * 0.95f)
            val th = tw * 0.62f
            val tl = Offset(cx - tw / 2f, cy - th / 2f)
            val screenM = th * 0.07f
            val scrW = tw - 2 * screenM
            val scrH = th - 2 * screenM

            // ---- tamanhos e posições das capas ----
            val orbW = min(W, H) * 0.16f
            val orbH = orbW * 1.4f
            val cellW = scrW * 0.30f
            val cellH = scrH * 0.45f
            val gapX = (scrW - 3 * cellW) / 4f
            val gapY = (scrH - 2 * cellH) / 3f

            val tA = t
            val fly = easeOut(seg(tA, 0.00f, 0.30f))
            val merge = ease(seg(tA, 0.30f, 0.46f))

            fun orbitPos(i: Int, tt: Float): Offset {
                val f = easeOut(seg(tt, 0.00f, 0.30f))
                val base = (2.0 * PI * i / n - PI / 2).toFloat()
                val ang = base + (1f - f) * 2.6f * (if (i % 2 == 0) 1f else -1f) + f * 0.6f
                val r = lerp(maxOf(W, H) * 0.75f, tw * 0.55f, f)
                return Offset(cx + cos(ang) * r, cy + sin(ang) * r * 0.62f)
            }
            fun cellPos(i: Int): Offset {
                val col = i % 3
                val row = i / 3
                return Offset(
                    tl.x + screenM + gapX + col * (cellW + gapX) + cellW / 2f,
                    tl.y + screenM + gapY + row * (cellH + gapY) + cellH / 2f
                )
            }

            // ---- giro do aparelho (revela o logo) ----
            val flipOut = ease(seg(t, 0.72f, 0.80f))      // 0 -> 1: aparelho de frente -> de lado
            val flipIn = ease(seg(t, 0.80f, 0.88f))       // 0 -> 1: logo de lado -> de frente
            val devScale = 1f - 0.25f * flipOut

            // ---- fundo: brilho, rastros das capas, flash ----
            Canvas(Modifier.fillMaxSize()) {
                val glow = 0.08f + 0.20f * ease(seg(t, 0.30f, 0.95f))
                drawRect(
                    Brush.radialGradient(
                        listOf(accent.copy(alpha = glow), Color.Transparent),
                        center = Offset(cx, cy), radius = maxOf(W, H) * 0.7f
                    )
                )
                // rastros das capas voando
                if (t < 0.34f) {
                    for (i in 0 until n) {
                        val appear = seg(t, 0.0f + i * 0.012f, 0.08f + i * 0.012f)
                        for (k in 1..5) {
                            val p0 = orbitPos(i, (t - 0.006f * (k - 1)).coerceAtLeast(0f))
                            val p1 = orbitPos(i, (t - 0.006f * k).coerceAtLeast(0f))
                            drawLine(
                                accent.copy(alpha = (0.5f - 0.09f * k) * appear * (1f - merge)),
                                p0, p1, strokeWidth = (5f - k) * dens, cap = StrokeCap.Round
                            )
                        }
                    }
                }
                // anel de luz na fusão
                val ringP = seg(t, 0.30f, 0.46f)
                if (ringP > 0f && ringP < 1f) {
                    drawCircle(
                        accent.copy(alpha = 0.6f * (1f - ringP)), tw * (0.2f + 0.9f * ringP), Offset(cx, cy),
                        style = Stroke(width = 3f * dens)
                    )
                }
                // flash quando o aparelho vira o logo
                val fl = seg(t, 0.76f, 0.86f)
                if (fl > 0f && fl < 1f) {
                    val a = sin(fl * PI.toFloat())
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.85f * a), accent.copy(alpha = 0.35f * a), Color.Transparent),
                            center = Offset(cx, cy), radius = tw * (0.4f + 0.9f * fl)
                        ),
                        tw * (0.4f + 0.9f * fl), Offset(cx, cy)
                    )
                }
                // raios do logo
                val rayP = seg(t, 0.80f, 0.92f)
                if (rayP > 0f) {
                    for (k in 0 until 16) {
                        val a = (2.0 * PI * k / 16).toFloat() + 0.2f
                        val r0 = tw * 0.22f
                        val r1 = tw * (0.22f + 0.38f * easeOut(rayP) * (if (k % 2 == 0) 1f else 0.7f))
                        drawLine(
                            accent.copy(alpha = 0.7f * (1f - rayP)),
                            Offset(cx + cos(a) * r0, cy + sin(a) * r0),
                            Offset(cx + cos(a) * r1, cy + sin(a) * r1),
                            strokeWidth = 2.5f * dens, cap = StrokeCap.Round
                        )
                    }
                }
            }

            // ---- aparelho (tablet + braços + capas na tela), gira como um corpo só ----
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        rotationY = -90f * flipOut
                        cameraDistance = 16f * density
                        scaleX = devScale
                        scaleY = devScale
                        alpha = 1f - 0.2f * flipOut
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    drawDevice(t, tl, tw, th, screenM, accent, dens)
                }
                // capas
                for (i in 0 until n) {
                    val appear = seg(t, 0.0f + i * 0.012f, 0.07f + i * 0.012f)
                    if (appear <= 0f) continue
                    val o = orbitPos(i, t)
                    val c = cellPos(i)
                    val px = lerp(o.x, c.x, merge)
                    val py = lerp(o.y, c.y, merge)
                    val w = lerp(orbW * (0.55f + 0.45f * fly), cellW, merge)
                    val h = lerp(orbH * (0.55f + 0.45f * fly), cellH, merge)
                    val rot = (1f - fly) * 140f * (if (i % 2 == 0) 1f else -1f) * (1f - merge)
                    val tilt = 28f * (1f - merge) * (if (i % 2 == 0) 1f else -1f)
                    Box(
                        Modifier
                            .offset { IntOffset((px - w / 2f).roundToInt(), (py - h / 2f).roundToInt()) }
                            .size((w / dens).dp, (h / dens).dp)
                            .graphicsLayer {
                                rotationZ = rot
                                rotationY = tilt
                                cameraDistance = 14f * density
                                alpha = appear
                            }
                            .clip(RoundedCornerShape(((1f - merge) * 8f + 4f).dp))
                            .background(PLACEHOLDERS[i % PLACEHOLDERS.size])
                    ) {
                        if (i < real) coverContent(i, Modifier.fillMaxSize())
                    }
                }
            }

            // ---- logo (aparece de lado e gira para a frente) ----
            if (flipIn > 0f || t > 0.8f) {
                val pop = easeOutBack(seg(t, 0.80f, 0.90f))
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .graphicsLayer {
                            rotationY = 90f * (1f - flipIn)
                            cameraDistance = 16f * density
                            val s = 0.55f + 0.45f * pop
                            scaleX = s
                            scaleY = s
                            alpha = flipIn
                        }
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_nexus_logo),
                        contentDescription = "Nexus",
                        modifier = Modifier.size((min(W, H) * 0.42f / dens).dp),
                        contentScale = ContentScale.Fit
                    )
                }
                val txtA = seg(t, 0.86f, 0.93f)
                if (txtA > 0f) {
                    Text(
                        "N E X U S",
                        color = Color.White.copy(alpha = 0.9f * txtA),
                        fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .offset(y = (min(W, H) * 0.25f / dens).dp)
                            .padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

/** Desenha o tablet (moldura que se traça sozinha), a tela e os braços telescópicos com direcional e botões. */
private fun DrawScope.drawDevice(
    t: Float, tl: Offset, tw: Float, th: Float, screenM: Float, accent: Color, dens: Float
) {
    val r = th * 0.09f
    val draw = easeOut(seg(t, 0.30f, 0.42f))      // moldura se desenhando
    val body = ease(seg(t, 0.38f, 0.46f))         // corpo preenchido
    val ext = seg(t, 0.46f, 0.64f)                // braços saindo
    val extE = easeOutBack(ext)
    val btn = seg(t, 0.62f, 0.70f)                // direcional e botões surgem

    if (draw <= 0f) return
    val cx = tl.x + tw / 2f
    val cy = tl.y + th / 2f
    val steel = Color(0xFF262C38)

    // --- braços telescópicos (atrás do tablet) ---
    if (ext > 0f) {
        val gw = tw * 0.22f
        val gh = th * 0.98f
        val tubeLen = tw * 0.21f
        for (side in intArrayOf(-1, 1)) {
            val base = if (side < 0) tl.x else tl.x + tw
            val d = (tubeLen + gw) * extE                  // distância percorrida (pode passar um pouco: "mola")
            val inner = (d - gw).coerceAtLeast(0f)
            // três seções que deslizam, cada uma mais fina que a anterior
            for (k in 0 until 3) {
                val a0 = inner * k / 3f
                val a1 = inner * (k + 1) / 3f
                val h = th * (0.54f - 0.10f * k)
                val xa = base + side * (a0 - 2f * dens)
                val xb = base + side * (a1 + 2f * dens)
                val left = min(xa, xb)
                val wd = kotlin.math.abs(xb - xa)
                if (wd > 1f) {
                    drawRoundRect(steel, Offset(left, cy - h / 2f), Size(wd, h), CornerRadius(h * 0.18f))
                    drawRoundRect(
                        accent.copy(alpha = 0.55f), Offset(left, cy - h / 2f), Size(wd, h), CornerRadius(h * 0.18f),
                        style = Stroke(width = 1.5f * dens)
                    )
                }
            }
            // manopla
            val gx0 = base + side * (d - gw)
            val gx1 = base + side * d
            val gl = min(gx0, gx1)
            drawRoundRect(Color(0xFF1B2029), Offset(gl, cy - gh / 2f), Size(gw, gh), CornerRadius(gw * 0.42f))
            drawRoundRect(
                accent, Offset(gl, cy - gh / 2f), Size(gw, gh), CornerRadius(gw * 0.42f),
                style = Stroke(width = 2f * dens)
            )
            val gcx = gl + gw / 2f
            if (btn > 0f) {
                val s = easeOutBack(btn)
                if (side < 0) {
                    // direcional (cruz)
                    val arm = gw * 0.30f * s
                    val th2 = gw * 0.20f * s
                    drawRoundRect(Color(0xFFDDE3F0), Offset(gcx - arm, cy - th2 / 2f), Size(arm * 2, th2), CornerRadius(th2 * 0.3f))
                    drawRoundRect(Color(0xFFDDE3F0), Offset(gcx - th2 / 2f, cy - arm), Size(th2, arm * 2), CornerRadius(th2 * 0.3f))
                    drawCircle(Color(0xFF3A4252), gw * 0.09f * s, Offset(gcx, cy - gh * 0.33f))
                } else {
                    val rr = gw * 0.115f * s
                    val o = gw * 0.25f * s
                    drawCircle(Color(0xFF30D158), rr, Offset(gcx, cy + o))   // A
                    drawCircle(Color(0xFFFF453A), rr, Offset(gcx + o, cy))   // B
                    drawCircle(accent, rr, Offset(gcx - o, cy))              // X
                    drawCircle(Color(0xFFFFD60A), rr, Offset(gcx, cy - o))   // Y
                    drawCircle(Color(0xFF3A4252), gw * 0.09f * s, Offset(gcx, cy + gh * 0.33f))
                }
            }
        }
    }

    // --- corpo do tablet ---
    if (body > 0f) {
        drawRoundRect(Color(0xFF0E1117).copy(alpha = body), tl, Size(tw, th), CornerRadius(r))
        val m = screenM
        drawRoundRect(
            Brush.linearGradient(
                listOf(accent.copy(alpha = 0.40f * body), Color(0xFF7A4DFF).copy(alpha = 0.28f * body)),
                start = tl, end = Offset(tl.x + tw, tl.y + th)
            ),
            Offset(tl.x + m, tl.y + m), Size(tw - 2 * m, th - 2 * m), CornerRadius(r * 0.55f)
        )
    }
    // moldura traçada progressivamente
    val path = Path().apply { addRoundRect(RoundRect(tl.x, tl.y, tl.x + tw, tl.y + th, CornerRadius(r))) }
    val pm = PathMeasure()
    pm.setPath(path, false)
    val part = Path()
    pm.getSegment(0f, pm.length * draw, part, true)
    drawPath(part, accent, style = Stroke(width = 3f * dens, cap = StrokeCap.Round))
    // brilho no canto superior
    if (body > 0.5f) {
        drawCircle(accent.copy(alpha = 0.9f * body), 2.5f * dens, Offset(cx, tl.y + screenM * 0.5f))
    }
}
