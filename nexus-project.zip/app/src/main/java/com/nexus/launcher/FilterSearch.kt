package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.FilterDialog() {
    val present = platformNames().filter { p -> games.any { it.shownPlatform == p } }
    val fFavOnly: @Composable () -> Unit = {
        CToggle("Apenas Favoritos", favOnly, Modifier.fillMaxWidth(), star = true) { favOnly = it }
    }
    val fPlat: @Composable () -> Unit = {
        CSelect(
            "Plataforma:", if (fPlatform.isEmpty()) "Todas" else fPlatform,
            listOf("Todas") + present, Modifier.fillMaxWidth()
        ) { fPlatform = if (it == "Todas") "" else it }
    }
    val fGen: @Composable () -> Unit = {
        CSelect(
            "Gênero:", if (fGenre.isEmpty()) "Todos" else fGenre,
            listOf("Todos", NO_GENRE) + genres.sortedAlpha { it }, Modifier.fillMaxWidth()
        ) { fGenre = if (it == "Todos") "" else it }
    }
    val fColl: @Composable () -> Unit = {
        CSelect(
            "Coleção:", if (fCollection.isEmpty()) "Todas" else fCollection,
            listOf("Todas") + orderedCollections(), Modifier.fillMaxWidth()
        ) { fCollection = if (it == "Todas") "" else it }
    }
    val fSort: @Composable () -> Unit = {
        CSelect("Ordem:", SORTS[sortMode], SORTS, Modifier.fillMaxWidth()) { sortMode = SORTS.indexOf(it) }
    }
    NexusModal(
        "Filtrar Biblioteca", { popOverlay() },
        footer = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CButton("Remover Filtros", C_ORANGE, Modifier.weight(1f)) { resetFilters() }
                CButton("Fechar", C_BLUE, Modifier.weight(1f)) {
                    selectedId = firstNavId()
                    overlay = Overlay.None
                }
            }
        }
    ) {
        if (filterActive) {
            Text(
                "Há filtro ativo na biblioteca.",
                color = parseColor(accentHex), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            )
        }
        if (landscape) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fFavOnly()
                    fPlat()
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    fGen()
                    fColl()
                    fSort()
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                fFavOnly()
                fPlat()
                fGen()
                fColl()
                fSort()
            }
        }
    }
}

@Composable
internal fun MainActivity.SearchGlyph(color: Color, dim: Dp) {
    Canvas(Modifier.size(dim)) {
        val w = this.size.minDimension
        val sw = w * 0.11f
        drawCircle(color, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(width = sw))
        drawLine(color, Offset(w * 0.66f, w * 0.66f), Offset(w * 0.9f, w * 0.9f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

// Pesquisa em tempo real (3.9.9): o grid de trás filtra enquanto você digita.
// "Ver Resultados" mantém o filtro; fechar (B) descarta e volta ao que estava antes.
@Composable
internal fun MainActivity.SearchDialog() {
    val accent = parseColor(accentHex)
    val panel = RoundedCornerShape(rPanel.dp)
    val btn = RoundedCornerShape(rBtn.dp)
    val prev = remember { searchTerm }
    var committed by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        onDispose { if (!committed) searchTerm = prev }
    }
    val focus = remember { FocusRequester() }
    var fieldFocused by remember { mutableStateOf(false) }
    val tvEdit = rememberTvEdit()
    val q = searchTerm
    val active = q.isNotBlank()
    val count = filteredGames().size
    val countText = when {
        !active -> if (count == 1) "1 jogo disponível" else "$count jogos disponíveis"
        count == 0 -> "0 jogos encontrados"
        count == 1 -> "1 jogo encontrado"
        else -> "$count jogos encontrados"
    }
    // Atalhos rápidos: coleções e plataformas que existem na sua biblioteca.
    val chips = (collections.sortedAlpha { it }.filter { !isFixedCollection(it) || games.any { g -> it in g.collections } } + (if (games.any { it.genres.isEmpty() }) listOf(NO_GENRE) else emptyList()) +
        games.groupBy { it.shownPlatform }.entries.sortedByDescending { it.value.size }.map { it.key })
        .filter { it.isNotBlank() }
        .distinctBy { it.lowercase() }
        .take(8)

    val applySearch: () -> Unit = {
        if (active && count == 0) {
            toast("Nenhum jogo encontrado")
        } else {
            committed = true
            selectedId = firstNavId()
            overlay = Overlay.None
        }
    }
    val clearSearch: () -> Unit = {
        searchTerm = ""
    }

    Dialog(
        onDismissRequest = { popOverlay() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .onPreviewKeyEvent { ev ->
                    val n = ev.nativeKeyEvent
                    if (n.action != KeyEvent.ACTION_DOWN) {
                        false
                    } else when (n.keyCode) {
                        KeyEvent.KEYCODE_BUTTON_Y -> {
                            clearSearch()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_CENTER -> if (fieldFocused) {
                            applySearch()
                            true
                        } else false
                        else -> false
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(if (landscape) 0.6f else 0.92f)
                    .widthIn(max = 440.dp)
                    .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                    .clip(panel)
                    .background(S_PANEL)
                    .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
                    .padding(16.dp)
            ) {
                // Cabeçalho: ícone, título com contagem e termo ativo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(34.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
                        contentAlignment = Alignment.Center
                    ) { SearchGlyph(accent, 17.dp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Pesquisar", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        Text(countText, color = S_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
                    }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .widthIn(max = 120.dp)
                            .clip(CircleShape)
                            .background(S_FIELD)
                            .border(1.dp, if (active) accent else Color(0x26FFFFFF), CircleShape)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        MarqueeText(
                            if (active) "\"${q.trim()}\"" else "Todos",
                            if (active) accent else Color(0xFFCBD2E0), 12
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Campo de busca
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clip(btn)
                        .background(if (tvEdit.selected) accent.copy(alpha = 0.16f) else S_FIELD)
                        .border(
                            if (tvEdit.selected) 3.dp else if (fieldFocused) 2.dp else 1.dp,
                            if (fieldFocused || tvEdit.selected) accent else S_LINE, btn
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SearchGlyph(S_MUTED, 16.dp)
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f).tvFieldBox(tvEdit)) {
                        if (q.isEmpty()) Text("Digite o título...", color = S_MUTED, fontSize = 14.sp, maxLines = 1)
                        BasicTextField(
                            value = q, onValueChange = { searchTerm = it }, singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium),
                            cursorBrush = SolidColor(Color.White),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { applySearch() }),
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focus)
                                .tvFieldInput(tvEdit)
                                .onFocusChanged { fieldFocused = it.isFocused }
                        )
                    }
                    // Microfone (4.0.8): fala o título sem abrir o teclado; o filtro ao vivo atualiza sozinho.
                    Spacer(Modifier.width(8.dp))
                    VoiceMic(q, { searchTerm = it }, accent, size = 32.dp)
                    if (q.isNotEmpty()) {
                        Spacer(Modifier.width(8.dp))
                        EBtn("Limpar", null, Color(0xFF222734), Color(0x26FFFFFF), Color(0xFFE2E6EF)) { clearSearch() }
                    }
                }

                // Atalhos rápidos
                if (chips.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "RÁPIDO:", color = S_MUTED, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp, maxLines = 1, softWrap = false
                        )
                        chips.forEach { c ->
                            val on = active && q.trim().equals(c, true)
                            Box(
                                modifier = Modifier
                                    .clip(btn)
                                    .background(if (on) accent.copy(alpha = 0.12f) else S_FIELD)
                                    .border(1.dp, if (on) accent else S_LINE, btn)
                                    .focusGlow(btn)
                                    .clickable { searchTerm = if (on) "" else c }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    c, color = if (on) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))

                // Botões menores, sem quebra de linha
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(btn)
                            .background(Color(0xFF1E222B))
                            .border(1.dp, S_LINE, btn)
                            .focusGlow(btn)
                            .clickable { popOverlay() }
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(18.dp).clip(CircleShape).background(S_PAD_B), contentAlignment = Alignment.Center) {
                            Text("B", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                                lineHeight = 10.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Fechar (B)", color = Color(0xFFE2E6EF), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, softWrap = false
                        )
                    }
                    EBtn("Ver Resultados", null, accent, accent, onAccent(accent), Modifier.weight(1f).height(38.dp)) { applySearch() }
                }
            }

            // Legenda do controle, no rodapé da tela
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF20A0C10))) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PadHint("A", "Confirmar", S_PAD_A, compact = true) { applySearch() }
                    Spacer(Modifier.width(14.dp))
                    PadHint("B", "Voltar", S_PAD_B, compact = true) { popOverlay() }
                    Spacer(Modifier.width(14.dp))
                    PadHint("Y", "Limpar", Color(0xFFF6CE48), compact = true) { clearSearch() }
                }
            }
        }
    }
}
