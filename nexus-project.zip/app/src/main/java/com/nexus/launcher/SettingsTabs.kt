package com.nexus.launcher

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.OrientationEventListener
import android.content.res.Configuration
import android.content.IntentFilter
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// 4.9.9: telas movidas do MainActivity.kt para este arquivo, sem mudar o comportamento.
// São funções de extensão da MainActivity: usam o estado dela como antes.

@Composable
internal fun MainActivity.SettingsTabs(accent: Color, compact: Boolean) {
    val outer = RoundedCornerShape((if (compact) rBtn else rCard).dp)
    val inner = RoundedCornerShape(rBtn.dp)
    val tabs = listOf("◐" to "Visual", "▦" to "Biblioteca", "▤" to "Sistema", "✦" to "Extras")
    Row(
        modifier = (if (compact) Modifier else Modifier.fillMaxWidth())
            .clip(outer)
            .background(S_FIELD)
            .border(1.dp, S_LINE, outer)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        tabs.forEachIndexed { i, t ->
            val sel = settingsTab == i
            val fg = if (sel) onAccent(accent) else S_MUTED
            Row(
                modifier = (if (compact) Modifier.height(30.dp) else Modifier.weight(t.second.length + (if (sel) 2.5f else 0f)).height(40.dp))
                    .clip(inner)
                    .background(if (sel) accent else Color.Transparent)
                    .focusGlow(inner)
                    .clickable {
                    settingsTab = i
                }
                    .padding(horizontal = if (compact) 12.dp else 2.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Com 4 abas, o retrato usa letras um pouco menores para tudo caber na largura.
                // Retrato: a aba escolhida fica mais larga e mostra o ícone; as outras mostram só o nome inteiro.
                if (compact || sel) {
                    Text(t.first, color = fg, fontSize = if (compact) 12.sp else 11.sp)
                    Spacer(Modifier.width(if (compact) 5.dp else 3.dp))
                }
                Text(t.second, color = fg, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
            }
        }
    }
}

@Composable
internal fun MainActivity.CornerOptions(compact: Boolean, vpad: Dp = 12.dp, land: Boolean = false) {
    val style = styleIdx
    val accent = parseColor(accentHex)
    val btn = RoundedCornerShape(rBtn.dp)
    if (land) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Reto", "Padrão", "Suave").forEachIndexed { i, name ->
                val sel = style == i
                val fg = if (sel) Color.White else Color(0xFFCBD2E0)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .clip(btn)
                        .background(if (sel) accent.copy(alpha = 0.15f) else S_FIELD)
                        .border(1.dp, if (sel) accent else S_LINE, btn)
                        .focusGlow(btn)
                        .clickable {
                            radius = intArrayOf(4, 14, 22)[i]
                            savePrefs()
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.width(16.dp).height(10.dp).border(1.5.dp, fg, RoundedCornerShape(intArrayOf(0, 3, 5)[i].dp)))
                    Spacer(Modifier.width(6.dp))
                    LTxt(name, 11f, fg, FontWeight.SemiBold)
                }
            }
        }
        return
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Reto", "Padrão", "Suave").forEachIndexed { i, name ->
            val sel = style == i
            val mod = Modifier
                .weight(1f)
                .clip(btn)
                .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
                .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
                .focusGlow(btn)
                .clickable {
                    radius = intArrayOf(4, 14, 22)[i]
                    savePrefs()
                }
            val icon: @Composable () -> Unit = {
                Box(
                    Modifier
                        .width(if (compact) 14.dp else 24.dp)
                        .height(if (compact) 10.dp else 16.dp)
                        .border(2.dp, if (sel) Color.White else S_MUTED, RoundedCornerShape(intArrayOf(2, 6, 8)[i].dp))
                )
            }
            val txtColor = if (sel) Color.White else Color(0xFFCBD2E0)
            if (compact) {
                Row(
                    modifier = mod.padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    icon()
                    Spacer(Modifier.width(6.dp))
                    Text(name, color = txtColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                        lineHeight = 13.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                }
            } else {
                Column(modifier = mod.padding(vertical = vpad), horizontalAlignment = Alignment.CenterHorizontally) {
                    icon()
                    Spacer(Modifier.height(if (vpad < 12.dp) 3.dp else 6.dp))
                    Text(name, color = txtColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                        lineHeight = 16.sp, style = TextStyle(lineHeightStyle = CenteredLine))
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.ColorsCard(accent: Color, land: Boolean, modifier: Modifier = Modifier) {
    SCard(modifier, if (land) 12.dp else 14.dp) {
        val colorName = ACCENTS.firstOrNull { it.second.equals(accentHex, true) }?.first ?: "Personalizada"
        if (land) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                LTxt("COR DA BORDA & LED", 10.5f, S_MUTED, FontWeight.Bold, 0.8f, Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .height(24.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.15f))
                        .border(1.dp, accent, CircleShape)
                        .padding(horizontal = 11.dp),
                    contentAlignment = Alignment.Center
                ) { LTxt(colorName, 11f, accent, FontWeight.Bold) }
            }
            Spacer(Modifier.height(3.dp))
            LTxt("Destaque dinâmico da interface", 10f, S_MUTED)
        } else {
            // O nome da cor fica colado ao título, assim a descrição nunca quebra de linha.
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SLabel("COR DA BORDA & LED")
                    Spacer(Modifier.width(10.dp))
                    SChip(colorName, accent)
                }
                Spacer(Modifier.height(4.dp))
                Text("Destaque dinâmico da interface", color = S_MUTED, fontSize = 12.sp, maxLines = 1, softWrap = false)
            }
        }
        if (land) {
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                // Cinco colunas iguais; o tamanho segue a altura disponível (no máximo 36dp).
                val sw = minOf(36.dp, (maxHeight - 10.dp) / 2, maxWidth / 5)
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                    ACCENTS.chunked(5).forEach { rowItems ->
                        Row(Modifier.fillMaxWidth()) {
                            rowItems.forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Swatch(it.second, sw, tight = true) } }
                        }
                    }
                }
            }
        } else {
            Spacer(Modifier.height(10.dp))
            ACCENTS.chunked(5).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    rowItems.forEach { Swatch(it.second) }
                }
            }
        }
    }
}

@Composable
internal fun MainActivity.CameraCard(sub: String, compact: Boolean, modifier: Modifier = Modifier) {
    val accent = parseColor(accentHex)
    val card = RoundedCornerShape(rCard.dp)
    val btn = RoundedCornerShape(rBtn.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(card)
            .background(S_CARD)
            .border(1.dp, S_LINE, card)
            .focusGlow(card)
            .clickable {
                cutoutPad = !cutoutPad
                savePrefs()
            }
            .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 6.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(if (compact) 30.dp else 44.dp).clip(btn).background(S_FIELD).border(1.dp, S_LINE, btn),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "📷", fontSize = if (compact) 14.sp else 19.sp,
                lineHeight = if (compact) 16.sp else 24.sp, style = TextStyle(lineHeightStyle = CenteredLine)
            )
        }
        Spacer(Modifier.width(if (compact) 10.dp else 12.dp))
        if (compact) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                LTxt("Recuar área da câmera", 11.5f, Color.White, FontWeight.Bold)
                LTxt(sub, 9.5f, S_MUTED)
            }
            Spacer(Modifier.width(10.dp))
            // Chave 40x20, como no desenho de referência.
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(20.dp)
                    .clip(CircleShape)
                    .background(if (cutoutPad) accent else Color(0xFF242C3D))
                    .padding(2.dp),
                contentAlignment = if (cutoutPad) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Box(
                    Modifier.size(16.dp).clip(CircleShape)
                        .background(if (cutoutPad) Color.White else Color(0xFF94A3B8))
                )
            }
        } else {
            Column(Modifier.weight(1f)) {
                Text("Recuar área da câmera", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2)
                Text(sub, color = S_MUTED, fontSize = 12.sp, maxLines = 2)
            }
            Spacer(Modifier.width(12.dp))
            SSwitch(cutoutPad, accent)
        }
    }
}

/** 4.9.3: três tamanhos de capa para a grade (pequenas, médias, grandes), cada um com a quantidade por linha. */
@Composable
internal fun MainActivity.GridSizeOptions(accent: Color, land: Boolean) {
    val btn = RoundedCornerShape(rBtn.dp)
    val names = listOf("Pequenas", "Médias", "Grandes")
    // 4.9.4: só o nome, centralizado (a quantidade por linha já aparece no título, na cor de destaque).
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0..2) {
            val sel = gridSize == i
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(if (land) 40.dp else 52.dp)
                    .clip(btn)
                    .background(if (sel) accent.copy(alpha = 0.15f) else S_FIELD)
                    .border(1.dp, if (sel) accent else S_LINE, btn)
                    .focusGlow(btn)
                    .clickable {
                        gridSize = i
                        savePrefs()
                    }
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    names[i], color = if (sel) Color.White else Color(0xFFCBD2E0), fontSize = if (land) 12.sp else 14.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
                    style = TextStyle(lineHeightStyle = CenteredLine)
                )
            }
        }
    }
}

@Composable
internal fun MainActivity.DashOption(label: String, mode: Int, glyph: String?, accent: Color, modifier: Modifier, land: Boolean = false) {
    val btn = RoundedCornerShape(rBtn.dp)
    val sel = dashMode == mode
    val pick = {
        if (dashMode != mode) {
            dashMode = mode
            dashPlatform = ""
            selectedId = firstNavId()
            savePrefs()
        }
    }
    if (land) {
        Row(
            modifier = modifier
                .height(36.dp)
                .clip(btn)
                .background(if (sel) accent.copy(alpha = 0.15f) else S_FIELD)
                .border(1.dp, if (sel) accent else S_LINE, btn)
                .focusGlow(btn)
                .initialFocus(sel)
                .clickable { pick() }
                .padding(horizontal = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LTxt(label, 11.5f, if (sel) Color.White else Color(0xFFCBD2E0), FontWeight.Medium, 0f, Modifier.weight(1f))
            if (sel) Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
        }
        return
    }
    Row(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(btn)
            .background(if (sel) accent.copy(alpha = 0.14f) else S_FIELD)
            .border(1.dp, if (sel) accent.copy(alpha = 0.6f) else S_LINE, btn)
            .focusGlow(btn)
            .initialFocus(sel)
            .clickable { pick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph != null) {
            Text(glyph, color = if (sel) accent else S_MUTED, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            label, color = if (sel) Color.White else Color(0xFFCBD2E0), fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
            modifier = Modifier.weight(1f)
        )
        if (sel) {
            Spacer(Modifier.width(4.dp))
            Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
        }
    }
}

@Composable
internal fun MainActivity.SgdbCard(accent: Color, modifier: Modifier = Modifier, compact: Boolean = false) {
    SCard(modifier, if (compact) 10.dp else 14.dp) {
        if (compact) {
            SLabel("STEAMGRIDDB (CAPAS E DADOS)", compact = true)
            Spacer(Modifier.height(6.dp))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(sgdbKey, { v ->
                sgdbKey = v.trim()
                prefs.edit().putString("sgdbKey", sgdbKey).apply()
            }, "Cole sua chave aqui", Modifier.weight(1f), mic = false)
            // 4.7.1: o "Colar" fica FORA da caixa (o D-pad da TV alcança sem abrir o teclado).
            CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                val t = clipboardText().trim()
                if (t.isEmpty()) toast("Nada copiado para colar") else {
                    sgdbKey = t
                    prefs.edit().putString("sgdbKey", sgdbKey).apply()
                    toast("Chave colada")
                }
            }
            CButton("Testar", C_BLUE, Modifier.width(76.dp)) { testSgdbKey() }
        }
        Text(
            "Criar chave grátis (steamgriddb.com)", color = accent, fontSize = 12.sp,
            textDecoration = TextDecoration.Underline,
            modifier = Modifier
                .clickable { openUrl("https://www.steamgriddb.com/profile/preferences/api") }
                .padding(top = 6.dp)
        )
        // 4.7.0: crédito movido da tela de detalhes para cá.
        Text(
            "Capas e dados dos jogos: SteamGridDB (steamgriddb.com)", color = S_MUTED, fontSize = if (compact) 10.sp else 11.sp,
            textDecoration = TextDecoration.Underline,
            modifier = Modifier
                .clickable { openUrl("https://www.steamgriddb.com") }
                .padding(top = 4.dp)
        )
    }
}

// 4.7.0: chave da API do YouTube. O "Colar" fica FORA da caixa para o D-pad alcançar sem abrir o teclado.
@Composable
internal fun MainActivity.YouTubeCard(accent: Color, modifier: Modifier = Modifier, compact: Boolean = false) {
    SCard(modifier, if (compact) 10.dp else 14.dp) {
        if (compact) {
            SLabel("YOUTUBE (VÍDEO GAMEPLAY)", compact = true)
            Spacer(Modifier.height(6.dp))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CField(ytKey, { v ->
                ytKey = v.trim()
                prefs.edit().putString("ytKey", ytKey).apply()
            }, "Cole sua chave aqui", Modifier.weight(1f), mic = false)
            CButton("Colar", C_ORANGE, Modifier.width(64.dp)) {
                val t = clipboardText().trim()
                if (t.isEmpty()) toast("Nada copiado para colar") else {
                    ytKey = t
                    prefs.edit().putString("ytKey", ytKey).apply()
                    toast("Chave colada")
                }
            }
            CButton("Testar", C_BLUE, Modifier.width(76.dp)) { testYtKey() }
        }
        Text(
            "Criar chave grátis (Google Cloud › YouTube Data API v3)", color = accent, fontSize = if (compact) 11.sp else 12.sp,
            textDecoration = TextDecoration.Underline,
            modifier = Modifier
                .clickable { openUrl("https://console.cloud.google.com/apis/library/youtube.googleapis.com") }
                .padding(top = 6.dp)
        )
        Text(
            "Cada jogo faz 1 busca (a 1ª vez que abre os detalhes). Cota grátis: ~100 buscas por dia.",
            color = S_MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp)
        )
    }
}

// ----- Retrato: tudo cabe na tela, sem rolagem e sem texto cortado -----
@Composable
internal fun MainActivity.TabVisual(accent: Color) {
    SCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SLabel("TELA INICIAL", modifier = Modifier.weight(1f))
            Text(if (dashMode == 1) "Plataformas" else "Todos os Jogos", color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DashOption("Plataformas", 1, null, accent, Modifier.weight(1f))
            DashOption("Todos os Jogos", 0, null, accent, Modifier.weight(1f))
        }
    }
    SCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SLabel("ESTILO DAS BORDAS", modifier = Modifier.weight(1f))
            Text(listOf("Reto", "Padrão", "Suave")[styleIdx], color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))
        CornerOptions(false)
    }
    // 4.9.3: no celular em pé as capas ficam em grade; escolha quantas por linha (3 tamanhos pela largura da tela).
    SCard {
        val sw = LocalConfiguration.current.screenWidthDp.toFloat()
        Row(verticalAlignment = Alignment.CenterVertically) {
            SLabel("CAPAS POR LINHA", modifier = Modifier.weight(1f))
            Text("${gridColsFor(sw, gridSize, inPlatformList())} por linha", color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(10.dp))
        GridSizeOptions(accent, false)
    }
    ColorsCard(accent, false)
    if (!TvMode.isTv) CameraCard("Evita corte pelo furo frontal", false)
}

@Composable
internal fun MainActivity.TabLibrary(accent: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CatalogTile("🎮", "Apps de jogos", "Escolha o que é jogo", allApps.count { it.pkg !in hiddenGameApps }, Modifier.weight(1f)) { appFilterKind = 1 }
        CatalogTile("🧩", "Apps emuladores", "Escolha o que é emulador", allApps.count { it.pkg !in hiddenEmuApps }, Modifier.weight(1f)) { appFilterKind = 2 }
    }
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        SLabel("GERENCIAR CATÁLOGO", modifier = Modifier.weight(1f))
        Text("Toque para editar", color = S_MUTED, fontSize = 12.sp)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f).returnFocus("gen")) { returnKey = "gen"; overlay = Overlay.Genres }
        CatalogTile("▣", "Coleções", "${userCollectionCount()} criadas", userCollectionCount(), Modifier.weight(1f).returnFocus("col")) { returnKey = "col"; overlay = Overlay.Collections }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CatalogTile("🖼", "Capas em lote", "SteamGridDB", coverMissingCount(), Modifier.weight(1f).returnFocus("cov")) { returnKey = "cov"; overlay = Overlay.CoverBatchSetup }
        CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f).returnFocus("emu")) { returnKey = "emu"; overlay = Overlay.Platforms }
    }
    Text(
        "Total de jogos no catálogo: ${games.size}", color = S_MUTED, fontSize = 12.sp,
        modifier = Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, bottom = 10.dp), textAlign = TextAlign.Center
    )
}

@Composable
internal fun MainActivity.TabSystem(accent: Color) {
    val soft = accent.copy(alpha = 0.14f)
    val edge = accent.copy(alpha = 0.45f)
    val danger = Color(0xFFFF5A72)
    SLabel("BACKUP & RESTAURAÇÃO", modifier = Modifier.padding(horizontal = 2.dp))
    ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
        bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent)) { doExport() }
    ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
        bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { doImport() }
    SLabel("CONTROLE", modifier = Modifier.padding(horizontal = 2.dp))
    ActionRow("🎮", "Testar controle", "Mostra o que o controle manda (botões, setas, gatilhos)",
        bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
        modifier = Modifier.returnFocus("pad")) { openPadTest() }
    SLabel("STEAMGRIDDB (CAPAS E DADOS DOS JOGOS)", modifier = Modifier.padding(horizontal = 2.dp))
    SgdbCard(accent)
    SLabel("YOUTUBE (VÍDEO GAMEPLAY)", modifier = Modifier.padding(horizontal = 2.dp))
    YouTubeCard(accent)
    SLabel("ZONA DE PERIGO", color = danger, modifier = Modifier.padding(horizontal = 2.dp))
    ActionRow("🗑", "Resetar Jogos", "Apaga os jogos da tela inicial (todos ou por plataforma). Mantém vínculos, apps, gêneros, coleções e chaves de API",
        bg = Color(0x1AFF375F), border = Color(0x66FF375F), iconBg = Color(0x33FF375F), iconFg = danger,
        titleColor = danger, chevron = false, modifier = Modifier.returnFocus("rst")) { returnKey = "rst"; overlay = Overlay.ResetGames }
    ActionRow("⚠", "Restaurar configurações de fábrica", "Apaga TUDO: jogos, configurações, vínculos e chaves de API. O Nexus reinicia",
        bg = Color(0x1AFF375F), border = Color(0x66FF375F), iconBg = Color(0x33FF375F), iconFg = danger,
        titleColor = danger, chevron = false, modifier = Modifier.returnFocus("fac")) { returnKey = "fac"; overlay = Overlay.ConfirmFactory }
}

@Composable
internal fun MainActivity.TabExtras(accent: Color) {
    val soft = accent.copy(alpha = 0.14f)
    val edge = accent.copy(alpha = 0.45f)
    SLabel("VISUAL", modifier = Modifier.padding(horizontal = 2.dp))
    // 4.7.7: o carrossel agora é escolhido pelo olho do cabeçalho (celular deitado e TV).
    SwitchCard("✨", "Animação de abertura", "Desligue para o app abrir mais rápido", introOn, false) { applyIntroOn(!introOn) }
    if (animCoversSupported) {
        SwitchCard("🎞", "Animar capas escolhidas", "Só a capa em foco e os Detalhes", animCovers, false) { applyAnimCovers(!animCovers) }
    }
    if (!TvMode.isRealTv) {
        SwitchCard("📺", "Modo TV", "Para controle remoto. Reabra o Nexus", TvMode.isForced, false) {
            TvMode.setForced(this@TabExtras, !TvMode.isForced)
        }
    }
    // 4.9.3: a Fire TV não informa a temperatura nem aceita painel flutuante, então esta parte some por lá.
    if (!TvMode.isFireTv) {
        SLabel("PAINEL FLUTUANTE", modifier = Modifier.padding(horizontal = 2.dp))
        SwitchCard("📌", "Temperatura sobre qualquer app",
            if (TvMode.isTv) "Painel com a temperatura do aparelho" else "Painel arrastável com temperatura e bateria",
            FloatState.on, false) { toggleFloat() }
        SwitchCard("📏", "Painel flutuante menor", if (FloatState.on) "Painel compacto, ainda legível" else "Ligue o painel flutuante para usar",
            floatSmall, false, enabled = FloatState.on) { applyFloatSmall(!floatSmall) }
        Text(
            if (TvMode.isTv) "Também liga e desliga pela temperatura no cabeçalho. Avisa quando o aparelho esquenta demais."
            else "Também liga e desliga tocando na temperatura/bateria do cabeçalho. Sobre outros apps: toque no painel para diminuir ou aumentar; segure e arraste até o X para fechar. Avisa e vibra quando o aparelho esquenta demais.",
            color = S_MUTED, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
    // TV: launcher padrão, apps ocultos e configurações do Android são coisas de celular e ficam escondidos.
    if (!TvMode.isTv) SLabel("LAUNCHER", modifier = Modifier.padding(horizontal = 2.dp))
    if (TvMode.isTv) {
        // sem opções de launcher na TV
    } else if (!isHome) {
        ActionRow("⌂", "Definir como launcher padrão", "Use o Nexus como tela inicial do aparelho",
            bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent)) { askDefaultLauncher() }
        Text(
            "Com o Nexus como launcher padrão, aparecem aqui os apps ocultos e o acesso às configurações do Android.",
            color = S_MUTED, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp)
        )
    } else {
        ActionRow("⌂", "Launcher padrão ativo", "O Nexus é a tela inicial do aparelho",
            bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent), chevron = false) { }
        SLabel("MODO LAUNCHER", modifier = Modifier.padding(horizontal = 2.dp))
        ActionRow("▦", "Apps ocultos", "Apps que você ocultou da gaveta",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { hiddenAppsOpen = true }
        ActionRow("⚙", "Configurações do Android", "Abre as configurações originais do aparelho",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { openSystemSettings() }
        ActionRow("⇄", "Trocar launcher padrão", "Escolher outro launcher do aparelho",
            bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent) { openHomeSettings() }
    }
}

@Composable
internal fun MainActivity.TabExtrasL(accent: Color) {
    val soft = accent.copy(alpha = 0.14f)
    val edge = accent.copy(alpha = 0.45f)
    // Cada coluna rola se precisar; nenhum cartão é espremido: todos têm altura própria.
    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SwitchCard("✨", "Animação de abertura", "Desligue para abrir mais rápido", introOn, true, Modifier.height(54.dp)) { applyIntroOn(!introOn) }
            if (animCoversSupported) {
                SwitchCard("🎞", "Animar capas escolhidas", "Só a capa em foco e os Detalhes", animCovers, true, Modifier.height(54.dp)) { applyAnimCovers(!animCovers) }
            }
            if (!TvMode.isFireTv) {
                SwitchCard("📌", "Painel flutuante", "Temperatura sobre qualquer app", FloatState.on, true, Modifier.height(54.dp)) { toggleFloat() }
                // "Painel flutuante menor" fica SEMPRE logo abaixo de "Painel flutuante", aconteça o que acontecer.
                SwitchCard("📏", "Painel flutuante menor", if (FloatState.on) "Painel compacto, ainda legível" else "Ligue o painel flutuante",
                    floatSmall, true, Modifier.height(54.dp), enabled = FloatState.on) { applyFloatSmall(!floatSmall) }
            }
            if (!TvMode.isRealTv) {
                SwitchCard("📺", "Modo TV", "Controle remoto. Reabra o Nexus", TvMode.isForced, true, Modifier.height(54.dp)) {
                    TvMode.setForced(this@TabExtrasL, !TvMode.isForced)
                }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (TvMode.isTv) {
                // sem opções de launcher na TV
            } else if (!isHome) {
                ActionRow("⌂", "Definir como launcher padrão", "Use o Nexus como tela inicial do aparelho",
                    bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent),
                    modifier = Modifier.height(60.dp), compact = true) { askDefaultLauncher() }
                Text(
                    "Com o Nexus como launcher padrão, aparecem aqui os apps ocultos e o acesso às configurações do Android.",
                    color = S_MUTED, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp)
                )
            } else {
                ActionRow("⌂", "Launcher padrão ativo", "O Nexus é a tela inicial do aparelho",
                    bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent), chevron = false,
                    modifier = Modifier.height(54.dp), compact = true) { }
                ActionRow("▦", "Apps ocultos", "Apps que você ocultou da gaveta",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.height(54.dp), compact = true) { hiddenAppsOpen = true }
                ActionRow("⚙", "Configurações do Android", "Abre as configurações originais do aparelho",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.height(54.dp), compact = true) { openSystemSettings() }
                ActionRow("⇄", "Trocar launcher padrão", "Escolher outro launcher do aparelho",
                    bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                    modifier = Modifier.height(54.dp), compact = true) { openHomeSettings() }
            }
        }
    }
}

// ----- Paisagem: layout em duas colunas, igual ao protótipo, sem rolagem -----
@Composable
internal fun MainActivity.TabVisualL(accent: Color) {
    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            LCard(Modifier.weight(1f)) {
                LHead("TELA INICIAL", if (dashMode == 1) "Plataformas" else "Todos os Jogos", accent)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DashOption("Plataformas", 1, null, accent, Modifier.weight(1f), land = true)
                    DashOption("Todos os Jogos", 0, null, accent, Modifier.weight(1f), land = true)
                }
            }
            LCard(Modifier.weight(1f)) {
                LHead("ESTILO DAS BORDAS", listOf("Reto", "Padrão", "Suave")[styleIdx], accent)
                Spacer(Modifier.height(6.dp))
                CornerOptions(false, land = true)
            }
            LCard(Modifier.weight(1f)) {
                if (tvGridOn) {
                    // 4.9.3: grade — 3 tamanhos, calculados pela largura da tela (capas por linha).
                    val sw = LocalConfiguration.current.screenWidthDp.toFloat()
                    LHead("CAPAS POR LINHA", "${gridColsFor(sw, gridSize, inPlatformList())} por linha", accent)
                    Spacer(Modifier.height(6.dp))
                    GridSizeOptions(accent, true)
                } else if (tvListOn) {
                    // 4.9.3: lista — a linha cresce/diminui na vertical (a capa acompanha); a largura não muda.
                    LHead("ALTURA DA LINHA", "${listRowH}px", accent)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LTxt("${LIST_ROW_MIN_DP}px", 10f, S_MUTED, FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        LSlider(
                            value = listRowH, lo = LIST_ROW_MIN_DP, hi = LIST_ROW_MAX_DP, accent = accent,
                            onChange = { v -> listRowH = v },
                            onDone = { savePrefs() },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        LTxt("${LIST_ROW_MAX_DP}px", 10f, S_MUTED, FontWeight.SemiBold)
                    }
                } else {
                    LHead("TAMANHO DAS CAPAS", "${widthL}px", accent)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LTxt("110px", 10f, S_MUTED, FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        LSlider(
                            value = widthL, lo = 110, hi = 260, accent = accent,
                            onChange = { v -> widthL = v },
                            onDone = { savePrefs() },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        LTxt("260px", 10f, S_MUTED, FontWeight.SemiBold)
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            ColorsCard(accent, true, Modifier.weight(1f))
            if (!TvMode.isTv) CameraCard("Evita corte pelo furo frontal", true, Modifier.height(52.dp))
        }
    }
}

@Composable
internal fun MainActivity.TabLibraryL(accent: Color) {
    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(5f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            CatalogTile("🎮", "Apps de jogos", "Escolha o que é jogo", allApps.count { it.pkg !in hiddenGameApps }, Modifier.weight(1f).fillMaxWidth(), true) { appFilterKind = 1 }
            CatalogTile("🧩", "Apps emuladores", "Escolha o que é emulador", allApps.count { it.pkg !in hiddenEmuApps }, Modifier.weight(1f).fillMaxWidth(), true) { appFilterKind = 2 }
        }
        Column(Modifier.weight(7f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CatalogTile("◈", "Gêneros", "${genres.size} cadastrados", genres.size, Modifier.weight(1f).fillMaxHeight().returnFocus("gen"), true) { returnKey = "gen"; overlay = Overlay.Genres }
                CatalogTile("▣", "Coleções", "${userCollectionCount()} criadas", userCollectionCount(), Modifier.weight(1f).fillMaxHeight().returnFocus("col"), true) { returnKey = "col"; overlay = Overlay.Collections }
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CatalogTile("🖼", "Capas em lote", "SteamGridDB", coverMissingCount(), Modifier.weight(1f).fillMaxHeight().returnFocus("cov"), true) { returnKey = "cov"; overlay = Overlay.CoverBatchSetup }
                CatalogTile("⇄", "Emuladores", "${links.size} vínculos", links.size, Modifier.weight(1f).fillMaxHeight().returnFocus("emu"), true) { returnKey = "emu"; overlay = Overlay.Platforms }
            }
            Text(
                "Total de jogos no catálogo: ${games.size}", color = S_MUTED, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
internal fun MainActivity.TabSystemL(accent: Color) {
    val soft = accent.copy(alpha = 0.14f)
    val edge = accent.copy(alpha = 0.45f)
    val danger = Color(0xFFFF5A72)
    val shape = RoundedCornerShape(rCard.dp)
    // 4.7.8: coluna da esquerda: backup, SteamGridDB e (embaixo dele) YouTube; coluna da direita: zona de perigo.
    // Alturas naturais: a aba inteira rola na vertical quando não cabe.
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(7f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionRow("⤒", "Exportar backup", "Salvar biblioteca, configurações e vínculos",
                bg = soft, border = edge, iconBg = accent, iconFg = onAccent(accent),
                modifier = Modifier.height(58.dp), compact = true) { doExport() }
            ActionRow("⤓", "Importar backup", "Restaurar arquivo .json",
                bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                modifier = Modifier.height(58.dp), compact = true) { doImport() }
            ActionRow("🎮", "Testar controle", "Mostra o que o controle manda (botões, setas, gatilhos)",
                bg = S_CARD, border = S_LINE, iconBg = soft, iconFg = accent,
                modifier = Modifier.height(58.dp).returnFocus("pad"), compact = true) { openPadTest() }
            SgdbCard(accent, compact = true)
            YouTubeCard(accent, compact = true)
        }
        Column(Modifier.weight(5f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Color(0x1AFF375F))
                    .border(1.dp, Color(0x66FF375F), shape)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("\u26A0\uFE0E", color = danger, fontSize = 13.sp)
                    Spacer(Modifier.width(6.dp))
                    SLabel("ZONA DE PERIGO", danger, compact = true)
                }
                Column {
                    Text("Resetar Jogos", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Apaga os jogos da tela inicial, todos ou de uma plataforma. Mantém vínculos, apps de jogos e emuladores, gêneros, coleções e chaves de API.",
                        color = Color(0xB3FFC9D1), fontSize = 10.sp
                    )
                }
                DangerButton("Resetar Jogos", Color(0xE6E11D48), "rst") { returnKey = "rst"; overlay = Overlay.ResetGames }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x33FF375F)))
                Column {
                    Text("Restaurar configurações de fábrica", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Apaga TUDO: jogos, configurações, vínculos, gêneros, coleções e chaves de API. O Nexus reinicia. Seus arquivos de ROM não são apagados.",
                        color = Color(0xB3FFC9D1), fontSize = 10.sp
                    )
                }
                DangerButton("Restaurar de fábrica", Color(0xFF9F1239), "fac") { returnKey = "fac"; overlay = Overlay.ConfirmFactory }
            }
        }
    }
}

/**
 * 4.9.19: faixa fina no topo das Configurações, só enquanto o Nexus é launcher padrão "de passagem" (fluxo de recriar atalho):
 * diz isso e leva direto a devolver o launcher anterior. Quem escolheu o Nexus como launcher pelas Extras nunca vê a faixa.
 */
@Composable
internal fun MainActivity.LauncherTempBanner() {
    if (!tempLauncher || !isHome || TvMode.isTv) return
    val shape = RoundedCornerShape(rBtn.dp)
    val prev = prevLauncherName()
    Row(
        modifier = Modifier.fillMaxWidth().background(C_ORANGE.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(16.dp).clip(RoundedCornerShape(8.dp)).background(C_ORANGE), contentAlignment = Alignment.Center) {
            Text("!", color = Color(0xFF1A1200), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 11.sp,
                style = TextStyle(lineHeightStyle = CenteredLine))
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "O Nexus é o launcher padrão", color = Color(0xFFFFE2B0), fontSize = 12.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(shape)
                .background(C_ORANGE)
                .focusGlow(shape)
                .clickable { backToPreviousLauncher() }
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Text(
                if (prev.isNotEmpty()) "Voltar ao $prev" else "Voltar ao launcher anterior",
                color = Color(0xFF1A1200), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
}

@Composable
internal fun MainActivity.SettingsLandscape(accent: Color) {
    val panel = RoundedCornerShape(rPanel.dp)
    val btn = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .then(if (cutoutPad) Modifier.windowInsetsPadding(WindowInsets.displayCutout) else Modifier)
            .padding(start = 22.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                .clip(panel)
                .background(S_PANEL)
                .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
        ) {
            // Cabeçalho compacto: título à esquerda, abas e fechar à direita
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(btn)
                        .background(accent.copy(alpha = 0.14f))
                        .border(1.dp, accent.copy(alpha = 0.45f), btn),
                    contentAlignment = Alignment.Center
                ) { Text("\u2699\uFE0E", color = accent, fontSize = 16.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    LTxt("Configurações do Nexus", 14f, Color.White, FontWeight.Bold)
                    Spacer(Modifier.height(3.dp))
                    LTxt("Frontend & Launcher • v$APP_VERSION", 10f, S_MUTED, FontWeight.Medium)
                }
                AboutButton(accent, 32)
                Spacer(Modifier.width(10.dp))
                SettingsTabs(accent, true)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
            LauncherTempBanner() // 4.9.19

            // 4.7.7: a paisagem também rola na vertical. Cada aba tem uma altura mínima (a que ela precisa para
            // não espremer os cartões); se a janela for mais baixa que isso, o conteúdo rola.
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth().padding(10.dp)) {
                val avail = maxHeight
                val minH = if (settingsTab == 2) 340.dp else 270.dp
                key(settingsTab) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        // Aba Sistema: altura natural (rola se passar da janela); as outras ocupam a janela.
                        Box(Modifier.fillMaxWidth().then(if (settingsTab == 2) Modifier else Modifier.height(if (avail > minH) avail else minH))) {
                            when (settingsTab) {
                                0 -> TabVisualL(accent)
                                1 -> TabLibraryL(accent)
                                2 -> TabSystemL(accent)
                                else -> TabExtrasL(accent)
                            }
                        }
                    }
                }
            }

            // Rodapé central: L1/R1 Abas, A Selecionar, B Voltar
            Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xF20E1017))
                    .padding(horizontal = 16.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LRHint()
                Spacer(Modifier.width(14.dp))
                PadHint("A", "Selecionar", S_PAD_A, compact = true, onClick = null)
                Spacer(Modifier.width(14.dp))
                PadHint("B", "Voltar", S_PAD_B, compact = true) { popOverlay() }
            }
        }
    }
}

@Composable
internal fun MainActivity.SettingsPortrait(accent: Color) {
    val panel = RoundedCornerShape(rPanel.dp)
    val btn = RoundedCornerShape(rBtn.dp)
    Box(
        modifier = Modifier.fillMaxSize().imePadding().padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.95f)
                .shadow(18.dp, panel, ambientColor = accent, spotColor = accent)
                .clip(panel)
                .background(S_PANEL)
                .border(1.5.dp, accent.copy(alpha = 0.75f), panel)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(btn)
                            .background(accent.copy(alpha = 0.14f))
                            .border(1.dp, accent.copy(alpha = 0.45f), btn),
                        contentAlignment = Alignment.Center
                    ) { Text("\u2699\uFE0E", color = accent, fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Configurações do Nexus", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Frontend & Launcher • v$APP_VERSION", color = S_MUTED, fontSize = 12.sp)
                    }
                    AboutButton(accent, 40)
                }
                Spacer(Modifier.height(10.dp))
                SettingsTabs(accent, false)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
            LauncherTempBanner() // 4.9.19

            // Cabe inteiro na tela. A rolagem só existiria como rede de segurança em telas muito baixas.
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(if (settingsTab == 2) 8.dp else 12.dp)
            ) {
                when (settingsTab) {
                    0 -> TabVisual(accent)
                    1 -> TabLibrary(accent)
                    2 -> TabSystem(accent)
                    else -> TabExtras(accent)
                }
            }

            Box(Modifier.fillMaxWidth().height(1.dp).background(S_LINE))
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PadHint("A", "Selecionar", S_PAD_A, onClick = null)
                Spacer(Modifier.width(20.dp))
                PadHint("B", "Voltar", S_PAD_B) { popOverlay() }
            }
        }
    }
}

@Composable
internal fun MainActivity.SettingsDialog() {
    val accent = parseColor(accentHex)
    Dialog(
        onDismissRequest = { popOverlay() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        HideBarsInDialog(settings = true)
        if (landscape) {
            // Na paisagem a janela ocupa a tela toda, inclusive sob o furo da câmera,
            // e o "Recuar área da câmera" afasta a borda esquerda na hora.
            val view = LocalView.current
            SideEffect {
                val w = (view.parent as? DialogWindowProvider)?.window
                if (w != null) {
                    val lp = w.attributes
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    w.attributes = lp
                }
            }
            SettingsLandscape(accent)
        } else {
            SettingsPortrait(accent)
        }
    }
}
