package com.nexus.launcher

import android.content.Context
import org.json.JSONArray

/**
 * Catálogo de plataformas e emuladores importado do Daijishō (pasta "platforms" do GitHub).
 * Os dados ficam em assets/daijisho_platforms.json (122 plataformas, 1.023 emuladores).
 */
class DjPlayer(
    val name: String,
    val id: String,
    val pkg: String,
    /** Comando de abertura no formato do Daijishō (uma linha). */
    val args: String,
    /** Extensões de ROM aceitas pelo emulador (minúsculas). */
    val exts: List<String>,
    /** O Daijishō fecha o app do emulador antes de abrir o jogo. */
    val kill: Boolean
) {
    /** Comando no formato do Nexus; "--nexus-kill" fecha o emulador antes de abrir. */
    val template: String get() = if (kill) "$args --nexus-kill" else args
}

class DjPlatform(
    val id: String,
    val name: String,
    val manufacturer: String,
    val players: List<DjPlayer>
)

/** Plataformas embutidas do Nexus -> id da plataforma equivalente no Daijishō. */
val DJ_ID_BY_BUILTIN: Map<String, String> = mapOf(
    "PlayStation 1" to "psx",
    "PlayStation 2" to "ps2",
    "PSP" to "psp",
    "PS Vita" to "vita",
    "Super Nintendo" to "snes",
    "Nintendo 64" to "n64",
    "GameCube" to "gc",
    "Wii" to "wii",
    "Nintendo Wii U" to "wiiu",
    "Nintendo Switch" to "switch",
    "Game Boy Advance" to "gba",
    "Nintendo DS" to "nds",
    "Nintendo 3DS" to "3ds",
    "Xbox Clássico" to "xbox",
    "Xbox 360" to "xbox360",
    "PC" to "windows",
    "Sega Mega Drive" to "genesis",
    "Sega Saturn" to "saturn"
)

object Daijisho {
    @Volatile
    private var cache: List<DjPlatform>? = null

    fun all(ctx: Context): List<DjPlatform> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val list = try {
                val text = ctx.applicationContext.assets.open("daijisho_platforms.json")
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                parse(text)
            } catch (_: Exception) {
                emptyList()
            }
            cache = list
            return list
        }
    }

    private fun parse(json: String): List<DjPlatform> {
        val arr = JSONArray(json)
        val out = ArrayList<DjPlatform>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val pa = o.optJSONArray("pl") ?: JSONArray()
            val players = ArrayList<DjPlayer>(pa.length())
            for (k in 0 until pa.length()) {
                val p = pa.getJSONObject(k)
                players.add(
                    DjPlayer(
                        name = p.optString("n"),
                        id = p.optString("id"),
                        pkg = p.optString("p"),
                        args = p.optString("a"),
                        exts = p.optString("x").split(",").map { it.trim() }.filter { it.isNotEmpty() },
                        kill = p.optInt("k", 0) == 1
                    )
                )
            }
            out.add(DjPlatform(o.optString("id"), o.optString("name"), o.optString("m"), players))
        }
        return out
    }

    /** Plataforma do catálogo equivalente a uma plataforma do Nexus (chave = nome base/embutido). */
    fun forPlatform(ctx: Context, key: String): DjPlatform? {
        val list = all(ctx)
        val id = DJ_ID_BY_BUILTIN[key]
        if (id != null) return list.firstOrNull { it.id == id }
        return list.firstOrNull { it.name.equals(key, ignoreCase = true) }
    }
}
