plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nexus.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexus.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 40008
        versionName = "4.0.7"
    }

    // Assinatura fixa: sem ela, cada build no GitHub gera uma chave nova e o Android
    // não deixa atualizar por cima do app já instalado (pedindo para desinstalar).
    signingConfigs {
        create("nexus") {
            storeFile = file("nexus.keystore")
            storePassword = "nexus123"
            keyAlias = "nexus"
            keyPassword = "nexus123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("nexus")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("nexus")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
