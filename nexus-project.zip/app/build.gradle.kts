plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nexus.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexus.launcher"
        minSdk = 26
        targetSdk = 34
        versionCode = 49800
        versionName = "4.9.8"
    }

    // 4.9.8: a chave de assinatura NÃO fica mais dentro do projeto (o repositório é público).
    // O GitHub Actions entrega a chave pelas variáveis de ambiente NEXUS_KEYSTORE_PATH e NEXUS_KEY_PASSWORD
    // (vindas dos Secrets do repositório). Assinatura fixa é o que permite atualizar o app por cima do instalado.
    // Sem essas variáveis (build local), o Android usa a chave de depuração padrão e o build continua funcionando.
    val nexusKeystorePath: String? = System.getenv("NEXUS_KEYSTORE_PATH")
    val nexusKeyPassword: String? = System.getenv("NEXUS_KEY_PASSWORD")
    val hasNexusKey = !nexusKeystorePath.isNullOrBlank() && !nexusKeyPassword.isNullOrBlank() &&
        file(nexusKeystorePath).exists()

    signingConfigs {
        if (hasNexusKey) {
            create("nexus") {
                storeFile = file(nexusKeystorePath!!)
                storePassword = nexusKeyPassword
                keyAlias = "nexus"
                keyPassword = nexusKeyPassword
                storeType = "pkcs12"
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (hasNexusKey) signingConfig = signingConfigs.getByName("nexus")
        }
        getByName("release") {
            if (hasNexusKey) signingConfig = signingConfigs.getByName("nexus")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
