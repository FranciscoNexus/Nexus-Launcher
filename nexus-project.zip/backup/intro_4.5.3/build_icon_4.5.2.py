"""Gera os recursos visuais da 4.5.2 a partir da imagem do novo ícone (1376x768):
 - recolore os controles (esq. azul, dir. vermelho, botões pretos, ABXY nas cores do rodapé)
 - recorta as 9 capas, os 2 controles e o texto NEXUS (para a animação de abertura)
 - monta o ícone adaptativo (foreground) o maior possível dentro da zona segura
Uso: python3 build_icon.py <imagem.jpg> <pasta res/drawable-nodpi> """
import sys, json
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi

SRC, OUT = sys.argv[1], sys.argv[2]
img = np.asarray(Image.open(SRC).convert('RGB')).astype(np.float32)
H, W, _ = img.shape

# ---------- 1) fundo (gradiente horizontal) e máscara do conteúdo ----------
bgcol = np.median(img[5:60], axis=0)                      # cor do fundo por coluna
bgcol = ndi.median_filter(bgcol, size=(15, 1))
bg = np.broadcast_to(bgcol[None], img.shape)
dist = np.linalg.norm(img - bg, axis=2)
alpha = np.clip((dist - 28) / 40.0, 0, 1)
mask = alpha > 0.5
lab, n = ndi.label(ndi.binary_closing(mask, iterations=3))
sizes = ndi.sum(mask, lab, range(1, n + 1))
keep = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s > 3000])
keep = ndi.binary_fill_holes(keep)
alpha = np.where(keep, np.maximum(alpha, 0.0), 0.0)
alpha = np.where(ndi.binary_erosion(keep, iterations=2), 1.0, alpha)     # interior sempre opaco

# ---------- 2) recolor dos controles ----------
BLUE = np.array([38, 112, 238], np.float32)
RED = np.array([226, 34, 42], np.float32)
rgb = img.copy()
lum = rgb.mean(2)
mx, mn = rgb.max(2), rgb.min(2)
sat = (mx - mn) / np.maximum(mx, 1)
def recolor(x0, x1, y0, y1, base):
    reg = np.zeros((H, W), bool); reg[y0:y1, x0:x1] = True
    gray = reg & (sat < 0.22) & (alpha > 0.3)
    body = gray & (lum >= 88)
    dark = gray & (lum < 88)
    for c in range(3):
        ch = rgb[..., c]
        ch[body] = np.clip(base[c] * (lum[body] / 112.0), 0, 255)
        ch[dark] = lum[dark] * 0.42
        rgb[..., c] = ch
L_BOX = (380, 482, 275, 552)
R_BOX = (899, 1000, 275, 552)
recolor(*L_BOX, BLUE)
recolor(*R_BOX, RED)

# ---------- 3) botões de ação (cores do rodapé: A verde, B vermelho, Y amarelo, X azul) ----------
ACT = {'Y': ((942, 330), (255, 214, 10)), 'X': ((922, 351), (10, 132, 255)),
       'B': ((965, 351), (255, 69, 96)), 'A': ((944, 371), (48, 209, 88))}
pil = Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8))
d = ImageDraw.Draw(pil)
S = 4  # supersample
layer = Image.new('RGBA', (W * 1, H * 1), (0, 0, 0, 0))
for k, ((cx, cy), col) in ACT.items():
    r = 11.5
    d.ellipse((cx - r - 1.8, cy - r - 1.8, cx + r + 1.8, cy + r + 1.8), fill=(10, 10, 12))
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col)
    d.ellipse((cx - r * 0.55, cy - r * 0.55, cx + r * 0.55, cy + r * 0.55), fill=tuple(int(c * 0.82) for c in col))
rgb = np.asarray(pil).astype(np.float32)

# ---------- 4) RGBA do conteúdo (remove o fundo: c = (px - (1-a)*bg) / a) ----------
a = alpha[..., None]
fg = np.where(a > 0.02, (rgb - (1 - a) * bg) / np.maximum(a, 0.02), 0)
fg = np.clip(fg, 0, 255)
rgba = np.dstack([fg, alpha * 255]).astype(np.uint8)
full = Image.fromarray(rgba, 'RGBA')

# ---------- 5) círculo mínimo que envolve o conteúdo ----------
ys, xs = np.nonzero(alpha > 0.5)
pts = np.stack([xs, ys], 1).astype(np.float64)
hull_idx = []
from scipy.spatial import ConvexHull
hull = pts[ConvexHull(pts).vertices]
def min_circle(P):
    c = P.mean(0); r = 0
    # método iterativo simples (Badoiu-Clarkson)
    c = P[0].copy()
    for i in range(1, 4000):
        far = P[np.argmax(((P - c) ** 2).sum(1))]
        c = c + (far - c) / (i + 1)
    return c, np.sqrt(((P - c) ** 2).sum(1).max())
(cx0, cy0), R0 = min_circle(hull)
print('círculo do conteúdo (px originais): centro', round(cx0, 1), round(cy0, 1), 'raio', round(R0, 1))

# ---------- 6) foreground adaptativo: 108 dp -> 864 px; raio ocupado = 34 dp (zona segura = 33 dp) ----------
CAN = 864
R_DP = 34.0
k = (R_DP / 108.0 * CAN) / R0           # px do canvas por px original
newW, newH = int(round(W * k)), int(round(H * k))
big = full.resize((newW, newH), Image.LANCZOS)
canvas = Image.new('RGBA', (CAN, CAN), (0, 0, 0, 0))
canvas.alpha_composite(big, (int(round(CAN / 2 - cx0 * k)), int(round(CAN / 2 - cy0 * k))), (0, 0)) if False else None
ox, oy = int(round(CAN / 2 - cx0 * k)), int(round(CAN / 2 - cy0 * k))
tmp = Image.new('RGBA', (CAN, CAN), (0, 0, 0, 0)); tmp.paste(big, (ox, oy), big)
tmp.save(f'{OUT}/ic_nexus_logo.png')
print('foreground: escala k =', round(k, 4), 'px do canvas por px original; canvas', CAN)

# ---------- 7) peças da animação (unidade = px originais, guardadas em 2x) ----------
def piece(name, box, scale=2):
    x0, y0, x1, y1 = box
    c = full.crop(box).resize(((x1 - x0) * scale, (y1 - y0) * scale), Image.LANCZOS)
    c.save(f'{OUT}/{name}.png')
piece('intro_ctrl_left', (378, 272, 483, 556))
piece('intro_ctrl_right', (898, 272, 1003, 556))
piece('intro_nexus_text', (572, 118, 812, 184))

# capas
boxes = [(493, 199, 606, 319), (614, 199, 766, 316), (774, 198, 889, 320),
         (493, 328, 606, 458), (614, 328, 766, 458), (775, 328, 888, 458),
         (493, 466, 606, 597), (615, 467, 766, 600), (775, 467, 888, 600)]
src = Image.open(SRC).convert('RGB')
for i, b in enumerate(boxes, 1):
    c = src.crop((b[0] + 1, b[1] + 1, b[2] - 1, b[3] - 1))
    w, h = c.size; s = 3
    c = c.resize((w * s, h * s), Image.LANCZOS).filter(ImageFilter.UnsharpMask(radius=2, percent=60, threshold=2))
    m = Image.new('L', c.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, c.size[0] - 1, c.size[1] - 1), radius=9 * s, fill=255)
    c = c.convert('RGBA'); c.putalpha(m)
    c.save(f'{OUT}/intro_cover_{i}.png')

json.dump({'k': k, 'cx0': cx0, 'cy0': cy0, 'R0': R0, 'boxes': boxes,
           'bg_left': bgcol[5].round().tolist(), 'bg_mid': bgcol[W // 2].round().tolist(), 'bg_right': bgcol[W - 5].round().tolist()},
          open('/tmp/icon_meta.json', 'w'))
# prévia
prev = Image.new('RGBA', (CAN, CAN), (150, 40, 140, 255)); prev.alpha_composite(Image.open(f'{OUT}/ic_nexus_logo.png'))
prev.save('/tmp/icon_preview.png')
Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8)).crop((370, 110, 1010, 630)).save('/tmp/recolored.png')
